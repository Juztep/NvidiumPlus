package nvidiumplus.engine.terrain;

import java.nio.ByteBuffer;

public final class SectionRecord {
   public static final int SECTION_SIZE = 32;
   public static final int SECTIONS_PER_REGION = 256;
   public static final int BYTES_PER_REGION = 8192;
   public static final int HIDE_BIT = 17;

   private SectionRecord() {
   }

   public static long sectionBufferBytes(int maxRegions) {
      return maxRegions * 8192L;
   }

   public static void write(
      ByteBuffer dst,
      int chunkX,
      int chunkY,
      int chunkZ,
      int geomMinX,
      int geomMinY,
      int geomMinZ,
      int geomSizeX,
      int geomSizeY,
      int geomSizeZ,
      boolean hidden,
      int compactedSectionId,
      int terrainAddress,
      short[] offsets
   ) {
      write(dst, chunkX, chunkY, chunkZ, geomMinX, geomMinY, geomMinZ, geomSizeX, geomSizeY, geomSizeZ, hidden, compactedSectionId, 0, terrainAddress, offsets);
   }

   public static void write(
      ByteBuffer dst,
      int chunkX,
      int chunkY,
      int chunkZ,
      int geomMinX,
      int geomMinY,
      int geomMinZ,
      int geomSizeX,
      int geomSizeY,
      int geomSizeZ,
      boolean hidden,
      int compactedSectionId,
      int scaleTag,
      int terrainAddress,
      short[] offsets
   ) {
      TerrainVertexCodec.checkOrder(dst);
      checkSigned("chunkX", chunkX, 24);
      checkSigned("chunkY", chunkY, 9);
      checkSigned("chunkZ", chunkZ, 24);
      checkNibble("geomMinX", geomMinX);
      checkNibble("geomMinY", geomMinY);
      checkNibble("geomMinZ", geomMinZ);
      checkNibble("geomSizeX", geomSizeX);
      checkNibble("geomSizeY", geomSizeY);
      checkNibble("geomSizeZ", geomSizeZ);
      if (compactedSectionId < 0 || compactedSectionId > 255) {
         throw new IllegalArgumentException("compactedSectionId must be 0..255, got " + compactedSectionId);
      }

      if (scaleTag >= 0 && scaleTag <= 63) {
         if (offsets.length != 8) {
            throw new IllegalArgumentException("offsets must have length 8, got " + offsets.length);
         }

         int px = chunkX << 8 | geomSizeX << 4 | geomMinX;
         int py = (chunkY & 511) << 8 | geomSizeY << 4 | geomMinY | (hidden ? 131072 : 0) | compactedSectionId << 18 | scaleTag << 26;
         int pz = chunkZ << 8 | geomSizeZ << 4 | geomMinZ;
         dst.putInt(px);
         dst.putInt(py);
         dst.putInt(pz);
         dst.putInt(terrainAddress);

         for (int i = 0; i < 4; i++) {
            dst.putInt(Short.toUnsignedInt(offsets[i * 2]) | Short.toUnsignedInt(offsets[i * 2 + 1]) << 16);
         }
      } else {
         throw new IllegalArgumentException("scaleTag must be 0..63, got " + scaleTag);
      }
   }

   public static void write(
      ByteBuffer dst, int chunkX, int chunkY, int chunkZ, EncodedSectionMesh mesh, boolean hidden, int compactedSectionId, int terrainAddress
   ) {
      write(
         dst,
         chunkX,
         chunkY,
         chunkZ,
         mesh.minX(),
         mesh.minY(),
         mesh.minZ(),
         mesh.sizeX(),
         mesh.sizeY(),
         mesh.sizeZ(),
         hidden,
         compactedSectionId,
         terrainAddress,
         mesh.offsets()
      );
   }

   public static void writeEmpty(ByteBuffer dst) {
      TerrainVertexCodec.checkOrder(dst);

      for (int i = 0; i < 8; i++) {
         dst.putInt(0);
      }
   }

   private static void checkSigned(String what, int value, int bits) {
      int min = -(1 << bits - 1);
      int max = (1 << bits - 1) - 1;
      if (value < min || value > max) {
         throw new IllegalArgumentException(what + " must fit signed " + bits + "-bit [" + min + ".." + max + "], got " + value);
      }
   }

   private static void checkNibble(String what, int value) {
      if (value < 0 || value > 15) {
         throw new IllegalArgumentException(what + " must be 0..15, got " + value);
      }
   }
}
