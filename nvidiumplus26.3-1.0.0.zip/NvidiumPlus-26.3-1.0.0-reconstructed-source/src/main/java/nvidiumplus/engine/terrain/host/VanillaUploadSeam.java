package nvidiumplus.engine.terrain.host;

import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusNotify;

public final class VanillaUploadSeam {
   private static final int HANDOVER_FRAMES = 20;
   private static final int QUIET_HANDOVER_FRAMES = 100;
   private static volatile boolean armed;
   private static volatile boolean suppressedThisWorld;
   private static volatile boolean vanillaHasGeometry = true;
   private static volatile boolean demotedThisWorld;
   private static volatile boolean pendingRebuild;
   private static volatile boolean rebuildIssued;
   private static volatile boolean sawRebuildRunning;
   private static volatile int completeFrames;
   private static volatile String demoteReason = "";
   private static volatile long suppressedSections;

   private VanillaUploadSeam() {
   }

   public static boolean armed() {
      return armed;
   }

   public static boolean suppressedThisWorld() {
      return suppressedThisWorld;
   }

   public static boolean vanillaHasGeometry() {
      return vanillaHasGeometry;
   }

   public static long suppressedSections() {
      return suppressedSections;
   }

   public static String demoteReason() {
      return demoteReason;
   }

   public static void armForNewWorld() {
      if (NvidiumPlusConfig.suppressVanillaUploads()) {
         if (NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
            armed = true;
            demotedThisWorld = false;
            demoteReason = "";
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus is suppressing vanilla's duplicate terrain uploads for this world. Vanilla keeps a full second copy of the terrain that nothing draws, measured at 1.3x to 2.6x NvidiumPlus's own arena. While this is on, NvidiumPlus owns the frame even if its own picture has holes, because vanilla's would be empty"
               );
         }
      }
   }

   public static void onSettingChanged() {
      if (NvidiumPlusConfig.suppressVanillaUploads()) {
         if (armed) {
            return;
         }

         if (NvidiumPlusGate.state() != NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
            return;
         }

         if (!NvidiumPlusConfig.terrainRenderingConfigured()) {
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus will free vanilla's duplicate terrain once NvidiumPlus terrain rendering is switched back on; with both off there would be nothing left to draw the world"
               );
            return;
         }

         armed = true;
         demotedThisWorld = false;
         demoteReason = "";
         pendingRebuild = true;
         rebuildIssued = false;
         sawRebuildRunning = false;
         completeFrames = 0;
         NvidiumPlusNotify.chat("nvidiumplus.chat.seam.freeing");
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus is freeing vanilla's duplicate terrain copy now. Vanilla's heaps only close once completely empty, so every section is being dropped and the seam stops them coming back; the memory returns over the next few seconds rather than instantly"
            );
      } else {
         if (!armed && !suppressedThisWorld) {
            return;
         }

         demote("setting turned off");
      }
   }

   public static void onTerrainRenderingEnabled() {
      onSettingChanged();
   }

   public static void noteSuppressed() {
      suppressedThisWorld = true;
      vanillaHasGeometry = false;
      suppressedSections++;
   }

   public static void demote(String reason) {
      armed = false;
      if (!suppressedThisWorld) {
         vanillaHasGeometry = true;
      } else if (!demotedThisWorld) {
         demotedThisWorld = true;
         demoteReason = reason;
         pendingRebuild = true;
         completeFrames = 0;
         NvidiumPlusNotify.chat("nvidiumplus.chat.seam.demoted");
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus stopped suppressing vanilla's terrain uploads ({}). Vanilla's copy is incomplete, so NvidiumPlus keeps drawing until a rebuild refills it; the render distance clamp that usually follows makes that rebuild a 32-chunk job rather than a 120-chunk one",
               reason
            );
      }
   }

   public static void requestVanillaRebuild(String why) {
      pendingRebuild = true;
      NvidiumPlusNotify.chat("nvidiumplus.chat.swap");
      NvidiumPlusLog.LOGGER.info("NvidiumPlus is reloading the terrain so the renderers can swap cleanly ({})", why);
   }

   public static boolean consumeRebuildRequest() {
      if (!pendingRebuild) {
         return false;
      }

      pendingRebuild = false;
      rebuildIssued = true;
      sawRebuildRunning = false;
      return true;
   }

   public static void reinstateRebuildRequest() {
      pendingRebuild = true;
   }

   public static void noteRebuildProgress(boolean vanillaLooksComplete) {
      if (suppressedThisWorld && !vanillaHasGeometry) {
         if (!armed) {
            if (rebuildIssued) {
               if (!vanillaLooksComplete) {
                  sawRebuildRunning = true;
                  completeFrames = 0;
               } else {
                  completeFrames++;
                  int floor = sawRebuildRunning ? 20 : 100;
                  if (completeFrames >= floor) {
                     vanillaHasGeometry = true;
                     rebuildIssued = false;
                     NvidiumPlusLog.LOGGER
                        .info(
                           "NvidiumPlus handed the terrain frame back to vanilla after {} calm frames ({})",
                           completeFrames,
                           sawRebuildRunning
                              ? "its rebuild was seen to run and then finish"
                              : "the rebuild was asked for and never caught running, which a world small enough to rebuild inside one tick will do"
                        );
                  }
               }
            }
         }
      }
   }

   public static void resetForWorld() {
      armed = false;
      suppressedThisWorld = false;
      vanillaHasGeometry = true;
      demotedThisWorld = false;
      pendingRebuild = false;
      rebuildIssued = false;
      sawRebuildRunning = false;
      completeFrames = 0;
      demoteReason = "";
      suppressedSections = 0L;
   }
}
