package nvidiumplus.engine.terrain.host;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map.Entry;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusNotify;
import nvidiumplus.engine.NvidiumPlusScaling;
import nvidiumplus.engine.NvidiumPlusVramState;
import nvidiumplus.engine.VanillaTerrainCensus;
import nvidiumplus.engine.farfield.FarFieldConfig;
import nvidiumplus.engine.farfield.FarFieldResidency;
import nvidiumplus.engine.terrain.EncodedSectionMesh;
import nvidiumplus.engine.terrain.GreedyMesher;
import nvidiumplus.engine.terrain.TerrainArena;
import nvidiumplus.engine.terrain.TranslucentPrefix;

public final class TerrainResidency {
   public static final int FREE_FRAME_LAG = 3;
   static final long UPLOAD_BYTES_PER_PUMP = 16777216L;
   private static final Object LOCK = new Object();
   static final byte LEDGER_UNBOUND = 0;
   static final byte LEDGER_NEAR_LIVE = 1;
   static final byte LEDGER_NEAR_HELD = 2;
   static final byte LEDGER_FAR = 3;
   static final byte LEDGER_AWAITING_SUCCESSOR = 4;
   static final byte LEDGER_CLEARED = 5;
   private static long ledgerParked;
   private static long ledgerDemoted;
   private static long ledgerResolvedSwap;
   private static long ledgerResolvedVanilla;
   private static long ledgerResolvedUncovered;
   private static long ledgerEvictedWall;
   private static long ledgerEvictedWallRingSum;
   private static long ledgerHoldMillis;
   private static long ledgerHoldMaxMillis;
   private static long ledgerAwaitingQuads;
   private static long ledgerAwaitingQuadsPeak;
   private static long ledgerIllegalTransitions;
   private static long ledgerAuditMismatches;
   private static int ledgerReportBudget = 8;
   private static final boolean LEDGER_AUDIT = Boolean.getBoolean("nvidiumplus.debug.ledgerAudit");
   private static final LinkedHashMap<Object, TerrainResidency.PendingUpload> pendingUploads = new LinkedHashMap<>();
   private static final HashMap<Long, Integer> pendingByPos = new HashMap<>();
   private static final IdentityHashMap<Object, TerrainResidency.Resident> resident = new IdentityHashMap<>();
   private static final LinkedHashMap<Long, TerrainResidency.Resident> retained = new LinkedHashMap<>();
   private static final LinkedHashMap<Long, TerrainResidency.Resident> farResident = new LinkedHashMap<>();
   private static final LongArrayList farFreedPending = new LongArrayList();
   private static final LongArrayList successorRequests = new LongArrayList();
   private static final LongArrayList[] awaitingByRing = new LongArrayList[194];
   private static final int AWAITING_BUDGET_SECTIONS = 6144;
   private static final long AWAITING_MEAN_QUADS_PER_SECTION = 953L;
   private static long awaitingBudgetQuads = 5855232L;
   private static int awaitingScanRing;
   private static final int FAR_ADMISSIONS_PER_PUMP = 64;
   private static final int FAR_REGION_GUARD_PCT = 85;
   private static final int FAR_ARENA_GUARD_PCT = 70;
   private static long unlistedSweepCamera = Long.MIN_VALUE;
   private static int unlistedSweepRadius = -1;
   private static int unlistedSweepCameraY = Integer.MIN_VALUE;
   private static int unlistedLiveDrawn;
   private static int unlistedAltitudeDrawn;
   private static int unlistedBandDrawn;
   private static int unlistedBandCoreDrawn;
   private static long unlistedMaskFlips;
   private static long unlistedTransFlips;
   private static final String PROPERTY_DRAW_UNLISTED_LIVE = "nvidiumplus.drawUnlistedLive";
   private static final String PROPERTY_DRAW_UNLISTED_ALTITUDE = "nvidiumplus.drawUnlistedLive.altitude";
   private static final int VANILLA_ADVANCED_CULL_SECTIONS = 3;
   private static final int ALTITUDE_ARM_HYSTERESIS = 2;
   private static final double MARCH_SKIP_MIN_CAMERA_ABOVE_BLOCKS = 64.0;
   private static final int SY_HISTOGRAM_MIN = -32;
   private static final int SY_HISTOGRAM_SIZE = 64;
   private static final int[] syHistogram = new int[64];
   private static int unlistedTerrainTopSy = Integer.MIN_VALUE;
   private static int unlistedTerrainLowSy = Integer.MIN_VALUE;
   private static boolean altitudeArmLatched;
   private static int[] columnTopSy = new int[0];
   private static int columnTopSide;
   private static int columnTopMargin;
   private static final int COLUMN_TOP_MAX_MARGIN = 130;
   private static int unlistedHorizonEntries;
   private static boolean unlistedSweepHighCamera;
   private static boolean unlistedSweepLocalHorizon;
   private static boolean unlistedSweepEnabled;
   private static long unlistedBindMarks;
   private static long unlistedBindBandMarks;
   private static volatile boolean altitudeCullRelaxed;
   private static long bfsAdvancedCullRelaxed;
   private static long altitudeArmSweeps;
   private static volatile long farCoverageCamera = Long.MIN_VALUE;
   private static volatile int farCoverageCoverEdge = -1;
   private static volatile int farCoverageL1 = -1;
   private static boolean farHookBroken;
   private static boolean farEverArmed;
   private static final ArrayDeque<TerrainResidency.FreeEpoch> freeEpochs = new ArrayDeque<>();
   private static final LinkedHashSet<TerrainResidency.Resident> pendingPrefixUploads = new LinkedHashSet<>();
   private static RegionStore regionStore = new RegionStore();
   private static TerrainArena arena;
   private static long sectionRecordsHandle;
   private static long frameCounter;
   private static long drawEpoch;
   private static final int SNAPSHOT_SLOTS_INITIAL = 32768;
   private static final int SNAPSHOT_LOG_INITIAL = 4096;
   private static final int SNAPSHOT_LOG_MAX = 65536;
   private static int snapshotSlotCap = 32768;
   private static int snapshotSlotHighWater;
   private static TerrainResidency.Resident[] snapshotSlotOwner = new TerrainResidency.Resident[32768];
   private static final IntArrayList snapshotFreeSlots = new IntArrayList();
   private static int[] snapshotLog = new int[4096];
   private static long snapshotLogEnd;
   private static TerrainResidency.SnapshotBuffer snapshotFront = new TerrainResidency.SnapshotBuffer();
   private static TerrainResidency.SnapshotBuffer snapshotBack = new TerrainResidency.SnapshotBuffer();
   private static long snapshotPublishes;
   private static long snapshotFullRebuilds;
   private static long snapshotLogRecords;
   private static long retainedQuads;
   private static long parkedQuads;
   private static long orphanedSections;
   private static long retainedSuperseded;
   private static long evictedByAge;
   private static long evictedByPressure;
   private static long evictedByDisable;
   private static long retainedBackpressure;
   private static long handoverRetained;
   private static long arenaTrims;
   private static long lastBusyMillis;
   private static long stagedBytesThisPump;
   private static long stagedBytesSinceQuiet;
   private static final int ARENA_HIGH_WATER_PCT = 85;
   private static final int REGION_HIGH_WATER_PCT = 90;
   private static final int EVICT_BUDGET_PER_PUMP = 256;
   private static final int FORCE_EVICT_BATCH = 64;
   private static final ThreadLocal<int[]> RESET_DEPTH = ThreadLocal.withInitial(() -> new int[1]);
   private static long quadsResident;
   private static long freedSections;
   private static long encodedSections;
   private static long uploadedSections;
   private static long discardedBeforeUpload;
   private static long droppedOversize;
   private static long droppedArenaFull;
   private static long droppedRegionBudget;
   private static long droppedEncoding;
   private static long staleParks;
   private static long decoderSkippedLayers;
   private static long arenaGrowths;
   private static long arenaGrowthFailures;
   private static long dropBaseline;
   private static long resortsApplied;
   private static long resortBytes;
   private static long resortsNoop;
   private static long resortsUnknownMesh;
   private static long resortsMalformed;
   private static volatile String lastError;
   private static volatile TerrainResidency.Counters disposeSnapshot;
   private static long lastStatsNanos;
   private static volatile int pendingGrowOption;
   private static volatile boolean pinnedGrowFailed;
   private static long pinnedGrows;
   private static long pinnedGrowFailures;
   private static volatile TerrainResidency.GuardTrip guardTrip;
   private static final Long2IntOpenHashMap unlistedRegionIndex = new Long2IntOpenHashMap();
   private static final int LEAF_TIER_REDIRTY_BUDGET = 64;
   private static long leafTierWalkCamera = Long.MIN_VALUE;
   private static int leafTierWalkSmartRing = -1;
   private static int leafTierWalkSolidRing = -1;
   private static boolean leafTierWalkPending;
   private static int tierBuiltFlagged;
   private static final int VERDICT_LISTED = 0;
   private static final int VERDICT_OUTSIDE_DISC = 1;
   private static final int VERDICT_ALTITUDE = 2;
   private static final int VERDICT_BAND = 3;
   private static final long RESIDENT_SY_BAND_EMPTY = Long.MIN_VALUE;

   public static void requestPinnedGrow(int optionRd) {
      if (!pinnedGrowFailed) {
         pendingGrowOption = optionRd;
      }
   }

   public static boolean pinnedGrowFailedThisWorld() {
      return pinnedGrowFailed;
   }

   public static long pinnedGrows() {
      synchronized (LOCK) {
         return pinnedGrows;
      }
   }

   public static long pinnedGrowFailures() {
      synchronized (LOCK) {
         return pinnedGrowFailures;
      }
   }

   private static void consumePendingGrowLocked(TerrainGpuHost gpu) {
      int optionRd = pendingGrowOption;
      if (optionRd > 0) {
         pendingGrowOption = 0;
         NvidiumPlusScaling.Snapshot current = NvidiumPlusScaling.current();
         NvidiumPlusScaling.Snapshot target = NvidiumPlusScaling.computeForOption(optionRd);
         if (target.maxRd() > current.maxRd() || target.maxRegions() > current.maxRegions() || target.dispatchCapacity() > current.dispatchCapacity()) {
            target = new NvidiumPlusScaling.Snapshot(
               Math.max(target.maxRd(), current.maxRd()),
               target.extended() || current.extended(),
               Math.max(target.maxRegions(), current.maxRegions()),
               Math.max(target.dispatchCapacity(), current.dispatchCapacity()),
               Math.max(target.arenaBytes(), current.arenaBytes())
            );
            if (target.maxRegions() > current.maxRegions()) {
               long newHandle = gpu.growRecords(target.maxRegions());
               if (newHandle == 0L) {
                  pinnedGrowFailed = true;
                  pinnedGrowFailures++;
                  NvidiumPlusLog.LOGGER
                     .warn(
                        "NvidiumPlus live render-distance raise: record growth {} -> {} regions failed; this world keeps the pinned budget (the rejoin hint takes over)",
                        current.maxRegions(),
                        target.maxRegions()
                     );
                  return;
               }

               sectionRecordsHandle = newHandle;
            } else {
               gpu.dropSnapshotSizedDrawResources();
            }

            NvidiumPlusScaling.growPinned(target);
            pinnedGrows++;
            forceSnapshotRebuildLocked();
            drawEpoch++;
         }
      }
   }

   private TerrainResidency() {
   }

   public static long handoverRetained() {
      synchronized (LOCK) {
         return handoverRetained;
      }
   }

   public static TerrainResidency.Counters counters() {
      synchronized (LOCK) {
         return countersLocked();
      }
   }

   public static boolean gpuCommitBacklogEmpty() {
      synchronized (LOCK) {
         return regionStore.dirtyRegionCount() == 0 && pendingUploads.isEmpty();
      }
   }

   public static String lastError() {
      return lastError;
   }

   public static TerrainResidency.Counters lastDisposeSnapshot() {
      return disposeSnapshot;
   }

   public static int maxRegions() {
      return RegionStore.maxRegions();
   }

   public static long dropsThisWorld() {
      synchronized (LOCK) {
         return droppedOversize + droppedArenaFull + droppedRegionBudget + droppedEncoding - dropBaseline;
      }
   }

   public static TerrainResidency.GuardTrip guardTrip() {
      return guardTrip;
   }

   public static String guardTripDescription() {
      TerrainResidency.GuardTrip trip = guardTrip;
      if (trip == null) {
         return "";
      }

      return switch (trip.kind()) {
         case "arena" -> "terrain memory: the "
            + trip.value()
            + " MiB arena reached its "
            + trip.limit()
            + " MiB ceiling (growth exhausted; raise nvidiumplus.tune.arenaCeilingMiB or lower the render distance)";
         case "oversize" -> "a single section's " + trip.value() + " MiB mesh exceeded the " + trip.limit() + " MiB staging ring";
         case "region" -> "region budget: " + trip.value() + " of " + trip.limit() + " region ids in use";
         case "vram" -> "the graphics card is out of room: growing terrain memory to "
            + trip.value()
            + " MiB needs more than the "
            + trip.limit()
            + " MiB actually free, so the allocation was refused rather than risk crashing the game";
         case "encoding" -> "a section failed to encode (see the residency error latch)";
         default -> "unknown cause '" + trip.kind() + "' (this is a NvidiumPlus bug; the drop counters in the same line say which one really fired)";
      };
   }

   private static void noteGuardTripLocked(String kind, long value, long limit) {
      if (guardTrip == null) {
         guardTrip = new TerrainResidency.GuardTrip(kind, value, limit);
      }
   }

   public static TerrainResidency.DrawSnapshot drawSnapshot(long knownEpoch) {
      synchronized (LOCK) {
         if (drawEpoch == knownEpoch) {
            return null;
         }

         TerrainResidency.SnapshotBuffer back = snapshotBack;
         if (!back.needsFullRebuild && back.data.length == snapshotSlotCap * 20) {
            for (long i = back.appliedLogIndex; i < snapshotLogEnd; i++) {
               applySnapshotRecordLocked(back.data, snapshotLog[(int)(i % snapshotLog.length)]);
            }

            back.appliedLogIndex = snapshotLogEnd;
         } else {
            rebuildSnapshotBufferLocked(back);
            snapshotFullRebuilds++;
         }

         long handle = arena == null ? 0L : arena.backingHandle();
         long[] blockHandles = arena == null ? new long[0] : arena.blockHandles();
         int[] regionData = regionStore.snapshotRegions();
         int[] retainedMasks = regionStore.snapshotRetainedMasks();
         int[] unlistedMasks = snapshotUnlistedMasksLocked(regionData);
         snapshotBack = snapshotFront;
         snapshotFront = back;
         snapshotPublishes++;
         return new TerrainResidency.DrawSnapshot(
            drawEpoch,
            resident.size() + retained.size() + farResident.size(),
            snapshotSlotHighWater - 1,
            back.data,
            handle,
            blockHandles,
            regionData.length / 7,
            regionData,
            sectionRecordsHandle,
            retainedMasks,
            unlistedMasks
         );
      }
   }

   private static int[] snapshotUnlistedMasksLocked(int[] regionData) {
      int regions = regionData.length / 7;
      int[] out = new int[regions * 8];
      if (regions != 0 && !resident.isEmpty()) {
         unlistedRegionIndex.clear();

         for (int r = 0; r < regions; r++) {
            int ro = r * 7;
            unlistedRegionIndex.put(RegionStore.regionKey(regionData[ro + 1] << 3, regionData[ro + 2] << 2, regionData[ro + 3] << 3), r);
         }

         for (TerrainResidency.Resident r : resident.values()) {
            if (r.ownsSlot && r.unlistedDrawn) {
               int idx = unlistedRegionIndex.get(r.regionKey);
               if (idx >= 0) {
                  out[idx * 8 + (r.posKey >>> 5)] = out[idx * 8 + (r.posKey >>> 5)] | 1 << (r.posKey & 31);
               }
            }
         }

         return out;
      } else {
         return out;
      }
   }

   private static void writeSnapshotEntryLocked(int[] data, int o, TerrainResidency.Resident r, int retainedFlag) {
      data[o] = r.sx;
      data[o + 1] = r.sy;
      data[o + 2] = r.sz;
      data[o + 3] = r.arenaAddr;

      for (int b = 0; b < 7; b++) {
         data[o + 4 + b] = r.bucketStarts[b];
         data[o + 11 + b] = r.bucketCounts[b];
      }

      data[o + 18] = r.ownsSlot ? regionStore.globalSectionIndex(r.regionKey, r.posKey, r) : -1;
      data[o + 19] = retainedFlag == 0 && !r.unlistedDrawn ? 0 : 1;
   }

   private static void applySnapshotRecordLocked(int[] data, int record) {
      int slot = record >= 0 ? record : ~record;
      TerrainResidency.Resident r = record >= 0 ? snapshotSlotOwner[slot] : null;
      if (r == null) {
         tombstoneSnapshotSlot(data, slot);
      } else {
         writeSnapshotEntryLocked(data, slot * 20, r, r.orphanedAtMillis != 0L ? 1 : 0);
      }
   }

   private static void tombstoneSnapshotSlot(int[] data, int slot) {
      int o = slot * 20;
      Arrays.fill(data, o, o + 20, 0);
      data[o + 18] = -2;
   }

   private static void rebuildSnapshotBufferLocked(TerrainResidency.SnapshotBuffer buf) {
      int capInts = snapshotSlotCap * 20;
      if (buf.data.length != capInts) {
         buf.data = new int[capInts];
      } else {
         Arrays.fill(buf.data, 0);
      }

      for (int slot = 0; slot < snapshotSlotHighWater; slot++) {
         buf.data[slot * 20 + 18] = -2;
      }

      for (TerrainResidency.Resident r : resident.values()) {
         writeSnapshotEntryLocked(buf.data, r.snapshotSlot * 20, r, 0);
      }

      for (TerrainResidency.Resident r : retained.values()) {
         writeSnapshotEntryLocked(buf.data, r.snapshotSlot * 20, r, 1);
      }

      for (TerrainResidency.Resident r : farResident.values()) {
         writeSnapshotEntryLocked(buf.data, r.snapshotSlot * 20, r, 1);
      }

      buf.appliedLogIndex = snapshotLogEnd;
      buf.needsFullRebuild = false;
   }

   private static void forceSnapshotRebuildLocked() {
      snapshotFront.needsFullRebuild = true;
      snapshotBack.needsFullRebuild = true;
   }

   private static void logSlotWriteLocked(int slot) {
      appendSnapshotLogLocked(slot);
   }

   private static void logSlotTombstoneLocked(int slot) {
      appendSnapshotLogLocked(~slot);
   }

   private static void logMovedOwnerLocked(Object movedOwner) {
      if (movedOwner instanceof TerrainResidency.Resident moved) {
         logSlotWriteLocked(moved.snapshotSlot);
      }
   }

   private static void appendSnapshotLogLocked(int record) {
      if (!snapshotFront.needsFullRebuild || !snapshotBack.needsFullRebuild) {
         long oldest = snapshotLogEnd;
         if (!snapshotFront.needsFullRebuild) {
            oldest = Math.min(oldest, snapshotFront.appliedLogIndex);
         }

         if (!snapshotBack.needsFullRebuild) {
            oldest = Math.min(oldest, snapshotBack.appliedLogIndex);
         }

         if (snapshotLogEnd - oldest >= snapshotLog.length) {
            if (snapshotLog.length >= 65536) {
               forceSnapshotRebuildLocked();
               return;
            }

            int[] grown = new int[snapshotLog.length << 1];

            for (long i = oldest; i < snapshotLogEnd; i++) {
               grown[(int)(i % grown.length)] = snapshotLog[(int)(i % snapshotLog.length)];
            }

            snapshotLog = grown;
         }

         snapshotLog[(int)(snapshotLogEnd % snapshotLog.length)] = record;
         snapshotLogEnd++;
         snapshotLogRecords++;
      }
   }

   private static int allocSnapshotSlotLocked() {
      if (!snapshotFreeSlots.isEmpty()) {
         return snapshotFreeSlots.popInt();
      }

      if (snapshotSlotHighWater == snapshotSlotCap) {
         snapshotSlotCap <<= 1;
         snapshotSlotOwner = Arrays.copyOf(snapshotSlotOwner, snapshotSlotCap);
         forceSnapshotRebuildLocked();
      }

      return snapshotSlotHighWater++;
   }

   private static void freeSnapshotSlotLocked(TerrainResidency.Resident r) {
      snapshotSlotOwner[r.snapshotSlot] = null;
      snapshotFreeSlots.push(r.snapshotSlot);
      logSlotTombstoneLocked(r.snapshotSlot);
   }

   private static void putRetainedLocked(long packedPos, TerrainResidency.Resident r) {
      TerrainResidency.Resident displaced = retained.put(packedPos, r);
      if (displaced != null) {
         NvidiumPlusLog.LOGGER
            .error(
               "NvidiumPlus retained.put displaced an entry at packed pos {} — a NvidiumPlus bug (the retained map's re-entry invariant broke); the draw snapshot heals through a full rebuild, the displaced arena range leaks until dispose",
               packedPos
            );
         forceSnapshotRebuildLocked();
      }
   }

   public static long snapshotPublishes() {
      synchronized (LOCK) {
         return snapshotPublishes;
      }
   }

   public static long snapshotFullRebuilds() {
      synchronized (LOCK) {
         return snapshotFullRebuilds;
      }
   }

   public static long snapshotLogRecords() {
      synchronized (LOCK) {
         return snapshotLogRecords;
      }
   }

   static void enqueueUpload(Object mesh, int sx, int sy, int sz, EncodedSectionMesh encoded, int[] translucentOrder, byte builtTier) {
      TerrainResidency.TranslucentState translucent = null;
      int translucentCount = encoded.translucentCount();
      if (translucentCount > 0) {
         byte[] prefix = new byte[translucentCount * 64];
         ByteBuffer geometry = encoded.geometry();
         geometry.get(0, prefix, 0, prefix.length);
         int[] order = translucentOrder;
         if (order == null || order.length != translucentCount) {
            order = new int[translucentCount];
            int i = 0;

            while (i < translucentCount) {
               order[i] = i++;
            }
         }

         translucent = new TerrainResidency.TranslucentState(prefix, order);
      }

      synchronized (LOCK) {
         encodedSections++;
         TerrainResidency.PendingUpload previous = pendingUploads.put(mesh, new TerrainResidency.PendingUpload(sx, sy, sz, encoded, translucent, builtTier));
         if (previous != null) {
            staleParks++;
            pendingPosDrop(previous.sx(), previous.sy(), previous.sz());
         }

         pendingPosAdd(sx, sy, sz);
      }
   }

   private static void pendingPosAdd(int sx, int sy, int sz) {
      long pos = posPack(sx, sy, sz);
      pendingByPos.merge(pos, 1, Integer::sum);
      if (!retained.isEmpty()) {
         TerrainResidency.Resident held = retained.get(pos);
         if (held != null && held.ledgerState == 2) {
            ledgerTransitionLocked(held, (byte)4);
         }
      }
   }

   private static void pendingPosDrop(int sx, int sy, int sz) {
      long pos = posPack(sx, sy, sz);
      pendingByPos.compute(pos, (k, n) -> n != null && n > 1 ? n - 1 : null);
      if (!pendingByPos.containsKey(pos) && !retained.isEmpty()) {
         TerrainResidency.Resident held = retained.get(pos);
         if (held != null && held.ledgerState == 4 && coveredNow(held.sx, held.sz, false)) {
            successorRequests.add(pos);
         }
      }
   }

   private static boolean successorQueued(int sx, int sy, int sz) {
      return pendingByPos.containsKey(posPack(sx, sy, sz));
   }

   public static void onTranslucentResort(Object mesh, ByteBuffer indexBytes) {
      if (mesh != null) {
         synchronized (LOCK) {
            TerrainResidency.TranslucentState state = null;
            TerrainResidency.Resident r = resident.get(mesh);
            if (r != null) {
               state = r.translucent;
            } else {
               TerrainResidency.PendingUpload pending = pendingUploads.get(mesh);
               if (pending != null) {
                  state = pending.translucent();
               }
            }

            if (state == null) {
               resortsUnknownMesh++;
            } else {
               int n = state.order.length;
               int[] newOrder = VanillaMeshDecoder.resortQuadOrder(indexBytes, n);
               if (newOrder == null) {
                  resortsMalformed++;
               } else if (Arrays.equals(newOrder, state.order)) {
                  resortsNoop++;
               } else {
                  try {
                     TranslucentPrefix.permute(state.prefix, state.order, newOrder, new byte[state.prefix.length]);
                  } catch (IllegalArgumentException e) {
                     resortsMalformed++;
                     return;
                  }

                  state.order = newOrder;
                  resortsApplied++;
                  if (r != null) {
                     pendingPrefixUploads.add(r);
                  } else {
                     state.dirtySinceEncode = true;
                  }
               }
            }
         }
      }
   }

   static void countStalePark() {
      synchronized (LOCK) {
         staleParks++;
      }
   }

   static void countDecoderSkips(int layers) {
      synchronized (LOCK) {
         decoderSkippedLayers += layers;
      }
   }

   static void countEncodeFailure(Throwable cause) {
      synchronized (LOCK) {
         noteGuardTripLocked("encoding", 0L, 0L);
         droppedEncoding++;
      }

      recordError("encode: " + cause);
   }

   public static void beginSlotReset() {
      RESET_DEPTH.get()[0]++;
   }

   public static void endSlotReset() {
      int[] depth = RESET_DEPTH.get();
      if (depth[0] > 0) {
         depth[0]--;
      }
   }

   private static boolean inSlotReset() {
      return RESET_DEPTH.get()[0] > 0;
   }

   private static long monotonicMillis() {
      return System.nanoTime() / 1000000L;
   }

   static long posPack(int sx, int sy, int sz) {
      return (sx & 2097151L) << 42 | (sy & 2097151L) << 21 | sz & 2097151L;
   }

   private static void ledgerTransitionLocked(TerrainResidency.Resident r, byte to) {
      byte from = r.ledgerState;
      r.ledgerState = to;
      if (!ledgerLegalTransition(from, to)) {
         ledgerIllegalTransitions++;
         if (ledgerReportBudget > 0) {
            ledgerReportBudget--;
            NvidiumPlusLog.LOGGER
               .error(
                  "NvidiumPlus ownership ledger saw a transition outside the legal table: {} -> {} at section {},{},{} ({} more of these will be logged this session). The producing sites of every dead edge were deleted at seam step 4, so this is a resurrected mechanism or a real ownership bug.",
                  new Object[]{ledgerStateName(from), ledgerStateName(to), r.sx, r.sy, r.sz, ledgerReportBudget}
               );
         }
      }

      if (to == 4 && from != 4) {
         ledgerParked++;
         ledgerAwaitingQuads = ledgerAwaitingQuads + r.quadCount;
         if (ledgerAwaitingQuads > ledgerAwaitingQuadsPeak) {
            ledgerAwaitingQuadsPeak = ledgerAwaitingQuads;
         }

         int ring = (int)Math.min(awaitingByRing.length - 1L, ledgerCameraRingLocked(r));
         LongArrayList bucket = awaitingByRing[ring];
         if (bucket == null) {
            bucket = new LongArrayList();
            awaitingByRing[ring] = bucket;
         }

         bucket.add(posPack(r.sx, r.sy, r.sz));
      } else if (from == 4 && to != 4) {
         ledgerAwaitingQuads = ledgerAwaitingQuads - r.quadCount;
         long held = r.orphanedAtMillis == 0L ? 0L : monotonicMillis() - r.orphanedAtMillis;
         if (held < 0L) {
            held = 0L;
         }

         ledgerHoldMillis += held;
         if (held > ledgerHoldMaxMillis) {
            ledgerHoldMaxMillis = held;
         }

         if (to == 2) {
            ledgerDemoted++;
         }
      }
   }

   private static boolean ledgerLegalTransition(byte from, byte to) {
      return switch (from) {
         case 0 -> to == 1 || to == 3;
         case 1 -> to == 2 || to == 4 || to == 5;
         case 2 -> to == 4 || to == 5;
         case 3 -> to == 5;
         case 4 -> to == 5;
         default -> false;
      };
   }

   private static String ledgerStateName(byte state) {
      return switch (state) {
         case 0 -> "UNBOUND";
         case 1 -> "NEAR_LIVE";
         case 2 -> "NEAR_HELD";
         case 3 -> "FAR";
         case 4 -> "AWAITING_SUCCESSOR";
         case 5 -> "CLEARED";
         default -> "?" + state;
      };
   }

   private static long ledgerCameraRingLocked(TerrainResidency.Resident r) {
      long camera = SectionBuildTap.cameraSectionXZ();
      if (camera == Long.MIN_VALUE) {
         camera = farCoverageCamera;
      }

      if (camera == Long.MIN_VALUE) {
         return 0L;
      }

      long dx = Math.abs((long)r.sx - (int)(camera >> 32));
      long dz = Math.abs((long)r.sz - (int)camera);
      return Math.max(dx, dz);
   }

   private static void auditLedgerLocked() {
      for (TerrainResidency.Resident r : resident.values()) {
         if (r.ledgerState != 1) {
            reportLedgerMismatchLocked("live map", r);
         }
      }

      long awaitingQuadsSeen = 0L;

      for (Entry<Long, TerrainResidency.Resident> entry : retained.entrySet()) {
         TerrainResidency.Resident r = entry.getValue();
         long pos = entry.getKey();
         if (r.ledgerState != 4 && r.ledgerState != 2) {
            reportLedgerMismatchLocked("retained", r);
         } else if (pendingByPos.containsKey(pos) && r.ledgerState != 4) {
            reportLedgerMismatchLocked("retained (successor queued)", r);
         }

         if (r.ledgerState == 4) {
            awaitingQuadsSeen += r.quadCount;
         }
      }

      if (awaitingQuadsSeen != ledgerAwaitingQuads) {
         ledgerAuditMismatches++;
         if (ledgerReportBudget > 0) {
            ledgerReportBudget--;
            NvidiumPlusLog.LOGGER
               .error(
                  "NvidiumPlus ledger audit: AWAITING quad gauge {} but the retained map holds {} awaiting quads ({} more of these will be logged this session)",
                  new Object[]{ledgerAwaitingQuads, awaitingQuadsSeen, ledgerReportBudget}
               );
         }
      }

      for (TerrainResidency.Resident r : farResident.values()) {
         if (r.ledgerState != 3) {
            reportLedgerMismatchLocked("far map", r);
         }
      }
   }

   private static void reportLedgerMismatchLocked(String container, TerrainResidency.Resident r) {
      ledgerAuditMismatches++;
      if (ledgerReportBudget > 0) {
         ledgerReportBudget--;
         NvidiumPlusLog.LOGGER
            .error(
               "NvidiumPlus ledger audit: section {},{},{} sits in {} but carries state {} ({} more of these will be logged this session)",
               new Object[]{r.sx, r.sy, r.sz, container, ledgerStateName(r.ledgerState), ledgerReportBudget}
            );
      }
   }

   public static void onMeshReleased(Object mesh) {
      if (mesh != null) {
         synchronized (LOCK) {
            TerrainResidency.PendingUpload pending = pendingUploads.remove(mesh);
            if (pending != null) {
               discardedBeforeUpload++;
               pendingPosDrop(pending.sx(), pending.sy(), pending.sz());
            } else {
               TerrainResidency.Resident r = resident.remove(mesh);
               if (r != null) {
                  if (r.ownsSlot && arena != null && successorQueued(r.sx, r.sy, r.sz) && regionStore.markRetained(r.regionKey, r.posKey, r)) {
                     r.orphanedAtMillis = monotonicMillis();
                     putRetainedLocked(posPack(r.sx, r.sy, r.sz), r);
                     ledgerTransitionLocked(r, (byte)4);
                     quadsResident = quadsResident - r.quadCount;
                     retainedQuads = retainedQuads + r.quadCount;
                     handoverRetained++;
                     logSlotWriteLocked(r.snapshotSlot);
                     drawEpoch++;
                  } else if (r.ownsSlot
                     && inSlotReset()
                     && NvidiumPlusConfig.retainTerrainEnabled()
                     && arena != null
                     && regionStore.markRetained(r.regionKey, r.posKey, r)) {
                     r.orphanedAtMillis = monotonicMillis();
                     putRetainedLocked(posPack(r.sx, r.sy, r.sz), r);
                     ledgerTransitionLocked(r, (byte)2);
                     quadsResident = quadsResident - r.quadCount;
                     retainedQuads = retainedQuads + r.quadCount;
                     orphanedSections++;
                     logSlotWriteLocked(r.snapshotSlot);
                     drawEpoch++;
                  } else {
                     long pos = posPack(r.sx, r.sy, r.sz);
                     if (r.ownsSlot && arena != null && coveredNow(r.sx, r.sz, inSlotReset()) && regionStore.markRetained(r.regionKey, r.posKey, r)) {
                        r.orphanedAtMillis = monotonicMillis();
                        putRetainedLocked(pos, r);
                        ledgerTransitionLocked(r, (byte)4);
                        quadsResident = quadsResident - r.quadCount;
                        retainedQuads = retainedQuads + r.quadCount;
                        logSlotWriteLocked(r.snapshotSlot);
                        drawEpoch++;
                        successorRequests.add(pos);
                        if (ledgerAwaitingQuads > awaitingBudgetQuads) {
                           evictAwaitingFarthestLocked();
                        }
                     } else {
                        pendingPrefixUploads.remove(r);
                        ledgerTransitionLocked(r, (byte)5);
                        drawEpoch++;
                        quadsResident = quadsResident - r.quadCount;
                        freedSections++;
                        if (r.ownsSlot) {
                           logMovedOwnerLocked(regionStore.remove(r.regionKey, r.posKey, r));
                        }

                        parkAddrLocked(r.arenaAddr, r.quadCount);
                        freeSnapshotSlotLocked(r);
                     }
                  }
               }
            }
         }
      }
   }

   public static void onSectionCompiledEmpty(int sx, int sy, int sz) {
      synchronized (LOCK) {
         long pos = posPack(sx, sy, sz);
         if (!farResident.isEmpty()) {
            TerrainResidency.Resident far = farResident.remove(pos);
            if (far != null) {
               freeFarLocked(far);
               farFreedPending.add(pos);
               drawEpoch++;
            }
         }

         TerrainResidency.Resident r = retained.remove(pos);
         if (r != null) {
            if (r.ledgerState == 4) {
               ledgerResolvedVanilla++;
            }

            ledgerTransitionLocked(r, (byte)5);
            freeRetainedLocked(r);
            retainedSuperseded++;
            drawEpoch++;
         }
      }
   }

   private static void evictAwaitingFarthestLocked() {
      for (int ring = awaitingByRing.length - 1; ring >= 0 && ledgerAwaitingQuads > awaitingBudgetQuads; ring--) {
         LongArrayList bucket = awaitingByRing[ring];
         if (bucket != null && !bucket.isEmpty()) {
            for (int i = bucket.size() - 1; i >= 0 && ledgerAwaitingQuads > awaitingBudgetQuads; i--) {
               long pos = bucket.getLong(i);
               TerrainResidency.Resident r = retained.get(pos);
               if (r == null || r.ledgerState != 4) {
                  bucket.removeLong(i);
               } else if (!successorQueued(r.sx, r.sy, r.sz)) {
                  bucket.removeLong(i);
                  retained.remove(pos);
                  freeRetainedLocked(r);
                  drawEpoch++;
               }
            }
         }
      }
   }

   private static void scanAwaitingCoverageLocked() {
      if (ledgerAwaitingQuads > 0L) {
         int budget = 256;

         for (int step = 0; step < awaitingByRing.length && budget > 0; step++) {
            awaitingScanRing = (awaitingScanRing + 1) % awaitingByRing.length;
            LongArrayList bucket = awaitingByRing[awaitingScanRing];
            if (bucket != null && !bucket.isEmpty()) {
               for (int i = bucket.size() - 1; i >= 0 && budget > 0; i--) {
                  long pos = bucket.getLong(i);
                  TerrainResidency.Resident r = retained.get(pos);
                  if (r != null && r.ledgerState == 4) {
                     budget--;
                     if (!successorQueued(r.sx, r.sy, r.sz) && !withinCoverageOuterEdge(r.sx, r.sz)) {
                        bucket.removeLong(i);
                        retained.remove(pos);
                        ledgerResolvedUncovered++;
                        ledgerTransitionLocked(r, (byte)5);
                        freeRetainedLocked(r);
                        drawEpoch++;
                     }
                  } else {
                     bucket.removeLong(i);
                  }
               }
            }
         }
      }
   }

   private static void freeRetainedLocked(TerrainResidency.Resident r) {
      if (r.ledgerState == 4) {
         ledgerEvictedWall++;
         ledgerEvictedWallRingSum = ledgerEvictedWallRingSum + ledgerCameraRingLocked(r);
         ledgerTransitionLocked(r, (byte)5);
      } else if (r.ledgerState != 5) {
         ledgerTransitionLocked(r, (byte)5);
      }

      pendingPrefixUploads.remove(r);
      retainedQuads = retainedQuads - r.quadCount;
      freedSections++;
      logMovedOwnerLocked(regionStore.remove(r.regionKey, r.posKey, r));
      parkAddrLocked(r.arenaAddr, r.quadCount);
      freeSnapshotSlotLocked(r);
   }

   private static void parkAddrLocked(int addr, int quadCount) {
      TerrainResidency.FreeEpoch epoch = freeEpochs.peekLast();
      if (epoch == null || epoch.frame != frameCounter) {
         epoch = new TerrainResidency.FreeEpoch(frameCounter);
         freeEpochs.addLast(epoch);
      }

      epoch.addrs.add(addr);
      epoch.quads += quadCount;
      parkedQuads += quadCount;
   }

   public static TerrainResidency.Counters disposeAndReset() {
      return disposeAndReset(true);
   }

   public static TerrainResidency.Counters disposeAndResetKeepingSeam() {
      return disposeAndReset(false);
   }

   private static TerrainResidency.Counters disposeAndReset(boolean resetSeam) {
      if (resetSeam) {
         VanillaUploadSeam.resetForWorld();
      }

      synchronized (LOCK) {
         TerrainResidency.Counters snapshot = countersLocked();
         disposeSnapshot = snapshot;
         drawEpoch++;
         freedSections = freedSections + retained.size();
         retainedQuads = 0L;
         ledgerAwaitingQuads = 0L;
         retained.clear();
         successorRequests.clear();

         for (int ring = 0; ring < awaitingByRing.length; ring++) {
            LongArrayList bucket = awaitingByRing[ring];
            if (bucket != null) {
               bucket.clear();
            }
         }

         awaitingScanRing = 0;
         farCoverageCamera = Long.MIN_VALUE;
         farCoverageCoverEdge = -1;
         farCoverageL1 = -1;
         if (farEverArmed) {
            int farDropped = farResident.size() + farFreedPending.size();
            farResident.clear();
            farFreedPending.clear();
            FarFieldResidency.onResidencyDisposed(farDropped);
         }

         parkedQuads = 0L;
         pendingUploads.clear();
         pendingByPos.clear();
         resident.clear();
         freeEpochs.clear();
         pendingPrefixUploads.clear();
         tierBuiltFlagged = 0;
         leafTierWalkCamera = Long.MIN_VALUE;
         leafTierWalkSmartRing = -1;
         leafTierWalkSolidRing = -1;
         leafTierWalkPending = false;
         unlistedSweepCamera = Long.MIN_VALUE;
         unlistedSweepRadius = -1;
         unlistedSweepCameraY = Integer.MIN_VALUE;
         unlistedLiveDrawn = 0;
         unlistedAltitudeDrawn = 0;
         unlistedBandDrawn = 0;
         unlistedBandCoreDrawn = 0;
         unlistedTerrainTopSy = Integer.MIN_VALUE;
         unlistedTerrainLowSy = Integer.MIN_VALUE;
         altitudeArmLatched = false;
         altitudeCullRelaxed = false;
         columnTopSide = 0;
         unlistedHorizonEntries = 0;
         unlistedSweepHighCamera = false;
         unlistedSweepLocalHorizon = false;
         unlistedSweepEnabled = false;
         unlistedBindMarks = 0L;
         unlistedBindBandMarks = 0L;
         regionStore = new RegionStore();
         arena = null;
         sectionRecordsHandle = 0L;
         snapshotSlotCap = 32768;
         snapshotSlotHighWater = 0;
         snapshotSlotOwner = new TerrainResidency.Resident[32768];
         snapshotFreeSlots.clear();
         snapshotLog = new int[4096];
         forceSnapshotRebuildLocked();
         quadsResident = 0L;
         dropBaseline = droppedOversize + droppedArenaFull + droppedRegionBudget + droppedEncoding;
         guardTrip = null;
         pendingGrowOption = 0;
         pinnedGrowFailed = false;
         return snapshot;
      }
   }

   public static void attachArena(TerrainArena attached, long recordsHandle) {
      synchronized (LOCK) {
         arena = attached;
         sectionRecordsHandle = recordsHandle;
         lastBusyMillis = monotonicMillis();
      }
   }

   public static void pump(TerrainGpuHost gpu) {
      Minecraft minecraft = Minecraft.getInstance();
      int vanillaViewRadius = minecraft != null && minecraft.options != null ? minecraft.options.getEffectiveRenderDistance() : 0;
      Camera mainCamera = minecraft != null && minecraft.gameRenderer != null ? minecraft.gameRenderer.mainCamera() : null;
      int cameraSectionY = mainCamera != null && mainCamera.isInitialized() && mainCamera.blockPosition() != null
         ? mainCamera.blockPosition().getY() >> 4
         : Integer.MIN_VALUE;
      IntArrayList leafTierRestores;
      synchronized (LOCK) {
         long frame = ++frameCounter;
         RESET_DEPTH.get()[0] = 0;
         stagedBytesThisPump = 0L;
         awaitingBudgetQuads = Math.min(NvidiumPlusScaling.arenaCeilingBytes() / 64L / 8L, 5855232L);
         if (!gpu.beginFrame(frame)) {
            return;
         }

         if (arena != null) {
            consumePendingGrowLocked(gpu);
            releaseExpiredFreesLocked(frame);
            evictRetainedLocked();
            scanAwaitingCoverageLocked();
            if (ledgerAwaitingQuads > awaitingBudgetQuads) {
               evictAwaitingFarthestLocked();
            }

            syncUnlistedLiveMaskLocked(vanillaViewRadius, cameraSectionY);
            drainPendingUploadsLocked(gpu);
            drainFarFieldLocked(gpu);
            drainPendingPrefixUploadsLocked(gpu);
            maybeTrimArenaLocked(gpu);
            if (LEDGER_AUDIT) {
               auditLedgerLocked();
            }
         }

         regionStore.commitDirty(gpu);
         gpu.endFrame();
         maybeLogStatsLocked(gpu);
         leafTierRestores = collectLeafTierRestoresLocked();
      }

      redirtyLeafTierSections(leafTierRestores);
      pumpFarFieldOutsideLock();
   }

   private static void pumpFarFieldOutsideLock() {
      if (!farHookBroken) {
         if (!farEverArmed) {
            if (!FarFieldConfig.enabled()) {
               return;
            }

            farEverArmed = true;
         }

         try {
            FarFieldResidency.pump();
         } catch (Throwable t) {
            farHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error("NvidiumPlus far-field pump hook failed; the far field is off for this session (near-field rendering is unaffected)", t);
         }
      }
   }

   private static IntArrayList collectLeafTierRestoresLocked() {
      long camera = SectionBuildTap.cameraSectionXZ();
      if (camera == Long.MIN_VALUE) {
         return null;
      }

      int smartRing = NvidiumPlusConfig.smartLeavesChunks();
      int solidRing = NvidiumPlusConfig.solidLeavesChunks();
      if (camera != leafTierWalkCamera || smartRing != leafTierWalkSmartRing || solidRing != leafTierWalkSolidRing) {
         leafTierWalkCamera = camera;
         leafTierWalkSmartRing = smartRing;
         leafTierWalkSolidRing = solidRing;
         leafTierWalkPending = true;
      }

      if (leafTierWalkPending && tierBuiltFlagged != 0) {
         IntArrayList out = null;
         int budget = 64;
         int smartKeepsFrom = Math.max(1, smartRing - 1);
         int solidKeepsFrom = Math.max(1, solidRing - 1);

         for (TerrainResidency.Resident r : resident.values()) {
            if (r.builtTier != 0) {
               int dist = SectionBuildTap.chunkDistanceXZ(camera, r.sx, r.sz);
               int earned = solidRing > 0 && dist >= solidKeepsFrom ? 2 : (smartRing > 0 && dist >= smartKeepsFrom ? 1 : 0);
               if (r.builtTier > earned) {
                  r.builtTier = 0;
                  tierBuiltFlagged--;
                  if (out == null) {
                     out = new IntArrayList(192);
                  }

                  out.add(r.sx);
                  out.add(r.sy);
                  out.add(r.sz);
                  if (--budget == 0) {
                     return out;
                  }
               }
            }
         }

         leafTierWalkPending = false;
         return out;
      } else {
         return null;
      }
   }

   private static void redirtyLeafTierSections(IntArrayList triples) {
      if (triples != null && !triples.isEmpty()) {
         ClientLevel level = Minecraft.getInstance().level;
         if (level != null) {
            for (int i = 0; i < triples.size(); i += 3) {
               level.setSectionDirtyWithNeighbors(triples.getInt(i), triples.getInt(i + 1), triples.getInt(i + 2));
            }
         }
      }
   }

   private static boolean vanillaMayList(int dx, int dz, int radiusChunks) {
      if (radiusChunks <= 0) {
         return false;
      }

      long px = Math.max(0, Math.abs(dx) - 1);
      long pz = Math.max(0, Math.abs(dz) - 1);
      return px * px + pz * pz < (long)radiusChunks * radiusChunks;
   }

   public static int vanillaCompileDiscColumns(int radiusChunks) {
      if (radiusChunks <= 0) {
         return 0;
      }

      int columns = 0;

      for (int dx = -radiusChunks - 1; dx <= radiusChunks + 1; dx++) {
         for (int dz = -radiusChunks - 1; dz <= radiusChunks + 1; dz++) {
            if (vanillaMayList(dx, dz, radiusChunks)) {
               columns++;
            }
         }
      }

      return columns;
   }

   private static void syncUnlistedLiveMaskLocked(int viewRadius, int cameraSectionY) {
      long camera = SectionBuildTap.cameraSectionXZ();
      if (camera != Long.MIN_VALUE && viewRadius > 0 && !resident.isEmpty()) {
         if (camera != unlistedSweepCamera || viewRadius != unlistedSweepRadius || cameraSectionY != unlistedSweepCameraY) {
            unlistedSweepCamera = camera;
            unlistedSweepRadius = viewRadius;
            unlistedSweepCameraY = cameraSectionY;
            if (!Boolean.parseBoolean(System.getProperty("nvidiumplus.drawUnlistedLive", "true"))) {
               unlistedLiveDrawn = 0;
               unlistedAltitudeDrawn = 0;
               unlistedBandDrawn = 0;
               unlistedBandCoreDrawn = 0;
               unlistedHorizonEntries = 0;
               altitudeArmLatched = false;
               altitudeCullRelaxed = false;
               columnTopSide = 0;
               unlistedSweepLocalHorizon = false;
               unlistedSweepHighCamera = false;
               unlistedSweepEnabled = false;
            } else {
               int camX = (int)(camera >> 32);
               int camZ = (int)camera;
               boolean altitudeArmEnabled = cameraSectionY != Integer.MIN_VALUE
                  && Boolean.parseBoolean(System.getProperty("nvidiumplus.drawUnlistedLive.altitude", "true"));
               long band = altitudeArmEnabled ? residentTerrainScanLocked(camX, camZ, viewRadius) : Long.MIN_VALUE;
               int terrainTopSy = Integer.MIN_VALUE;
               int terrainLowSy = Integer.MIN_VALUE;
               if (band != Long.MIN_VALUE) {
                  terrainTopSy = (int)(band >> 32);
                  terrainLowSy = (int)band;
               }

               boolean highCamera = altitudeArmLatched;
               int reach = vanillaAdjacencyReach(viewRadius);
               if (terrainLowSy == Integer.MIN_VALUE) {
                  highCamera = false;
               } else {
                  int above = cameraSectionY - terrainLowSy;
                  if (above > reach) {
                     highCamera = true;
                  } else if (above <= reach - 2) {
                     highCamera = false;
                  }
               }

               altitudeArmLatched = highCamera;
               boolean localHorizon = altitudeArmEnabled && columnTopSide > 0;
               unlistedTerrainTopSy = terrainTopSy;
               unlistedTerrainLowSy = terrainLowSy;
               altitudeCullRelaxed = highCamera;
               if (highCamera) {
                  altitudeArmSweeps++;
               }

               unlistedSweepHighCamera = highCamera;
               unlistedSweepLocalHorizon = localHorizon;
               unlistedSweepEnabled = true;
               int drawn = 0;
               int altitude = 0;
               int bandOnly = 0;
               int bandCore = 0;
               int horizonEntries = 0;
               boolean changed = false;

               for (TerrainResidency.Resident r : resident.values()) {
                  if (r.ownsSlot) {
                     if (localHorizon && cameraSectionY > columnTopSyLocked(r.sx - camX, r.sz - camZ)) {
                        horizonEntries++;
                     }

                     int verdict = unlistedVerdictLocked(r, camX, camZ, cameraSectionY, viewRadius, highCamera, localHorizon);
                     boolean unlisted = verdict != 0;
                     if (unlisted) {
                        drawn++;
                     }

                     if (verdict == 2 || verdict == 3) {
                        altitude++;
                     }

                     if (verdict == 3) {
                        bandOnly++;
                        if (Math.abs(r.sx - camX) <= 3 && Math.abs(r.sz - camZ) <= 3) {
                           bandCore++;
                        }
                     }

                     if (regionStore.setRetained(r.regionKey, r.posKey, r, unlisted)) {
                        changed = true;
                        unlistedMaskFlips++;
                     }

                     if (r.unlistedDrawn != unlisted) {
                        r.unlistedDrawn = unlisted;
                        logSlotWriteLocked(r.snapshotSlot);
                        changed = true;
                        unlistedTransFlips++;
                     }
                  }
               }

               unlistedLiveDrawn = drawn;
               unlistedAltitudeDrawn = altitude;
               unlistedBandDrawn = bandOnly;
               unlistedBandCoreDrawn = bandCore;
               unlistedHorizonEntries = horizonEntries;
               if (changed) {
                  drawEpoch++;
               }
            }
         }
      } else {
         altitudeArmLatched = false;
         altitudeCullRelaxed = false;
         columnTopSide = 0;
         unlistedSweepLocalHorizon = false;
         unlistedSweepHighCamera = false;
         unlistedSweepEnabled = false;
      }
   }

   private static int unlistedVerdictLocked(
      TerrainResidency.Resident r, int camX, int camZ, int cameraSectionY, int viewRadius, boolean highCamera, boolean localHorizon
   ) {
      int dx = r.sx - camX;
      int dz = r.sz - camZ;
      if (!vanillaMayList(dx, dz, viewRadius)) {
         return 1;
      } else {
         int dsy = cameraSectionY - r.sy;
         if (highCamera && dsy > vanillaAdjacencyReach(viewRadius)) {
            return 2;
         } else {
            return localHorizon && dsy >= 0 && r.ledgerState == 1 && cameraSectionY > columnTopSyLocked(dx, dz) ? 3 : 0;
         }
      }
   }

   private static int vanillaAdjacencyReach(int viewRadius) {
      return viewRadius > 0 ? Math.min(3, viewRadius) : 3;
   }

   private static void applyUnlistedVerdictLocked(TerrainResidency.Resident r) {
      if (unlistedSweepEnabled && unlistedSweepCamera != Long.MIN_VALUE && unlistedSweepRadius > 0 && unlistedSweepCameraY != Integer.MIN_VALUE && r.ownsSlot) {
         int camX = (int)(unlistedSweepCamera >> 32);
         int camZ = (int)unlistedSweepCamera;
         noteColumnTopLocked(r.sx - camX, r.sz - camZ, r.sy);
         int verdict = unlistedVerdictLocked(r, camX, camZ, unlistedSweepCameraY, unlistedSweepRadius, unlistedSweepHighCamera, unlistedSweepLocalHorizon);
         if (verdict != 0) {
            if (regionStore.setRetained(r.regionKey, r.posKey, r, true)) {
               unlistedMaskFlips++;
            }

            if (!r.unlistedDrawn) {
               r.unlistedDrawn = true;
               unlistedTransFlips++;
            }

            unlistedBindMarks++;
            if (verdict == 3) {
               unlistedBindBandMarks++;
            }
         }
      }
   }

   private static void noteColumnTopLocked(int dx, int dz, int sy) {
      int m = columnTopMargin;
      if (columnTopSide > 0 && dx >= -m && dx <= m && dz >= -m && dz <= m) {
         int i = (dx + m) * columnTopSide + dz + m;
         if (sy > columnTopSy[i]) {
            columnTopSy[i] = sy;
         }
      }
   }

   private static int columnTopSyLocked(int dx, int dz) {
      int m = columnTopMargin;
      return columnTopSide > 0 && dx >= -m && dx <= m && dz >= -m && dz <= m ? columnTopSy[(dx + m) * columnTopSide + dz + m] : Integer.MIN_VALUE;
   }

   private static long residentTerrainScanLocked(int camX, int camZ, int viewRadius) {
      Arrays.fill(syHistogram, 0);
      int margin = Math.min(130, Math.max(0, viewRadius) + 2);
      int side = 2 * margin + 1;
      if (columnTopSide != side || columnTopSy.length != side * side) {
         columnTopSy = new int[side * side];
         columnTopSide = side;
      }

      columnTopMargin = margin;
      Arrays.fill(columnTopSy, Integer.MIN_VALUE);
      int total = 0;

      for (TerrainResidency.Resident r : resident.values()) {
         if (r.ownsSlot) {
            int b = r.sy - -32;
            if (b < 0) {
               b = 0;
            } else if (b >= 64) {
               b = 63;
            }

            syHistogram[b]++;
            noteColumnTopLocked(r.sx - camX, r.sz - camZ, r.sy);
            total++;
         }
      }

      if (total == 0) {
         columnTopSide = 0;
         return Long.MIN_VALUE;
      }

      int lowTarget = total / 10;
      if (lowTarget == 0) {
         lowTarget = 1;
      }

      int topTarget = total - total / 10;
      int lowSy = 31;
      int topSy = 31;
      boolean lowFound = false;
      int seen = 0;

      for (int b = 0; b < 64; b++) {
         seen += syHistogram[b];
         if (!lowFound && seen >= lowTarget) {
            lowSy = b + -32;
            lowFound = true;
         }

         if (seen >= topTarget) {
            topSy = b + -32;
            break;
         }
      }

      return (long)topSy << 32 | lowSy & 4294967295L;
   }

   public static boolean skipAdvancedRayMarch(double cameraAboveBlocks) {
      if (!altitudeCullRelaxed) {
         return false;
      }

      if (cameraAboveBlocks < 64.0) {
         return false;
      }

      bfsAdvancedCullRelaxed++;
      return true;
   }

   public static int unlistedTerrainTopSy() {
      synchronized (LOCK) {
         return unlistedTerrainTopSy;
      }
   }

   public static int unlistedTerrainLowSy() {
      synchronized (LOCK) {
         return unlistedTerrainLowSy;
      }
   }

   public static boolean altitudeCullArmed() {
      return altitudeCullRelaxed;
   }

   public static long bfsAdvancedCullRelaxed() {
      synchronized (LOCK) {
         return bfsAdvancedCullRelaxed;
      }
   }

   public static long altitudeArmSweeps() {
      synchronized (LOCK) {
         return altitudeArmSweeps;
      }
   }

   public static int unlistedLiveDrawn() {
      synchronized (LOCK) {
         return unlistedLiveDrawn;
      }
   }

   public static int unlistedAltitudeDrawn() {
      synchronized (LOCK) {
         return unlistedAltitudeDrawn;
      }
   }

   public static int unlistedBandDrawn() {
      synchronized (LOCK) {
         return unlistedBandDrawn;
      }
   }

   public static int unlistedBandCoreDrawn() {
      synchronized (LOCK) {
         return unlistedBandCoreDrawn;
      }
   }

   public static int unlistedHorizonEntries() {
      synchronized (LOCK) {
         return unlistedHorizonEntries;
      }
   }

   public static long unlistedBindMarks() {
      synchronized (LOCK) {
         return unlistedBindMarks;
      }
   }

   public static long unlistedBindBandMarks() {
      synchronized (LOCK) {
         return unlistedBindBandMarks;
      }
   }

   public static TerrainResidency.CoverageAudit auditUnlistedCoverage(
      long[] regionKeys,
      int[] regionWords,
      int regionCount,
      int stride,
      int inFrustumBit,
      int noMaskBit,
      int cameraSectionY,
      int viewRadius,
      int maxSamples,
      TerrainResidency.SectionFrustumTest sectionInFrustum
   ) {
      synchronized (LOCK) {
         long camera = SectionBuildTap.cameraSectionXZ();
         if (camera != Long.MIN_VALUE && viewRadius > 0 && cameraSectionY != Integer.MIN_VALUE) {
            int camX = (int)(camera >> 32);
            int camZ = (int)camera;
            residentTerrainScanLocked(camX, camZ, viewRadius);
            Long2IntOpenHashMap index = new Long2IntOpenHashMap(Math.max(16, regionCount * 2));
            index.defaultReturnValue(-1);

            for (int i = 0; i < regionCount; i++) {
               index.put(regionKeys[i], i);
            }

            int expected = 0;
            int absent = 0;
            int absentCore = 0;
            int absentAbove = 0;
            int absentOccluded = 0;
            int outOfFrustum = 0;
            int notCaptured = 0;
            int drawnExpected = 0;
            int[] absentByDsy = new int[9];
            StringBuilder samples = new StringBuilder();
            int named = 0;

            for (TerrainResidency.Resident r : resident.values()) {
               if (r.ownsSlot && r.ledgerState == 1) {
                  int dx = r.sx - camX;
                  int dz = r.sz - camZ;
                  if (vanillaMayList(dx, dz, viewRadius)) {
                     int idx = index.get(r.regionKey);
                     if (idx < 0) {
                        notCaptured++;
                     } else {
                        int o = idx * stride;
                        if ((regionWords[o] & inFrustumBit) == 0) {
                           outOfFrustum++;
                        } else if (sectionInFrustum != null && !sectionInFrustum.visible(r.sx, r.sy, r.sz)) {
                           outOfFrustum++;
                        } else {
                           boolean drawn = (regionWords[o] & noMaskBit) != 0 || (regionWords[o + 1 + (r.posKey >>> 5)] & 1 << (r.posKey & 31)) != 0;
                           int dsy = cameraSectionY - r.sy;
                           boolean core = Math.abs(dx) <= 3 && Math.abs(dz) <= 3;
                           boolean pastHorizon = cameraSectionY > columnTopSyLocked(dx, dz);
                           if (dsy >= 0 && pastHorizon) {
                              expected++;
                              if (drawn) {
                                 drawnExpected++;
                              }
                           }

                           if (!drawn) {
                              if (dsy < 0) {
                                 absentAbove++;
                              } else if (!pastHorizon) {
                                 absentOccluded++;
                              } else {
                                 absent++;
                                 absentByDsy[Math.min(8, dsy)]++;
                                 if (core) {
                                    absentCore++;
                                 }

                                 if (named < maxSamples) {
                                    if (named > 0) {
                                       samples.append(' ');
                                    }

                                    samples.append('(')
                                       .append(r.sx)
                                       .append(',')
                                       .append(r.sy)
                                       .append(',')
                                       .append(r.sz)
                                       .append(" d=")
                                       .append(dx)
                                       .append(',')
                                       .append(dsy)
                                       .append(',')
                                       .append(dz)
                                       .append(" colTop=")
                                       .append(columnTopSyLocked(dx, dz))
                                       .append(core ? " core" : " ring")
                                       .append(')');
                                    named++;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }

            StringBuilder byDsy = new StringBuilder();

            for (int d = 0; d < absentByDsy.length; d++) {
               if (absentByDsy[d] != 0) {
                  if (byDsy.length() > 0) {
                     byDsy.append(' ');
                  }

                  byDsy.append(d == 8 ? "8+" : Integer.toString(d)).append(':').append(absentByDsy[d]);
               }
            }

            return new TerrainResidency.CoverageAudit(
               expected, drawnExpected, absent, absentCore, absentAbove, absentOccluded, outOfFrustum, notCaptured, byDsy.toString(), samples.toString()
            );
         } else {
            return new TerrainResidency.CoverageAudit(0, 0, 0, 0, 0, 0, 0, 0, "", "no camera");
         }
      }
   }

   public static long unlistedMaskFlips() {
      synchronized (LOCK) {
         return unlistedMaskFlips;
      }
   }

   public static long unlistedTransFlips() {
      synchronized (LOCK) {
         return unlistedTransFlips;
      }
   }

   public static long ledgerParked() {
      synchronized (LOCK) {
         return ledgerParked;
      }
   }

   public static long ledgerDemoted() {
      synchronized (LOCK) {
         return ledgerDemoted;
      }
   }

   public static long ledgerResolvedSwap() {
      synchronized (LOCK) {
         return ledgerResolvedSwap;
      }
   }

   public static long ledgerResolvedVanilla() {
      synchronized (LOCK) {
         return ledgerResolvedVanilla;
      }
   }

   public static long ledgerResolvedUncovered() {
      synchronized (LOCK) {
         return ledgerResolvedUncovered;
      }
   }

   public static long ledgerEvictedWall() {
      synchronized (LOCK) {
         return ledgerEvictedWall;
      }
   }

   public static long ledgerEvictedWallRingSum() {
      synchronized (LOCK) {
         return ledgerEvictedWallRingSum;
      }
   }

   public static long ledgerHoldMillis() {
      synchronized (LOCK) {
         return ledgerHoldMillis;
      }
   }

   public static long ledgerHoldMaxMillis() {
      synchronized (LOCK) {
         return ledgerHoldMaxMillis;
      }
   }

   public static long ledgerAwaitingQuads() {
      synchronized (LOCK) {
         return ledgerAwaitingQuads;
      }
   }

   public static long ledgerAwaitingQuadsPeak() {
      synchronized (LOCK) {
         return ledgerAwaitingQuadsPeak;
      }
   }

   public static long ledgerIllegalTransitions() {
      synchronized (LOCK) {
         return ledgerIllegalTransitions;
      }
   }

   public static long ledgerAuditMismatches() {
      synchronized (LOCK) {
         return ledgerAuditMismatches;
      }
   }

   public static int farResidentSectionsAt(int cx, int cz) {
      synchronized (LOCK) {
         int sections = 0;

         for (TerrainResidency.Resident r : farResident.values()) {
            if (r.sx == cx && r.sz == cz) {
               sections++;
            }
         }

         return sections;
      }
   }

   public static long farResidentQuadsAt(int cx, int cz) {
      synchronized (LOCK) {
         long quads = 0L;

         for (TerrainResidency.Resident r : farResident.values()) {
            if (r.sx == cx && r.sz == cz) {
               quads += r.quadCount;
            }
         }

         return quads;
      }
   }

   public static LongOpenHashSet boundColumnsSnapshot() {
      synchronized (LOCK) {
         LongOpenHashSet out = new LongOpenHashSet();

         for (TerrainResidency.Resident r : resident.values()) {
            out.add((long)r.sx << 32 | r.sz & 4294967295L);
         }

         for (TerrainResidency.Resident r : retained.values()) {
            out.add((long)r.sx << 32 | r.sz & 4294967295L);
         }

         for (TerrainResidency.Resident r : farResident.values()) {
            out.add((long)r.sx << 32 | r.sz & 4294967295L);
         }

         return out;
      }
   }

   public static void publishFarCoverage(long camera, int coverEdge, int l1) {
      farCoverageCoverEdge = coverEdge;
      farCoverageL1 = l1;
      farCoverageCamera = camera;
   }

   public static void clearFarCoverage() {
      farCoverageCamera = Long.MIN_VALUE;
      farCoverageCoverEdge = -1;
      farCoverageL1 = -1;
   }

   public static int publishedFarCoverageL1() {
      return farCoverageL1;
   }

   public static void onVanillaGeometryInvalidated(int effectiveRenderDistance) {
      if (farEverArmed && !farHookBroken && farCoverageL1 > 0) {
         try {
            FarFieldResidency.republishCoverage(effectiveRenderDistance);
         } catch (Throwable t) {
            farHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error("NvidiumPlus far-field coverage republish failed; the far field is off for this session (near-field rendering is unaffected)", t);
         }
      }
   }

   private static boolean coveredNow(int chunkX, int chunkZ, boolean leavingGrid) {
      long camera = farCoverageCamera;
      if (camera == Long.MIN_VALUE) {
         return false;
      }

      int l1 = farCoverageL1;
      int coverEdge = farCoverageCoverEdge;
      if (l1 > 0 && coverEdge >= 0) {
         long live = SectionBuildTap.cameraSectionXZ();
         if (live != Long.MIN_VALUE) {
            camera = live;
         }

         return coveredNow(camera, coverEdge, l1, chunkX, chunkZ, leavingGrid);
      } else {
         return false;
      }
   }

   private static boolean withinCoverageOuterEdge(int chunkX, int chunkZ) {
      long camera = farCoverageCamera;
      if (camera == Long.MIN_VALUE) {
         return false;
      }

      int l1 = farCoverageL1;
      if (l1 <= 0) {
         return false;
      }

      long live = SectionBuildTap.cameraSectionXZ();
      if (live != Long.MIN_VALUE) {
         camera = live;
      }

      long dx = chunkX - (int)(camera >> 32);
      long dz = chunkZ - (int)camera;
      return dx * dx + dz * dz <= (long)l1 * l1;
   }

   private static boolean coveredNow(long camera, int coverEdge, int l1, int chunkX, int chunkZ, boolean leavingGrid) {
      long dx = chunkX - (int)(camera >> 32);
      long dz = chunkZ - (int)camera;
      if (!leavingGrid) {
         long px = Math.max(0L, Math.abs(dx) - 1L);
         long pz = Math.max(0L, Math.abs(dz) - 1L);
         if (px * px + pz * pz < (long)coverEdge * coverEdge) {
            return false;
         }
      }

      return dx * dx + dz * dz <= (long)l1 * l1;
   }

   private static void evictRetainedLocked() {
      if (!retained.isEmpty()) {
         int budget = 256;
         if (!NvidiumPlusConfig.retainTerrainEnabled()) {
            Iterator<TerrainResidency.Resident> it = retained.values().iterator();

            while (it.hasNext() && budget-- > 0) {
               TerrainResidency.Resident r = it.next();
               if (r.ledgerState != 4) {
                  it.remove();
                  freeRetainedLocked(r);
                  evictedByDisable++;
                  drawEpoch++;
               }
            }
         } else {
            long limitMillis = NvidiumPlusConfig.retainLimitMillis();
            if (limitMillis > 0L) {
               long cutoff = monotonicMillis() - limitMillis;
               Iterator<TerrainResidency.Resident> it = retained.values().iterator();

               while (it.hasNext() && budget > 0) {
                  TerrainResidency.Resident r = it.next();
                  if (r.orphanedAtMillis > cutoff) {
                     break;
                  }

                  if (r.ledgerState != 4) {
                     it.remove();
                     freeRetainedLocked(r);
                     evictedByAge++;
                     drawEpoch++;
                     budget--;
                  }
               }
            }

            if (budget > 0 && !retained.isEmpty()) {
               long capacityQuads = NvidiumPlusScaling.arenaCeilingBytes() / 64L - 1L;
               long usedQuads = arena.liveQuads() - 1L - parkedQuads;
               long arenaHighWater = capacityQuads * 85L / 100L;
               int regionHighWater = maxRegions() * 90 / 100;
               Iterator<TerrainResidency.Resident> it = retained.values().iterator();

               while (it.hasNext() && budget > 0 && (usedQuads > arenaHighWater || regionStore.regionCount() > regionHighWater)) {
                  TerrainResidency.Resident r = it.next();
                  if (r.ledgerState != 4) {
                     it.remove();
                     usedQuads -= r.quadCount;
                     freeRetainedLocked(r);
                     evictedByPressure++;
                     drawEpoch++;
                     budget--;
                  }
               }
            }
         }
      }
   }

   private static boolean forceEvictRetainedLocked() {
      if (retained.isEmpty()) {
         return false;
      }

      int budget = 64;
      boolean any = false;
      int maxRing = awaitingByRing.length - 1;
      LongArrayList[] buckets = new LongArrayList[maxRing + 1];

      for (TerrainResidency.Resident r : retained.values()) {
         if (r.ledgerState != 4) {
            int ring = (int)Math.min(maxRing, ledgerCameraRingLocked(r));
            LongArrayList bucket = buckets[ring];
            if (bucket == null) {
               bucket = new LongArrayList();
               buckets[ring] = bucket;
            }

            bucket.add(posPack(r.sx, r.sy, r.sz));
         }
      }

      for (int ring = maxRing; ring >= 0 && budget > 0; ring--) {
         LongArrayList bucket = buckets[ring];
         if (bucket != null) {
            for (int i = bucket.size() - 1; i >= 0 && budget > 0; i--) {
               TerrainResidency.Resident r = retained.remove(bucket.getLong(i));
               if (r != null) {
                  freeRetainedLocked(r);
                  evictedByPressure++;
                  drawEpoch++;
                  budget--;
                  any = true;
               }
            }
         }
      }

      for (int ring = maxRing; ring >= 0 && budget > 0; ring--) {
         LongArrayList bucket = awaitingByRing[ring];
         if (bucket != null && !bucket.isEmpty()) {
            for (int i = bucket.size() - 1; i >= 0 && budget > 0; i--) {
               long pos = bucket.getLong(i);
               TerrainResidency.Resident r = retained.get(pos);
               if (r != null && r.ledgerState == 4) {
                  bucket.removeLong(i);
                  retained.remove(pos);
                  freeRetainedLocked(r);
                  evictedByPressure++;
                  drawEpoch++;
                  budget--;
                  any = true;
               } else {
                  bucket.removeLong(i);
               }
            }
         }
      }

      if (any) {
         retainedBackpressure++;
      }

      return any;
   }

   private static boolean forceEvictFarLocked() {
      if (farResident.isEmpty()) {
         return false;
      }

      int maxRing = awaitingByRing.length - 1;
      LongArrayList[] buckets = new LongArrayList[maxRing + 1];

      for (TerrainResidency.Resident r : farResident.values()) {
         int ring = (int)Math.min(maxRing, ledgerCameraRingLocked(r));
         LongArrayList bucket = buckets[ring];
         if (bucket == null) {
            bucket = new LongArrayList();
            buckets[ring] = bucket;
         }

         bucket.add(posPack(r.sx, r.sy, r.sz));
      }

      int budget = 64;
      boolean any = false;

      for (int ring = maxRing; ring >= 0 && budget > 0; ring--) {
         LongArrayList bucket = buckets[ring];
         if (bucket != null) {
            for (int i = bucket.size() - 1; i >= 0 && budget > 0; i--) {
               long pos = bucket.getLong(i);
               TerrainResidency.Resident r = farResident.remove(pos);
               if (r != null) {
                  ledgerEvictedWall++;
                  ledgerEvictedWallRingSum = ledgerEvictedWallRingSum + ledgerCameraRingLocked(r);
                  freeFarLocked(r);
                  farFreedPending.add(pos);
                  drawEpoch++;
                  budget--;
                  any = true;
               }
            }
         }
      }

      return any;
   }

   private static void freeFarLocked(TerrainResidency.Resident r) {
      ledgerTransitionLocked(r, (byte)5);
      logMovedOwnerLocked(regionStore.remove(r.regionKey, r.posKey, r));
      parkAddrLocked(r.arenaAddr, r.quadCount);
      freeSnapshotSlotLocked(r);
   }

   public static int releaseFarColumn(int cx, int cz, int[] sectionYs, int count) {
      synchronized (LOCK) {
         int released = 0;

         for (int i = 0; i < count; i++) {
            TerrainResidency.Resident r = farResident.remove(posPack(cx, sectionYs[i], cz));
            if (r != null) {
               freeFarLocked(r);
               drawEpoch++;
               released++;
            }
         }

         return released;
      }
   }

   public static int releaseAllFar() {
      synchronized (LOCK) {
         if (farResident.isEmpty()) {
            return 0;
         }

         int released = 0;

         for (TerrainResidency.Resident r : farResident.values()) {
            freeFarLocked(r);
            released++;
         }

         farResident.clear();
         drawEpoch++;
         return released;
      }
   }

   public static boolean farPromotionHasRoom() {
      synchronized (LOCK) {
         return farFillHasRoomLocked();
      }
   }

   private static boolean farFillHasRoomLocked() {
      int max = maxRegions();
      int rd = NvidiumPlusScaling.current().maxRd();
      int chunks = 2 * rd + 1;
      int horizontal = (chunks + 7) / 8 + 1;
      int nearReserve = horizontal * horizontal * 7;
      int gate = Math.min(max * 85 / 100, max - nearReserve);
      if (regionStore.regionCount() >= gate) {
         return false;
      }

      long capacityQuads = NvidiumPlusScaling.arenaCeilingBytes() / 64L - 1L;
      long usedQuads = arena.liveQuads() - 1L - parkedQuads;
      return usedQuads < capacityQuads * 70L / 100L;
   }

   private static void drainFarFieldLocked(TerrainGpuHost gpu) {
      if (!farFreedPending.isEmpty()) {
         try {
            for (int i = 0; i < farFreedPending.size(); i++) {
               long pos = farFreedPending.getLong(i);
               int sx = (int)(pos >>> 42) << 11 >> 11;
               int sy = (int)(pos >>> 21) << 11 >> 11;
               int sz = (int)pos << 11 >> 11;
               FarFieldResidency.onSectionEvicted(sx, sy, sz);
            }
         } catch (Throwable t) {
            farHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error("NvidiumPlus far-field eviction flush failed; the far field is off for this session (near-field rendering is unaffected)", t);
         }

         farFreedPending.clear();
      }

      if (!successorRequests.isEmpty()) {
         drainSuccessorRequestsLocked();
      }

      if (!farHookBroken) {
         if (farEverArmed) {
            if (FarFieldResidency.admissionsPending()) {
               try {
                  int budget = 64;
                  boolean fillHasRoom = farFillHasRoomLocked();

                  while (budget-- > 0) {
                     FarFieldResidency.Admission a = FarFieldResidency.pollAdmission();
                     if (a == null) {
                        break;
                     }

                     int outcome = admitFarSectionLocked(gpu, a, fillHasRoom);
                     FarFieldResidency.onAdmissionOutcome(outcome);
                     if (outcome == 1) {
                        break;
                     }
                  }
               } catch (Throwable t) {
                  farHookBroken = true;
                  FarFieldResidency.latchBroken("far admission drain", t);
               }
            }
         }
      }
   }

   private static void drainSuccessorRequestsLocked() {
      if (farHookBroken) {
         successorRequests.clear();
      } else {
         try {
            for (int i = 0; i < successorRequests.size(); i++) {
               long pos = successorRequests.getLong(i);
               int sx = (int)(pos >>> 42) << 11 >> 11;
               int sy = (int)(pos >>> 21) << 11 >> 11;
               int sz = (int)pos << 11 >> 11;
               if (!successorQueued(sx, sy, sz)) {
                  FarFieldResidency.onFarBlockerReleased(sx, sy, sz);
               }
            }
         } catch (Throwable t) {
            farHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error("NvidiumPlus far-field successor-request flush failed; the far field is off for this session (near-field rendering is unaffected)", t);
         }

         successorRequests.clear();
      }
   }

   private static int admitFarSectionLocked(TerrainGpuHost gpu, FarFieldResidency.Admission a, boolean fillHasRoom) {
      int sx = a.sx();
      int sy = a.sy();
      int sz = a.sz();
      long pos = posPack(sx, sy, sz);
      TerrainResidency.Resident farPrev = farResident.get(pos);
      if (farPrev != null && !a.refresh()) {
         return 3;
      }

      boolean farReplace = farPrev != null;
      if (farReplace && successorQueued(sx, sy, sz)) {
         return 3;
      }

      TerrainResidency.Resident held = farReplace ? null : retained.get(pos);
      boolean bridged = held != null && held.ledgerState == 4 && !successorQueued(sx, sy, sz);
      if (farReplace || (held == null || bridged) && !successorQueued(sx, sy, sz)) {
         if (!bridged && !farReplace && regionStore.isOccupied(RegionStore.regionKey(sx, sy, sz), RegionStore.posKey(sx, sy, sz))) {
            return 4;
         }

         if (!bridged && !farReplace && !fillHasRoom) {
            return 2;
         }

         EncodedSectionMesh encoded = a.mesh();
         if (!regionStore.hasCapacityFor(sx, sy, sz)) {
            return 2;
         }

         int addr = arena.allocQuads(encoded.quadCount());
         if (addr == -1) {
            return 2;
         }

         if (!gpu.stageArenaCopy(encoded.geometry(), arena.blockOf(addr), arena.byteOffsetInBlock(addr))) {
            arena.free(addr);
            arena.releasePending();
            return 1;
         }

         int[] bucketStarts = new int[7];
         int[] bucketCounts = new int[7];

         for (int b = 0; b < bucketStarts.length; b++) {
            bucketStarts[b] = encoded.bucketStart(b);
            bucketCounts[b] = encoded.bucketCount(b);
         }

         TerrainResidency.Resident r = new TerrainResidency.Resident(
            addr,
            encoded.quadCount(),
            RegionStore.regionKey(sx, sy, sz),
            RegionStore.posKey(sx, sy, sz),
            sx,
            sy,
            sz,
            bucketStarts,
            bucketCounts,
            null,
            allocSnapshotSlotLocked()
         );
         r.orphanedAtMillis = monotonicMillis();
         snapshotSlotOwner[r.snapshotSlot] = r;
         RegionStore.Assignment assignment = regionStore.addOrReplace(sx, sy, sz, encoded, addr, r);
         if (assignment == null) {
            throw new IllegalStateException("far region assignment failed after capacity pre-flight");
         }

         if (assignment.previousOwner() != null) {
            TerrainResidency.Resident previous = assignment.previousOwner() instanceof TerrainResidency.Resident p ? p : null;
            if (farReplace) {
               if (previous == null || previous != farPrev) {
                  throw new IllegalStateException("far refresh displaced a stranger at " + sx + "," + sy + "," + sz);
               }

               previous.ownsSlot = false;
               pendingPrefixUploads.remove(previous);
               ledgerResolvedSwap++;
               ledgerTransitionLocked(previous, (byte)5);
               parkAddrLocked(previous.arenaAddr, previous.quadCount);
               freeSnapshotSlotLocked(previous);
            } else {
               if (!bridged || previous == null || previous != held) {
                  throw new IllegalStateException("far admission found an owned slot at " + sx + "," + sy + "," + sz);
               }

               retained.remove(pos);
               previous.ownsSlot = false;
               pendingPrefixUploads.remove(previous);
               retainedQuads = retainedQuads - previous.quadCount;
               freedSections++;
               ledgerResolvedSwap++;
               ledgerTransitionLocked(previous, (byte)5);
               parkAddrLocked(previous.arenaAddr, previous.quadCount);
               freeSnapshotSlotLocked(previous);
            }
         } else if (farReplace) {
            throw new IllegalStateException("far refresh found no previous owner at " + sx + "," + sy + "," + sz);
         }

         regionStore.markRetained(r.regionKey, r.posKey, r);
         farResident.put(pos, r);
         ledgerTransitionLocked(r, (byte)3);
         logSlotWriteLocked(r.snapshotSlot);
         drawEpoch++;
         stagedBytesThisPump = stagedBytesThisPump + encoded.geometryBytes();
         return farReplace ? 5 : 0;
      } else {
         return 4;
      }
   }

   private static void drainPendingPrefixUploadsLocked(TerrainGpuHost gpu) {
      if (!pendingPrefixUploads.isEmpty()) {
         Iterator<TerrainResidency.Resident> it = pendingPrefixUploads.iterator();

         while (it.hasNext()) {
            TerrainResidency.Resident r = it.next();
            byte[] prefix = r.translucent.prefix;
            if (!gpu.stageArenaCopyLate(meterPrefixStage(prefix), arena.blockOf(r.arenaAddr), arena.byteOffsetInBlock(r.arenaAddr))) {
               break;
            }

            it.remove();
            resortBytes += prefix.length;
         }
      }
   }

   private static void releaseExpiredFreesLocked(long frame) {
      boolean freedAny;
      for (freedAny = false; !freeEpochs.isEmpty() && frame - freeEpochs.peekFirst().frame >= 3L; freedAny = true) {
         TerrainResidency.FreeEpoch epoch = freeEpochs.pollFirst();
         IntArrayList addrs = epoch.addrs;

         for (int i = 0; i < addrs.size(); i++) {
            arena.free(addrs.getInt(i));
         }

         parkedQuads = parkedQuads - epoch.quads;
      }

      if (freedAny) {
         arena.releasePending();
      }
   }

   /**
    * Reconstructed from this release's bytecode because the decompiler could not
    * recover the original source for this method. This is a bytecode-guided
    * reconstruction, not the author's original source text.
    */
   private static void drainPendingUploadsLocked(TerrainGpuHost gpu) {
      long remainingBytes = UPLOAD_BYTES_PER_PUMP;
      Iterator<Entry<Object, TerrainResidency.PendingUpload>> iterator = pendingUploads.entrySet().iterator();

      while (iterator.hasNext() && remainingBytes > 0L) {
         Entry<Object, TerrainResidency.PendingUpload> entry = iterator.next();
         TerrainResidency.PendingUpload pending = entry.getValue();
         Object mesh = entry.getKey();
         boolean removed = false;

         try {
            int geometryBytes = pending.encoded().geometryBytes();
            if ((long)geometryBytes > gpu.maxStageBytes()) {
               iterator.remove();
               removed = true;
               noteGuardTripLocked("oversize", ((long)geometryBytes + 1048575L) >> 20, gpu.maxStageBytes() >> 20);
               droppedOversize++;
               continue;
            }

            if (!regionStore.hasCapacityFor(pending.sx(), pending.sy(), pending.sz())) {
               if (pendingGrowOption > 0) {
                  break;
               }
               if (!forceEvictFarLocked() && !forceEvictRetainedLocked()) {
                  iterator.remove();
                  removed = true;
                  noteGuardTripLocked("region", regionStore.regionCount(), maxRegions());
                  droppedRegionBudget++;
                  continue;
               }
               break;
            }

            int arenaAddress = arena.allocQuads(pending.encoded().quadCount());
            if (arenaAddress == -1 && growArenaLocked(gpu, pending.encoded().quadCount())) {
               arenaAddress = arena.allocQuads(pending.encoded().quadCount());
            }

            if (arenaAddress == -1) {
               if (forceEvictFarLocked() || forceEvictRetainedLocked()) {
                  break;
               }
               iterator.remove();
               removed = true;
               noteGuardTripLocked("arena", arena.memoryBytes() >> 20, NvidiumPlusScaling.arenaCeilingBytes() >> 20);
               droppedArenaFull++;
               continue;
            }

            if (!gpu.stageArenaCopy(
               pending.encoded().geometry(),
               arena.blockOf(arenaAddress),
               arena.byteOffsetInBlock(arenaAddress)
            )) {
               arena.free(arenaAddress);
               arena.releasePending();
               break;
            }

            iterator.remove();
            removed = true;

            int[] bucketStarts = new int[7];
            int[] bucketCounts = new int[7];
            for (int i = 0; i < bucketStarts.length; i++) {
               bucketStarts[i] = pending.encoded().bucketStart(i);
               bucketCounts[i] = pending.encoded().bucketCount(i);
            }

            TerrainResidency.Resident current = new TerrainResidency.Resident(
               arenaAddress,
               pending.encoded().quadCount(),
               RegionStore.regionKey(pending.sx(), pending.sy(), pending.sz()),
               RegionStore.posKey(pending.sx(), pending.sy(), pending.sz()),
               pending.sx(),
               pending.sy(),
               pending.sz(),
               bucketStarts,
               bucketCounts,
               pending.translucent(),
               allocSnapshotSlotLocked()
            );

            if (pending.builtTier() != 0) {
               current.builtTier = pending.builtTier();
               tierBuiltFlagged++;
            }

            snapshotSlotOwner[current.snapshotSlot] = current;
            RegionStore.Assignment assignment = regionStore.addOrReplace(
               pending.sx(),
               pending.sy(),
               pending.sz(),
               pending.encoded(),
               arenaAddress,
               current
            );
            if (assignment == null) {
               throw new IllegalStateException("region assignment failed after capacity pre-flight");
            }

            Object previousOwner = assignment.previousOwner();
            if (previousOwner instanceof TerrainResidency.Resident previous) {
               if (previous.orphanedAtMillis != 0L) {
                  long previousPosition = posPack(previous.sx, previous.sy, previous.sz);
                  TerrainResidency.Resident previousFar = farResident.remove(previousPosition);
                  if (previousFar != null) {
                     previous.ownsSlot = false;
                     if (previousFar == previous) {
                        ledgerTransitionLocked(previous, (byte)5);
                        parkAddrLocked(previous.arenaAddr, previous.quadCount);
                        freeSnapshotSlotLocked(previous);
                        farFreedPending.add(previousPosition);
                        FarFieldResidency.farSupersededByVanilla.increment();
                     } else {
                        forceSnapshotRebuildLocked();
                     }
                  } else {
                     TerrainResidency.Resident previousRetained = retained.remove(previousPosition);
                     previous.ownsSlot = false;
                     if (previousRetained == previous) {
                        if (previous.ledgerState == 4) {
                           ledgerResolvedVanilla++;
                        }
                        ledgerTransitionLocked(previous, (byte)5);
                        pendingPrefixUploads.remove(previous);
                        retainedQuads -= previous.quadCount;
                        freedSections++;
                        retainedSuperseded++;
                        parkAddrLocked(previous.arenaAddr, previous.quadCount);
                        freeSnapshotSlotLocked(previous);
                     } else {
                        forceSnapshotRebuildLocked();
                     }
                  }
               } else {
                  previous.ownsSlot = false;
                  logSlotWriteLocked(previous.snapshotSlot);
               }
            }

            resident.put(mesh, current);
            ledgerTransitionLocked(current, (byte)1);
            applyUnlistedVerdictLocked(current);
            logSlotWriteLocked(current.snapshotSlot);

            if (current.translucent != null && current.translucent.dirtySinceEncode) {
               current.translucent.dirtySinceEncode = false;
               pendingPrefixUploads.add(current);
            }

            drawEpoch++;
            uploadedSections++;
            quadsResident += current.quadCount;
            remainingBytes -= geometryBytes;
            stagedBytesThisPump += geometryBytes;
         } catch (Throwable error) {
            if (!removed) {
               iterator.remove();
            }
            noteGuardTripLocked("encoding", 0L, 0L);
            droppedEncoding++;
            recordError("upload: " + error);
         } finally {
            if (!pendingUploads.containsKey(mesh)) {
               pendingPosDrop(pending.sx(), pending.sy(), pending.sz());
            }
         }
      }
   }

   private static void maybeTrimArenaLocked(TerrainGpuHost gpu) {
      long now = monotonicMillis();
      stagedBytesSinceQuiet = stagedBytesSinceQuiet + stagedBytesThisPump;
      if (stagedBytesSinceQuiet > 8388608L || pendingGrowOption > 0) {
         lastBusyMillis = now;
         stagedBytesSinceQuiet = 0L;
      }

      if (stagedBytesThisPump <= 0L && pendingUploads.isEmpty() && pendingPrefixUploads.isEmpty()) {
         if (NvidiumPlusConfig.arenaTrimEnabled() && now - lastBusyMillis >= Long.getLong("nvidiumplus.tune.arenaTrimQuietSec", 30L) * 1000L) {
            long capacity = arena.lastBlockBytes();
            long extent = arena.lastBlockExtentBytes();
            long target = Math.max(extent, 16777216L);
            target = target + 1048576L - 1L >> 20 << 20;
            long minSave = Long.getLong("nvidiumplus.tune.arenaTrimMinMiB", 64L) << 20;
            if (capacity - target >= minSave) {
               long newHandle = gpu.trimArena(target, extent);
               if (newHandle == 0L) {
                  lastBusyMillis = now;
               } else {
                  arena.shrinkLastBlock(target, newHandle);
                  arenaTrims++;
                  drawEpoch++;
               }
            }
         }
      }
   }

   public static long arenaTrims() {
      synchronized (LOCK) {
         return arenaTrims;
      }
   }

   private static ByteBuffer meterPrefixStage(byte[] prefix) {
      stagedBytesThisPump += prefix.length;
      return ByteBuffer.wrap(prefix);
   }

   private static boolean growArenaLocked(TerrainGpuHost gpu, int quadCount) {
      long ceiling = NvidiumPlusScaling.arenaCeilingBytes();
      long current = arena.memoryBytes();
      if (current >= ceiling) {
         return false;
      }

      long needed = quadCount * 4L * 16L;
      long blockBytes = arena.blockBytes();
      long lastBlock = arena.lastBlockBytes();
      if (lastBlock < blockBytes) {
         long target = Math.max(lastBlock + (lastBlock >> 1), lastBlock + needed);
         target = target + 1048576L - 1L >> 20 << 20;
         target = Math.min(target, blockBytes);
         target = Math.min(target, lastBlock + (ceiling - current));
         if (target > lastBlock) {
            long newHandle = gpu.growArena(target);
            if (newHandle != 0L) {
               arena.grow(target, newHandle);
               arenaGrowths++;
               drawEpoch++;
               return true;
            }

            arenaGrowthFailures++;
         }
      }

      long appendBytes = Math.min(blockBytes, ceiling - current);
      appendBytes = appendBytes >> 20 << 20;
      if (appendBytes >= needed && appendBytes > 0L) {
         long headroom = NvidiumPlusVramState.headroomBytes();
         if (headroom < appendBytes) {
            arenaGrowthFailures++;
            noteGuardTripLocked("vram", current + appendBytes >> 20, current + Math.max(0L, headroom) >> 20);
            return false;
         } else if (!arena.appendBlock(appendBytes)) {
            arenaGrowthFailures++;
            return false;
         } else {
            gpu.onArenaBlockAppended(appendBytes);
            arenaGrowths++;
            drawEpoch++;
            return true;
         }
      } else {
         return false;
      }
   }

   public static void recordError(String message) {
      if (lastError == null) {
         lastError = message;
         NvidiumPlusLog.LOGGER.error("NvidiumPlus terrain residency error (first and only report): {}", message);
         NvidiumPlusNotify.chat("nvidiumplus.chat.error.residency");
      }
   }

   private static TerrainResidency.Counters countersLocked() {
      long backlogBytes = 0L;

      for (TerrainResidency.PendingUpload p : pendingUploads.values()) {
         backlogBytes += p.encoded().geometryBytes();
      }

      int pendingFreeRanges = arena == null ? 0 : arena.pendingFreeCount();

      for (TerrainResidency.FreeEpoch epoch : freeEpochs) {
         pendingFreeRanges += epoch.addrs.size();
      }

      long arenaUsed = 0L;
      long arenaCapacity = 0L;
      long arenaExtent = 0L;
      int arenaBlocks = 0;
      int emptyTopBlocks = 0;
      if (arena != null) {
         arenaUsed = (arena.liveQuads() - 1L) * 4L * 16L;
         arenaCapacity = arena.memoryBytes();
         arenaExtent = (arena.quadExtent() - 1L) * 4L * 16L;
         arenaBlocks = arena.blockCount();
         emptyTopBlocks = arena.emptyTopBlocks();
      }

      return new TerrainResidency.Counters(
         frameCounter,
         resident.size(),
         quadsResident,
         arenaUsed,
         arenaCapacity,
         regionStore.regionCount(),
         regionStore.dirtyRegionCount(),
         pendingUploads.size(),
         backlogBytes,
         pendingFreeRanges,
         encodedSections,
         uploadedSections,
         freedSections,
         discardedBeforeUpload,
         droppedOversize,
         droppedArenaFull,
         droppedRegionBudget,
         droppedEncoding,
         staleParks,
         decoderSkippedLayers,
         resortsApplied,
         resortBytes,
         resortsNoop,
         resortsUnknownMesh,
         resortsMalformed,
         retained.size(),
         retainedQuads,
         orphanedSections,
         retainedSuperseded,
         evictedByAge,
         evictedByPressure,
         evictedByDisable,
         retainedBackpressure,
         arenaGrowths,
         arenaGrowthFailures,
         arenaExtent,
         arenaBlocks,
         emptyTopBlocks
      );
   }

   private static String farSeamCountersLocked() {
      if (farEverArmed && !farHookBroken) {
         try {
            return " far[resident="
               + FarFieldResidency.farSectionsResident.sum()
               + " requests="
               + FarFieldResidency.farShellRequests.sum()
               + " admissions="
               + FarFieldResidency.farAdmissions.sum()
               + " contested="
               + FarFieldResidency.farContestedSections.sum()
               + " noBudget="
               + FarFieldResidency.farAdmitNoBudget.sum()
               + " budgetStalls="
               + FarFieldResidency.farPromoteBudgetStalls.sum()
               + " holesFiled="
               + FarFieldResidency.farHolesFiled.sum()
               + " holesDrained="
               + FarFieldResidency.farHolesDrained.sum()
               + " idleRescans="
               + FarFieldResidency.farIdleRescans.sum()
               + " retryBackoffs="
               + FarFieldResidency.farHoleRetryBackoffs.sum()
               + "]";
         } catch (Throwable ignored) {
            return "";
         }
      } else {
         return "";
      }
   }

   private static void maybeLogStatsLocked(TerrainGpuHost gpu) {
      if (NvidiumPlusConfig.debugStatsEnabled()) {
         long now = System.nanoTime();
         if (now - lastStatsNanos >= 5000000000L) {
            lastStatsNanos = now;
            TerrainResidency.Counters c = countersLocked();
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus residency: sections={} quads={} retained={}/{} quads arena={}/{} MiB (ceiling {} MiB, growths={}, trims={}, growthFailures={}) holes={} MiB tail={} MiB emptyTopBlocks={}/{} regions={} (dirty {}) stagingBacklog={} entries/{} KiB ringUsed={} KiB freesPending={} encoded={} uploaded={} drops[oversize={},arena={},region={},encode={}] retention[orphaned={},superseded={},evictAge={},evictPressure={},evictOff={},backpressure={}] handoverHeld={} discarded={} staleParks={} snapshot[publishes={},fullRebuilds={},logRecords={}] greedyMerge[{}]",
                  new Object[]{
                     c.sectionsResident(),
                     c.quadsResident(),
                     c.retainedSections(),
                     c.retainedQuads(),
                     c.arenaUsedBytes() >> 20,
                     c.arenaCapacityBytes() >> 20,
                     NvidiumPlusScaling.arenaCeilingBytes() >> 20,
                     c.arenaGrowths(),
                     arenaTrims,
                     c.arenaGrowthFailures(),
                     Math.max(0L, c.arenaExtentBytes() - c.arenaUsedBytes()) >> 20,
                     Math.max(0L, c.arenaCapacityBytes() - c.arenaExtentBytes()) >> 20,
                     c.emptyTopBlocks(),
                     c.arenaBlocks(),
                     c.regionsLive(),
                     c.regionsDirty(),
                     c.stagingBacklogEntries(),
                     c.stagingBacklogBytes() >> 10,
                     gpu.stagingUsedBytes() >> 10,
                     c.pendingFreeRanges(),
                     c.encodedSections(),
                     c.uploadedSections(),
                     c.droppedOversize(),
                     c.droppedArenaFull(),
                     c.droppedRegionBudget(),
                     c.droppedEncoding(),
                     c.orphanedSections(),
                     c.retainedSuperseded(),
                     c.evictedByAge(),
                     c.evictedByPressure(),
                     c.evictedByDisable(),
                     c.retainedBackpressure(),
                     handoverRetained,
                     c.discardedBeforeUpload(),
                     c.staleParks(),
                     snapshotPublishes,
                     snapshotFullRebuilds,
                     snapshotLogRecords,
                     GreedyMesher.costSummary() + " " + GreedyMesher.quadSummary()
                  }
               );
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus seam: ledger[parked={} resolved[swap={} vanilla={} uncovered={}] evictedWall={} wallRingSum={} demoted={} illegal={} awaitingQuads={}/{} peak={} holdMs[sum={} max={}]] unlisted[live={} altitude={} band={} core={} horizon={} bind={}/{} maskFlips={} transFlips={}] bfsRelax[armed={} armSweeps={} topSy={} loSy={} suppressed={} listed={} lo={} hi={}]{}",
                  new Object[]{
                     ledgerParked,
                     ledgerResolvedSwap,
                     ledgerResolvedVanilla,
                     ledgerResolvedUncovered,
                     ledgerEvictedWall,
                     ledgerEvictedWallRingSum,
                     ledgerDemoted,
                     ledgerIllegalTransitions,
                     ledgerAwaitingQuads,
                     awaitingBudgetQuads,
                     ledgerAwaitingQuadsPeak,
                     ledgerHoldMillis,
                     ledgerHoldMaxMillis,
                     unlistedLiveDrawn,
                     unlistedAltitudeDrawn,
                     unlistedBandDrawn,
                     unlistedBandCoreDrawn,
                     unlistedHorizonEntries,
                     unlistedBindBandMarks,
                     unlistedBindMarks,
                     unlistedMaskFlips,
                     unlistedTransFlips,
                     altitudeCullRelaxed,
                     altitudeArmSweeps,
                     unlistedTerrainTopSy,
                     unlistedTerrainLowSy,
                     bfsAdvancedCullRelaxed,
                     SectionBuildTap.visibleSectionsListed(),
                     SectionBuildTap.visibleSectionsListedMin(),
                     SectionBuildTap.visibleSectionsListedMax(),
                     farSeamCountersLocked()
                  }
               );
            long vanillaBytes = VanillaTerrainCensus.committedBytes();
            long arenaBytes = c.arenaCapacityBytes();
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus terrain bill: NvidiumPlus {} MiB, VANILLA {} MiB{} (vanilla keeps a full second copy that nothing draws while NvidiumPlus owns the frame)",
                  new Object[]{
                     arenaBytes >> 20,
                     vanillaBytes < 0L ? -1L : vanillaBytes >> 20,
                     vanillaBytes > 0L && arenaBytes > 0L ? String.format(" = %.2fx ours", (double)vanillaBytes / arenaBytes) : ""
                  }
               );
            long budget = NvidiumPlusVramState.budgetBytes();
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus vram: budget={} MiB used={} MiB ({}%) headroom={} MiB{}",
                  new Object[]{
                     budget >> 20,
                     NvidiumPlusVramState.usageBytes() >> 20,
                     NvidiumPlusVramState.pressurePct(),
                     budget <= 0L ? -1L : NvidiumPlusVramState.headroomBytes() >> 20,
                     budget <= 0L ? " (UNKNOWN - no VK_EXT_memory_budget; the static ceiling is the only bound, exactly as before this probe existed)" : ""
                  }
               );
         }
      }
   }

   static {
      unlistedRegionIndex.defaultReturnValue(-1);
   }

   public record Counters(
      long frame,
      int sectionsResident,
      long quadsResident,
      long arenaUsedBytes,
      long arenaCapacityBytes,
      int regionsLive,
      int regionsDirty,
      int stagingBacklogEntries,
      long stagingBacklogBytes,
      int pendingFreeRanges,
      long encodedSections,
      long uploadedSections,
      long freedSections,
      long discardedBeforeUpload,
      long droppedOversize,
      long droppedArenaFull,
      long droppedRegionBudget,
      long droppedEncoding,
      long staleParks,
      long decoderSkippedLayers,
      long resortsApplied,
      long resortBytes,
      long resortsNoop,
      long resortsUnknownMesh,
      long resortsMalformed,
      int retainedSections,
      long retainedQuads,
      long orphanedSections,
      long retainedSuperseded,
      long evictedByAge,
      long evictedByPressure,
      long evictedByDisable,
      long retainedBackpressure,
      long arenaGrowths,
      long arenaGrowthFailures,
      long arenaExtentBytes,
      int arenaBlocks,
      int emptyTopBlocks
   ) {
      public boolean isCompletelyIdle() {
         return this.frame == 0L
            && this.sectionsResident == 0
            && this.quadsResident == 0L
            && this.arenaUsedBytes == 0L
            && this.arenaCapacityBytes == 0L
            && this.regionsLive == 0
            && this.regionsDirty == 0
            && this.stagingBacklogEntries == 0
            && this.stagingBacklogBytes == 0L
            && this.pendingFreeRanges == 0
            && this.encodedSections == 0L
            && this.uploadedSections == 0L
            && this.freedSections == 0L
            && this.discardedBeforeUpload == 0L
            && this.droppedOversize == 0L
            && this.droppedArenaFull == 0L
            && this.droppedRegionBudget == 0L
            && this.droppedEncoding == 0L
            && this.staleParks == 0L
            && this.decoderSkippedLayers == 0L
            && this.resortsApplied == 0L
            && this.resortBytes == 0L
            && this.resortsNoop == 0L
            && this.resortsUnknownMesh == 0L
            && this.resortsMalformed == 0L
            && this.retainedSections == 0
            && this.retainedQuads == 0L
            && this.orphanedSections == 0L
            && this.retainedSuperseded == 0L
            && this.evictedByAge == 0L
            && this.evictedByPressure == 0L
            && this.evictedByDisable == 0L
            && this.retainedBackpressure == 0L
            && this.arenaGrowths == 0L
            && this.arenaGrowthFailures == 0L
            && this.arenaExtentBytes == 0L
            && this.arenaBlocks == 0
            && this.emptyTopBlocks == 0;
      }
   }

   public record CoverageAudit(
      int expected,
      int drawn,
      int absent,
      int absentCore,
      int absentAbove,
      int absentOccluded,
      int outOfFrustum,
      int notCaptured,
      String absentDsy,
      String samples
   ) {
      @Override
      public String toString() {
         return "expected="
            + this.expected
            + " drawn="
            + this.drawn
            + " ABSENT="
            + this.absent
            + " absentCore="
            + this.absentCore
            + " absentAbove="
            + this.absentAbove
            + " absentOccluded="
            + this.absentOccluded
            + " outOfFrustum="
            + this.outOfFrustum
            + " notCaptured="
            + this.notCaptured
            + (this.absentDsy.isEmpty() ? "" : " absentByDsy[" + this.absentDsy + "]");
      }
   }

   public record DrawSnapshot(
      long epoch,
      int liveSlotCount,
      int maxSlot,
      int[] data,
      long arenaBackingHandle,
      long[] arenaBlockHandles,
      int regionCount,
      int[] regionData,
      long sectionRecordsHandle,
      int[] retainedMasks,
      int[] unlistedMasks
   ) {
      public static final int STRIDE = 20;
      public static final int BUCKETS = 7;
      public static final int REGION_STRIDE = 7;

      public int sectionCount() {
         return this.liveSlotCount;
      }
   }

   private static final class FreeEpoch {
      final long frame;
      final IntArrayList addrs = new IntArrayList();
      long quads;

      FreeEpoch(long frame) {
         this.frame = frame;
      }
   }

   public record GuardTrip(String kind, long value, long limit) {
   }

   private record PendingUpload(int sx, int sy, int sz, EncodedSectionMesh encoded, TerrainResidency.TranslucentState translucent, byte builtTier) {
   }

   private static final class Resident {
      final int arenaAddr;
      final int quadCount;
      final long regionKey;
      final int posKey;
      boolean ownsSlot = true;
      final int snapshotSlot;
      final int sx;
      final int sy;
      final int sz;
      final int[] bucketStarts;
      final int[] bucketCounts;
      final TerrainResidency.TranslucentState translucent;
      byte builtTier;
      long orphanedAtMillis;
      boolean unlistedDrawn;
      byte ledgerState = 0;

      Resident(
         int arenaAddr,
         int quadCount,
         long regionKey,
         int posKey,
         int sx,
         int sy,
         int sz,
         int[] bucketStarts,
         int[] bucketCounts,
         TerrainResidency.TranslucentState translucent,
         int snapshotSlot
      ) {
         this.arenaAddr = arenaAddr;
         this.quadCount = quadCount;
         this.regionKey = regionKey;
         this.posKey = posKey;
         this.sx = sx;
         this.sy = sy;
         this.sz = sz;
         this.bucketStarts = bucketStarts;
         this.bucketCounts = bucketCounts;
         this.translucent = translucent;
         this.snapshotSlot = snapshotSlot;
      }
   }

   @FunctionalInterface
   public interface SectionFrustumTest {
      boolean visible(int var1, int var2, int var3);
   }

   private static final class SnapshotBuffer {
      int[] data = new int[0];
      long appliedLogIndex;
      boolean needsFullRebuild = true;
   }

   private static final class TranslucentState {
      final byte[] prefix;
      int[] order;
      boolean dirtySinceEncode;

      TranslucentState(byte[] prefix, int[] order) {
         this.prefix = prefix;
         this.order = order;
      }
   }
}
