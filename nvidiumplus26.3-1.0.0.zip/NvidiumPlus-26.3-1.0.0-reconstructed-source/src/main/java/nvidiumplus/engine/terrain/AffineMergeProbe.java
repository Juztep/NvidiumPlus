package nvidiumplus.engine.terrain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class AffineMergeProbe {
   private static final int CHANNELS = 5;
   private static final float EPS = 1.0E-4F;

   private AffineMergeProbe() {
   }

   public static long[] measure(List<TerrainQuad> quads) {
      Map<AffineMergeProbe.Key, List<AffineMergeProbe.Cell>> groups = new HashMap<>();

      for (TerrainQuad q : quads) {
         AffineMergeProbe.Cell cell = cellOf(q);
         if (cell != null) {
            int axis = planeAxis(q.facing());
            int axisA = axis == 0 ? 1 : 0;
            int axisB = axis == 2 ? 1 : 2;
            groups.computeIfAbsent(
                  new AffineMergeProbe.Key(
                     q.facing(),
                     Math.round(component(q.v0(), axis)),
                     q.alphaCutoffIndex(),
                     q.mip(),
                     quant(minU(q)),
                     quant(minV(q)),
                     quant(maxU(q)),
                     quant(maxV(q)),
                     orientation(q, axisA, axisB)
                  ),
                  k -> new ArrayList<>()
               )
               .add(cell);
         }
      }

      long consistent = 0L;
      long affine = 0L;
      long cells = 0L;

      for (List<AffineMergeProbe.Cell> group : groups.values()) {
         cells += group.size();
         consistent += sweep(group, false);
         affine += sweep(group, true);
      }

      return new long[]{consistent, affine, cells};
   }

   private static int sweep(List<AffineMergeProbe.Cell> group, boolean requireAffine) {
      Map<Long, AffineMergeProbe.Cell> grid = new HashMap<>(group.size() * 2);

      for (AffineMergeProbe.Cell c : group) {
         grid.put(pack(c.a(), c.b()), c);
      }

      HashSet<Long> used = new HashSet<>(group.size() * 2);
      List<AffineMergeProbe.Cell> sorted = new ArrayList<>(group);
      sorted.sort((x, y) -> x.b() != y.b() ? Integer.compare(x.b(), y.b()) : Integer.compare(x.a(), y.a()));
      int rectangles = 0;

      for (AffineMergeProbe.Cell c : sorted) {
         if (!used.contains(pack(c.a(), c.b()))) {
            int width = 1;

            while (width < 16 && free(grid, used, c.a() + width, c.b()) && latticeOk(grid, c.a(), c.b(), width + 1, 1, requireAffine)) {
               width++;
            }

            width = TerrainVertexCodec.largestRepeat(width);

            int height;
            label63:
            for (height = 1; height < 16; height++) {
               for (int i = 0; i < width; i++) {
                  if (!free(grid, used, c.a() + i, c.b() + height)) {
                     break label63;
                  }
               }

               if (!latticeOk(grid, c.a(), c.b(), width, height + 1, requireAffine)) {
                  break;
               }
            }

            height = TerrainVertexCodec.largestRepeat(height);

            for (int j = 0; j < height; j++) {
               for (int i = 0; i < width; i++) {
                  used.add(pack(c.a() + i, c.b() + j));
               }
            }

            rectangles++;
         }
      }

      return rectangles;
   }

   private static boolean free(Map<Long, AffineMergeProbe.Cell> grid, Set<Long> used, int a, int b) {
      long k = pack(a, b);
      return grid.containsKey(k) && !used.contains(k);
   }

   private static boolean latticeOk(Map<Long, AffineMergeProbe.Cell> grid, int baseA, int baseB, int w, int h, boolean requireAffine) {
      int stride = w + 1;
      int[] lattice = new int[stride * (h + 1) * 5];
      boolean[] set = new boolean[stride * (h + 1)];

      for (int j = 0; j < h; j++) {
         for (int i = 0; i < w; i++) {
            AffineMergeProbe.Cell cell = grid.get(pack(baseA + i, baseB + j));
            if (cell == null) {
               return false;
            }

            for (int da = 0; da < 2; da++) {
               for (int db = 0; db < 2; db++) {
                  int point = (j + db) * stride + i + da;
                  int src = (da * 2 + db) * 5;
                  int dst = point * 5;
                  if (set[point]) {
                     for (int ch = 0; ch < 5; ch++) {
                        if (lattice[dst + ch] != cell.corners()[src + ch]) {
                           return false;
                        }
                     }
                  } else {
                     set[point] = true;
                     System.arraycopy(cell.corners(), src, lattice, dst, 5);
                  }
               }
            }
         }
      }

      if (!requireAffine) {
         return true;
      }

      for (int ch = 0; ch < 5; ch++) {
         int v00 = lattice[ch];
         int du = lattice[5 + ch] - v00;
         int dv = lattice[stride * 5 + ch] - v00;

         for (int j = 0; j <= h; j++) {
            for (int i = 0; i <= w; i++) {
               if (lattice[(j * stride + i) * 5 + ch] != v00 + i * du + j * dv) {
                  return false;
               }
            }
         }
      }

      return true;
   }

   private static AffineMergeProbe.Cell cellOf(TerrainQuad q) {
      if (!q.translucent() && q.facing() != QuadFacing.UNASSIGNED) {
         int axis = planeAxis(q.facing());
         int axisA = axis == 0 ? 1 : 0;
         int axisB = axis == 2 ? 1 : 2;
         float planeF = component(q.v0(), axis);
         if (!integral(planeF)) {
            return null;
         }

         float minA = Float.MAX_VALUE;
         float maxA = -Float.MAX_VALUE;
         float minB = Float.MAX_VALUE;
         float maxB = -Float.MAX_VALUE;

         for (int i = 0; i < 4; i++) {
            TerrainVertex v = q.vertex(i);
            if (!near(component(v, axis), planeF)) {
               return null;
            }

            minA = Math.min(minA, component(v, axisA));
            maxA = Math.max(maxA, component(v, axisA));
            minB = Math.min(minB, component(v, axisB));
            maxB = Math.max(maxB, component(v, axisB));
         }

         if (unitSpan(minA, maxA) && unitSpan(minB, maxB)) {
            int baseA = Math.round(minA);
            int baseB = Math.round(minB);
            int[] corners = new int[20];
            boolean[] seen = new boolean[4];

            for (int i = 0; i < 4; i++) {
               TerrainVertex v = q.vertex(i);
               int da = Math.round(component(v, axisA)) > baseA ? 1 : 0;
               int db = Math.round(component(v, axisB)) > baseB ? 1 : 0;
               int slot = da * 2 + db;
               if (seen[slot]) {
                  return null;
               }

               seen[slot] = true;
               int base = slot * 5;
               int color = v.colorAbgr();
               corners[base] = color & 0xFF;
               corners[base + 1] = color >> 8 & 0xFF;
               corners[base + 2] = color >> 16 & 0xFF;
               corners[base + 3] = v.blockLight();
               corners[base + 4] = v.skyLight();
            }

            return new AffineMergeProbe.Cell(baseA, baseB, corners);
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private static int orientation(TerrainQuad q, int axisA, int axisB) {
      TerrainVertex origin = q.v0();
      float a0 = component(origin, axisA);
      float b0 = component(origin, axisB);
      TerrainVertex alongA = null;
      TerrainVertex alongB = null;

      for (int i = 1; i < 4; i++) {
         TerrainVertex o = q.vertex(i);
         boolean sameA = near(component(o, axisA), a0);
         boolean sameB = near(component(o, axisB), b0);
         if (!sameA && sameB) {
            alongA = o;
         } else if (sameA && !sameB) {
            alongB = o;
         }
      }

      if (alongA != null && alongB != null) {
         float signA = component(alongA, axisA) > a0 ? 1.0F : -1.0F;
         float signB = component(alongB, axisB) > b0 ? 1.0F : -1.0F;
         float duA = (alongA.u() - origin.u()) * signA;
         float dvA = (alongA.v() - origin.v()) * signA;
         float duB = (alongB.u() - origin.u()) * signB;
         float dvB = (alongB.v() - origin.v()) * signB;
         boolean uAlongB = Math.abs(duB) > Math.abs(duA);
         float du = uAlongB ? duB : duA;
         float dv = uAlongB ? dvA : dvB;
         return du != 0.0F && dv != 0.0F ? (uAlongB ? 1 : 0) | (du < 0.0F ? 2 : 0) | (dv < 0.0F ? 4 : 0) : -1;
      } else {
         return -1;
      }
   }

   private static int planeAxis(QuadFacing f) {
      return switch (f) {
         case POS_X, NEG_X -> 0;
         case POS_Y, NEG_Y -> 1;
         case POS_Z, NEG_Z -> 2;
         case UNASSIGNED -> -1;
      };
   }

   private static float component(TerrainVertex v, int axis) {
      return axis == 0 ? v.x() : (axis == 1 ? v.y() : v.z());
   }

   private static boolean near(float a, float b) {
      return Math.abs(a - b) <= 1.0E-4F;
   }

   private static boolean integral(float f) {
      return Math.abs(f - Math.round(f)) <= 1.0E-4F;
   }

   private static boolean unitSpan(float min, float max) {
      return integral(min) && Math.abs(max - min - 1.0F) <= 1.0E-4F;
   }

   private static long pack(long a, long b) {
      return (a & 4294967295L) << 32 | b & 4294967295L;
   }

   private static int quant(float uv) {
      return Math.round(uv * 32768.0F);
   }

   private static float minU(TerrainQuad q) {
      return Math.min(Math.min(q.v0().u(), q.v1().u()), Math.min(q.v2().u(), q.v3().u()));
   }

   private static float maxU(TerrainQuad q) {
      return Math.max(Math.max(q.v0().u(), q.v1().u()), Math.max(q.v2().u(), q.v3().u()));
   }

   private static float minV(TerrainQuad q) {
      return Math.min(Math.min(q.v0().v(), q.v1().v()), Math.min(q.v2().v(), q.v3().v()));
   }

   private static float maxV(TerrainQuad q) {
      return Math.max(Math.max(q.v0().v(), q.v1().v()), Math.max(q.v2().v(), q.v3().v()));
   }

   private record Cell(int a, int b, int[] corners) {
   }

   private record Key(QuadFacing facing, int plane, int cutoff, boolean mip, int u0, int v0, int u1, int v1, int orient) {
   }
}
