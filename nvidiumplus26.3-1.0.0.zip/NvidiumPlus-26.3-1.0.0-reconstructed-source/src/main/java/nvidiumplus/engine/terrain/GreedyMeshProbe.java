package nvidiumplus.engine.terrain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;
import nvidiumplus.engine.NvidiumPlusLog;

public final class GreedyMeshProbe {
   private static final LongAdder SECTIONS = new LongAdder();
   private static final LongAdder QUADS_IN = new LongAdder();
   private static final LongAdder ELIGIBLE = new LongAdder();
   private static final LongAdder MERGED = new LongAdder();
   private static final LongAdder SKIP_TRANSLUCENT = new LongAdder();
   private static final LongAdder SKIP_UNASSIGNED = new LongAdder();
   private static final LongAdder SKIP_NON_UNIT = new LongAdder();
   private static final LongAdder SKIP_NON_UNIFORM = new LongAdder();
   private static final LongAdder LIT_ELIGIBLE = new LongAdder();
   private static final LongAdder LIT_MERGED = new LongAdder();
   private static final LongAdder SHIPPED_OUT = new LongAdder();
   private static final LongAdder AFFINE_ELIGIBLE = new LongAdder();
   private static final LongAdder CONSISTENT_MERGED = new LongAdder();
   private static final LongAdder AFFINE_MERGED = new LongAdder();
   private static final LongAdder WATER_TOPS = new LongAdder();
   private static final LongAdder WATER_UNDERSIDES = new LongAdder();
   private static final LongAdder WATER_UNIFORM = new LongAdder();
   private static final LongAdder WATER_MERGED = new LongAdder();
   private static final LongAdder WET_SECTIONS = new LongAdder();
   private static final LongAdder PLANE_PURE_SECTIONS = new LongAdder();
   private static final LongAdder CUTOUT_QUADS = new LongAdder();
   private static final LongAdder CUTOUT_PAIRS = new LongAdder();
   private static final LongAdder CUTOUT_MIP_PAIRS = new LongAdder();
   private static final AtomicLong NANOS = new AtomicLong();
   private static final long REPORT_EVERY = 2000L;
   private static final float EPS = 1.0E-4F;

   private GreedyMeshProbe() {
   }

   public static boolean enabled() {
      return Boolean.getBoolean("nvidiumplus.probe.greedy");
   }

   public static void observe(List<TerrainQuad> quads) {
      if (enabled() && !quads.isEmpty()) {
         long t0 = System.nanoTime();

         GreedyMeshProbe.Result r;
         try {
            r = measure(quads);
         } catch (Throwable t) {
            return;
         }

         try {
            SHIPPED_OUT.add(GreedyMesher.merge(quads).size());
            long[] affine = AffineMergeProbe.measure(quads);
            CONSISTENT_MERGED.add(affine[0]);
            AFFINE_MERGED.add(affine[1]);
            AFFINE_ELIGIBLE.add(affine[2]);
            long[] water = waterCensus(quads);
            WATER_TOPS.add(water[0]);
            WATER_UNDERSIDES.add(water[1]);
            WATER_UNIFORM.add(water[2]);
            WATER_MERGED.add(water[3]);
            if (water[4] > 0L) {
               WET_SECTIONS.increment();
               if (water[0] + water[1] >= water[4]) {
                  PLANE_PURE_SECTIONS.increment();
               }
            }

            long[] cutout = cutoutInteriorCensus(quads);
            CUTOUT_QUADS.add(cutout[0]);
            CUTOUT_PAIRS.add(cutout[1]);
            CUTOUT_MIP_PAIRS.add(cutout[2]);
         } catch (Throwable t) {
            return;
         }

         NANOS.addAndGet(System.nanoTime() - t0);
         QUADS_IN.add(r.quadsIn());
         ELIGIBLE.add(r.eligible());
         MERGED.add(r.merged());
         SKIP_TRANSLUCENT.add(r.skippedTranslucent());
         SKIP_UNASSIGNED.add(r.skippedUnassigned());
         SKIP_NON_UNIT.add(r.skippedNonUnit());
         SKIP_NON_UNIFORM.add(r.skippedNonUniform());
         LIT_ELIGIBLE.add(r.litEligible());
         LIT_MERGED.add(r.litMerged());
         SECTIONS.increment();
         if (SECTIONS.sum() % 2000L == 0L) {
            NvidiumPlusLog.LOGGER.info(report());
         }
      }
   }

   public static String report() {
      long quads = QUADS_IN.sum();
      long eligible = ELIGIBLE.sum();
      long merged = MERGED.sum();
      if (quads == 0L) {
         return "NvidiumPlus greedy probe: no quads seen yet";
      }

      long after = merged + (quads - eligible);
      double ofAll = 100.0 * (quads - after) / quads;
      double ofEligible = eligible == 0L ? 0.0 : 100.0 * (eligible - merged) / eligible;
      long sections = Math.max(1L, SECTIONS.sum());
      long litEligible = LIT_ELIGIBLE.sum();
      long litMerged = LIT_MERGED.sum();
      long litAfter = litMerged + (quads - litEligible);
      double litOfAll = 100.0 * (quads - litAfter) / quads;
      long shipped = SHIPPED_OUT.sum();
      double shippedOfAll = 100.0 * (quads - shipped) / quads;
      long affineEligible = AFFINE_ELIGIBLE.sum();
      long consistentAfter = CONSISTENT_MERGED.sum() + (quads - affineEligible);
      double consistentOfAll = 100.0 * (quads - consistentAfter) / quads;
      long affineAfter = AFFINE_MERGED.sum() + (quads - affineEligible);
      double affineOfAll = 100.0 * (quads - affineAfter) / quads;
      String agreement = shipped == after ? "model agrees" : String.format("MODEL DISAGREES by %d quads - trust the shipped column", after - shipped);
      long waterTops = WATER_TOPS.sum();
      long waterUndersides = WATER_UNDERSIDES.sum();
      long waterCells = waterTops + waterUndersides;
      long waterMerged = WATER_MERGED.sum();
      long translucentQuads = SKIP_TRANSLUCENT.sum();
      double waterOfTranslucent = translucentQuads == 0L ? 0.0 : 100.0 * (waterCells - waterMerged) / translucentQuads;
      double waterOfAll = 100.0 * (waterCells - waterMerged) / quads;
      long cutoutQuads = CUTOUT_QUADS.sum();
      long cutoutPairs = CUTOUT_PAIRS.sum();
      long cutoutMipPairs = CUTOUT_MIP_PAIRS.sum();
      long cutoutRemovable = cutoutPairs * 2L;
      double cutoutOfCutout = cutoutQuads == 0L ? 0.0 : 100.0 * cutoutRemovable / cutoutQuads;
      double cutoutOfAll = 100.0 * cutoutRemovable / quads;
      return String.format(
         "NvidiumPlus greedy probe: %d sections, %d quads -> %d SHIPPED (%.1f%% fewer overall); model says %d (%.1f%% overall, %.1f%% of the %d eligible, %s). Not eligible: translucent %d, unassigned %d, not a unit face %d, corners disagree %d. IF LIGHTING WERE IN THE SHADER: %d eligible -> %d (%.1f%% fewer overall). FREE CEILINGS over %d cells: single-valued lattice -> %d (%.1f%% overall), AFFINE (exact, no shader work) -> %d (%.1f%% overall). TRANSLUCENT FLAT WATER over %d cells (%d tops, %d undersides, %d uniform) -> %d rectangles (%.1f%% fewer of translucent, %.1f%% fewer overall), PLANE-PURE sections %d of %d wet. CUTOUT INTERIOR PAIRS over %d cutout quads: %d pairs = %d quads removable (%.1f%% of cutout, %.1f%% of all), mipped %d pairs = %d quads. Cost %.2f ms/section",
         sections,
         quads,
         shipped,
         shippedOfAll,
         after,
         ofAll,
         ofEligible,
         eligible,
         agreement,
         translucentQuads,
         SKIP_UNASSIGNED.sum(),
         SKIP_NON_UNIT.sum(),
         SKIP_NON_UNIFORM.sum(),
         litEligible,
         litAfter,
         litOfAll,
         affineEligible,
         consistentAfter,
         consistentOfAll,
         affineAfter,
         affineOfAll,
         waterCells,
         waterTops,
         waterUndersides,
         WATER_UNIFORM.sum(),
         waterMerged,
         waterOfTranslucent,
         waterOfAll,
         PLANE_PURE_SECTIONS.sum(),
         WET_SECTIONS.sum(),
         cutoutQuads,
         cutoutPairs,
         cutoutRemovable,
         cutoutOfCutout,
         cutoutOfAll,
         cutoutMipPairs,
         cutoutMipPairs * 2L,
         NANOS.get() / 1000000.0 / sections
      );
   }

   public static GreedyMeshProbe.Result measure(List<TerrainQuad> quads) {
      int translucent = 0;
      int unassigned = 0;
      int nonUnit = 0;
      int nonUniform = 0;
      Map<GreedyMeshProbe.Key, List<long[]>> cells = new HashMap<>();

      for (TerrainQuad q : quads) {
         if (q.translucent()) {
            translucent++;
         } else if (q.facing() == QuadFacing.UNASSIGNED) {
            unassigned++;
         } else if (!uniform(q)) {
            nonUniform++;
         } else {
            long[] cell = unitCell(q);
            if (cell == null) {
               nonUnit++;
            } else {
               TerrainVertex a = q.v0();
               GreedyMeshProbe.Key key = new GreedyMeshProbe.Key(
                  q.facing(),
                  (int)cell[2],
                  q.alphaCutoffIndex(),
                  q.mip(),
                  a.colorAbgr(),
                  a.blockLight(),
                  a.skyLight(),
                  quant(minU(q)),
                  quant(minV(q)),
                  quant(maxU(q)),
                  quant(maxV(q))
               );
               cells.computeIfAbsent(key, k -> new ArrayList<>()).add(cell);
            }
         }
      }

      int eligible = 0;
      int merged = 0;

      for (List<long[]> group : cells.values()) {
         eligible += group.size();
         merged += greedyRectangles(group);
      }

      Map<GreedyMeshProbe.LitKey, List<long[]>> litCells = new HashMap<>();

      for (TerrainQuad q : quads) {
         if (!q.translucent() && q.facing() != QuadFacing.UNASSIGNED) {
            long[] cell = unitCell(q);
            if (cell != null) {
               GreedyMeshProbe.LitKey key = new GreedyMeshProbe.LitKey(
                  q.facing(), (int)cell[2], q.alphaCutoffIndex(), q.mip(), quant(minU(q)), quant(minV(q)), quant(maxU(q)), quant(maxV(q))
               );
               litCells.computeIfAbsent(key, k -> new ArrayList<>()).add(cell);
            }
         }
      }

      int litEligible = 0;
      int litMerged = 0;

      for (List<long[]> group : litCells.values()) {
         litEligible += group.size();
         litMerged += greedyRectangles(group);
      }

      return new GreedyMeshProbe.Result(quads.size(), eligible, merged, translucent, unassigned, nonUnit, nonUniform, litEligible, litMerged);
   }

   private static long[] waterCensus(List<TerrainQuad> quads) {
      long translucent = 0L;
      long tops = 0L;
      long undersides = 0L;
      long uniformCells = 0L;
      Map<GreedyMeshProbe.WaterKey, List<long[]>> groups = new HashMap<>();

      for (TerrainQuad q : quads) {
         if (q.translucent()) {
            translucent++;
            if (q.facing() == QuadFacing.POS_Y || q.facing() == QuadFacing.NEG_Y) {
               long[] cell = flatCell(q);
               if (cell != null) {
                  if (q.facing() == QuadFacing.POS_Y) {
                     tops++;
                  } else {
                     undersides++;
                  }

                  if (uniform(q)) {
                     uniformCells++;
                  }

                  GreedyMeshProbe.WaterKey key = new GreedyMeshProbe.WaterKey(
                     q.facing(), (int)cell[2], q.alphaCutoffIndex(), q.mip(), quant(minU(q)), quant(minV(q)), quant(maxU(q)), quant(maxV(q)), orientation(q)
                  );
                  groups.computeIfAbsent(key, k -> new ArrayList<>()).add(cell);
               }
            }
         }
      }

      long rectangles = 0L;

      for (List<long[]> group : groups.values()) {
         rectangles += greedyRectangles(group);
      }

      return new long[]{tops, undersides, uniformCells, rectangles, translucent};
   }

   private static long[] cutoutInteriorCensus(List<TerrainQuad> quads) {
      long cutoutQuads = 0L;
      Map<GreedyMeshProbe.BoundaryKey, int[]> boundaries = new HashMap<>();

      for (TerrainQuad q : quads) {
         if (!q.translucent() && q.alphaCutoffIndex() != 0) {
            cutoutQuads++;
            long[] cell = unitCell(q);
            if (cell != null) {
               int axis = switch (q.facing()) {
                  case POS_X, NEG_X -> 0;
                  case POS_Y, NEG_Y -> 1;
                  case POS_Z, NEG_Z -> 2;
                  case UNASSIGNED -> -1;
               };
               boolean positive = q.facing() == QuadFacing.POS_X || q.facing() == QuadFacing.POS_Y || q.facing() == QuadFacing.POS_Z;
               int[] counts = boundaries.computeIfAbsent(new GreedyMeshProbe.BoundaryKey(axis, (int)cell[2], (int)cell[0], (int)cell[1]), k -> new int[4]);
               counts[positive ? 0 : 1]++;
               if (q.mip()) {
                  counts[positive ? 2 : 3]++;
               }
            }
         }
      }

      long pairs = 0L;
      long mipPairs = 0L;

      for (int[] c : boundaries.values()) {
         pairs += Math.min(c[0], c[1]);
         mipPairs += Math.min(c[2], c[3]);
      }

      return new long[]{cutoutQuads, pairs, mipPairs};
   }

   private static int greedyRectangles(List<long[]> cells) {
      HashSet<Long> grid = new HashSet<>(cells.size() * 2);

      for (long[] c : cells) {
         grid.add(pack(c[0], c[1]));
      }

      HashSet<Long> used = new HashSet<>(cells.size() * 2);
      List<long[]> sorted = new ArrayList<>(cells);
      sorted.sort((x, y) -> x[1] != y[1] ? Long.compare(x[1], y[1]) : Long.compare(x[0], y[0]));
      int rectangles = 0;

      for (long[] c : sorted) {
         long a = c[0];
         long b = c[1];
         if (!used.contains(pack(a, b))) {
            int width = 1;

            while (width < 16 && grid.contains(pack(a + width, b)) && !used.contains(pack(a + width, b))) {
               width++;
            }

            width = TerrainVertexCodec.largestRepeat(width);

            int height;
            label62:
            for (height = 1; height < 16; height++) {
               for (int i = 0; i < width; i++) {
                  long probe = pack(a + i, b + height);
                  if (!grid.contains(probe) || used.contains(probe)) {
                     break label62;
                  }
               }
            }

            height = TerrainVertexCodec.largestRepeat(height);

            for (int j = 0; j < height; j++) {
               for (int i = 0; i < width; i++) {
                  used.add(pack(a + i, b + j));
               }
            }

            rectangles++;
         }
      }

      return rectangles;
   }

   private static long pack(long a, long b) {
      return (a & 4294967295L) << 32 | b & 4294967295L;
   }

   private static boolean uniform(TerrainQuad q) {
      TerrainVertex a = q.v0();

      for (int i = 1; i < 4; i++) {
         TerrainVertex o = q.vertex(i);
         if (o.colorAbgr() != a.colorAbgr() || o.blockLight() != a.blockLight() || o.skyLight() != a.skyLight()) {
            return false;
         }
      }

      return true;
   }

   private static long[] unitCell(TerrainQuad q) {
      int axis = switch (q.facing()) {
         case POS_X, NEG_X -> 0;
         case POS_Y, NEG_Y -> 1;
         case POS_Z, NEG_Z -> 2;
         case UNASSIGNED -> -1;
      };
      if (axis < 0) {
         return null;
      }

      float planeF = component(q.v0(), axis);
      float minA = Float.MAX_VALUE;
      float maxA = -Float.MAX_VALUE;
      float minB = Float.MAX_VALUE;
      float maxB = -Float.MAX_VALUE;
      int axisA = axis == 0 ? 1 : 0;
      int axisB = axis == 2 ? 1 : 2;

      for (int i = 0; i < 4; i++) {
         TerrainVertex v = q.vertex(i);
         if (!near(component(v, axis), planeF)) {
            return null;
         }

         float ca = component(v, axisA);
         float cb = component(v, axisB);
         minA = Math.min(minA, ca);
         maxA = Math.max(maxA, ca);
         minB = Math.min(minB, cb);
         maxB = Math.max(maxB, cb);
      }

      return isUnitSpan(minA, maxA) && isUnitSpan(minB, maxB) && isIntegral(planeF) ? new long[]{Math.round(minA), Math.round(minB), Math.round(planeF)} : null;
   }

   private static long[] flatCell(TerrainQuad q) {
      float planeF = q.v0().y();
      float minA = Float.MAX_VALUE;
      float maxA = -Float.MAX_VALUE;
      float minB = Float.MAX_VALUE;
      float maxB = -Float.MAX_VALUE;

      for (int i = 0; i < 4; i++) {
         TerrainVertex v = q.vertex(i);
         if (!near(v.y(), planeF)) {
            return null;
         }

         minA = Math.min(minA, v.x());
         maxA = Math.max(maxA, v.x());
         minB = Math.min(minB, v.z());
         maxB = Math.max(maxB, v.z());
      }

      return isUnitSpan(minA, maxA) && isUnitSpan(minB, maxB) ? new long[]{Math.round(minA), Math.round(minB), quant(planeF)} : null;
   }

   private static int orientation(TerrainQuad q) {
      TerrainVertex origin = q.v0();
      float a0 = origin.x();
      float b0 = origin.z();
      TerrainVertex alongA = null;
      TerrainVertex alongB = null;

      for (int i = 1; i < 4; i++) {
         TerrainVertex o = q.vertex(i);
         boolean sameA = near(o.x(), a0);
         boolean sameB = near(o.z(), b0);
         if (!sameA && sameB) {
            alongA = o;
         } else if (sameA && !sameB) {
            alongB = o;
         }
      }

      if (alongA != null && alongB != null) {
         float signA = alongA.x() > a0 ? 1.0F : -1.0F;
         float signB = alongB.z() > b0 ? 1.0F : -1.0F;
         float duA = (alongA.u() - origin.u()) * signA;
         float dvA = (alongA.v() - origin.v()) * signA;
         float duB = (alongB.u() - origin.u()) * signB;
         float dvB = (alongB.v() - origin.v()) * signB;
         boolean uAlongB = Math.abs(duB) > Math.abs(duA);
         float du = uAlongB ? duB : duA;
         float dv = uAlongB ? dvA : dvB;
         return du != 0.0F && dv != 0.0F ? (uAlongB ? 1 : 0) | (du < 0.0F ? 2 : 0) | (dv < 0.0F ? 4 : 0) : -1;
      } else {
         return -1;
      }
   }

   private static float component(TerrainVertex v, int axis) {
      return axis == 0 ? v.x() : (axis == 1 ? v.y() : v.z());
   }

   private static boolean near(float a, float b) {
      return Math.abs(a - b) <= 1.0E-4F;
   }

   private static boolean isIntegral(float f) {
      return Math.abs(f - Math.round(f)) <= 1.0E-4F;
   }

   private static boolean isUnitSpan(float min, float max) {
      return isIntegral(min) && Math.abs(max - min - 1.0F) <= 1.0E-4F;
   }

   private static int quant(float uv) {
      return Math.round(uv * 32768.0F);
   }

   private static float minU(TerrainQuad q) {
      return Math.min(Math.min(q.v0().u(), q.v1().u()), Math.min(q.v2().u(), q.v3().u()));
   }

   private static float maxU(TerrainQuad q) {
      return Math.max(Math.max(q.v0().u(), q.v1().u()), Math.max(q.v2().u(), q.v3().u()));
   }

   private static float minV(TerrainQuad q) {
      return Math.min(Math.min(q.v0().v(), q.v1().v()), Math.min(q.v2().v(), q.v3().v()));
   }

   private static float maxV(TerrainQuad q) {
      return Math.max(Math.max(q.v0().v(), q.v1().v()), Math.max(q.v2().v(), q.v3().v()));
   }

   private record BoundaryKey(int axis, int plane, int a, int b) {
   }

   private record Key(QuadFacing facing, int plane, int cutoff, boolean mip, int colorAbgr, int blockLight, int skyLight, int u0, int v0, int u1, int v1) {
   }

   private record LitKey(QuadFacing facing, int plane, int cutoff, boolean mip, int u0, int v0, int u1, int v1) {
   }

   public record Result(
      int quadsIn,
      int eligible,
      int merged,
      int skippedTranslucent,
      int skippedUnassigned,
      int skippedNonUnit,
      int skippedNonUniform,
      int litEligible,
      int litMerged
   ) {
      public double reductionOfAll() {
         return this.quadsIn == 0 ? 0.0 : (double)(this.quadsIn - (this.merged + this.quadsIn - this.eligible)) / this.quadsIn;
      }

      public double reductionOfEligible() {
         return this.eligible == 0 ? 0.0 : (double)(this.eligible - this.merged) / this.eligible;
      }
   }

   private record WaterKey(QuadFacing facing, int plane, int cutoff, boolean mip, int u0, int v0, int u1, int v1, int orient) {
   }
}
