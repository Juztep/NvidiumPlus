package nvidiumplus.engine.terrain;

import java.util.Objects;

public record TerrainQuad(
   QuadFacing facing,
   boolean translucent,
   int alphaCutoffIndex,
   boolean mip,
   TerrainVertex v0,
   TerrainVertex v1,
   TerrainVertex v2,
   TerrainVertex v3,
   int repeatU,
   int repeatV
) {
   public TerrainQuad(
      QuadFacing facing, boolean translucent, int alphaCutoffIndex, boolean mip, TerrainVertex v0, TerrainVertex v1, TerrainVertex v2, TerrainVertex v3
   ) {
      this(facing, translucent, alphaCutoffIndex, mip, v0, v1, v2, v3, 1, 1);
   }

   public TerrainQuad(
      QuadFacing facing,
      boolean translucent,
      int alphaCutoffIndex,
      boolean mip,
      TerrainVertex v0,
      TerrainVertex v1,
      TerrainVertex v2,
      TerrainVertex v3,
      int repeatU,
      int repeatV
   ) {
      Objects.requireNonNull(facing, "facing");
      Objects.requireNonNull(v0, "v0");
      Objects.requireNonNull(v1, "v1");
      Objects.requireNonNull(v2, "v2");
      Objects.requireNonNull(v3, "v3");
      if (alphaCutoffIndex >= 0 && alphaCutoffIndex <= 2) {
         this.facing = facing;
         this.translucent = translucent;
         this.alphaCutoffIndex = alphaCutoffIndex;
         this.mip = mip;
         this.v0 = v0;
         this.v1 = v1;
         this.v2 = v2;
         this.v3 = v3;
         this.repeatU = repeatU;
         this.repeatV = repeatV;
      } else {
         throw new IllegalArgumentException("alphaCutoffIndex must be 0..2, got " + alphaCutoffIndex);
      }
   }

   public boolean merged() {
      return this.repeatU != 1 || this.repeatV != 1;
   }

   public TerrainVertex vertex(int i) {
      return switch (i) {
         case 0 -> this.v0;
         case 1 -> this.v1;
         case 2 -> this.v2;
         case 3 -> this.v3;
         default -> throw new IndexOutOfBoundsException("quad vertex index " + i);
      };
   }
}
