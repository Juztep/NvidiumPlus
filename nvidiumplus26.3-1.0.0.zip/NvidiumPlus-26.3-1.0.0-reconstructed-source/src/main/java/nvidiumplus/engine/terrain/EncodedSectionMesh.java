package nvidiumplus.engine.terrain;

import java.nio.ByteBuffer;

public final class EncodedSectionMesh {
   private final ByteBuffer geometry;
   private final int quadCount;
   private final short[] offsets;
   private final int[] bucketStarts;
   private final int minX;
   private final int minY;
   private final int minZ;
   private final int sizeX;
   private final int sizeY;
   private final int sizeZ;

   EncodedSectionMesh(ByteBuffer geometry, int quadCount, short[] offsets, int[] bucketStarts, int minX, int minY, int minZ, int sizeX, int sizeY, int sizeZ) {
      this.geometry = geometry;
      this.quadCount = quadCount;
      this.offsets = offsets;
      this.bucketStarts = bucketStarts;
      this.minX = minX;
      this.minY = minY;
      this.minZ = minZ;
      this.sizeX = sizeX;
      this.sizeY = sizeY;
      this.sizeZ = sizeZ;
   }

   public ByteBuffer geometry() {
      return this.geometry.duplicate().order(this.geometry.order());
   }

   public int quadCount() {
      return this.quadCount;
   }

   public int geometryBytes() {
      return this.quadCount * 64;
   }

   public short[] offsets() {
      return (short[])this.offsets.clone();
   }

   public int bucketStart(int bucket) {
      return this.bucketStarts[bucket];
   }

   public int bucketCount(int bucket) {
      return Short.toUnsignedInt(this.offsets[bucket]);
   }

   public int translucentCount() {
      return Short.toUnsignedInt(this.offsets[7]);
   }

   public int minX() {
      return this.minX;
   }

   public int minY() {
      return this.minY;
   }

   public int minZ() {
      return this.minZ;
   }

   public int sizeX() {
      return this.sizeX;
   }

   public int sizeY() {
      return this.sizeY;
   }

   public int sizeZ() {
      return this.sizeZ;
   }
}
