package nvidiumplus.engine.terrain;

import java.util.List;

public final class QuadFacingBuckets {
   public static final int BUCKET_COUNT = 7;
   public static final int OFFSETS_LENGTH = 8;
   public static final int TRANSLUCENT_SLOT = 7;

   private QuadFacingBuckets() {
   }

   public static int[] countSolidByBucket(List<TerrainQuad> quads) {
      int[] counts = new int[7];

      for (TerrainQuad quad : quads) {
         if (!quad.translucent()) {
            counts[quad.facing().ordinal()]++;
         }
      }

      return counts;
   }

   public static int[] bucketStarts(int translucentCount, int[] bucketCounts) {
      if (bucketCounts.length != 7) {
         throw new IllegalArgumentException("expected 7 bucket counts");
      }

      int[] starts = new int[7];
      int fr = translucentCount;

      for (int i = 0; i < 7; i++) {
         starts[i] = fr;
         fr += bucketCounts[i];
      }

      return starts;
   }

   public static short[] toOffsets(int translucentCount, int[] bucketCounts) {
      if (bucketCounts.length != 7) {
         throw new IllegalArgumentException("expected 7 bucket counts");
      }

      short[] offsets = new short[8];

      for (int i = 0; i < 7; i++) {
         offsets[i] = toU16(bucketCounts[i], "bucket " + QuadFacing.byIndex(i) + " quad count");
      }

      offsets[7] = toU16(translucentCount, "translucent quad count");
      return offsets;
   }

   static short toU16(int value, String what) {
      if (value >= 0 && value <= 65535) {
         return (short)value;
      } else {
         throw new IllegalArgumentException(what + " must fit u16, got " + value);
      }
   }
}
