package nvidiumplus.engine.terrain;

public enum QuadFacing {
   POS_X,
   POS_Y,
   POS_Z,
   NEG_X,
   NEG_Y,
   NEG_Z,
   UNASSIGNED;

   public static final int COUNT = 7;
   private static final QuadFacing[] VALUES = values();

   public static QuadFacing byIndex(int index) {
      return VALUES[index];
   }

   public boolean visibleFrom(int relChunkX, int relChunkY, int relChunkZ) {
      return switch (this) {
         case POS_X -> relChunkX <= 0;
         case POS_Y -> relChunkY <= 0;
         case POS_Z -> relChunkZ <= 0;
         case NEG_X -> relChunkX >= 0;
         case NEG_Y -> relChunkY >= 0;
         case NEG_Z -> relChunkZ >= 0;
         case UNASSIGNED -> true;
      };
   }
}
