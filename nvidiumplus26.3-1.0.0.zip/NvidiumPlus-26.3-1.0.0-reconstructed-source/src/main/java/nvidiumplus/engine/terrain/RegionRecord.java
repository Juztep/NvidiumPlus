package nvidiumplus.engine.terrain;

import java.nio.ByteBuffer;

public final class RegionRecord {
   public static final int META_SIZE = 16;
   public static final int MAX_TRANSFORMATION_SIZE_BITS = 10;
   public static final int MAX_TRANSFORMATION_COUNT = 1024;

   private RegionRecord() {
   }

   public static long regionBufferBytes(int maxRegions) {
      return maxRegions * 16L;
   }

   public static void write(
      ByteBuffer dst, int rx, int ry, int rz, int localMinX, int localMinY, int localMinZ, int sizeX, int sizeY, int sizeZ, int lastIdx, int transformationId
   ) {
      TerrainVertexCodec.checkOrder(dst);
      checkRange("localMinX", localMinX, 7);
      checkRange("localMinY", localMinY, 3);
      checkRange("localMinZ", localMinZ, 7);
      checkRange("sizeX", sizeX, 7);
      checkRange("sizeY", sizeY, 3);
      checkRange("sizeZ", sizeZ, 7);
      checkRange("lastIdx", lastIdx, 255);
      if (transformationId >= 0 && transformationId < 1024) {
         checkAbs("absolute min section X", ((long)rx << 3) + localMinX);
         checkAbs("absolute min section Y", ((long)ry << 2) + localMinY);
         checkAbs("absolute min section Z", ((long)rz << 3) + localMinZ);
         long size = (long)sizeY << 62 | (long)sizeX << 59 | (long)sizeZ << 56;
         long count = (long)lastIdx << 48;
         long x = (((long)rx << 3) + localMinX & 16777215L) << 24;
         long y = ((long)ry << 2) + localMinY & 16777215L;
         long z = (((long)rz << 3) + localMinZ & 16777215L) << 40;
         long transformation = (long)transformationId << 30;
         dst.putLong(size | count | x | y);
         dst.putLong(z | transformation);
      } else {
         throw new IllegalArgumentException("transformationId out of bounds: " + transformationId);
      }
   }

   public static void fromOccupancy(ByteBuffer dst, boolean[] occupancy, int rx, int ry, int rz, int transformationId) {
      if (occupancy.length != 256) {
         throw new IllegalArgumentException("occupancy must have 256 slots, got " + occupancy.length);
      }

      int minX = Integer.MAX_VALUE;
      int maxX = Integer.MIN_VALUE;
      int minY = Integer.MAX_VALUE;
      int maxY = Integer.MIN_VALUE;
      int minZ = Integer.MAX_VALUE;
      int maxZ = Integer.MIN_VALUE;
      int lastIdx = -1;

      for (int i = 0; i < 256; i++) {
         if (occupancy[i]) {
            int x = i & 7;
            int y = i >>> 6;
            int z = i >>> 3 & 7;
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            minZ = Math.min(minZ, z);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
            maxZ = Math.max(maxZ, z);
            lastIdx = i;
         }
      }

      if (lastIdx < 0) {
         throw new IllegalArgumentException("empty region - write the tombstone instead (RegionManager.java:66-79)");
      }

      write(dst, rx, ry, rz, minX, minY, minZ, maxX - minX, maxY - minY, maxZ - minZ, lastIdx, transformationId);
   }

   public static void writeTombstone(ByteBuffer dst) {
      TerrainVertexCodec.checkOrder(dst);
      dst.putLong(-1L);
      dst.putLong(-1L);
   }

   private static void checkRange(String what, int value, int max) {
      if (value < 0 || value > max) {
         throw new IllegalArgumentException(what + " must be 0.." + max + ", got " + value);
      }
   }

   private static void checkAbs(String what, long value) {
      if (value < -8388608L || value >= 8388608L) {
         throw new IllegalArgumentException(what + " exceeds the signed 24-bit budget: " + value);
      }
   }
}
