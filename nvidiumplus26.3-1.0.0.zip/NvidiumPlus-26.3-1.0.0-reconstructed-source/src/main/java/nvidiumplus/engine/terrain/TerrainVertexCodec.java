package nvidiumplus.engine.terrain;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class TerrainVertexCodec {
   public static final int VERTEX_STRIDE = 16;
   public static final int QUAD_STRIDE = 64;
   public static final int POSITION_MAX_VALUE = 65536;
   public static final int TEXTURE_MAX_VALUE = 32768;
   public static final float MODEL_ORIGIN = 8.0F;
   public static final float MODEL_RANGE = 32.0F;
   public static final float MODEL_SCALE_INV = 2048.0F;
   public static final float MODEL_SCALE = 4.8828125E-4F;
   public static final int LIGHT_MIN = 8;
   public static final int LIGHT_MAX = 248;
   public static final int REPEAT_STEPS = 5;
   public static final int MAX_REPEAT = 16;

   private TerrainVertexCodec() {
   }

   public static int encodePosition(float v) {
      int q = (int)((8.0F + v) * 2048.0F);
      return Math.min(Math.max(q, 0), 65535);
   }

   public static float decodePosition(int q) {
      return (q & 65535) * 4.8828125E-4F - 8.0F;
   }

   public static int encodeUv(float uv) {
      return Math.round(uv * 32768.0F) & 65535;
   }

   public static float decodeUv(int q) {
      return (q & 65535) * 3.0517578E-5F;
   }

   public static int clampLight(int light) {
      return Math.min(Math.max(light & 0xFF, 8), 248);
   }

   public static int materialBits(int alphaCutoffIndex, boolean mip) {
      return materialBits(alphaCutoffIndex, mip, 1, 1);
   }

   public static int materialBits(int alphaCutoffIndex, boolean mip, int repeatU, int repeatV) {
      if (alphaCutoffIndex >= 0 && alphaCutoffIndex <= 2) {
         int pair = log2Repeat(repeatU, "repeatU") * 5 + log2Repeat(repeatV, "repeatV");
         return alphaCutoffIndex & 3 | (mip ? 4 : 0) | pair << 3;
      } else {
         throw new IllegalArgumentException("alphaCutoffIndex must be 0..2, got " + alphaCutoffIndex);
      }
   }

   private static int log2Repeat(int repeat, String what) {
      return switch (repeat) {
         case 1 -> 0;
         case 2 -> 1;
         case 4 -> 2;
         case 8 -> 3;
         case 16 -> 4;
         default -> throw new IllegalArgumentException(what + " must be 1, 2, 4, 8 or 16, got " + repeat);
      };
   }

   public static int largestRepeat(int span) {
      if (span >= 16) {
         return 16;
      } else if (span >= 8) {
         return 8;
      } else if (span >= 4) {
         return 4;
      } else {
         return span >= 2 ? 2 : 1;
      }
   }

   public static int premultiplyColor(int colorAbgr) {
      float brightness = (colorAbgr >>> 24 & 0xFF) / 255.0F;
      int r = Math.round((colorAbgr & 0xFF) * brightness);
      int g = Math.round((colorAbgr >>> 8 & 0xFF) * brightness);
      int b = Math.round((colorAbgr >>> 16 & 0xFF) * brightness);
      return r | g << 8 | b << 16;
   }

   public static void encodeVertex(ByteBuffer dst, TerrainVertex v, int materialBits) {
      checkOrder(dst);
      int blockLight = clampLight(v.blockLight());
      int skyLight = clampLight(v.skyLight());
      dst.putInt(encodePosition(v.x()) | encodePosition(v.y()) << 16);
      dst.putInt(encodePosition(v.z()) | (materialBits & 0xFF) << 16 | blockLight << 24);
      dst.putInt(premultiplyColor(v.colorAbgr()) | skyLight << 24);
      dst.putInt(encodeUv(v.u()) | encodeUv(v.v()) << 16);
   }

   public static void encodeQuad(ByteBuffer dst, TerrainQuad quad) {
      int material = materialBits(quad.alphaCutoffIndex(), quad.mip(), quad.repeatU(), quad.repeatV());

      for (int i = 0; i < 4; i++) {
         encodeVertex(dst, quad.vertex(i), material);
      }
   }

   public static TerrainVertexCodec.Decoded decodeVertex(ByteBuffer src) {
      checkOrder(src);
      int i0 = src.getInt();
      int i1 = src.getInt();
      int i2 = src.getInt();
      int i3 = src.getInt();
      return new TerrainVertexCodec.Decoded(
         decodePosition(i0 & 65535),
         decodePosition(i0 >>> 16 & 65535),
         decodePosition(i1 & 65535),
         decodeUv(i3 & 65535),
         decodeUv(i3 >>> 16 & 65535),
         i2 & 0xFF,
         i2 >>> 8 & 0xFF,
         i2 >>> 16 & 0xFF,
         i1 >>> 24 & 0xFF,
         i2 >>> 24 & 0xFF,
         i1 >>> 16 & 3,
         (i1 >>> 16 & 4) != 0
      );
   }

   static void checkOrder(ByteBuffer buffer) {
      if (buffer.order() != ByteOrder.LITTLE_ENDIAN) {
         throw new IllegalArgumentException("Terrain data buffers must be LITTLE_ENDIAN (GPU bit-field layout), got " + buffer.order());
      }
   }

   public record Decoded(
      float x, float y, float z, float u, float v, int red, int green, int blue, int blockLight, int skyLight, int alphaCutoffIndex, boolean mip
   ) {
   }
}
