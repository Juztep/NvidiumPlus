package nvidiumplus.engine.terrain;

public interface ArenaBacking {
   long allocate(long var1);

   default long appendBlock(long sizeBytes) {
      return 0L;
   }
}
