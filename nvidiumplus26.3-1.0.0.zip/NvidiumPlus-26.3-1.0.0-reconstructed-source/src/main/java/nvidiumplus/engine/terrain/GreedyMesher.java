package nvidiumplus.engine.terrain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.LongAdder;

public final class GreedyMesher {
   private static final int MAX_RUN = 16;
   private static final boolean VERIFY = Boolean.getBoolean("nvidiumplus.verifyGreedy");
   private static final LongAdder MERGE_NANOS = new LongAdder();
   private static final LongAdder MERGE_SECTIONS = new LongAdder();
   private static final LongAdder MERGE_QUADS_IN = new LongAdder();
   private static final LongAdder MERGE_QUADS_OUT = new LongAdder();
   private static final LongAdder FAR_QUADS_IN = new LongAdder();
   private static final LongAdder FAR_QUADS_OUT = new LongAdder();
   private static final int CHANNELS = 5;
   private static final ThreadLocal<GreedyMesher.Plane> PLANE = ThreadLocal.withInitial(GreedyMesher.Plane::new);
   private static final float EPS = 1.0E-4F;

   private GreedyMesher() {
   }

   public static String costSummary() {
      long sections = MERGE_SECTIONS.sum();
      return sections == 0L ? "off" : String.format("%.0f us/section over %d", MERGE_NANOS.sum() / 1000.0 / sections, sections);
   }

   public static String quadSummary() {
      long in = MERGE_QUADS_IN.sum();
      if (in == 0L) {
         return "off";
      }

      long far = FAR_QUADS_IN.sum();
      long farOut = FAR_QUADS_OUT.sum();
      return String.format("near %s, far %s", ratio(in - far, MERGE_QUADS_OUT.sum() - farOut), ratio(far, farOut));
   }

   private static String ratio(long in, long out) {
      return in <= 0L ? "none" : String.format("%d->%d (%.1f%% merged)", in, out, 100.0 * (in - out) / in);
   }

   public static List<TerrainQuad> merge(List<TerrainQuad> quads) {
      long t0 = System.nanoTime();

      try {
         List<TerrainQuad> merged = mergeTimed(quads);
         MERGE_QUADS_IN.add(quads.size());
         MERGE_QUADS_OUT.add(merged.size());
         return merged;
      } finally {
         MERGE_NANOS.add(System.nanoTime() - t0);
         MERGE_SECTIONS.increment();
      }
   }

   public static List<TerrainQuad> mergeFar(List<TerrainQuad> quads) {
      List<TerrainQuad> merged = merge(quads);
      FAR_QUADS_IN.add(quads.size());
      FAR_QUADS_OUT.add(merged.size());
      return merged;
   }

   private static List<TerrainQuad> mergeTimed(List<TerrainQuad> quads) {
      Map<GreedyMesher.Key, List<GreedyMesher.Cell>> groups = null;
      List<TerrainQuad> passthrough = new ArrayList<>(quads.size());

      for (TerrainQuad q : quads) {
         GreedyMesher.Cell cell = eligibleCell(q);
         if (cell == null) {
            passthrough.add(q);
         } else {
            if (groups == null) {
               groups = new HashMap<>();
            }

            int axis = planeAxis(q.facing());
            GreedyMesher.Key key = new GreedyMesher.Key(
               q.facing(),
               Math.round(component(q.v0(), axis)),
               q.alphaCutoffIndex(),
               q.mip(),
               quant(minU(q)),
               quant(minV(q)),
               quant(maxU(q)),
               quant(maxV(q)),
               uvOrientation(q, axis == 0 ? 1 : 0, axis == 2 ? 1 : 2)
            );
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(cell);
         }
      }

      if (groups == null) {
         return quads;
      }

      List<TerrainQuad> out = passthrough;

      for (List<GreedyMesher.Cell> group : groups.values()) {
         mergeGroup(group, out);
      }

      return out;
   }

   private static void mergeGroup(List<GreedyMesher.Cell> group, List<TerrainQuad> out) {
      if (group.size() == 1) {
         out.add(group.get(0).quad());
      } else {
         Map<Long, GreedyMesher.Cell> grid = new HashMap<>(group.size() * 2);

         for (GreedyMesher.Cell c : group) {
            grid.put(pack(c.a(), c.b()), c);
         }

         HashSet<Long> used = new HashSet<>(group.size() * 2);
         List<GreedyMesher.Cell> sorted = new ArrayList<>(group);
         sorted.sort((x, y) -> x.b() != y.b() ? Integer.compare(x.b(), y.b()) : Integer.compare(x.a(), y.a()));
         long area = 0L;

         for (GreedyMesher.Cell c : sorted) {
            long here = pack(c.a(), c.b());
            if (!used.contains(here)) {
               int width = 1;
               int height = 1;
               GreedyMesher.Plane plane = PLANE.get();
               if (plane.begin(c)) {
                  while (width < 16) {
                     GreedyMesher.Cell next = freeCell(grid, used, c.a() + width, c.b());
                     if (next == null || !plane.fits(next, width, 0)) {
                        break;
                     }

                     width++;
                  }

                  width = TerrainVertexCodec.largestRepeat(width);

                  label74:
                  while (height < 16) {
                     for (int i = 0; i < width; i++) {
                        GreedyMesher.Cell next = freeCell(grid, used, c.a() + i, c.b() + height);
                        if (next == null || !plane.fits(next, i, height)) {
                           break label74;
                        }
                     }

                     height++;
                  }

                  height = TerrainVertexCodec.largestRepeat(height);
               }

               for (int j = 0; j < height; j++) {
                  for (int i = 0; i < width; i++) {
                     used.add(pack(c.a() + i, c.b() + j));
                  }
               }

               area += (long)width * height;
               out.add(width == 1 && height == 1 ? c.quad() : expand(grid, c.quad(), c.a(), c.b(), width, height));
            }
         }

         if (VERIFY && (area != group.size() || used.size() != group.size())) {
            throw new IllegalStateException(
               "greedy merge did not partition a group of "
                  + group.size()
                  + " faces: rectangles cover "
                  + area
                  + " cells over "
                  + used.size()
                  + " distinct positions"
            );
         }
      }
   }

   private static GreedyMesher.Cell freeCell(Map<Long, GreedyMesher.Cell> grid, Set<Long> used, int a, int b) {
      long k = pack(a, b);
      return used.contains(k) ? null : grid.get(k);
   }

   private static TerrainQuad expand(Map<Long, GreedyMesher.Cell> grid, TerrainQuad q, int baseA, int baseB, int width, int height) {
      int axis = planeAxis(q.facing());
      int axisA = axis == 0 ? 1 : 0;
      int axisB = axis == 2 ? 1 : 2;
      TerrainVertex[] v = new TerrainVertex[4];

      for (int i = 0; i < 4; i++) {
         TerrainVertex s = q.vertex(i);
         boolean highA = Math.round(component(s, axisA)) > baseA;
         boolean highB = Math.round(component(s, axisB)) > baseB;
         float na = highA ? baseA + width : baseA;
         float nb = highB ? baseB + height : baseB;
         TerrainVertex shade = cornerVertex(grid, baseA, baseB, width, height, highA, highB);
         v[i] = withPlaneCoords(withShading(s, shade), axis, axisA, na, axisB, nb);
      }

      boolean uAlongB = (uvOrientation(q, axisA, axisB) & 1) != 0;
      int repeatU = uAlongB ? height : width;
      int repeatV = uAlongB ? width : height;
      return new TerrainQuad(q.facing(), q.translucent(), q.alphaCutoffIndex(), q.mip(), v[0], v[1], v[2], v[3], repeatU, repeatV);
   }

   private static TerrainVertex cornerVertex(Map<Long, GreedyMesher.Cell> grid, int baseA, int baseB, int width, int height, boolean highA, boolean highB) {
      int cellA = baseA + (highA ? width - 1 : 0);
      int cellB = baseB + (highB ? height - 1 : 0);
      GreedyMesher.Cell cell = grid.get(pack(cellA, cellB));
      int slot = (highA ? 1 : 0) * 2 + (highB ? 1 : 0);
      return cell.quad().vertex(cell.vertexAt()[slot]);
   }

   private static TerrainVertex withShading(TerrainVertex geometry, TerrainVertex shade) {
      return geometry == shade
         ? geometry
         : new TerrainVertex(geometry.x(), geometry.y(), geometry.z(), geometry.u(), geometry.v(), shade.colorAbgr(), shade.blockLight(), shade.skyLight());
   }

   private static TerrainVertex withPlaneCoords(TerrainVertex s, int axis, int axisA, float a, int axisB, float b) {
      float x = s.x();
      float y = s.y();
      float z = s.z();
      if (axisA == 0) {
         x = a;
      } else if (axisA == 1) {
         y = a;
      } else {
         z = a;
      }

      if (axisB == 0) {
         x = b;
      } else if (axisB == 1) {
         y = b;
      } else {
         z = b;
      }

      return new TerrainVertex(x, y, z, s.u(), s.v(), s.colorAbgr(), s.blockLight(), s.skyLight());
   }

   private static GreedyMesher.Cell eligibleCell(TerrainQuad q) {
      if (!q.translucent() && q.facing() != QuadFacing.UNASSIGNED) {
         int axis = planeAxis(q.facing());
         float planeF = component(q.v0(), axis);
         int axisA = axis == 0 ? 1 : 0;
         int axisB = axis == 2 ? 1 : 2;
         float minA = Float.MAX_VALUE;
         float maxA = -Float.MAX_VALUE;
         float minB = Float.MAX_VALUE;
         float maxB = -Float.MAX_VALUE;

         for (int i = 0; i < 4; i++) {
            TerrainVertex v = q.vertex(i);
            if (!near(component(v, axis), planeF)) {
               return null;
            }

            minA = Math.min(minA, component(v, axisA));
            maxA = Math.max(maxA, component(v, axisA));
            minB = Math.min(minB, component(v, axisB));
            maxB = Math.max(maxB, component(v, axisB));
         }

         if (!unitSpan(minA, maxA) || !unitSpan(minB, maxB) || !integral(planeF)) {
            return null;
         }

         if (uvOrientation(q, axisA, axisB) < 0) {
            return null;
         }

         int baseA = Math.round(minA);
         int baseB = Math.round(minB);
         int[] corners = new int[20];
         int[] vertexAt = new int[4];
         Arrays.fill(vertexAt, -1);

         for (int i = 0; i < 4; i++) {
            TerrainVertex v = q.vertex(i);
            int da = Math.round(component(v, axisA)) > baseA ? 1 : 0;
            int db = Math.round(component(v, axisB)) > baseB ? 1 : 0;
            int slot = da * 2 + db;
            if (vertexAt[slot] >= 0) {
               return null;
            }

            vertexAt[slot] = i;
            int base = slot * 5;
            int color = v.colorAbgr();
            corners[base] = color & 0xFF;
            corners[base + 1] = color >> 8 & 0xFF;
            corners[base + 2] = color >> 16 & 0xFF;
            corners[base + 3] = v.blockLight();
            corners[base + 4] = v.skyLight();
         }

         return new GreedyMesher.Cell(baseA, baseB, q, corners, vertexAt);
      } else {
         return null;
      }
   }

   private static int uvOrientation(TerrainQuad q, int axisA, int axisB) {
      TerrainVertex origin = q.v0();
      float a0 = component(origin, axisA);
      float b0 = component(origin, axisB);
      TerrainVertex alongA = null;
      TerrainVertex alongB = null;

      for (int i = 1; i < 4; i++) {
         TerrainVertex o = q.vertex(i);
         boolean sameA = near(component(o, axisA), a0);
         boolean sameB = near(component(o, axisB), b0);
         if (!sameA && sameB) {
            alongA = o;
         } else if (sameA && !sameB) {
            alongB = o;
         }
      }

      if (alongA != null && alongB != null) {
         float signA = component(alongA, axisA) > a0 ? 1.0F : -1.0F;
         float signB = component(alongB, axisB) > b0 ? 1.0F : -1.0F;
         float duA = (alongA.u() - origin.u()) * signA;
         float dvA = (alongA.v() - origin.v()) * signA;
         float duB = (alongB.u() - origin.u()) * signB;
         float dvB = (alongB.v() - origin.v()) * signB;
         boolean uAlongB = Math.abs(duB) > Math.abs(duA);
         float du = uAlongB ? duB : duA;
         float dv = uAlongB ? dvA : dvB;
         return du != 0.0F && dv != 0.0F ? (uAlongB ? 1 : 0) | (du < 0.0F ? 2 : 0) | (dv < 0.0F ? 4 : 0) : -1;
      } else {
         return -1;
      }
   }

   private static int planeAxis(QuadFacing f) {
      return switch (f) {
         case POS_X, NEG_X -> 0;
         case POS_Y, NEG_Y -> 1;
         case POS_Z, NEG_Z -> 2;
         case UNASSIGNED -> -1;
      };
   }

   private static float component(TerrainVertex v, int axis) {
      return axis == 0 ? v.x() : (axis == 1 ? v.y() : v.z());
   }

   private static boolean near(float a, float b) {
      return Math.abs(a - b) <= 1.0E-4F;
   }

   private static boolean integral(float f) {
      return Math.abs(f - Math.round(f)) <= 1.0E-4F;
   }

   private static boolean unitSpan(float min, float max) {
      return integral(min) && Math.abs(max - min - 1.0F) <= 1.0E-4F;
   }

   private static long pack(long a, long b) {
      return (a & 4294967295L) << 32 | b & 4294967295L;
   }

   private static int quant(float uv) {
      return Math.round(uv * 32768.0F);
   }

   private static float minU(TerrainQuad q) {
      return Math.min(Math.min(q.v0().u(), q.v1().u()), Math.min(q.v2().u(), q.v3().u()));
   }

   private static float maxU(TerrainQuad q) {
      return Math.max(Math.max(q.v0().u(), q.v1().u()), Math.max(q.v2().u(), q.v3().u()));
   }

   private static float minV(TerrainQuad q) {
      return Math.min(Math.min(q.v0().v(), q.v1().v()), Math.min(q.v2().v(), q.v3().v()));
   }

   private static float maxV(TerrainQuad q) {
      return Math.max(Math.max(q.v0().v(), q.v1().v()), Math.max(q.v2().v(), q.v3().v()));
   }

   private record Cell(int a, int b, TerrainQuad quad, int[] corners, int[] vertexAt) {
   }

   private record Key(QuadFacing facing, int plane, int cutoff, boolean mip, int u0, int v0, int u1, int v1, int orient) {
   }

   private static final class Plane {
      private final int[] v00 = new int[5];
      private final int[] du = new int[5];
      private final int[] dv = new int[5];

      boolean begin(GreedyMesher.Cell seed) {
         int[] c = seed.corners();

         for (int ch = 0; ch < 5; ch++) {
            int p00 = c[ch];
            int p01 = c[5 + ch];
            int p10 = c[10 + ch];
            int p11 = c[15 + ch];
            this.v00[ch] = p00;
            this.du[ch] = p10 - p00;
            this.dv[ch] = p01 - p00;
            if (p11 != p00 + this.du[ch] + this.dv[ch]) {
               return false;
            }
         }

         return true;
      }

      boolean fits(GreedyMesher.Cell cell, int ci, int cj) {
         int[] c = cell.corners();

         for (int slot = 0; slot < 4; slot++) {
            int i = ci + (slot >> 1);
            int j = cj + (slot & 1);
            int base = slot * 5;

            for (int ch = 0; ch < 5; ch++) {
               if (c[base + ch] != this.v00[ch] + i * this.du[ch] + j * this.dv[ch]) {
                  return false;
               }
            }
         }

         return true;
      }
   }
}
