package nvidiumplus.engine.terrain.host;

import it.unimi.dsi.fastutil.ints.IntIterator;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import nvidiumplus.engine.NvidiumPlusScaling;
import nvidiumplus.engine.terrain.EncodedSectionMesh;
import nvidiumplus.engine.terrain.IdProvider;
import nvidiumplus.engine.terrain.RegionRecord;
import nvidiumplus.engine.terrain.SectionRecord;

final class RegionStore {
   private final IdProvider ids = new IdProvider();
   private final Long2ObjectOpenHashMap<RegionStore.Region> byKey = new Long2ObjectOpenHashMap();
   private final LinkedHashSet<RegionStore.Region> dirtyRegions = new LinkedHashSet<>();
   private final IntOpenHashSet tombstonePending = new IntOpenHashSet();
   private final ByteBuffer recordScratch = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN);
   private final boolean[] occupancyScratch = new boolean[256];

   static int maxRegions() {
      return NvidiumPlusScaling.current().maxRegions();
   }

   static long regionKey(int sx, int sy, int sz) {
      long rx = sx >> 3;
      long ry = sy >> 2;
      long rz = sz >> 3;
      return (rx & 2097151L) << 42 | (ry & 2097151L) << 21 | rz & 2097151L;
   }

   static int posKey(int sx, int sy, int sz) {
      return (sy & 3) << 6 | (sz & 7) << 3 | sx & 7;
   }

   boolean hasCapacityFor(int sx, int sy, int sz) {
      if (this.byKey.containsKey(regionKey(sx, sy, sz))) {
         return true;
      }

      int id = this.ids.provide();
      this.ids.release(id);
      return id < maxRegions();
   }

   boolean isOccupied(long regionKey, int posKey) {
      RegionStore.Region region = (RegionStore.Region)this.byKey.get(regionKey);
      return region != null && region.ownerByPos[posKey] != null;
   }

   RegionStore.Assignment addOrReplace(int sx, int sy, int sz, EncodedSectionMesh mesh, int terrainAddress, Object owner) {
      long key = regionKey(sx, sy, sz);
      RegionStore.Region region = (RegionStore.Region)this.byKey.get(key);
      if (region == null) {
         int id = this.ids.provide();
         if (id >= maxRegions()) {
            this.ids.release(id);
            return null;
         }

         region = new RegionStore.Region(id, key, sx >> 3, sy >> 2, sz >> 3);
         this.byKey.put(key, region);
      }

      int posKey = posKey(sx, sy, sz);
      int slot = region.pos2id[posKey];
      Object previousOwner = null;
      if (slot < 0) {
         slot = region.count++;
         region.pos2id[posKey] = (short)slot;
         region.id2pos[slot] = (short)posKey;
      } else {
         previousOwner = region.ownerByPos[posKey];
      }

      region.ownerByPos[posKey] = owner;
      region.retainedMask[posKey >>> 5] = region.retainedMask[posKey >>> 5] & ~(1 << (posKey & 31));
      ByteBuffer mirror = region.mirror.duplicate().order(ByteOrder.LITTLE_ENDIAN);
      mirror.position(slot * 32);
      SectionRecord.write(mirror, sx, sy, sz, mesh, false, slot, terrainAddress);
      region.markSlotDirty(slot);
      this.dirtyRegions.add(region);
      return new RegionStore.Assignment(region, posKey, slot, previousOwner);
   }

   Object remove(long regionKey, int posKey, Object owner) {
      RegionStore.Region region = (RegionStore.Region)this.byKey.get(regionKey);
      if (region != null && region.ownerByPos[posKey] == owner) {
         int slot = region.pos2id[posKey];
         if (slot < 0) {
            return null;
         }

         int last = region.count - 1;
         ByteBuffer mirror = region.mirror;
         Object movedOwner = null;
         if (slot != last) {
            for (int i = 0; i < 32; i += 4) {
               mirror.putInt(slot * 32 + i, mirror.getInt(last * 32 + i));
            }

            int headerYOffset = slot * 32 + 4;
            int py = mirror.getInt(headerYOffset);
            py = py & -66846721 | slot << 18;
            mirror.putInt(headerYOffset, py);
            int movedPos = region.id2pos[last];
            movedOwner = region.ownerByPos[movedPos];
            region.pos2id[movedPos] = (short)slot;
            region.id2pos[slot] = (short)movedPos;
         }

         for (int i = 0; i < 32; i += 4) {
            mirror.putInt(last * 32 + i, 0);
         }

         region.pos2id[posKey] = -1;
         region.id2pos[last] = -1;
         region.ownerByPos[posKey] = null;
         region.retainedMask[posKey >>> 5] = region.retainedMask[posKey >>> 5] & ~(1 << (posKey & 31));
         region.count--;
         region.markSlotDirty(slot);
         region.markSlotDirty(last);
         if (region.count == 0) {
            this.byKey.remove(regionKey);
            this.dirtyRegions.remove(region);
            this.ids.release(region.id);
            this.tombstonePending.add(region.id);
         } else {
            this.dirtyRegions.add(region);
         }

         return movedOwner;
      } else {
         return null;
      }
   }

   void commitDirty(TerrainGpuHost gpu) {
      if (!this.tombstonePending.isEmpty()) {
         IntIterator it = this.tombstonePending.iterator();

         while (it.hasNext()) {
            int id = it.nextInt();
            gpu.fillSectionBlockZero(id * 8192L, 8192L);
            gpu.fillRegionTombstone(id * 16L);
         }

         this.tombstonePending.clear();
      }

      if (!this.dirtyRegions.isEmpty()) {
         Iterator<RegionStore.Region> it = this.dirtyRegions.iterator();
         List<RegionStore.Region> requeue = new ArrayList<>(0);

         while (it.hasNext()) {
            RegionStore.Region region = it.next();
            it.remove();
            int min = region.dirtyMinSlot;
            int max = region.dirtyMaxSlot;
            if (max >= 0) {
               ByteBuffer slice = region.mirror.duplicate().order(ByteOrder.LITTLE_ENDIAN);
               slice.position(min * 32).limit((max + 1) * 32);
               long sectionOffset = region.id * 8192L + min * 32L;
               if (!gpu.stageSectionRecords(slice, sectionOffset)) {
                  requeue.add(region);
               } else {
                  this.recordScratch.clear();

                  for (int p = 0; p < 256; p++) {
                     this.occupancyScratch[p] = region.pos2id[p] >= 0;
                  }

                  RegionRecord.fromOccupancy(this.recordScratch, this.occupancyScratch, region.rx, region.ry, region.rz, 0);
                  this.recordScratch.flip();
                  if (!gpu.stageRegionRecord(this.recordScratch, region.id * 16L)) {
                     requeue.add(region);
                  } else {
                     region.dirtyMinSlot = Integer.MAX_VALUE;
                     region.dirtyMaxSlot = -1;
                  }
               }
            }
         }

         this.dirtyRegions.addAll(requeue);
      }
   }

   int[] snapshotRegions() {
      int[] out = new int[this.byKey.size() * 7];
      int o = 0;

      for (ObjectIterator var3 = this.byKey.values().iterator(); var3.hasNext(); o += 7) {
         RegionStore.Region r = (RegionStore.Region)var3.next();
         int minX = 8;
         int minY = 4;
         int minZ = 8;
         int maxX = -1;
         int maxY = -1;
         int maxZ = -1;

         for (int p = 0; p < 256; p++) {
            if (r.pos2id[p] >= 0) {
               int x = p & 7;
               int y = p >> 6 & 3;
               int z = p >> 3 & 7;
               minX = Math.min(minX, x);
               minY = Math.min(minY, y);
               minZ = Math.min(minZ, z);
               maxX = Math.max(maxX, x);
               maxY = Math.max(maxY, y);
               maxZ = Math.max(maxZ, z);
            }
         }

         if (maxX < 0) {
            minZ = 0;
            minY = 0;
            minX = 0;
            maxZ = 0;
            maxY = 0;
            maxX = 0;
         }

         out[o] = r.id;
         out[o + 1] = r.rx;
         out[o + 2] = r.ry;
         out[o + 3] = r.rz;
         out[o + 4] = r.count;
         out[o + 5] = minX | minY << 8 | minZ << 16;
         out[o + 6] = maxX | maxY << 8 | maxZ << 16;
      }

      return out;
   }

   int globalSectionIndex(long regionKey, int posKey, Object owner) {
      RegionStore.Region region = (RegionStore.Region)this.byKey.get(regionKey);
      if (region != null && region.ownerByPos[posKey] == owner) {
         int slot = region.pos2id[posKey];
         return slot < 0 ? -1 : region.id << 8 | slot;
      } else {
         return -1;
      }
   }

   boolean markRetained(long regionKey, int posKey, Object owner) {
      RegionStore.Region region = (RegionStore.Region)this.byKey.get(regionKey);
      if (region != null && region.ownerByPos[posKey] == owner && region.pos2id[posKey] >= 0) {
         region.retainedMask[posKey >>> 5] = region.retainedMask[posKey >>> 5] | 1 << (posKey & 31);
         return true;
      } else {
         return false;
      }
   }

   boolean setRetained(long regionKey, int posKey, Object owner, boolean retainedNow) {
      RegionStore.Region region = (RegionStore.Region)this.byKey.get(regionKey);
      if (region != null && region.ownerByPos[posKey] == owner && region.pos2id[posKey] >= 0) {
         int word = posKey >>> 5;
         int bit = 1 << (posKey & 31);
         boolean set = (region.retainedMask[word] & bit) != 0;
         if (set == retainedNow) {
            return false;
         }

         if (retainedNow) {
            region.retainedMask[word] = region.retainedMask[word] | bit;
         } else {
            region.retainedMask[word] = region.retainedMask[word] & ~bit;
         }

         return true;
      } else {
         return false;
      }
   }

   int[] snapshotRetainedMasks() {
      int[] out = new int[this.byKey.size() * 8];
      int o = 0;

      for (ObjectIterator var3 = this.byKey.values().iterator(); var3.hasNext(); o += 8) {
         RegionStore.Region r = (RegionStore.Region)var3.next();
         System.arraycopy(r.retainedMask, 0, out, o, 8);
      }

      return out;
   }

   int regionCount() {
      return this.byKey.size();
   }

   int dirtyRegionCount() {
      return this.dirtyRegions.size() + this.tombstonePending.size();
   }

   record Assignment(RegionStore.Region region, int posKey, int slot, Object previousOwner) {
   }

   static final class Region {
      final int id;
      final long key;
      final int rx;
      final int ry;
      final int rz;
      int count;
      final short[] pos2id = new short[256];
      final short[] id2pos = new short[256];
      final Object[] ownerByPos = new Object[256];
      final ByteBuffer mirror = ByteBuffer.allocate(8192).order(ByteOrder.LITTLE_ENDIAN);
      final int[] retainedMask = new int[8];
      int dirtyMinSlot = Integer.MAX_VALUE;
      int dirtyMaxSlot = -1;

      Region(int id, long key, int rx, int ry, int rz) {
         this.id = id;
         this.key = key;
         this.rx = rx;
         this.ry = ry;
         this.rz = rz;
         Arrays.fill(this.pos2id, (short)-1);
         Arrays.fill(this.id2pos, (short)-1);
      }

      void markSlotDirty(int slot) {
         this.dirtyMinSlot = Math.min(this.dirtyMinSlot, slot);
         this.dirtyMaxSlot = Math.max(this.dirtyMaxSlot, slot);
      }
   }
}
