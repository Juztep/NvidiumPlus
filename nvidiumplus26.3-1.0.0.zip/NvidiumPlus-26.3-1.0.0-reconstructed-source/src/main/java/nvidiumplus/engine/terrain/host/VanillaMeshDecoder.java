package nvidiumplus.engine.terrain.host;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.MeshData.DrawState;
import com.mojang.renderpearl.api.pipeline.IndexType;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import nvidiumplus.engine.terrain.QuadFacing;
import nvidiumplus.engine.terrain.TerrainQuad;
import nvidiumplus.engine.terrain.TerrainVertex;

final class VanillaMeshDecoder {
   static final int BLOCK_STRIDE = 28;
   private static final float DOMINANCE = 0.9999F;

   private VanillaMeshDecoder() {
   }

   static VanillaMeshDecoder.DecodedSection decode(Map<ChunkSectionLayer, MeshData> renderedLayers) {
      List<TerrainQuad> quads = new ArrayList<>();
      int skipped = 0;
      int[] translucentOrder = null;
      int[][] appliedOrder = new int[1][];

      for (Entry<ChunkSectionLayer, MeshData> entry : renderedLayers.entrySet()) {
         appliedOrder[0] = null;
         if (!decodeLayer(entry.getKey(), entry.getValue(), quads, appliedOrder)) {
            skipped++;
         } else if (entry.getKey().translucent() && appliedOrder[0] != null) {
            translucentOrder = appliedOrder[0];
         }
      }

      return new VanillaMeshDecoder.DecodedSection(quads, skipped, translucentOrder);
   }

   private static int[] identityOrder(int n) {
      int[] order = new int[n];
      int i = 0;

      while (i < n) {
         order[i] = i++;
      }

      return order;
   }

   private static boolean decodeLayer(ChunkSectionLayer layer, MeshData meshData, List<TerrainQuad> out, int[][] appliedOrderOut) {
      DrawState drawState = meshData.drawState();
      if (drawState.format() == DefaultVertexFormat.BLOCK && drawState.format().getVertexSize() == 28) {
         int vertexCount = drawState.vertexCount();
         if (vertexCount > 0 && (vertexCount & 3) == 0) {
            int quadCount = vertexCount / 4;
            ByteBuffer vertices = meshData.vertexBuffer().duplicate().order(ByteOrder.LITTLE_ENDIAN);
            int base = vertices.position();
            if (vertices.remaining() < quadCount * 4 * 28) {
               return false;
            }

            boolean translucent = layer.translucent();
            int cutoffIndex = materialCutoffIndex(layer);
            int[] order = translucent ? sortedQuadOrder(meshData, drawState, quadCount) : null;
            if (translucent && quadCount > 0) {
               appliedOrderOut[0] = order != null ? order : identityOrder(quadCount);
            }

            for (int i = 0; i < quadCount; i++) {
               int q = order != null ? order[i] : i;
               int offset = base + q * 4 * 28;
               TerrainVertex v0 = readVertex(vertices, offset);
               TerrainVertex v1 = readVertex(vertices, offset + 28);
               TerrainVertex v2 = readVertex(vertices, offset + 56);
               TerrainVertex v3 = readVertex(vertices, offset + 84);
               QuadFacing facing = deriveFacing(v0, v1, v2);
               out.add(new TerrainQuad(facing, translucent, cutoffIndex, true, v0, v1, v2, v3));
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private static int materialCutoffIndex(ChunkSectionLayer layer) {
      return switch (layer) {
         case SOLID -> 0;
         case CUTOUT -> 2;
         case TRANSLUCENT -> 1;
         default -> throw new MatchException(null, null);
      };
   }

   private static TerrainVertex readVertex(ByteBuffer buf, int offset) {
      float x = buf.getFloat(offset);
      float y = buf.getFloat(offset + 4);
      float z = buf.getFloat(offset + 8);
      int colorAbgr = buf.getInt(offset + 12);
      float u = buf.getFloat(offset + 16);
      float v = buf.getFloat(offset + 20);
      int blockRaw = buf.getShort(offset + 24) & '\uffff';
      int skyRaw = buf.getShort(offset + 26) & '\uffff';
      return new TerrainVertex(x, y, z, u, v, colorAbgr, Math.min(255, blockRaw + 8), Math.min(255, skyRaw + 8));
   }

   static QuadFacing deriveFacing(TerrainVertex v0, TerrainVertex v1, TerrainVertex v2) {
      float e1x = v1.x() - v0.x();
      float e1y = v1.y() - v0.y();
      float e1z = v1.z() - v0.z();
      float e2x = v2.x() - v0.x();
      float e2y = v2.y() - v0.y();
      float e2z = v2.z() - v0.z();
      float nx = e1y * e2z - e1z * e2y;
      float ny = e1z * e2x - e1x * e2z;
      float nz = e1x * e2y - e1y * e2x;
      float ax = Math.abs(nx);
      float ay = Math.abs(ny);
      float az = Math.abs(nz);
      float len2 = ax * ax + ay * ay + az * az;
      if (len2 < 1.0E-12F) {
         return QuadFacing.UNASSIGNED;
      } else if (ax >= ay && ax >= az) {
         return ax * ax >= 0.9999F * len2 ? (nx > 0.0F ? QuadFacing.POS_X : QuadFacing.NEG_X) : QuadFacing.UNASSIGNED;
      } else if (ay >= az) {
         return ay * ay >= 0.9999F * len2 ? (ny > 0.0F ? QuadFacing.POS_Y : QuadFacing.NEG_Y) : QuadFacing.UNASSIGNED;
      } else {
         return az * az >= 0.9999F * len2 ? (nz > 0.0F ? QuadFacing.POS_Z : QuadFacing.NEG_Z) : QuadFacing.UNASSIGNED;
      }
   }

   static int[] resortQuadOrder(ByteBuffer indexBytes, int quadCount) {
      if (indexBytes != null && quadCount > 0) {
         ByteBuffer ib = indexBytes.duplicate().order(ByteOrder.LITTLE_ENDIAN);
         int base = ib.position();
         long remaining = ib.remaining();
         int indexBytesPer;
         if (remaining == quadCount * 6L * 2L) {
            indexBytesPer = 2;
         } else {
            if (remaining != quadCount * 6L * 4L) {
               return null;
            }

            indexBytesPer = 4;
         }

         int[] order = new int[quadCount];
         boolean[] seen = new boolean[quadCount];

         for (int i = 0; i < quadCount; i++) {
            int first = indexBytesPer == 2 ? ib.getShort(base + i * 6 * 2) & 65535 : ib.getInt(base + i * 6 * 4);
            int quad = first >>> 2;
            if (quad >= quadCount || seen[quad]) {
               return null;
            }

            seen[quad] = true;
            order[i] = quad;
         }

         return order;
      } else {
         return null;
      }
   }

   private static int[] sortedQuadOrder(MeshData meshData, DrawState drawState, int quadCount) {
      ByteBuffer indices = meshData.indexBuffer();
      if (indices != null && drawState.indexCount() == quadCount * 6) {
         ByteBuffer ib = indices.duplicate().order(ByteOrder.LITTLE_ENDIAN);
         int base = ib.position();
         boolean shortType = drawState.indexType() == IndexType.SHORT;
         int indexBytes = shortType ? 2 : 4;
         if (ib.remaining() < quadCount * 6 * indexBytes) {
            return null;
         }

         int[] order = new int[quadCount];
         boolean[] seen = new boolean[quadCount];

         for (int i = 0; i < quadCount; i++) {
            int first = shortType ? ib.getShort(base + i * 6 * 2) & 65535 : ib.getInt(base + i * 6 * 4);
            int quad = first >>> 2;
            if (quad >= quadCount || seen[quad]) {
               return null;
            }

            seen[quad] = true;
            order[i] = quad;
         }

         return order;
      } else {
         return null;
      }
   }

   record DecodedSection(List<TerrainQuad> quads, int skippedLayers, int[] translucentOrder) {
   }
}
