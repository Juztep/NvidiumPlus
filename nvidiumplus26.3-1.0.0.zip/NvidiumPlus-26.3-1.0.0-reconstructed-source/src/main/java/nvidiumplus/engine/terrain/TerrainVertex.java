package nvidiumplus.engine.terrain;

public record TerrainVertex(float x, float y, float z, float u, float v, int colorAbgr, int blockLight, int skyLight) {
}
