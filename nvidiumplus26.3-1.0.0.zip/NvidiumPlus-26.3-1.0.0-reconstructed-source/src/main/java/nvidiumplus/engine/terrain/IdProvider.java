package nvidiumplus.engine.terrain;

import it.unimi.dsi.fastutil.ints.IntAVLTreeSet;
import it.unimi.dsi.fastutil.ints.IntSortedSet;

public class IdProvider {
   private int cid = 0;
   private final IntSortedSet free = new IntAVLTreeSet(Integer::compareTo);

   public int provide() {
      if (this.free.isEmpty()) {
         return this.cid++;
      }

      int ret = this.free.firstInt();
      this.free.remove(ret);
      return ret;
   }

   public void release(int id) {
      this.free.add(id);

      while (!this.free.isEmpty() && this.free.lastInt() + 1 == this.cid) {
         this.free.remove(--this.cid);
      }
   }

   public int maxIndex() {
      return this.cid;
   }
}
