package nvidiumplus.engine.terrain;

import java.util.Arrays;

public final class TranslucentPrefix {
   private TranslucentPrefix() {
   }

   public static void permute(byte[] prefix, int[] currentOrder, int[] newOrder, byte[] scratch) {
      int n = currentOrder.length;
      if (newOrder.length != n) {
         throw new IllegalArgumentException("order length mismatch: current " + n + " vs new " + newOrder.length);
      }

      if (prefix.length == n * 64 && scratch.length >= prefix.length) {
         int[] slotOfQuad = new int[n];
         Arrays.fill(slotOfQuad, -1);
         int slot = 0;

         while (slot < n) {
            int quad = currentOrder[slot];
            if (quad < 0 || quad >= n || slotOfQuad[quad] != -1) {
               throw new IllegalArgumentException("currentOrder is not a permutation of 0.." + (n - 1));
            }

            slotOfQuad[quad] = slot++;
         }

         boolean[] seen = new boolean[n];

         for (int j = 0; j < n; j++) {
            int quad = newOrder[j];
            if (quad < 0 || quad >= n || seen[quad]) {
               throw new IllegalArgumentException("newOrder is not a permutation of 0.." + (n - 1));
            }

            seen[quad] = true;
            System.arraycopy(prefix, slotOfQuad[quad] * 64, scratch, j * 64, 64);
         }

         System.arraycopy(scratch, 0, prefix, 0, prefix.length);
      } else {
         throw new IllegalArgumentException("prefix/scratch sized wrong for " + n + " quads");
      }
   }
}
