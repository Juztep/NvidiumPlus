package nvidiumplus.engine.terrain.host;

import java.nio.ByteBuffer;

public interface TerrainGpuHost {
   boolean beginFrame(long var1);

   long maxStageBytes();

   long stagingUsedBytes();

   boolean stageArenaCopy(ByteBuffer var1, int var2, long var3);

   boolean stageArenaCopyLate(ByteBuffer var1, int var2, long var3);

   boolean stageSectionRecords(ByteBuffer var1, long var2);

   boolean stageRegionRecord(ByteBuffer var1, long var2);

   long growArena(long var1);

   long trimArena(long var1, long var3);

   void onArenaBlockAppended(long var1);

   long growRecords(int var1);

   void dropSnapshotSizedDrawResources();

   void fillSectionBlockZero(long var1, long var3);

   void fillRegionTombstone(long var1);

   void endFrame();
}
