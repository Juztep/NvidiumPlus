package nvidiumplus.engine.terrain;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import java.util.ArrayList;
import java.util.List;

public final class TerrainArena {
   public static final int ALLOC_FAILED = -1;
   private final ArenaBacking backing;
   private final List<SegmentedManager> blockSegments = new ArrayList<>();
   private final LongArrayList blockHandles = new LongArrayList();
   private final LongArrayList blockPhysicalQuads = new LongArrayList();
   private final long blockQuads;
   private final int blockShift;
   private final long blockMask;
   private final int maxBlocks;
   private long memoryBytes;
   private final int vertexStride;
   private long quadLimit;
   private long liveQuads;
   private int liveAllocations;
   private final IntArrayList pendingFreeList = new IntArrayList();
   private final IntOpenHashSet pendingFreeSet = new IntOpenHashSet();
   private long pendingQuads;

   public TerrainArena(ArenaBacking backing, long memoryBytes, int vertexStride) {
      this(backing, memoryBytes, vertexStride, memoryBytes, 1);
   }

   public TerrainArena(ArenaBacking backing, long memoryBytes, int vertexStride, long blockBytes, int maxBlocks) {
      if (memoryBytes > 0L && vertexStride > 0) {
         long quadBytes = 4L * vertexStride;
         if (blockBytes < quadBytes || Long.bitCount(blockBytes) != 1) {
            throw new IllegalArgumentException("blockBytes must be a power of two >= " + quadBytes + ", got " + blockBytes);
         }

         if (maxBlocks < 1) {
            throw new IllegalArgumentException("maxBlocks must be >= 1, got " + maxBlocks);
         }

         this.backing = backing;
         this.vertexStride = vertexStride;
         this.maxBlocks = maxBlocks;
         this.blockQuads = blockBytes / quadBytes;
         this.blockShift = Long.numberOfTrailingZeros(this.blockQuads);
         this.blockMask = this.blockQuads - 1L;
         long firstBytes = Math.min(memoryBytes, blockBytes);
         this.commitBlock(backing.allocate(firstBytes), firstBytes);
         this.memoryBytes = firstBytes;
         this.quadLimit = firstBytes / quadBytes;
         int reserved = this.allocQuads(1);
         if (reserved != 0) {
            throw new IllegalStateException("reserved quad 0 landed at " + reserved);
         }
      } else {
         throw new IllegalArgumentException("memoryBytes and vertexStride must be positive");
      }
   }

   private void commitBlock(long handle, long physicalBytes) {
      long quads = physicalBytes / (4L * this.vertexStride);
      if (quads > this.blockQuads) {
         throw new IllegalStateException(
            "block physical quads " + quads + " exceeds the block address stride " + this.blockQuads + " - an allocation could straddle two buffers"
         );
      }

      SegmentedManager manager = new SegmentedManager();
      manager.setLimit(quads);
      this.blockSegments.add(manager);
      this.blockHandles.add(handle);
      this.blockPhysicalQuads.add(quads);
   }

   public int allocQuads(int quadCount) {
      if (quadCount <= 0) {
         throw new IllegalArgumentException("quadCount must be positive, got " + quadCount);
      }

      if (quadCount > this.blockQuads) {
         return -1;
      }

      int blocks = this.blockSegments.size();

      for (int b = 0; b < blocks; b++) {
         long local = this.blockSegments.get(b).alloc(quadCount);
         if (local != -1L) {
            this.liveQuads += quadCount;
            this.liveAllocations++;
            return (int)((long)b << this.blockShift | local);
         }
      }

      return -1;
   }

   public int blockOf(int addr) {
      return (int)(Integer.toUnsignedLong(addr) >>> this.blockShift);
   }

   private long localOf(int addr) {
      return Integer.toUnsignedLong(addr) & this.blockMask;
   }

   private SegmentedManager segmentsOf(int addr) {
      int b = this.blockOf(addr);
      if (b >= 0 && b < this.blockSegments.size()) {
         return this.blockSegments.get(b);
      } else {
         throw new IllegalStateException(
            "quad address "
               + Integer.toUnsignedString(addr)
               + " names block "
               + b
               + ", which is not committed ("
               + this.blockSegments.size()
               + " blocks) - this is the silent-corruption case, refusing to guess"
         );
      }
   }

   public void free(int addr) {
      if (this.pendingFreeSet.contains(addr)) {
         throw new IllegalStateException("double free of quad address " + addr);
      }

      long size = this.segmentsOf(addr).getSize(addr & (int)this.blockMask);
      this.pendingFreeSet.add(addr);
      this.pendingFreeList.add(addr);
      this.pendingQuads += size;
      this.liveQuads -= size;
      this.liveAllocations--;
   }

   public int releasePending() {
      int released = this.pendingFreeList.size();

      for (int i = 0; i < released; i++) {
         int addr = this.pendingFreeList.getInt(i);
         this.segmentsOf(addr).free((int)this.localOf(addr));
      }

      this.pendingFreeList.clear();
      this.pendingFreeSet.clear();
      this.pendingQuads = 0L;
      return released;
   }

   public void grow(long newLastBlockBytes, long newBackingHandle) {
      int last = this.blockSegments.size() - 1;
      long oldBytes = this.blockPhysicalQuads.getLong(last) * 4L * this.vertexStride;
      if (newLastBlockBytes <= oldBytes) {
         throw new IllegalArgumentException("arena grow " + oldBytes + " -> " + newLastBlockBytes + " bytes is not a growth");
      }

      long quads = newLastBlockBytes / (4L * this.vertexStride);
      if (quads > this.blockQuads) {
         throw new IllegalStateException("grow would take block " + last + " to " + quads + " quads, past its " + this.blockQuads + " address stride");
      }

      this.blockHandles.set(last, newBackingHandle);
      this.blockPhysicalQuads.set(last, quads);
      this.blockSegments.get(last).setLimit(quads);
      this.memoryBytes += newLastBlockBytes - oldBytes;
      this.quadLimit = this.totalQuadCapacity();
   }

   public void shrinkLastBlock(long newLastBlockBytes, long newBackingHandle) {
      int last = this.blockSegments.size() - 1;
      long oldBytes = this.blockPhysicalQuads.getLong(last) * 4L * this.vertexStride;
      if (newLastBlockBytes >= oldBytes) {
         throw new IllegalArgumentException("arena shrink " + oldBytes + " -> " + newLastBlockBytes + " bytes is not a shrink");
      }

      long quads = newLastBlockBytes / (4L * this.vertexStride);
      long extent = this.blockSegments.get(last).getSize();
      if (quads < extent) {
         throw new IllegalStateException("shrink would take block " + last + " to " + quads + " quads, below its live extent of " + extent);
      }

      this.blockHandles.set(last, newBackingHandle);
      this.blockPhysicalQuads.set(last, quads);
      this.blockSegments.get(last).setLimit(quads);
      this.memoryBytes -= oldBytes - newLastBlockBytes;
      this.quadLimit = this.totalQuadCapacity();
   }

   public long lastBlockExtentBytes() {
      return this.blockSegments.get(this.blockSegments.size() - 1).getSize() * 4L * this.vertexStride;
   }

   public boolean appendBlock(long blockBytes) {
      if (this.blockSegments.size() >= this.maxBlocks) {
         return false;
      }

      long handle = this.backing.appendBlock(blockBytes);
      if (handle == 0L) {
         return false;
      }

      this.commitBlock(handle, blockBytes);
      this.memoryBytes += blockBytes;
      this.quadLimit = this.totalQuadCapacity();
      return true;
   }

   private long totalQuadCapacity() {
      long total = 0L;

      for (int i = 0; i < this.blockPhysicalQuads.size(); i++) {
         total += this.blockPhysicalQuads.getLong(i);
      }

      return total;
   }

   public int blockCount() {
      return this.blockSegments.size();
   }

   public long lastBlockBytes() {
      return this.blockPhysicalQuads.getLong(this.blockPhysicalQuads.size() - 1) * 4L * this.vertexStride;
   }

   public long blockBytes() {
      return this.blockQuads * 4L * this.vertexStride;
   }

   public long[] blockHandles() {
      return this.blockHandles.toLongArray();
   }

   public boolean canReuse(int addr, int quadCount) {
      if (this.pendingFreeSet.contains(addr)) {
         throw new IllegalStateException("address " + addr + " was freed and is pending release");
      } else {
         return this.segmentsOf(addr).getSize((int)this.localOf(addr)) == quadCount;
      }
   }

   public long byteOffsetInBlock(int addr) {
      return this.localOf(addr) * 4L * this.vertexStride;
   }

   public long byteSize(int addr) {
      return this.segmentsOf(addr).getSize((int)this.localOf(addr)) * 4L * this.vertexStride;
   }

   public long backingHandle() {
      return this.blockHandles.isEmpty() ? 0L : this.blockHandles.getLong(0);
   }

   public long memoryBytes() {
      return this.memoryBytes;
   }

   public int vertexStride() {
      return this.vertexStride;
   }

   public long quadLimit() {
      return this.quadLimit;
   }

   public long liveQuads() {
      return this.liveQuads;
   }

   public int liveAllocationCount() {
      return this.liveAllocations;
   }

   public int pendingFreeCount() {
      return this.pendingFreeList.size();
   }

   public long pendingQuads() {
      return this.pendingQuads;
   }

   public long quadExtent() {
      long total = 0L;

      for (SegmentedManager m : this.blockSegments) {
         total += m.getSize();
      }

      return total;
   }

   public boolean blockIsEmpty(int block) {
      return this.blockSegments.get(block).getSize() == 0L;
   }

   public int emptyTopBlocks() {
      int empty = 0;

      for (int b = this.blockSegments.size() - 1; b > 0 && this.blockIsEmpty(b); b--) {
         empty++;
      }

      return empty;
   }

   public int getUsedMB() {
      return (int)(this.liveQuads * this.vertexStride * 4L / 1048576L);
   }

   public float getFragmentation() {
      long expected = this.liveQuads * this.vertexStride * 4L;
      return (float)((double)expected / this.memoryBytes);
   }
}
