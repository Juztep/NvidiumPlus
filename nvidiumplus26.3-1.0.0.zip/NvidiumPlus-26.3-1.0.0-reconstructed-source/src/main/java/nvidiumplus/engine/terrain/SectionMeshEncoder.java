package nvidiumplus.engine.terrain;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

public final class SectionMeshEncoder {
   private SectionMeshEncoder() {
   }

   public static EncodedSectionMesh encode(List<TerrainQuad> quads) {
      ByteBuffer dst = ByteBuffer.allocate(quads.size() * 64).order(ByteOrder.LITTLE_ENDIAN);
      return encodeInto(quads, dst);
   }

   public static EncodedSectionMesh encodeInto(List<TerrainQuad> quads, ByteBuffer dst) {
      if (quads.isEmpty()) {
         throw new IllegalArgumentException("0-quad sections are never encoded - delete the section instead (SectionManager.java:58-61)");
      }

      TerrainVertexCodec.checkOrder(dst);
      List<TerrainQuad> translucent = new ArrayList<>();
      List<TerrainQuad>[] buckets = new List[7];

      for (int i = 0; i < buckets.length; i++) {
         buckets[i] = new ArrayList<>();
      }

      for (TerrainQuad quad : quads) {
         if (quad.translucent()) {
            translucent.add(quad);
         } else {
            buckets[quad.facing().ordinal()].add(quad);
         }
      }

      int[] bucketCounts = new int[7];

      for (int i = 0; i < buckets.length; i++) {
         bucketCounts[i] = buckets[i].size();
      }

      short[] offsets = QuadFacingBuckets.toOffsets(translucent.size(), bucketCounts);
      int[] starts = QuadFacingBuckets.bucketStarts(translucent.size(), bucketCounts);
      int geometryStart = dst.position();
      SectionMeshEncoder.Bounds bounds = new SectionMeshEncoder.Bounds();

      for (TerrainQuad quad : translucent) {
         encodeQuadTracked(dst, quad, bounds);
      }

      List[] var19 = buckets;
      int var22 = var19.length;

      for (int var11 = 0; var11 < var22; var11++) {
         for (TerrainQuad quad : var19[var11]) {
            encodeQuadTracked(dst, quad, bounds);
         }
      }

      ByteBuffer geometry = dst.duplicate().order(dst.order());
      geometry.limit(dst.position()).position(geometryStart);
      ByteBuffer var21 = geometry.slice().asReadOnlyBuffer().order(dst.order());
      bounds.clampLikeRepackager();
      return new EncodedSectionMesh(var21, quads.size(), offsets, starts, bounds.minX, bounds.minY, bounds.minZ, bounds.sizeX, bounds.sizeY, bounds.sizeZ);
   }

   private static void encodeQuadTracked(ByteBuffer dst, TerrainQuad quad, SectionMeshEncoder.Bounds bounds) {
      TerrainVertexCodec.encodeQuad(dst, quad);

      for (int i = 0; i < 4; i++) {
         TerrainVertex v = quad.vertex(i);
         bounds.add(
            TerrainVertexCodec.decodePosition(TerrainVertexCodec.encodePosition(v.x())),
            TerrainVertexCodec.decodePosition(TerrainVertexCodec.encodePosition(v.y())),
            TerrainVertexCodec.decodePosition(TerrainVertexCodec.encodePosition(v.z()))
         );
      }
   }

   private static final class Bounds {
      int minX = 2000;
      int minY = 2000;
      int minZ = 2000;
      int maxX = -2000;
      int maxY = -2000;
      int maxZ = -2000;
      int sizeX;
      int sizeY;
      int sizeZ;

      void add(float x, float y, float z) {
         this.minX = Math.min(this.minX, (int)Math.floor(x));
         this.minY = Math.min(this.minY, (int)Math.floor(y));
         this.minZ = Math.min(this.minZ, (int)Math.floor(z));
         this.maxX = Math.max(this.maxX, (int)Math.ceil(x));
         this.maxY = Math.max(this.maxY, (int)Math.ceil(y));
         this.maxZ = Math.max(this.maxZ, (int)Math.ceil(z));
      }

      void clampLikeRepackager() {
         this.minX = Math.min(Math.max(this.minX, 0), 15);
         this.minY = Math.min(Math.max(this.minY, 0), 15);
         this.minZ = Math.min(Math.max(this.minZ, 0), 15);
         this.maxX = Math.max(Math.min(this.maxX, 16), 0);
         this.maxY = Math.max(Math.min(this.maxY, 16), 0);
         this.maxZ = Math.max(Math.min(this.maxZ, 16), 0);
         this.sizeX = Math.min(15, Math.max(this.maxX - this.minX - 1, 0));
         this.sizeY = Math.min(15, Math.max(this.maxY - this.minY - 1, 0));
         this.sizeZ = Math.min(15, Math.max(this.maxZ - this.minZ - 1, 0));
      }
   }
}
