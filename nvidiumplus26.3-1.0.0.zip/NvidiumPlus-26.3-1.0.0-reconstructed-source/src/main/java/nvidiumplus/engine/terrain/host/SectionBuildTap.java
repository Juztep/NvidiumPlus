package nvidiumplus.engine.terrain.host;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.client.renderer.chunk.SectionCompiler.Results;
import net.minecraft.core.SectionPos;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusCpuStages;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.terrain.EncodedSectionMesh;
import nvidiumplus.engine.terrain.GreedyMeshProbe;
import nvidiumplus.engine.terrain.GreedyMesher;
import nvidiumplus.engine.terrain.QuadFacing;
import nvidiumplus.engine.terrain.SectionMeshEncoder;
import nvidiumplus.engine.terrain.TerrainQuad;
import nvidiumplus.engine.terrain.TerrainVertex;

public final class SectionBuildTap {
   private static final ThreadLocal<SectionBuildTap.Parked> PARKED = new ThreadLocal<>();
   private static final AtomicLong COMPILE_TAP_HITS = new AtomicLong();
   private static final AtomicLong MESH_TAP_ORPHANS = new AtomicLong();
   private static final AtomicBoolean TAP_BREAK_REPORTED = new AtomicBoolean();
   private static final long TAP_BREAK_THRESHOLD = 256L;
   static final byte TIER_NONE = 0;
   static final byte TIER_SMART = 1;
   static final byte TIER_SOLID = 2;
   public static final long CAMERA_SECTION_UNKNOWN = Long.MIN_VALUE;
   private static volatile long cameraSectionXZ = Long.MIN_VALUE;
   private static volatile int visibleSectionsListed = -1;
   private static volatile int visibleSectionsListedMin = -1;
   private static volatile int visibleSectionsListedMax = -1;
   private static final float EPS = 1.0E-4F;

   public static long compileTapHits() {
      return COMPILE_TAP_HITS.get();
   }

   public static long meshTapOrphans() {
      return MESH_TAP_ORPHANS.get();
   }

   private SectionBuildTap() {
   }

   public static void publishCameraSection(int sectionX, int sectionZ) {
      cameraSectionXZ = (long)sectionX << 32 | sectionZ & 4294967295L;
   }

   public static long cameraSectionXZ() {
      return cameraSectionXZ;
   }

   public static void publishVisibleSections(int listed) {
      visibleSectionsListed = listed;
      int min = visibleSectionsListedMin;
      if (min < 0 || listed < min) {
         visibleSectionsListedMin = listed;
      }

      if (listed > visibleSectionsListedMax) {
         visibleSectionsListedMax = listed;
      }
   }

   public static int visibleSectionsListed() {
      return visibleSectionsListed;
   }

   public static int visibleSectionsListedMin() {
      return visibleSectionsListedMin;
   }

   public static int visibleSectionsListedMax() {
      return visibleSectionsListedMax;
   }

   static int chunkDistanceXZ(long packedCamera, int sx, int sz) {
      long dx = sx - (packedCamera >> 32);
      long dz = sz - (int)packedCamera;
      return (int)Math.ceil(Math.sqrt(dx * dx + dz * dz));
   }

   public static void onCompileReturn(SectionPos pos, Results results) {
      SectionBuildTap.Parked already = PARKED.get();
      if (already == null || already.results() != results) {
         NvidiumPlusCpuStages.noteTapCompile();
         COMPILE_TAP_HITS.incrementAndGet();
         PARKED.remove();
         if (results != null && !results.renderedLayers.isEmpty()) {
            try {
               VanillaMeshDecoder.DecodedSection decoded = VanillaMeshDecoder.decode(results.renderedLayers);
               if (decoded.skippedLayers() > 0) {
                  TerrainResidency.countDecoderSkips(decoded.skippedLayers());
               }

               if (decoded.quads().isEmpty()) {
                  TerrainResidency.onSectionCompiledEmpty(pos.x(), pos.y(), pos.z());
                  return;
               }

               GreedyMeshProbe.observe(decoded.quads());
               List<TerrainQuad> toEncode = decoded.quads();
               byte builtTier = 0;
               int smartRing = NvidiumPlusConfig.smartLeavesChunks();
               int solidRing = NvidiumPlusConfig.solidLeavesChunks();
               if (smartRing > 0 || solidRing > 0) {
                  long camera = cameraSectionXZ;
                  if (camera != Long.MIN_VALUE) {
                     int dist = chunkDistanceXZ(camera, pos.x(), pos.z());
                     byte tier = (byte)(solidRing > 0 && dist > solidRing + 1 ? 2 : (smartRing > 0 && dist > smartRing + 1 ? 1 : 0));
                     if (tier != 0) {
                        List<TerrainQuad> filtered = filterCutoutInteriorPairs(toEncode);
                        if (filtered != toEncode && !filtered.isEmpty()) {
                           toEncode = filtered;
                           builtTier = 1;
                        }

                        if (tier == 2) {
                           List<TerrainQuad> solidified = solidifyCutouts(toEncode);
                           if (solidified != toEncode) {
                              toEncode = solidified;
                              builtTier = 2;
                           }
                        }
                     }
                  }
               }

               if (NvidiumPlusConfig.greedyMeshingEnabled()) {
                  toEncode = GreedyMesher.merge(toEncode);
               }

               EncodedSectionMesh encoded = SectionMeshEncoder.encode(toEncode);
               PARKED.set(new SectionBuildTap.Parked(results, pos.x(), pos.y(), pos.z(), encoded, decoded.translucentOrder(), builtTier));
            } catch (Throwable t) {
               TerrainResidency.countEncodeFailure(t);
            }
         } else {
            if (results != null) {
               TerrainResidency.onSectionCompiledEmpty(pos.x(), pos.y(), pos.z());
            }
         }
      }
   }

   public static void onMeshConstructed(Object mesh, Results results) {
      SectionBuildTap.Parked parked = PARKED.get();
      if (parked == null) {
         if (COMPILE_TAP_HITS.get() == 0L && MESH_TAP_ORPHANS.incrementAndGet() >= 256L && TAP_BREAK_REPORTED.compareAndSet(false, true)) {
            NvidiumPlusLog.LOGGER
               .error(
                  "NvidiumPlus's section-compile tap is DISCONNECTED: vanilla has built {} sections and SectionCompiler.compile has not been seen once, so nothing is being decoded, nothing is uploaded, and every frame is being handed back to vanilla. The world will look correct and run at vanilla speed. This means the mixin's pinned compile(...) descriptor no longer matches the game - check SectionCompilerMixin against this Minecraft build (a loader that adds a parameter to compile, or repoints its caller at an overload, produces exactly this).",
                  MESH_TAP_ORPHANS.get()
               );
         }
      } else {
         PARKED.remove();
         if (parked.results() != results) {
            TerrainResidency.countStalePark();
         } else {
            TerrainResidency.enqueueUpload(mesh, parked.sx(), parked.sy(), parked.sz(), parked.encoded(), parked.translucentOrder(), parked.builtTier());
         }
      }
   }

   private static SectionBuildTap.BoundaryKey boundaryKey(QuadFacing facing, long[] cell) {
      int axis = switch (facing) {
         case POS_X, NEG_X -> 0;
         case POS_Y, NEG_Y -> 1;
         case POS_Z, NEG_Z -> 2;
         case UNASSIGNED -> -1;
      };
      return new SectionBuildTap.BoundaryKey(axis, (int)cell[2], (int)cell[0], (int)cell[1]);
   }

   public static List<TerrainQuad> filterCutoutInteriorPairs(List<TerrainQuad> quads) {
      Map<SectionBuildTap.BoundaryKey, ArrayDeque<Integer>> unpairedPos = new HashMap<>();
      Map<SectionBuildTap.BoundaryKey, ArrayDeque<Integer>> unpairedNeg = new HashMap<>();
      boolean[] removed = new boolean[quads.size()];
      int removedCount = 0;

      for (int i = 0; i < quads.size(); i++) {
         TerrainQuad q = quads.get(i);
         if (!q.translucent() && q.alphaCutoffIndex() != 0) {
            long[] cell = unitCell(q);
            if (cell != null) {
               boolean positive = q.facing() == QuadFacing.POS_X || q.facing() == QuadFacing.POS_Y || q.facing() == QuadFacing.POS_Z;
               SectionBuildTap.BoundaryKey key = boundaryKey(q.facing(), cell);
               ArrayDeque<Integer> opposite = (positive ? unpairedNeg : unpairedPos).get(key);
               if (opposite != null && !opposite.isEmpty()) {
                  removed[opposite.pollFirst()] = true;
                  removed[i] = true;
                  removedCount += 2;
               } else {
                  (positive ? unpairedPos : unpairedNeg).computeIfAbsent(key, k -> new ArrayDeque<>()).addLast(i);
               }
            }
         }
      }

      if (removedCount == 0) {
         return quads;
      }

      List<TerrainQuad> out = new ArrayList<>(quads.size() - removedCount);

      for (int i = 0; i < quads.size(); i++) {
         if (!removed[i]) {
            out.add(quads.get(i));
         }
      }

      return out;
   }

   public static List<TerrainQuad> solidifyCutouts(List<TerrainQuad> quads) {
      Set<SectionBuildTap.BoundaryKey> solidBoundaries = null;
      List<TerrainQuad> out = null;

      for (int i = 0; i < quads.size(); i++) {
         TerrainQuad q = quads.get(i);
         if (!q.translucent() && q.alphaCutoffIndex() != 0) {
            long[] cell = unitCell(q);
            if (cell != null) {
               if (solidBoundaries == null) {
                  solidBoundaries = solidBoundaryKeys(quads);
               }

               if (!solidBoundaries.contains(boundaryKey(q.facing(), cell))) {
                  if (out == null) {
                     out = new ArrayList<>(quads);
                  }

                  out.set(i, new TerrainQuad(q.facing(), false, 0, q.mip(), q.v0(), q.v1(), q.v2(), q.v3(), q.repeatU(), q.repeatV()));
               }
            }
         }
      }

      return out == null ? quads : out;
   }

   private static Set<SectionBuildTap.BoundaryKey> solidBoundaryKeys(List<TerrainQuad> quads) {
      Set<SectionBuildTap.BoundaryKey> keys = new HashSet<>();

      for (int i = 0; i < quads.size(); i++) {
         TerrainQuad q = quads.get(i);
         if (!q.translucent() && q.alphaCutoffIndex() == 0) {
            long[] cell = unitCell(q);
            if (cell != null) {
               keys.add(boundaryKey(q.facing(), cell));
            }
         }
      }

      return keys;
   }

   private static long[] unitCell(TerrainQuad q) {
      int axis = switch (q.facing()) {
         case POS_X, NEG_X -> 0;
         case POS_Y, NEG_Y -> 1;
         case POS_Z, NEG_Z -> 2;
         case UNASSIGNED -> -1;
      };
      if (axis < 0) {
         return null;
      }

      float planeF = component(q.v0(), axis);
      float minA = Float.MAX_VALUE;
      float maxA = -Float.MAX_VALUE;
      float minB = Float.MAX_VALUE;
      float maxB = -Float.MAX_VALUE;
      int axisA = axis == 0 ? 1 : 0;
      int axisB = axis == 2 ? 1 : 2;

      for (int i = 0; i < 4; i++) {
         TerrainVertex v = q.vertex(i);
         if (!near(component(v, axis), planeF)) {
            return null;
         }

         float ca = component(v, axisA);
         float cb = component(v, axisB);
         minA = Math.min(minA, ca);
         maxA = Math.max(maxA, ca);
         minB = Math.min(minB, cb);
         maxB = Math.max(maxB, cb);
      }

      return isUnitSpan(minA, maxA) && isUnitSpan(minB, maxB) && isIntegral(planeF) ? new long[]{Math.round(minA), Math.round(minB), Math.round(planeF)} : null;
   }

   private static float component(TerrainVertex v, int axis) {
      return axis == 0 ? v.x() : (axis == 1 ? v.y() : v.z());
   }

   private static boolean near(float a, float b) {
      return Math.abs(a - b) <= 1.0E-4F;
   }

   private static boolean isIntegral(float f) {
      return Math.abs(f - Math.round(f)) <= 1.0E-4F;
   }

   private static boolean isUnitSpan(float min, float max) {
      return isIntegral(min) && Math.abs(max - min - 1.0F) <= 1.0E-4F;
   }

   private record BoundaryKey(int axis, int plane, int a, int b) {
   }

   private record Parked(Results results, int sx, int sy, int sz, EncodedSectionMesh encoded, int[] translucentOrder, byte builtTier) {
   }
}
