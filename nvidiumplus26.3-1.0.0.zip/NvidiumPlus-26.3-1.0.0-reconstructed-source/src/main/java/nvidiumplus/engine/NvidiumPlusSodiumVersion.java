package nvidiumplus.engine;

public final class NvidiumPlusSodiumVersion {
   public static final String BUILT_AGAINST = NvidiumPlusBuild.SODIUM_BUILT_AGAINST;

   private NvidiumPlusSodiumVersion() {
   }

   public static String baseVersion(String reported) {
      if (reported == null) {
         return "";
      }

      int plus = reported.indexOf(43);
      return plus < 0 ? reported : reported.substring(0, plus);
   }

   public static String builtAgainstBase() {
      return baseVersion(BUILT_AGAINST);
   }

   public static boolean matches(String reported) {
      String base = baseVersion(reported);
      return !base.isEmpty() && (base.equals(builtAgainstBase()) || NvidiumPlusBuild.SODIUM_ALSO_MATCHING.contains(base));
   }
}
