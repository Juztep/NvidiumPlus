package nvidiumplus.engine;

import com.sun.management.HotSpotDiagnosticMXBean;
import java.lang.management.ManagementFactory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.toasts.SystemToast.SystemToastId;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;

public final class NvidiumPlusLaunchCheck {
   public static final int REQUIRED_SHADOW_PAGES = NvidiumPlusBuild.LAUNCH_SHADOW_PAGES;
   static final int FIRST_JAVA_WITH_FLAG = 25;
   private static final SystemToastId TOAST_ID = new SystemToastId();
   private static volatile long effectiveShadowPages = -1L;
   private static volatile boolean noticeOwed;
   private static volatile boolean noticeShown;

   private NvidiumPlusLaunchCheck() {
   }

   public static void run() {
      try {
         if (REQUIRED_SHADOW_PAGES <= 0) {
            NvidiumPlusLog.LOGGER
               .debug("Launch check: Minecraft {}'s launch profile passes no -XX:StackShadowPages; nothing to check", NvidiumPlusBuild.MINECRAFT_TARGET);
            return;
         }

         int java = Runtime.version().feature();
         if (java < 25) {
            return;
         }

         long pages = readShadowPages();
         effectiveShadowPages = pages;
         if (pages < 0L) {
            NvidiumPlusLog.LOGGER.debug("Launch check: could not read -XX:StackShadowPages on this JVM; skipped");
            return;
         }

         if (pages >= REQUIRED_SHADOW_PAGES) {
            NvidiumPlusLog.LOGGER
               .info(
                  "Launch check: -XX:StackShadowPages={} (Minecraft {}'s launch profile asks for {}) - fine",
                  new Object[]{pages, NvidiumPlusBuild.MINECRAFT_TARGET, REQUIRED_SHADOW_PAGES}
               );
            return;
         }

         NvidiumPlusLog.LOGGER
            .warn(
               "Your launcher started Minecraft without -XX:StackShadowPages={} (the JVM is running with {}). Minecraft {}'s own launch profile passes it, and without it the game can close without a word - no crash report, no hs_err file - at start-up, at the title screen, or when a menu opens. Add -XX:StackShadowPages={} to this instance's Java arguments. This is a launcher setting, not a NvidiumPlus problem (MultiMC/Launcher#5779, PrismLauncher/PrismLauncher#6073); NvidiumPlus only reports it so the closing stops being a mystery.",
               new Object[]{REQUIRED_SHADOW_PAGES, pages, NvidiumPlusBuild.MINECRAFT_TARGET, REQUIRED_SHADOW_PAGES}
            );
         noticeOwed = true;
         NvidiumPlusPlatform.onEndClientTick(NvidiumPlusLaunchCheck::onEndTick);
      } catch (Throwable t) {
         NvidiumPlusLog.LOGGER.debug("Launch check skipped", t);
      }
   }

   static long readShadowPages() {
      try {
         HotSpotDiagnosticMXBean bean = ManagementFactory.getPlatformMXBean(HotSpotDiagnosticMXBean.class);
         if (bean != null) {
            return Long.parseLong(bean.getVMOption("StackShadowPages").getValue().trim());
         }
      } catch (Throwable t) {
         NvidiumPlusLog.LOGGER.debug("Launch check: no HotSpot diagnostic bean, reading the command line", t);
      }

      try {
         String prefix = "-XX:StackShadowPages=";

         for (String argument : ManagementFactory.getRuntimeMXBean().getInputArguments()) {
            if (argument.startsWith(prefix)) {
               return Long.parseLong(argument.substring(prefix.length()).trim());
            }
         }
      } catch (Throwable t) {
         NvidiumPlusLog.LOGGER.debug("Launch check: could not read the JVM arguments", t);
      }

      return -1L;
   }

   private static void onEndTick(Minecraft minecraft) {
      if (noticeOwed && !noticeShown && minecraft != null && minecraft.gui != null) {
         if (minecraft.gui.screen() instanceof TitleScreen) {
            noticeShown = true;
            NvidiumPlusNotify.error(
               TOAST_ID,
               Component.translatable("nvidiumplus.toast.launch.title"),
               Component.translatable("nvidiumplus.toast.launch.shadow", new Object[]{REQUIRED_SHADOW_PAGES, effectiveShadowPages})
            );
         }
      }
   }

   public static long effectiveShadowPages() {
      return effectiveShadowPages;
   }

   public static boolean noticeOwed() {
      return noticeOwed;
   }
}
