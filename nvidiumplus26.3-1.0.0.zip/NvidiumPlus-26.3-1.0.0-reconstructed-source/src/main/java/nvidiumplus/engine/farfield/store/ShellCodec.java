package nvidiumplus.engine.farfield.store;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Inflater;

public final class ShellCodec {
   static final byte[] MAGIC = new byte[]{77, 70, 70, 49};
   public static final byte FORMAT_VERSION = 5;
   public static final byte SIGNATURE_MIN_VERSION = 5;
   public static final int NO_STATE = -1;
   public static final int MAX_STATE_INDEX = 1048575;
   static final int STATE_SIG_BYTES = 2;
   public static final int ORIGIN_UNKNOWN = Integer.MIN_VALUE;
   public static final int TINT_SIDE_NONE = 0;
   public static final int TINT_SIDE_CELL = 16;
   public static final int TINT_SIDE_EXACT = 17;
   public static final int TINT_SIDE_SINGLE = 1;
   public static final int TINT_SIDE_COARSE = 3;
   public static final int TINT_SIDE_FINE = 5;
   public static final byte MIN_READ_VERSION = 1;
   public static final byte FULL_SHELL = -1;
   public static final int TIER_GENERATED = 0;
   public static final int TIER_IMPORTED = 1;
   public static final int TIER_VISITED = 2;
   public static final int MAX_CELLS = 65536;
   public static final int MAX_PALETTE = 256;
   public static final int MAX_PAYLOAD_BYTES = 1048576;
   static final int MIN_WORLD_Y = -2032;
   static final int MAX_WORLD_Y = 2031;
   private static final int FACE_MASK_ALL = 63;

   private ShellCodec() {
   }

   public static int packCell(int x, int yRel, int z, int paletteIndex, int faceMask) {
      return faceMask << 24 | paletteIndex << 16 | (yRel & 0xFF) << 8 | (x & 15) << 4 | z & 15;
   }

   public static int cellX(int cell) {
      return cell >>> 4 & 15;
   }

   public static int cellZ(int cell) {
      return cell & 15;
   }

   public static int cellYRel(int cell) {
      return cell >>> 8 & 0xFF;
   }

   public static int cellPaletteIndex(int cell) {
      return cell >>> 16 & 0xFF;
   }

   public static int cellFaceMask(int cell) {
      return cell >>> 24 & 0xFF;
   }

   public static byte[] encode(ShellCodec.Shell shell) {
      if (shell != null && encodable(shell)) {
         ByteArrayOutputStream out = new ByteArrayOutputStream(64 + shell.cellCount * 2);
         out.write(MAGIC[0]);
         out.write(MAGIC[1]);
         out.write(MAGIC[2]);
         out.write(MAGIC[3]);
         Deflater deflater = new Deflater(6);

         try (DataOutputStream data = new DataOutputStream(new DeflaterOutputStream(out, deflater, 4096))) {
            data.writeByte(5);
            data.writeInt(shell.saveSignature);
            data.writeByte(shell.tier);
            data.writeByte(shell.bandOffset);
            data.writeShort(shell.minY);
            data.writeInt(shell.cellCount);
            data.writeShort(shell.palette.length);
            writePalette(data, shell);
            int[] tints = shell.paletteTint;
            int side = tints == null ? 0 : shell.tintGridSide;
            data.writeByte(side);
            if (tints != null) {
               int nodes = side * side;

               for (int e = 0; e < shell.palette.length; e++) {
                  int base = e * nodes;
                  if (side > 1) {
                     boolean uniform = true;
                     int first = tints[base];

                     for (int n = 1; n < nodes && uniform; n++) {
                        uniform = tints[base + n] == first;
                     }

                     data.writeByte(uniform ? 1 : 0);
                     if (uniform) {
                        writeRgb(data, first);
                        continue;
                     }
                  }

                  for (int n = 0; n < nodes; n++) {
                     writeRgb(data, tints[base + n]);
                  }
               }
            }

            byte[] light = shell.cellLight;
            data.writeByte(light == null ? 0 : 1);

            for (int i = 0; i < shell.cellCount; i++) {
               int cell = shell.cells[i];
               data.writeShort(cell & 65535);
               data.writeByte(cellPaletteIndex(cell));
               data.writeByte(cellFaceMask(cell));
            }

            if (light != null) {
               data.write(light, 0, shell.cellCount);
            }
         } catch (IOException impossible) {
            return null;
         } finally {
            deflater.end();
         }

         return out.toByteArray();
      } else {
         return null;
      }
   }

   private static void writePalette(DataOutputStream data, ShellCodec.Shell shell) throws IOException {
      String[] palette = shell.palette;
      String[] names = new String[palette.length];
      int[] nameSig = new int[palette.length];
      int[] nameOf = new int[palette.length];
      int nameCount = 0;

      for (int e = 0; e < palette.length; e++) {
         int found = -1;

         for (int n = 0; n < nameCount; n++) {
            if (names[n].equals(palette[e])) {
               found = n;
               break;
            }
         }

         if (found < 0) {
            found = nameCount;
            names[nameCount] = palette[e];
            nameSig[nameCount] = shell.stateSig(e) & 65535;
            nameCount++;
         }

         nameOf[e] = found;
      }

      data.writeShort(nameCount);

      for (int n = 0; n < nameCount; n++) {
         data.writeUTF(names[n]);
         data.writeShort(nameSig[n]);
      }

      for (int e = 0; e < palette.length; e++) {
         data.writeByte(nameOf[e]);
         int state = shell.stateIndex(e);
         writeVarInt(data, state == -1 ? 0 : state + 1);
      }
   }

   private static void writeVarInt(DataOutputStream data, int value) throws IOException {
      int v;
      for (v = value; (v & -128) != 0; v >>>= 7) {
         data.writeByte(v & 127 | 128);
      }

      data.writeByte(v);
   }

   private static int readVarInt(DataInputStream in) throws IOException {
      int value = 0;

      for (int shift = 0; shift < 35; shift += 7) {
         int b = in.readUnsignedByte();
         value |= (b & 127) << shift;
         if ((b & 128) == 0) {
            return value < 0 ? -1 : value;
         }
      }

      return -1;
   }

   private static void writeRgb(DataOutputStream data, int rgb) throws IOException {
      data.writeByte(rgb >>> 16 & 0xFF);
      data.writeByte(rgb >>> 8 & 0xFF);
      data.writeByte(rgb & 0xFF);
   }

   private static boolean legalTintSide(int side) {
      return side == 1 || side == 3 || side == 5 || side == 16 || side == 17;
   }

   private static boolean encodable(ShellCodec.Shell shell) {
      if (shell.formatVersion != 5) {
         return false;
      }

      if (shell.tier < 0 || shell.tier > 2) {
         return false;
      }

      if (shell.bandOffset != -1 && shell.bandOffset < 1) {
         return false;
      }

      if (shell.minY < -2032 || shell.minY > 2031) {
         return false;
      }

      if (shell.cellCount >= 0 && shell.cellCount <= 65536) {
         if (shell.cells != null && shell.cells.length >= shell.cellCount) {
            String[] palette = shell.palette;
            if (palette != null && palette.length <= 256 && (shell.cellCount <= 0 || palette.length != 0)) {
               for (String name : palette) {
                  if (name == null) {
                     return false;
                  }
               }

               int[] states = shell.paletteState;
               if (states != null) {
                  int[] sigs = shell.paletteStateSig;
                  if (states.length != palette.length || sigs == null || sigs.length != palette.length) {
                     return false;
                  }

                  for (int e = 0; e < palette.length; e++) {
                     if (states[e] != -1 && (states[e] < 0 || states[e] > 1048575)) {
                        return false;
                     }

                     if (sigs[e] != (sigs[e] & 65535)) {
                        return false;
                     }

                     for (int f = 0; f < e; f++) {
                        if (palette[f].equals(palette[e]) && sigs[f] != sigs[e]) {
                           return false;
                        }
                     }
                  }
               }

               if (shell.paletteTint != null) {
                  int side = shell.tintGridSide;
                  if (!legalTintSide(side) || shell.paletteTint.length != palette.length * side * side) {
                     return false;
                  }
               }

               if (shell.cellLight != null && shell.cellLight.length < shell.cellCount) {
                  return false;
               }

               for (int i = 0; i < shell.cellCount; i++) {
                  int cell = shell.cells[i];
                  if (cellPaletteIndex(cell) >= palette.length) {
                     return false;
                  }

                  int mask = cellFaceMask(cell);
                  if (mask == 0 || mask > 63) {
                     return false;
                  }
               }

               return true;
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static ShellCodec.Shell decode(byte[] record, int chunkX, int chunkZ) {
      ShellCodec.Shell shell = decode(record);
      return shell == null ? null : shell.withOrigin(chunkX, chunkZ);
   }

   public static ShellCodec.Shell decode(byte[] record) {
      if (record == null || record.length < MAGIC.length + 1) {
         return null;
      }

      if (record[0] == MAGIC[0] && record[1] == MAGIC[1] && record[2] == MAGIC[2] && record[3] == MAGIC[3]) {
         byte[] payload = inflateBounded(record, MAGIC.length, record.length - MAGIC.length);
         if (payload == null) {
            return null;
         }

         try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(payload))) {
            int version = in.readUnsignedByte();
            if (version < 1 || version > 5) {
               return null;
            }

            int saveSignature = version >= 5 ? in.readInt() : 0;
            int tier = in.readUnsignedByte();
            if (tier > 2) {
               return null;
            }

            byte bandOffset = in.readByte();
            if (bandOffset != -1 && bandOffset < 1) {
               return null;
            }

            short minY = in.readShort();
            if (minY < -2032 || minY > 2031) {
               return null;
            }

            int cellCount = in.readInt();
            if (cellCount < 0 || cellCount > 65536) {
               return null;
            }

            int paletteCount = in.readUnsignedShort();
            if (paletteCount > 256 || cellCount > 0 && paletteCount == 0) {
               return null;
            }

            String[] palette = new String[paletteCount];
            int[] paletteState = null;
            int[] paletteStateSig = null;
            if (version < 4) {
               for (int i = 0; i < paletteCount; i++) {
                  palette[i] = in.readUTF();
               }
            } else {
               int nameCount = in.readUnsignedShort();
               if (nameCount > paletteCount) {
                  return null;
               }

               String[] names = new String[nameCount];
               int[] sigs = new int[nameCount];

               for (int n = 0; n < nameCount; n++) {
                  names[n] = in.readUTF();
                  sigs[n] = in.readUnsignedShort();
               }

               paletteState = new int[paletteCount];
               paletteStateSig = new int[paletteCount];
               boolean anyState = false;

               for (int e = 0; e < paletteCount; e++) {
                  int nameIndex = in.readUnsignedByte();
                  if (nameIndex >= nameCount) {
                     return null;
                  }

                  int state = readVarInt(in);
                  if (state < 0 || state > 1048576) {
                     return null;
                  }

                  palette[e] = names[nameIndex];
                  paletteState[e] = state == 0 ? -1 : state - 1;
                  paletteStateSig[e] = sigs[nameIndex];
                  anyState |= state != 0;
               }

               if (!anyState) {
                  paletteState = null;
                  paletteStateSig = null;
               }
            }

            int[] paletteTint = null;
            int tintSide = 0;
            boolean hasLight = false;
            if (version >= 2) {
               int declared = in.readUnsignedByte();
               if (declared != 0 && !legalTintSide(declared)) {
                  return null;
               }

               if (version == 2 && declared > 1) {
                  return null;
               }

               tintSide = declared;
               if (tintSide != 0) {
                  int nodes = tintSide * tintSide;
                  paletteTint = new int[paletteCount * nodes];
                  boolean allUniform = true;

                  for (int e = 0; e < paletteCount; e++) {
                     int base = e * nodes;
                     boolean uniform = tintSide == 1;
                     if (!uniform) {
                        int flag = in.readUnsignedByte();
                        if (flag > 1) {
                           return null;
                        }

                        uniform = flag == 1;
                     }

                     allUniform &= uniform;
                     if (uniform) {
                        int rgb = readRgb(in);

                        for (int n = 0; n < nodes; n++) {
                           paletteTint[base + n] = rgb;
                        }
                     } else {
                        for (int n = 0; n < nodes; n++) {
                           paletteTint[base + n] = readRgb(in);
                        }
                     }
                  }

                  if (allUniform && tintSide != 1) {
                     int[] collapsed = new int[paletteCount];

                     for (int e = 0; e < paletteCount; e++) {
                        collapsed[e] = paletteTint[e * nodes];
                     }

                     paletteTint = collapsed;
                     tintSide = 1;
                  }
               }
            }

            if (version >= 3) {
               int lightPresent = in.readUnsignedByte();
               if (lightPresent > 1) {
                  return null;
               }

               hasLight = lightPresent == 1;
            }

            int[] cells = new int[cellCount];
            int i = 0;

            while (true) {
               if (i < cellCount) {
                  int pos = in.readUnsignedShort();
                  int paletteIndex = in.readUnsignedByte();
                  if (paletteIndex >= paletteCount) {
                     return null;
                  }

                  int mask = in.readUnsignedByte();
                  if (mask != 0 && mask <= 63) {
                     cells[i] = mask << 24 | paletteIndex << 16 | pos;
                     i++;
                     continue;
                  }

                  return null;
               }

               cellLight = null;
               if (hasLight) {
                  cellLight = new byte[cellCount];
                  in.readFully(cellLight);
               }
               break;
            }

            return in.read() != -1
               ? null
               : new ShellCodec.Shell(
                  cellCount,
                  cells,
                  palette,
                  paletteState,
                  paletteStateSig,
                  paletteTint,
                  tintSide,
                  cellLight,
                  (byte)tier,
                  (byte)version,
                  bandOffset,
                  minY,
                  Integer.MIN_VALUE,
                  Integer.MIN_VALUE,
                  saveSignature
               );
         } catch (IOException malformed) {
            return null;
         }
      } else {
         return null;
      }
   }

   private static int readRgb(DataInputStream in) throws IOException {
      return in.readUnsignedByte() << 16 | in.readUnsignedByte() << 8 | in.readUnsignedByte();
   }

   private static byte[] inflateBounded(byte[] src, int off, int len) {
      Inflater inflater = new Inflater();

      try {
         inflater.setInput(src, off, len);
         ByteArrayOutputStream out = new ByteArrayOutputStream((int)Math.max(64L, Math.min(len * 4L, 65536L)));
         byte[] buffer = new byte[8192];
         int total = 0;

         while (!inflater.finished()) {
            int n = inflater.inflate(buffer);
            if (n == 0) {
               if (!inflater.finished()) {
                  return null;
               }
               break;
            }

            total += n;
            if (total > 1048576) {
               return null;
            }

            out.write(buffer, 0, n);
         }

         return inflater.getRemaining() != 0 ? null : out.toByteArray();
      } catch (DataFormatException corrupt) {
         return null;
      } finally {
         inflater.end();
      }
   }

   public static final class Shell {
      public final int cellCount;
      public final int[] cells;
      public final String[] palette;
      public final int[] paletteState;
      public final int[] paletteStateSig;
      public final int[] paletteTint;
      public final int tintGridSide;
      public final byte[] cellLight;
      public final byte tier;
      public final byte formatVersion;
      public final byte bandOffset;
      public final short minY;
      public final int saveSignature;
      public final int chunkX;
      public final int chunkZ;

      public Shell(
         int cellCount,
         int[] cells,
         String[] palette,
         int[] paletteState,
         int[] paletteStateSig,
         int[] paletteTint,
         int tintGridSide,
         byte[] cellLight,
         byte tier,
         byte formatVersion,
         byte bandOffset,
         short minY
      ) {
         this(
            cellCount,
            cells,
            palette,
            paletteState,
            paletteStateSig,
            paletteTint,
            tintGridSide,
            cellLight,
            tier,
            formatVersion,
            bandOffset,
            minY,
            Integer.MIN_VALUE,
            Integer.MIN_VALUE,
            0
         );
      }

      public Shell(
         int cellCount,
         int[] cells,
         String[] palette,
         int[] paletteState,
         int[] paletteStateSig,
         int[] paletteTint,
         int tintGridSide,
         byte[] cellLight,
         byte tier,
         byte formatVersion,
         byte bandOffset,
         short minY,
         int chunkX,
         int chunkZ
      ) {
         this(
            cellCount,
            cells,
            palette,
            paletteState,
            paletteStateSig,
            paletteTint,
            tintGridSide,
            cellLight,
            tier,
            formatVersion,
            bandOffset,
            minY,
            chunkX,
            chunkZ,
            0
         );
      }

      public Shell(
         int cellCount,
         int[] cells,
         String[] palette,
         int[] paletteState,
         int[] paletteStateSig,
         int[] paletteTint,
         int tintGridSide,
         byte[] cellLight,
         byte tier,
         byte formatVersion,
         byte bandOffset,
         short minY,
         int chunkX,
         int chunkZ,
         int saveSignature
      ) {
         this.saveSignature = saveSignature;
         this.chunkX = chunkX;
         this.chunkZ = chunkZ;
         this.cellCount = cellCount;
         this.cells = cells;
         this.palette = palette;
         boolean states = paletteState != null && paletteStateSig != null;
         this.paletteState = states ? paletteState : null;
         this.paletteStateSig = states ? paletteStateSig : null;
         this.paletteTint = paletteTint;
         this.tintGridSide = paletteTint == null ? 0 : tintGridSide;
         this.cellLight = cellLight;
         this.tier = tier;
         this.formatVersion = formatVersion;
         this.bandOffset = bandOffset;
         this.minY = minY;
      }

      public Shell(
         int cellCount,
         int[] cells,
         String[] palette,
         int[] paletteTint,
         int tintGridSide,
         byte[] cellLight,
         byte tier,
         byte formatVersion,
         byte bandOffset,
         short minY
      ) {
         this(cellCount, cells, palette, null, null, paletteTint, tintGridSide, cellLight, tier, formatVersion, bandOffset, minY);
      }

      public Shell(int cellCount, int[] cells, String[] palette, int[] paletteTint, byte tier, byte formatVersion, byte bandOffset, short minY) {
         this(cellCount, cells, palette, paletteTint, 1, null, tier, formatVersion, bandOffset, minY);
      }

      public Shell(int cellCount, int[] cells, String[] palette, byte tier, byte formatVersion, byte bandOffset, short minY) {
         this(cellCount, cells, palette, null, 0, null, tier, formatVersion, bandOffset, minY);
      }

      public ShellCodec.Shell withOrigin(int chunkX, int chunkZ) {
         return new ShellCodec.Shell(
            this.cellCount,
            this.cells,
            this.palette,
            this.paletteState,
            this.paletteStateSig,
            this.paletteTint,
            this.tintGridSide,
            this.cellLight,
            this.tier,
            this.formatVersion,
            this.bandOffset,
            this.minY,
            chunkX,
            chunkZ,
            this.saveSignature
         );
      }

      public ShellCodec.Shell withSaveSignature(int saveSignature) {
         return new ShellCodec.Shell(
            this.cellCount,
            this.cells,
            this.palette,
            this.paletteState,
            this.paletteStateSig,
            this.paletteTint,
            this.tintGridSide,
            this.cellLight,
            this.tier,
            this.formatVersion,
            this.bandOffset,
            this.minY,
            this.chunkX,
            this.chunkZ,
            saveSignature
         );
      }

      public boolean hasSaveSignature() {
         return this.formatVersion >= 5;
      }

      public boolean signatureMatches(int current) {
         return this.hasSaveSignature() && this.saveSignature == current;
      }

      public boolean hasOrigin() {
         return this.chunkX != Integer.MIN_VALUE && this.chunkZ != Integer.MIN_VALUE;
      }

      public int stateIndex(int paletteIndex) {
         return this.paletteState != null && paletteIndex >= 0 && paletteIndex < this.paletteState.length ? this.paletteState[paletteIndex] : -1;
      }

      public int stateSig(int paletteIndex) {
         return this.paletteStateSig != null && paletteIndex >= 0 && paletteIndex < this.paletteStateSig.length ? this.paletteStateSig[paletteIndex] : 0;
      }

      public int tintNode(int paletteIndex, int gx, int gz) {
         if (this.paletteTint != null && this.tintGridSide > 0) {
            int side = this.tintGridSide;
            int cx = gx < 0 ? 0 : Math.min(gx, side - 1);
            int cz = gz < 0 ? 0 : Math.min(gz, side - 1);
            int index = (paletteIndex * side + cz) * side + cx;
            return index >= 0 && index < this.paletteTint.length ? this.paletteTint[index] : 16777215;
         } else {
            return 16777215;
         }
      }
   }
}
