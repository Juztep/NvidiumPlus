package nvidiumplus.engine.farfield;

import java.nio.file.Path;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.LevelResource;

public final class CacheKeys {
   public static final String UNKNOWN = "unknown";
   private static final int MAX_KEY_LENGTH = 64;

   private CacheKeys() {
   }

   public static String worldKey(Minecraft minecraft) {
      if (minecraft.hasSingleplayerServer()) {
         IntegratedServer server = minecraft.getSingleplayerServer();
         if (server != null) {
            return singleplayerKey(server.getWorldPath(LevelResource.ROOT));
         }
      }

      ServerData data = minecraft.getCurrentServer();
      if (data == null) {
         return "unknown";
      } else {
         return data.isRealm() ? "realms" : sanitize(data.ip);
      }
   }

   public static String dimensionKey(Level level) {
      Identifier id = level.dimension().identifier();
      return sanitize(id.getNamespace() + ":" + id.getPath());
   }

   static String singleplayerKey(Path worldRoot) {
      Path normalized = worldRoot.toAbsolutePath().normalize();
      Path name = normalized.getFileName();
      return name == null ? "unknown" : sanitize(name.toString());
   }

   public static String sanitize(String raw) {
      if (raw == null) {
         return "unknown";
      }

      String lower = raw.toLowerCase(Locale.ROOT).replace(':', '_');
      StringBuilder out = new StringBuilder(Math.min(lower.length(), 64));
      boolean allDots = true;

      for (int i = 0; i < lower.length() && out.length() < 64; i++) {
         char c = lower.charAt(i);
         boolean ok = c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '.' || c == '_' || c == '-';
         if (ok) {
            out.append(c);
            allDots &= c == '.';
         }
      }

      return !out.isEmpty() && !allDots ? out.toString() : "unknown";
   }
}
