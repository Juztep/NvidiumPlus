package nvidiumplus.engine.farfield;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.lang.ref.WeakReference;
import java.util.ArrayDeque;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.farfield.extract.ExtractDispatch;
import nvidiumplus.engine.farfield.mesh.ShellMesher;
import nvidiumplus.engine.farfield.mesh.SpriteUvResolver;
import nvidiumplus.engine.farfield.store.ShellCodec;
import nvidiumplus.engine.terrain.EncodedSectionMesh;
import nvidiumplus.engine.terrain.host.SectionBuildTap;
import nvidiumplus.engine.terrain.host.TerrainResidency;

public final class FarFieldResidency {
   public static final LongAdder farSectionsResident = new LongAdder();
   public static final LongAdder farShellRequests = new LongAdder();
   public static final LongAdder farMeshedSections = new LongAdder();
   public static final LongAdder farAdmissions = new LongAdder();
   public static final LongAdder farReleases = new LongAdder();
   public static final LongAdder farPromoteBudgetStalls = new LongAdder();
   public static final LongAdder farMeshSkippedCells = new LongAdder();
   public static final LongAdder farMeshErrors = new LongAdder();
   public static final LongAdder farLateShells = new LongAdder();
   public static final LongAdder farInFlightRescues = new LongAdder();
   public static final LongAdder farApronRefreshFiled = new LongAdder();
   public static final LongAdder farApronRefreshIssued = new LongAdder();
   public static final LongAdder farSupersededByVanilla = new LongAdder();
   public static final LongAdder farContestedSections = new LongAdder();
   public static final LongAdder farBlockersReleased = new LongAdder();
   public static final LongAdder farWaterOpaqueQuads = new LongAdder();
   public static final LongAdder farVanillaReloads = new LongAdder();
   public static final LongAdder farStandDownPumps = new LongAdder();
   public static final LongAdder farReloads = new LongAdder();
   public static final LongAdder farReloadSections = new LongAdder();
   public static final LongAdder farAdmitSkipped = new LongAdder();
   public static final LongAdder farAdmitNoBudget = new LongAdder();
   public static final LongAdder farAdmitDeferred = new LongAdder();
   public static final LongAdder farColumnsAllSkipped = new LongAdder();
   public static final LongAdder farHolesFiled = new LongAdder();
   public static final LongAdder farHolesDrained = new LongAdder();
   public static final LongAdder farIdleRescans = new LongAdder();
   public static final LongAdder farHoleRetryBackoffs = new LongAdder();
   public static final int ADMIT_OK = 0;
   public static final int ADMIT_DEFER = 1;
   public static final int ADMIT_NO_BUDGET = 2;
   public static final int ADMIT_SKIPPED = 3;
   public static final int ADMIT_CONTESTED = 4;
   public static final int ADMIT_REPLACED = 5;
   private static final int MAX_IN_FLIGHT = 8;
   private static final int SCAN_STEPS_PER_PUMP = 4096;
   private static final int DEFAULT_HANDOVER_BAND_CHUNKS = 4;
   private static final int MAX_HANDOVER_BAND_CHUNKS = 8;
   private static final int HANDOVER_BAND_CHUNKS = resolveHandoverBand();
   private static final int RELEASE_COLUMN_BUDGET = 64;
   private static final int NEAR_OWNED_CAP = 8192;
   private static final long IDLE_RESCAN_NANOS = 2000000000L;
   private static final int HOLED_COLUMN_CAP = 4096;
   private static final int HOLED_DRAIN_PER_PUMP = 8;
   private static final int RESULT_QUEUE_CAP = 64;
   private static final long MIN_STAND_DOWN_NANOS = 500000000L;
   private static final long MAX_STAND_DOWN_NANOS = 10000000000L;
   private static final int STAND_DOWN_SETTLED_PUMPS = 8;
   private static final int RESULT_MISS = 0;
   private static final int RESULT_DECODED = 1;
   private static final int RESULT_MESHED = 2;
   private static final int RESULT_ERROR = 3;
   private static final ArrayDeque<FarFieldResidency.IoResult> resultQueue = new ArrayDeque<>();
   private static volatile int generation;
   private static volatile boolean broken;
   private static final AtomicBoolean brokenLogged = new AtomicBoolean();
   private static final Long2ObjectOpenHashMap<IntArrayList> residentColumns = new Long2ObjectOpenHashMap();
   private static final LongOpenHashSet inFlightSet = new LongOpenHashSet();
   private static final LongOpenHashSet absentSet = new LongOpenHashSet();
   private static final LongOpenHashSet queuedSet = new LongOpenHashSet();
   private static final LongOpenHashSet partialColumns = new LongOpenHashSet();
   private static final LongOpenHashSet refillColumns = new LongOpenHashSet();
   private static final LongOpenHashSet lateShells = new LongOpenHashSet();
   private static final int LATE_SHELL_CAP = 4096;
   private static final LongOpenHashSet refreshColumns = new LongOpenHashSet();
   private static final LongOpenHashSet apronRefreshColumns = new LongOpenHashSet();
   private static final int APRON_REFRESH_ISSUES_PER_PUMP = 2;
   private static final int APRON_REFRESH_RESERVED_SLOTS = 4;
   private static final LongOpenHashSet unblockedColumns = new LongOpenHashSet();
   private static final LongOpenHashSet nearOwnedColumns = new LongOpenHashSet();
   private static final LongOpenHashSet holedColumns = new LongOpenHashSet();
   private static final ArrayDeque<FarFieldResidency.MeshedColumn> pendingAdmissions = new ArrayDeque<>();
   private static int pendingAdmissionSections;
   private static long lastCamera = Long.MIN_VALUE;
   private static int lastNearEdge = -1;
   private static int lastCoverEdge = -1;
   private static int lastL1 = -1;
   private static boolean scanPending;
   private static int scanRing;
   private static int scanIndex;
   private static boolean demotePending;
   private static long lastScanArmNanos = System.nanoTime();
   private static int farColumnsAllSkippedSinceScan;
   private static long lastNoBudgetSeen;
   private static long lastAdmissionsSeen;
   private static boolean lastPumpGuardOpen;
   private static long holeRetryBlockedUntilNanos = System.nanoTime();
   private static final int SIGNATURE_UNSET = Integer.MIN_VALUE;
   private static int lastMeshSignature = Integer.MIN_VALUE;
   private static int lastSaveSignature = Integer.MIN_VALUE;
   private static WeakReference<Object> lastLevel = new WeakReference<>(null);
   private static WeakReference<Object> lastViewArea = new WeakReference<>(null);
   private static boolean standDown;
   private static int heldSweepRadius;
   private static long standDownStartNanos;
   private static int standDownSettledPumps;
   public static final int COL_RESIDENT = 0;
   public static final int COL_RESIDENT_PARTIAL = 1;
   public static final int COL_RESIDENT_REFILL = 2;
   public static final int COL_IN_FLIGHT = 3;
   public static final int COL_QUEUED = 4;
   public static final int COL_LATE_PENDING = 5;
   public static final int COL_ABSENT = 6;
   public static final int COL_NEAR_COVERED = 7;
   public static final int COL_OUTSIDE_RING = 8;
   public static final int COL_NEVER_SCANNED = 9;
   public static final int COL_DROPPED = 10;
   public static final int COL_WALKER_IDLE = 11;
   public static final int COL_UNBLOCK_PENDING = 12;
   public static final int COL_NEAR_OWNED = 13;
   public static final int COL_STATE_COUNT = 14;

   private FarFieldResidency() {
   }

   public static void pump() {
      if (!broken) {
         try {
            pumpInner();
         } catch (Throwable t) {
            latchBroken("far-field pump", t);
         }
      }
   }

   private static void pumpInner() {
      Minecraft mc = Minecraft.getInstance();
      boolean nearFieldBusy = mc != null && mc.levelRenderer != null && !mc.levelRenderer.hasRenderedAllSections();
      if (detectVanillaReload(mc)) {
         onVanillaReload();
      }

      Object level = mc != null ? mc.level : null;
      if (level != lastLevel.get()) {
         lastLevel = new WeakReference<>(level);
         resetTransientState();
      }

      boolean enabled = FarFieldConfig.enabled() && NvidiumPlusConfig.terrainRenderingConfigured();
      long camera = SectionBuildTap.cameraSectionXZ();
      int nearEdge = mc != null && mc.options != null ? mc.options.getEffectiveRenderDistance() : 0;
      boolean cameraKnown = camera != Long.MIN_VALUE;
      ExtractDispatch.pumpGameThread(
         cameraKnown ? (int)(camera >> 32) : 0, cameraKnown ? (int)camera : 0, enabled && cameraKnown ? sweepRadiusFor(nearEdge) : 0, nearFieldBusy
      );
      drainResults(enabled);
      if (standDown && !releaseStandDown(nearFieldBusy)) {
         farStandDownPumps.increment();
      } else {
         int l1 = FarFieldConfig.l1RadiusChunks();
         if (mc != null && mc.options != null) {
            int farPlaneChunks = Math.max(nearEdge * 4, (Integer)mc.options.cloudRange().get());
            l1 = Math.min(l1, Math.max(0, farPlaneChunks - 1));
         }

         boolean armed = enabled && level != null && camera != Long.MIN_VALUE && nearEdge > 0 && l1 > nearEdge;
         if (!armed) {
            TerrainResidency.clearFarCoverage();
            scanPending = false;
            lastCamera = Long.MIN_VALUE;
            if (!pendingAdmissions.isEmpty()) {
               dropPendingAdmissions();
            }

            releaseColumns(64, Long.MIN_VALUE, -1, -1);
         } else {
            if (camera != lastCamera || nearEdge != lastNearEdge || l1 != lastL1) {
               if (l1 != lastL1 && mc != null && mc.options != null) {
                  TerrainResidency.requestPinnedGrow((Integer)mc.options.renderDistance().get());
               }

               if (nearEdge != lastNearEdge) {
                  nearOwnedColumns.clear();
               }

               lastCamera = camera;
               lastNearEdge = nearEdge;
               lastCoverEdge = coverRadius(nearEdge);
               lastL1 = l1;
               scanPending = true;
               scanRing = innerScanRing(lastCoverEdge);
               scanIndex = 0;
               lastScanArmNanos = System.nanoTime();
               farColumnsAllSkippedSinceScan = 0;
               demotePending = true;
               SpriteUvResolver.clearCache();
            }

            TerrainResidency.publishFarCoverage(lastCamera, lastCoverEdge, lastL1);
            if (demotePending) {
               demotePending = releaseColumns(64, camera, nearEdge, l1);
            }

            noteAppearanceSettings();
            boolean hasRoom = TerrainResidency.farPromotionHasRoom();
            noteRefusalsWhileGuardOpen(hasRoom);
            maybeRescanForOutstandingWork(hasRoom);
            if (!lateShells.isEmpty()
               || !unblockedColumns.isEmpty()
               || !refreshColumns.isEmpty()
               || !apronRefreshColumns.isEmpty()
               || !holedColumns.isEmpty()
               || scanPending) {
               if (!hasRoom) {
                  farPromoteBudgetStalls.increment();
               }

               drainUnblockedColumns();
               drainRefreshColumns();
               drainApronRefreshColumns();
               if (hasRoom) {
                  drainLateShells();
                  drainHoledColumns();
                  if (scanPending) {
                     continuePromotionScan();
                  }
               }
            }
         }
      }
   }

   private static void noteAppearanceSettings() {
      int mesh = FarFieldConfig.farMeshSignature();
      int save = FarFieldConfig.farSaveSignature();
      FarField.noteSaveSignature(save);
      boolean meshMoved = lastMeshSignature != Integer.MIN_VALUE && lastMeshSignature != mesh;
      boolean saveMoved = lastSaveSignature != Integer.MIN_VALUE && lastSaveSignature != save;
      lastMeshSignature = mesh;
      lastSaveSignature = save;
      if (meshMoved) {
         reloadFarField();
      }

      if (saveMoved) {
         ExtractDispatch.forgetExtractedColumns();
      }
   }

   private static void reloadFarField() {
      if (!pendingAdmissions.isEmpty()) {
         dropPendingAdmissions();
      }

      int released = TerrainResidency.releaseAllFar();
      farReleases.add(released);
      farSectionsResident.add(-released);
      farReloads.increment();
      farReloadSections.add(released);
      residentColumns.clear();
      partialColumns.clear();
      refillColumns.clear();
      refreshColumns.clear();
      apronRefreshColumns.clear();
      holedColumns.clear();
      scanPending = true;
      scanRing = innerScanRing(lastCoverEdge);
      scanIndex = 0;
      lastScanArmNanos = System.nanoTime();
      farColumnsAllSkippedSinceScan = 0;
   }

   private static int sweepRadiusFor(int nearEdge) {
      int storage = Math.max(2, nearEdge) + 3;
      if (storage >= heldSweepRadius) {
         heldSweepRadius = storage;
      } else if (!standDown && ExtractDispatch.pinnedCount() == 0 && ExtractDispatch.pendingCaptureCount() == 0) {
         heldSweepRadius = storage;
      }

      return heldSweepRadius;
   }

   public static void republishCoverage(int nearEdge) {
      int l1 = TerrainResidency.publishedFarCoverageL1();
      if (l1 > 0 && nearEdge > 0) {
         long camera = SectionBuildTap.cameraSectionXZ();
         if (camera == Long.MIN_VALUE) {
            camera = lastCamera;
         }

         if (camera != Long.MIN_VALUE) {
            TerrainResidency.publishFarCoverage(camera, coverRadius(nearEdge), l1);
         }
      }
   }

   private static boolean detectVanillaReload(Minecraft mc) {
      Object viewArea = mc != null && mc.levelRenderer != null ? mc.levelRenderer.viewArea() : null;
      Object previous = lastViewArea.get();
      if (viewArea == previous) {
         return false;
      }

      lastViewArea = new WeakReference<>(viewArea);
      return previous != null && viewArea != null;
   }

   private static void onVanillaReload() {
      farVanillaReloads.increment();
      absentSet.clear();
      nearOwnedColumns.clear();
      lateShells.clear();
      unblockedColumns.clear();
      holedColumns.clear();
      farColumnsAllSkippedSinceScan = 0;
      scanPending = false;
      demotePending = false;
      lastCamera = Long.MIN_VALUE;
      lastNearEdge = -1;
      lastCoverEdge = -1;
      lastL1 = -1;
      if (!standDown) {
         standDownStartNanos = System.nanoTime();
      }

      standDown = true;
      standDownSettledPumps = 0;
      ExtractDispatch.setStandDown(true);
   }

   private static boolean releaseStandDown(boolean nearFieldBusy) {
      long elapsed = System.nanoTime() - standDownStartNanos;
      if (elapsed >= 10000000000L) {
         endStandDown();
         return true;
      }

      if (elapsed < 500000000L) {
         standDownSettledPumps = 0;
         return false;
      }

      if (nearFieldBusy) {
         standDownSettledPumps = 0;
         return false;
      }

      if (++standDownSettledPumps < 8) {
         return false;
      }

      endStandDown();
      return true;
   }

   private static void endStandDown() {
      standDown = false;
      standDownSettledPumps = 0;
      ExtractDispatch.setStandDown(false);
   }

   private static void drainLateShells() {
      LongIterator it = lateShells.iterator();

      while (it.hasNext()) {
         if (inFlightSet.size() >= 8) {
            return;
         }

         long key = it.nextLong();
         it.remove();
         if (stillWanted(key)
            && (!residentColumns.containsKey(key) || partialColumns.contains(key) || refillColumns.contains(key))
            && !inFlightSet.contains(key)
            && !queuedSet.contains(key)) {
            issueRequest(key, false);
         }
      }
   }

   private static void drainUnblockedColumns() {
      LongIterator it = unblockedColumns.iterator();

      while (it.hasNext()) {
         if (inFlightSet.size() >= 8) {
            return;
         }

         long key = it.nextLong();
         it.remove();
         if (stillWanted(key)
            && !inFlightSet.contains(key)
            && !queuedSet.contains(key)
            && (!residentColumns.containsKey(key) || partialColumns.contains(key) || refillColumns.contains(key))) {
            issueRequest(key, false);
         }
      }
   }

   private static void drainRefreshColumns() {
      LongIterator it = refreshColumns.iterator();

      while (it.hasNext()) {
         if (inFlightSet.size() >= 8) {
            return;
         }

         long key = it.nextLong();
         if (!stillWanted(key)) {
            it.remove();
         } else if (!inFlightSet.contains(key) && !queuedSet.contains(key)) {
            it.remove();
            if (!residentColumns.containsKey(key)) {
               if (lateShells.size() < 4096) {
                  lateShells.add(key);
               }
            } else {
               issueRequest(key, true);
            }
         }
      }
   }

   private static void drainApronRefreshColumns() {
      int issued = 0;
      LongIterator it = apronRefreshColumns.iterator();

      while (it.hasNext()) {
         if (inFlightSet.size() >= 4 || issued >= 2) {
            return;
         }

         long key = it.nextLong();
         if (!stillWanted(key)) {
            it.remove();
         } else if (refreshColumns.contains(key)) {
            it.remove();
         } else if (!inFlightSet.contains(key) && !queuedSet.contains(key)) {
            it.remove();
            if (residentColumns.containsKey(key)) {
               issueRequest(key, true);
               issued++;
               farApronRefreshIssued.increment();
            }
         }
      }
   }

   private static void noteRefusalsWhileGuardOpen(boolean hasRoom) {
      long refusals = farAdmitNoBudget.sum();
      long refusedSince = refusals - lastNoBudgetSeen;
      lastNoBudgetSeen = refusals;
      long admits = farAdmissions.sum();
      long admittedSince = admits - lastAdmissionsSeen;
      lastAdmissionsSeen = admits;
      boolean wasOpen = lastPumpGuardOpen;
      lastPumpGuardOpen = hasRoom;
      if (wasOpen && refusedSince > 0L && admittedSince == 0L) {
         holeRetryBlockedUntilNanos = System.nanoTime() + 2000000000L;
         farHoleRetryBackoffs.increment();
      }
   }

   private static boolean holeRetriesBlocked() {
      return System.nanoTime() - holeRetryBlockedUntilNanos < 0L;
   }

   private static void maybeRescanForOutstandingWork(boolean hasRoom) {
      if (!scanPending && hasRoom && lastCoverEdge >= 0) {
         if (!holeRetriesBlocked()) {
            if (partialColumns.isEmpty() && refillColumns.isEmpty() && holedColumns.isEmpty() && farColumnsAllSkippedSinceScan == 0) {
               lastScanArmNanos = System.nanoTime();
            } else {
               long now = System.nanoTime();
               if (now - lastScanArmNanos >= 2000000000L) {
                  lastScanArmNanos = now;
                  farColumnsAllSkippedSinceScan = 0;
                  nearOwnedColumns.clear();
                  scanPending = true;
                  scanRing = innerScanRing(lastCoverEdge);
                  scanIndex = 0;
                  farIdleRescans.increment();
               }
            }
         }
      }
   }

   private static void drainHoledColumns() {
      if (!holedColumns.isEmpty() && !holeRetriesBlocked()) {
         int issued = 0;
         LongIterator it = holedColumns.iterator();

         while (it.hasNext()) {
            if (inFlightSet.size() >= 8 || issued >= 8) {
               return;
            }

            long key = it.nextLong();
            it.remove();
            if (stillWanted(key)
               && !inFlightSet.contains(key)
               && !queuedSet.contains(key)
               && (!residentColumns.containsKey(key) || partialColumns.contains(key) || refillColumns.contains(key))) {
               issued++;
               farHolesDrained.increment();
               issueRequest(key, false);
            }
         }
      }
   }

   private static void continuePromotionScan() {
      int camX = (int)(lastCamera >> 32);
      int camZ = (int)lastCamera;
      int steps = 4096;

      while (scanRing <= lastL1) {
         int perimeter = 8 * scanRing;

         while (scanIndex < perimeter) {
            if (inFlightSet.size() >= 8 || steps <= 0) {
               return;
            }

            steps--;
            long key = ringChunk(camX, camZ, scanRing, scanIndex);
            scanIndex++;
            int dx = colX(key) - camX;
            int dz = colZ(key) - camZ;
            if (!nearCovered(dx, dz, lastCoverEdge)
               && withinRing(dx, dz, lastL1)
               && (!residentColumns.containsKey(key) || partialColumns.contains(key) || refillColumns.contains(key))
               && !inFlightSet.contains(key)
               && !queuedSet.contains(key)
               && !absentSet.contains(key)
               && !nearOwnedColumns.contains(key)) {
               issueRequest(key, false);
            }
         }

         scanRing++;
         scanIndex = 0;
      }

      scanPending = false;
   }

   private static long ringChunk(int camX, int camZ, int r, int i) {
      int top = 2 * r + 1;
      int side = 2 * r - 1;
      int dx;
      int dz;
      if (i < top) {
         dx = -r + i;
         dz = -r;
      } else if (i < top + side) {
         dx = r;
         dz = -r + 1 + (i - top);
      } else if (i < top + side + top) {
         dx = r - (i - top - side);
         dz = r;
      } else {
         dx = -r;
         dz = r - 1 - (i - top - side - top);
      }

      return colKey(camX + dx, camZ + dz);
   }

   private static void issueRequest(long key, boolean refresh) {
      refillColumns.remove(key);
      absentSet.remove(key);
      nearOwnedColumns.remove(key);
      inFlightSet.add(key);
      farShellRequests.increment();
      int gen = generation;
      Consumer<FarField.Neighborhood> consumer = hood -> postResult(
         hood == null
            ? new FarFieldResidency.IoResult(gen, key, 0, null, null, refresh)
            : new FarFieldResidency.IoResult(gen, key, 1, hood.center(), hood.ring(), null, refresh)
      );
      FarField.requestShellNeighborhood(colX(key), colZ(key), consumer);
   }

   private static void postResult(FarFieldResidency.IoResult result) {
      synchronized (resultQueue) {
         if (resultQueue.size() < 64) {
            resultQueue.addLast(result);
            return;
         }
      }

      farMeshErrors.increment();
   }

   private static void drainResults(boolean enabled) {
      while (true) {
         FarFieldResidency.IoResult res;
         synchronized (resultQueue) {
            res = resultQueue.pollFirst();
         }

         if (res == null) {
            return;
         }

         if (res.gen == generation) {
            switch (res.kind) {
               case 0:
                  inFlightSet.remove(res.chunkKey);
                  boolean rescued = ExtractDispatch.tryExtractLoaded(colX(res.chunkKey), colZ(res.chunkKey));
                  if (!rescued) {
                     absentSet.add(res.chunkKey);
                  } else if (unblockedColumns.size() < 4096) {
                     unblockedColumns.add(res.chunkKey);
                  } else if (lateShells.size() < 4096) {
                     lateShells.add(res.chunkKey);
                  }
                  break;
               case 1:
                  if (enabled && !broken) {
                     SpriteUvResolver.ResolvedPalette palette = SpriteUvResolver.resolve(res.shell);
                     ShellMesher.NeighborColumn[] neighbors = res.ring == null ? null : new ShellMesher.NeighborColumn[9];
                     if (neighbors != null) {
                        for (int d = 0; d < 9; d++) {
                           ShellCodec.Shell nb = res.ring[d];
                           if (nb != null) {
                              neighbors[d] = new ShellMesher.NeighborColumn(nb, SpriteUvResolver.resolve(nb));
                           }
                        }
                     }

                     ShellCodec.Shell shell = res.shell;
                     int gen = res.gen;
                     long key = res.chunkKey;
                     boolean refresh = res.refresh;
                     boolean queued = FarField.submitCompute(() -> {
                        try {
                           ShellMesher.Result meshed = ShellMesher.mesh(shell, palette, neighbors);
                           postResult(new FarFieldResidency.IoResult(gen, key, 2, null, meshed, refresh));
                        } catch (Throwable t) {
                           farMeshErrors.increment();
                           latchBroken("far shell meshing", t);
                           postResult(new FarFieldResidency.IoResult(gen, key, 3, null, null, refresh));
                        }
                     });
                     if (!queued) {
                        inFlightSet.remove(res.chunkKey);
                     }
                  } else {
                     inFlightSet.remove(res.chunkKey);
                  }
                  break;
               case 2:
                  inFlightSet.remove(res.chunkKey);
                  ShellMesher.Result meshed = res.meshed;
                  farMeshedSections.add(meshed.sections().length);
                  farMeshSkippedCells.add(meshed.skippedCells());
                  farWaterOpaqueQuads.add(meshed.fluidQuads());
                  if (!enabled || broken) {
                     break;
                  }

                  if (meshed.sections().length == 0) {
                     absentSet.add(res.chunkKey);
                     break;
                  }

                  pendingAdmissions.addLast(new FarFieldResidency.MeshedColumn(res.gen, res.chunkKey, meshed.sections(), res.refresh));
                  pendingAdmissionSections = pendingAdmissionSections + meshed.sections().length;
                  queuedSet.add(res.chunkKey);
                  break;
               case 3:
                  inFlightSet.remove(res.chunkKey);
                  break;
               default:
                  inFlightSet.remove(res.chunkKey);
            }
         }
      }
   }

   public static boolean admissionsPending() {
      return !standDown && pendingAdmissionSections > 0;
   }

   public static FarFieldResidency.Admission pollAdmission() {
      while (true) {
         FarFieldResidency.MeshedColumn col = pendingAdmissions.peekFirst();
         if (col == null) {
            return null;
         }

         if (col.gen != generation) {
            pendingAdmissionSections = pendingAdmissionSections - (col.sections.length - col.next);
            pendingAdmissions.pollFirst();
            queuedSet.remove(col.chunkKey);
         } else {
            if (col.next < col.sections.length && stillWanted(col.chunkKey)) {
               ShellMesher.SectionMesh s = col.sections[col.next];
               return new FarFieldResidency.Admission(colX(col.chunkKey), s.sy(), colZ(col.chunkKey), s.mesh(), col.refresh);
            }

            retireColumn(col);
         }
      }
   }

   public static void onAdmissionOutcome(int outcome) {
      FarFieldResidency.MeshedColumn col = pendingAdmissions.peekFirst();
      if (col != null && col.next < col.sections.length) {
         if (outcome == 1) {
            farAdmitDeferred.increment();
         } else {
            if (outcome == 0) {
               farAdmissions.increment();
               farSectionsResident.increment();
               col.admittedSy.add(col.sections[col.next].sy());
            } else if (outcome == 5) {
               farAdmissions.increment();
               col.admittedSy.add(col.sections[col.next].sy());
            } else if (outcome == 3) {
               farAdmitSkipped.increment();
            } else if (outcome == 4) {
               farContestedSections.increment();
               col.contested++;
            } else if (outcome == 2) {
               farAdmitNoBudget.increment();
               farPromoteBudgetStalls.increment();
               col.incomplete = true;
            }

            col.next++;
            pendingAdmissionSections--;
            if (col.next >= col.sections.length) {
               retireColumn(col);
            }
         }
      }
   }

   private static void retireColumn(FarFieldResidency.MeshedColumn col) {
      boolean offeredInFull = col.next >= col.sections.length;
      queuedSet.remove(col.chunkKey);
      pendingAdmissionSections = pendingAdmissionSections - (col.sections.length - col.next);
      col.next = col.sections.length;
      pendingAdmissions.remove(col);
      if (col.admittedSy.isEmpty()) {
         if (offeredInFull && col.sections.length > 0) {
            farColumnsAllSkipped.increment();
            farColumnsAllSkippedSinceScan++;
            if (col.incomplete) {
               fileHole(col.chunkKey);
            }

            if (col.contested == col.sections.length) {
               if (nearOwnedColumns.size() >= 8192) {
                  nearOwnedColumns.clear();
               }

               nearOwnedColumns.add(col.chunkKey);
            }
         }
      } else {
         IntArrayList existing = (IntArrayList)residentColumns.get(col.chunkKey);
         if (existing == null) {
            residentColumns.put(col.chunkKey, col.admittedSy);
         } else {
            for (int i = 0; i < col.admittedSy.size(); i++) {
               int sy = col.admittedSy.getInt(i);
               if (!existing.contains(sy)) {
                  existing.add(sy);
               }
            }
         }

         if (col.incomplete) {
            partialColumns.add(col.chunkKey);
            fileHole(col.chunkKey);
         } else {
            partialColumns.remove(col.chunkKey);
         }
      }
   }

   private static void fileHole(long key) {
      if (stillWanted(key)) {
         if (holedColumns.size() >= 4096) {
            holedColumns.clear();
            if (lastCoverEdge >= 0) {
               scanPending = true;
               scanRing = innerScanRing(lastCoverEdge);
               scanIndex = 0;
            }
         } else {
            if (holedColumns.add(key)) {
               farHolesFiled.increment();
            }
         }
      }
   }

   private static void dropPendingAdmissions() {
      FarFieldResidency.MeshedColumn col;
      while ((col = pendingAdmissions.peekFirst()) != null) {
         retireColumn(col);
      }
   }

   private static boolean releaseColumns(int budget, long camera, int nearEdge, int l1) {
      if (residentColumns.isEmpty()) {
         return false;
      }

      boolean releaseAll = camera == Long.MIN_VALUE;
      int camX = (int)(camera >> 32);
      int camZ = (int)camera;
      LongArrayList toRelease = new LongArrayList();
      LongIterator it = residentColumns.keySet().iterator();

      while (it.hasNext()) {
         long key = it.nextLong();
         if (!releaseAll) {
            int dx = colX(key) - camX;
            int dz = colZ(key) - camZ;
            if (withinRing(dx, dz, l1 + 1)) {
               continue;
            }
         }

         toRelease.add(key);
         if (toRelease.size() >= budget) {
            break;
         }
      }

      for (int i = 0; i < toRelease.size(); i++) {
         long key = toRelease.getLong(i);
         IntArrayList sys = (IntArrayList)residentColumns.remove(key);
         partialColumns.remove(key);
         refillColumns.remove(key);
         unblockedColumns.remove(key);
         refreshColumns.remove(key);
         apronRefreshColumns.remove(key);
         nearOwnedColumns.remove(key);
         if (sys != null && !sys.isEmpty()) {
            int released = TerrainResidency.releaseFarColumn(colX(key), colZ(key), sys.elements(), sys.size());
            farReleases.add(released);
            farSectionsResident.add(-released);
         }
      }

      return toRelease.size() >= budget;
   }

   public static void onSectionEvicted(int sx, int sy, int sz) {
      farReleases.increment();
      farSectionsResident.add(-1L);
      long key = colKey(sx, sz);
      IntArrayList sys = (IntArrayList)residentColumns.get(key);
      if (sys != null) {
         sys.rem(sy);
         if (sys.isEmpty()) {
            residentColumns.remove(key);
            partialColumns.remove(key);
            refillColumns.remove(key);
         } else {
            refillColumns.add(key);
            fileHole(key);
         }
      }
   }

   public static void onFarBlockerReleased(int sx, int sy, int sz) {
      if (!broken) {
         farBlockersReleased.increment();
         long key = colKey(sx, sz);
         nearOwnedColumns.remove(key);
         if (stillWanted(key)) {
            absentSet.remove(key);
            IntArrayList sys = (IntArrayList)residentColumns.get(key);
            if (sys == null || !sys.contains(sy)) {
               if (sys != null) {
                  refillColumns.add(key);
               }

               unblockedColumns.add(key);
            }
         }
      }
   }

   public static void onResidencyDisposed(int droppedSections) {
      try {
         if (droppedSections > 0) {
            farReleases.add(droppedSections);
            farSectionsResident.add(-droppedSections);
         }

         resetTransientState();
      } catch (Throwable t) {
         latchBroken("far dispose bookkeeping", t);
      }
   }

   static void onWorldJoin() {
      try {
         resetTransientState();
      } catch (Throwable t) {
         latchBroken("far world-join", t);
      }
   }

   static void onWorldLeave() {
      try {
         while (true) {
            if (!releaseColumns(Integer.MAX_VALUE, Long.MIN_VALUE, -1, -1)) {
               resetTransientState();
               break;
            }
         }
      } catch (Throwable t) {
         latchBroken("far world-leave", t);
      }
   }

   static void onShellWritten(int chunkX, int chunkZ) {
      long key = colKey(chunkX, chunkZ);
      fileApronNeighbors(chunkX, chunkZ);
      if (residentColumns.containsKey(key) && stillWanted(key)) {
         absentSet.remove(key);
         refreshColumns.add(key);
         apronRefreshColumns.remove(key);
      } else {
         boolean wasAbsent = absentSet.remove(key);
         if (!wasAbsent) {
            if (!inFlightSet.contains(key)) {
               return;
            }

            farInFlightRescues.increment();
         } else {
            farLateShells.increment();
         }

         if (lateShells.size() >= 4096) {
            lateShells.clear();
            if (lastCoverEdge >= 0) {
               scanPending = true;
               scanRing = innerScanRing(lastCoverEdge);
               scanIndex = 0;
            }
         } else {
            lateShells.add(key);
         }
      }
   }

   private static void fileApronNeighbors(int chunkX, int chunkZ) {
      if (FarField.apronEnabled()) {
         for (int dz = -1; dz <= 1; dz++) {
            for (int dx = -1; dx <= 1; dx++) {
               if (dx != 0 || dz != 0) {
                  long nk = colKey(chunkX + dx, chunkZ + dz);
                  if (residentColumns.containsKey(nk) && stillWanted(nk) && !refreshColumns.contains(nk) && apronRefreshColumns.add(nk)) {
                     farApronRefreshFiled.increment();
                  }
               }
            }
         }
      }
   }

   private static void resetTransientState() {
      generation++;
      residentColumns.clear();
      inFlightSet.clear();
      queuedSet.clear();
      partialColumns.clear();
      refillColumns.clear();
      lateShells.clear();
      unblockedColumns.clear();
      refreshColumns.clear();
      apronRefreshColumns.clear();
      holedColumns.clear();
      farColumnsAllSkippedSinceScan = 0;
      lastScanArmNanos = System.nanoTime();
      nearOwnedColumns.clear();
      absentSet.clear();
      lastMeshSignature = Integer.MIN_VALUE;
      lastSaveSignature = Integer.MIN_VALUE;
      pendingAdmissions.clear();
      pendingAdmissionSections = 0;
      synchronized (resultQueue) {
         resultQueue.clear();
      }

      scanPending = false;
      demotePending = false;
      lastCamera = Long.MIN_VALUE;
      lastNearEdge = -1;
      lastCoverEdge = -1;
      lastL1 = -1;
      heldSweepRadius = 0;
      TerrainResidency.clearFarCoverage();
      SpriteUvResolver.clearCache();
   }

   public static boolean isBroken() {
      return broken;
   }

   public static void latchBroken(String where, Throwable cause) {
      broken = true;

      try {
         ExtractDispatch.setStandDown(false);
      } catch (Throwable var6) {
      }

      try {
         TerrainResidency.clearFarCoverage();
      } catch (Throwable var5) {
      }

      synchronized (resultQueue) {
         resultQueue.clear();
      }

      if (brokenLogged.compareAndSet(false, true)) {
         NvidiumPlusLog.LOGGER
            .error("NvidiumPlus far field failed ({}); the far field is parked for this session — near-field rendering is unaffected", where, cause);
      }
   }

   public static String columnStateName(int state) {
      return switch (state) {
         case 0 -> "RESIDENT";
         case 1 -> "RESIDENT_PARTIAL";
         case 2 -> "RESIDENT_REFILL";
         case 3 -> "IN_FLIGHT";
         case 4 -> "QUEUED";
         case 5 -> "LATE_PENDING";
         case 6 -> "ABSENT";
         case 7 -> "NEAR_COVERED";
         case 8 -> "OUTSIDE_RING";
         case 9 -> "NEVER_SCANNED";
         case 10 -> "DROPPED";
         case 11 -> "WALKER_IDLE";
         case 12 -> "UNBLOCK_PENDING";
         case 13 -> "NEAR_OWNED";
         default -> "UNKNOWN(" + state + ")";
      };
   }

   public static boolean isResidentState(int state) {
      return state == 0 || state == 1 || state == 2;
   }

   public static boolean isNearFieldDrawnState(int state) {
      return state == 7 || state == 13;
   }

   public static int classifyColumn(int chunkX, int chunkZ) {
      if (lastCamera != Long.MIN_VALUE && lastNearEdge > 0 && lastL1 > 0) {
         int camX = (int)(lastCamera >> 32);
         int camZ = (int)lastCamera;
         int dx = chunkX - camX;
         int dz = chunkZ - camZ;
         if (nearCovered(dx, dz, lastCoverEdge)) {
            return 7;
         }

         if (!withinRing(dx, dz, lastL1)) {
            return 8;
         }

         int dist = Math.max(Math.abs(dx), Math.abs(dz));
         long key = colKey(chunkX, chunkZ);
         if (residentColumns.containsKey(key)) {
            if (partialColumns.contains(key)) {
               return 1;
            } else {
               return refillColumns.contains(key) ? 2 : 0;
            }
         } else if (inFlightSet.contains(key)) {
            return 3;
         } else if (queuedSet.contains(key)) {
            return 4;
         } else if (lateShells.contains(key)) {
            return 5;
         } else if (unblockedColumns.contains(key)) {
            return 12;
         } else if (absentSet.contains(key)) {
            return 6;
         } else if (nearOwnedColumns.contains(key)) {
            return 13;
         } else {
            return scanPending && !scanCursorPassed(dx, dz, dist) ? 9 : 10;
         }
      } else {
         return 11;
      }
   }

   public static int residentSectionCount(int chunkX, int chunkZ) {
      IntArrayList sys = (IntArrayList)residentColumns.get(colKey(chunkX, chunkZ));
      return sys == null ? -1 : sys.size();
   }

   private static boolean scanCursorPassed(int dx, int dz, int dist) {
      if (dist < scanRing) {
         return true;
      } else {
         return dist > scanRing ? false : ringIndex(dx, dz, dist) < scanIndex;
      }
   }

   private static int ringIndex(int dx, int dz, int r) {
      if (r <= 0) {
         return 0;
      } else {
         int top = 2 * r + 1;
         int side = 2 * r - 1;
         if (dz == -r) {
            return dx + r;
         } else if (dz == r) {
            return top + side + (r - dx);
         } else if (dx == r) {
            return top + (dz + r - 1);
         } else {
            return dx == -r ? top + side + top + (r - 1 - dz) : 0;
         }
      }
   }

   public static FarFieldResidency.WalkerSnapshot walkerSnapshot() {
      boolean armed = lastCamera != Long.MIN_VALUE && lastNearEdge > 0 && lastL1 > 0;
      return new FarFieldResidency.WalkerSnapshot(
         armed,
         armed ? (int)(lastCamera >> 32) : 0,
         armed ? (int)lastCamera : 0,
         lastNearEdge,
         lastCoverEdge,
         lastL1,
         lastCoverEdge > 0 ? innerScanRing(lastCoverEdge) : -1,
         scanPending,
         scanRing,
         scanIndex,
         residentColumns.size(),
         inFlightSet.size(),
         queuedSet.size(),
         absentSet.size(),
         partialColumns.size(),
         refillColumns.size(),
         lateShells.size(),
         nearOwnedColumns.size(),
         pendingAdmissions.size(),
         pendingAdmissionSections
      );
   }

   private static boolean stillWanted(long chunkKey) {
      if (lastCamera == Long.MIN_VALUE) {
         return false;
      }

      int camX = (int)(lastCamera >> 32);
      int camZ = (int)lastCamera;
      int dx = colX(chunkKey) - camX;
      int dz = colZ(chunkKey) - camZ;
      return !nearCovered(dx, dz, lastCoverEdge) && withinRing(dx, dz, lastL1);
   }

   private static int coverRadius(int nearEdge) {
      if (nearEdge <= 0) {
         return nearEdge;
      }

      int band = Math.min(HANDOVER_BAND_CHUNKS, nearEdge / 4);
      return Math.max(1, nearEdge - band);
   }

   private static int resolveHandoverBand() {
      Integer override = Integer.getInteger("nvidiumplus.farfield.handoverBandChunks");
      return override == null ? 4 : Math.max(0, Math.min(8, override));
   }

   private static boolean nearCovered(int dx, int dz, int radiusChunks) {
      if (radiusChunks <= 0) {
         return false;
      }

      long px = Math.max(0, Math.abs(dx) - 1);
      long pz = Math.max(0, Math.abs(dz) - 1);
      return px * px + pz * pz < (long)radiusChunks * radiusChunks;
   }

   private static boolean withinRing(int dx, int dz, int radiusChunks) {
      if (radiusChunks < 0) {
         return false;
      }

      long x = dx;
      long z = dz;
      return x * x + z * z <= (long)radiusChunks * radiusChunks;
   }

   private static int innerScanRing(int coverEdge) {
      int r = Math.max(1, (int)(coverEdge * 0.7071067811865476) - 1);

      while (nearCovered(r, r, coverEdge)) {
         r++;
      }

      return r;
   }

   private static long colKey(int cx, int cz) {
      return (long)cx << 32 | cz & 4294967295L;
   }

   private static int colX(long key) {
      return (int)(key >> 32);
   }

   private static int colZ(long key) {
      return (int)key;
   }

   public record Admission(int sx, int sy, int sz, EncodedSectionMesh mesh, boolean refresh) {
   }

   private static final class IoResult {
      final int gen;
      final long chunkKey;
      final int kind;
      final ShellCodec.Shell shell;
      final ShellCodec.Shell[] ring;
      final ShellMesher.Result meshed;
      final boolean refresh;

      IoResult(int gen, long chunkKey, int kind, ShellCodec.Shell shell, ShellMesher.Result meshed, boolean refresh) {
         this(gen, chunkKey, kind, shell, null, meshed, refresh);
      }

      IoResult(int gen, long chunkKey, int kind, ShellCodec.Shell shell, ShellCodec.Shell[] ring, ShellMesher.Result meshed, boolean refresh) {
         this.gen = gen;
         this.chunkKey = chunkKey;
         this.kind = kind;
         this.shell = shell;
         this.ring = ring;
         this.meshed = meshed;
         this.refresh = refresh;
      }
   }

   private static final class MeshedColumn {
      final int gen;
      final long chunkKey;
      final ShellMesher.SectionMesh[] sections;
      int next;
      final IntArrayList admittedSy = new IntArrayList(4);
      boolean incomplete;
      int contested;
      final boolean refresh;

      MeshedColumn(int gen, long chunkKey, ShellMesher.SectionMesh[] sections, boolean refresh) {
         this.gen = gen;
         this.chunkKey = chunkKey;
         this.sections = sections;
         this.refresh = refresh;
      }
   }

   public record WalkerSnapshot(
      boolean armed,
      int cameraChunkX,
      int cameraChunkZ,
      int nearEdge,
      int coverEdge,
      int l1,
      int innerRing,
      boolean scanPending,
      int scanRing,
      int scanIndex,
      int residentColumnCount,
      int inFlightCount,
      int queuedCount,
      int absentCount,
      int partialCount,
      int refillCount,
      int latePendingCount,
      int nearOwnedCount,
      int pendingAdmissionColumns,
      int pendingAdmissionSections
   ) {
   }
}
