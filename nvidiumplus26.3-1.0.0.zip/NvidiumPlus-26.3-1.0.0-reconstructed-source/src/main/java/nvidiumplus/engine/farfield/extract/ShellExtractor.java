package nvidiumplus.engine.farfield.extract;

import it.unimi.dsi.fastutil.bytes.ByteArrayList;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.concurrent.atomic.LongAdder;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HalfTransparentBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import nvidiumplus.engine.farfield.mesh.SpriteUvResolver;
import nvidiumplus.engine.farfield.store.ShellCodec;

public final class ShellExtractor {
   public static final int FACE_DOWN = 1;
   public static final int FACE_UP = 2;
   public static final int FACE_NORTH = 4;
   public static final int FACE_SOUTH = 8;
   public static final int FACE_WEST = 16;
   public static final int FACE_EAST = 32;
   private static final int LEAK_BUDGET = 64;
   private static final int CROSS_BUDGET = 32;
   private static final int ADMIT_LEVEL_BUDGET = 16384;
   public static final LongAdder farBandLeakRefusals = new LongAdder();
   public static final LongAdder farBandDegradedPlanes = new LongAdder();
   public static final LongAdder farLightHomeNotResident = new LongAdder();
   public static final LongAdder farLightProbeGateRefusals = new LongAdder();
   public static final LongAdder farLightBrightestFacePicks = new LongAdder();
   static final int SIDE_W = 0;
   static final int SIDE_E = 1;
   static final int SIDE_N = 2;
   static final int SIDE_S = 3;
   static final int[] SIDE_DX = new int[]{-1, 1, 0, 0};
   static final int[] SIDE_DZ = new int[]{0, 0, -1, 1};
   static final int[] CORNER_DX = new int[]{-1, 1, -1, 1};
   static final int[] CORNER_DZ = new int[]{-1, -1, 1, 1};
   private static final byte LIGHT_FALLBACK_FLAT = -16;
   private static final int PLANE_KEEP = 0;
   private static final int PLANE_FLAT = 1;
   private static final int PLANE_UNTRUSTED = 2;

   private ShellExtractor() {
   }

   static int fluidFamily(FluidState fluid) {
      if (fluid.isEmpty()) {
         return 0;
      } else if (fluid.getType().isSame(Fluids.WATER)) {
         return 1;
      } else {
         return fluid.getType().isSame(Fluids.LAVA) ? 2 : 3;
      }
   }

   static ShellExtractor.CapturedStrip captureStrip(LevelChunk home, ChunkAccess neighbor, int side, int bandOffset) {
      int minSectionY = home.getMinSectionY();
      int worldMinY = home.getMinY();
      int worldMaxY = home.getMaxY();
      int[] tops;
      int[] ours;
      switch (side) {
         case 0:
            tops = edgeCutTops(neighbor, minSectionY, worldMinY, 15, -1);
            ours = edgeCutTops(home, minSectionY, worldMinY, 0, -1);
            break;
         case 1:
            tops = edgeCutTops(neighbor, minSectionY, worldMinY, 0, -1);
            ours = edgeCutTops(home, minSectionY, worldMinY, 15, -1);
            break;
         case 2:
            tops = edgeCutTops(neighbor, minSectionY, worldMinY, -1, 15);
            ours = edgeCutTops(home, minSectionY, worldMinY, -1, 0);
            break;
         default:
            tops = edgeCutTops(neighbor, minSectionY, worldMinY, -1, 0);
            ours = edgeCutTops(home, minSectionY, worldMinY, -1, 15);
      }

      int lowest = Integer.MAX_VALUE;
      int highest = Integer.MIN_VALUE;

      for (int i = 0; i < 16; i++) {
         lowest = Math.min(lowest, Math.min(tops[i], ours[i]));

         int nx = switch (side) {
            case 0 -> 15;
            case 1 -> 0;
            default -> i;
         };

         int nz = switch (side) {
            case 2 -> 15;
            case 3 -> 0;
            default -> i;
         };
         highest = Math.max(highest, neighbor.getHeight(Types.WORLD_SURFACE, nx, nz));
      }

      int yLo = Math.max(worldMinY, lowest - bandOffset - 64);
      int yHi = Math.min(worldMaxY, highest + 1);
      if (yHi < yLo) {
         yHi = yLo;
      }

      int rows = yHi - yLo + 1;
      byte[] cells = new byte[16 * rows];
      Block[] transparents = new Block[7];
      int transparentCount = 0;
      LevelChunkSection[] sections = neighbor.getSections();

      for (int i = 0; i < 16; i++) {
         int nx = switch (side) {
            case 0 -> 15;
            case 1 -> 0;
            default -> i;
         };

         int nz = switch (side) {
            case 2 -> 15;
            case 3 -> 0;
            default -> i;
         };

         for (int y = yLo; y <= yHi; y++) {
            BlockState state = stateAt(sections, minSectionY, nx, y, nz);
            if (state != null && !state.isAir()) {
               int b = state.isSolidRender() ? 1 : 0;
               b |= fluidFamily(state.getFluidState()) << 1;
               if (state.getBlock() instanceof HalfTransparentBlock) {
                  Block block = state.getBlock();
                  int token = 0;

                  for (int t = 0; t < transparentCount; t++) {
                     if (transparents[t] == block) {
                        token = t + 1;
                        break;
                     }
                  }

                  if (token == 0 && transparentCount < transparents.length) {
                     transparents[transparentCount++] = block;
                     token = transparentCount;
                  }

                  b |= token << 3;
               }

               cells[i * rows + (y - yLo)] = (byte)b;
            }
         }
      }

      return new ShellExtractor.CapturedStrip(tops, yLo, rows, cells, transparents);
   }

   private static boolean exposedAgainstStrip(BlockState owner, ShellExtractor.CapturedStrip strip, int row, int y) {
      int slot = y - strip.yLo;
      if (slot >= strip.rows) {
         return true;
      }

      if (slot < 0) {
         return false;
      }

      int b = strip.cells[row * strip.rows + slot];
      if ((b & 1) != 0) {
         return false;
      }

      int token = b >> 3 & 7;
      if (token != 0 && strip.transparents[token - 1] == owner.getBlock()) {
         return false;
      }

      int family = b >> 1 & 3;
      return family == 0 || family != fluidFamily(owner.getFluidState());
   }

   static ShellCodec.Shell extractCaptured(Pin pin) {
      if (!"nvidiumplus-pin-extract".equals(Thread.currentThread().getName())) {
         ExtractDispatch.farWalksOffWorker.increment();
      }

      ShellExtractor.WalkRequest req = new ShellExtractor.WalkRequest();
      req.chunk = pin.chunk;
      req.surfaceBand = pin.surfaceBand;
      req.bandOffset = pin.bandOffset;
      req.tint = pin.tintView();
      req.hasSkyLight = pin.hasSkyLight;
      req.neighbors = pin;
      req.light = pin;
      req.blendDivisor = pin.blendDivisor;
      req.keepUnderwaterPlants = pin.keepUnderwaterPlants;
      req.realLight = pin.realLight && pin.ownLightReady();
      req.lightPendingOut = pin.realLight && !pin.ownLightReady();
      ShellCodec.Shell shell = walk(req);
      pin.walkLightPending = req.lightPendingOut;
      return shell;
   }

   private static ShellCodec.Shell walk(ShellExtractor.WalkRequest req) {
      LevelChunk chunk = req.chunk;
      boolean surfaceBand = req.surfaceBand;
      int bandOffset = req.bandOffset;
      LevelChunkSection[] sections = chunk.getSections();
      int minSectionY = chunk.getMinSectionY();
      int worldMinY = chunk.getMinY();
      int worldMaxY = chunk.getMaxY();
      ChunkPos pos = chunk.getPos();
      BlockAndTintGetter tintLevel = req.tint;
      int baseX = pos.getMinBlockX();
      int baseZ = pos.getMinBlockZ();
      ShellExtractor.NeighborView neighbors = req.neighbors;
      ChunkAccess westChunk = neighbors.lateral(0);
      ChunkAccess eastChunk = neighbors.lateral(1);
      ChunkAccess northChunk = neighbors.lateral(2);
      ChunkAccess southChunk = neighbors.lateral(3);
      ShellExtractor.CapturedStrip westStrip = westChunk == null ? neighbors.strip(0) : null;
      ShellExtractor.CapturedStrip eastStrip = eastChunk == null ? neighbors.strip(1) : null;
      ShellExtractor.CapturedStrip northStrip = northChunk == null ? neighbors.strip(2) : null;
      ShellExtractor.CapturedStrip southStrip = southChunk == null ? neighbors.strip(3) : null;
      LevelChunkSection[] west = westChunk == null ? null : westChunk.getSections();
      LevelChunkSection[] east = eastChunk == null ? null : eastChunk.getSections();
      LevelChunkSection[] north = northChunk == null ? null : northChunk.getSections();
      LevelChunkSection[] south = southChunk == null ? null : southChunk.getSections();
      ShellExtractor.LightView light = req.light;
      boolean northLightOk = light.sideAdmissible(2);
      boolean southLightOk = light.sideAdmissible(3);
      boolean westLightOk = light.sideAdmissible(0);
      boolean eastLightOk = light.sideAdmissible(1);
      int[] bandFloor = null;
      int minCut = Integer.MIN_VALUE;
      if (surfaceBand) {
         int[] westEdge = westChunk != null ? edgeCutTops(westChunk, minSectionY, worldMinY, 15, -1) : (westStrip != null ? westStrip.edgeCutTops : null);
         int[] eastEdge = eastChunk != null ? edgeCutTops(eastChunk, minSectionY, worldMinY, 0, -1) : (eastStrip != null ? eastStrip.edgeCutTops : null);
         int[] northEdge = northChunk != null ? edgeCutTops(northChunk, minSectionY, worldMinY, -1, 15) : (northStrip != null ? northStrip.edgeCutTops : null);
         int[] southEdge = southChunk != null ? edgeCutTops(southChunk, minSectionY, worldMinY, -1, 0) : (southStrip != null ? southStrip.edgeCutTops : null);
         ChunkAccess nwChunk = neighbors.diagonal(0);
         ChunkAccess neChunk = neighbors.diagonal(1);
         ChunkAccess swChunk = neighbors.diagonal(2);
         ChunkAccess seChunk = neighbors.diagonal(3);
         LevelChunkSection[][] domain = new LevelChunkSection[][]{
            nwChunk == null ? null : nwChunk.getSections(),
            north,
            neChunk == null ? null : neChunk.getSections(),
            west,
            sections,
            east,
            swChunk == null ? null : swChunk.getSections(),
            south,
            seChunk == null ? null : seChunk.getSections()
         };
         int[][] domainCap = new int[][]{
            conduitCaps(nwChunk, worldMinY),
            conduitCaps(northChunk, worldMinY),
            conduitCaps(neChunk, worldMinY),
            conduitCaps(westChunk, worldMinY),
            null,
            conduitCaps(eastChunk, worldMinY),
            conduitCaps(swChunk, worldMinY),
            conduitCaps(southChunk, worldMinY),
            conduitCaps(seChunk, worldMinY)
         };
         int surfaceMax = worldMinY - 1;

         for (int z = 0; z < 16; z++) {
            for (int x = 0; x < 16; x++) {
               surfaceMax = Math.max(surfaceMax, chunk.getHeight(Types.WORLD_SURFACE, x, z));
            }
         }

         int spanFloor = Math.max(worldMinY, surfaceMax - 255);
         bandFloor = computeBandFloors(chunk, sections, minSectionY, worldMinY, spanFloor, bandOffset, westEdge, eastEdge, northEdge, southEdge);
         closeLeaks(sections, minSectionY, worldMinY, worldMaxY, surfaceMax, spanFloor, bandFloor, westEdge, eastEdge, northEdge, southEdge, domain, domainCap);
         minCut = Integer.MAX_VALUE;

         for (int i = 0; i < 256; i++) {
            minCut = Math.min(minCut, bandFloor[i]);
         }
      }

      LongArrayList raw = new LongArrayList(1024);
      ShellExtractor.Palette pal = new ShellExtractor.Palette(SpriteUvResolver.stateStorageAvailable());
      int blendDivisor = req.blendDivisor;
      int tintSide = blendDivisor <= 0 ? 1 : 16;
      boolean keepUnderwaterPlants = req.keepUnderwaterPlants;
      boolean realLight = req.realLight;
      boolean lightUntrusted = req.lightPendingOut;
      ByteArrayList rawLight = realLight ? new ByteArrayList(1024) : null;
      boolean anyProbeRefused = false;

      for (int s = 0; s < sections.length; s++) {
         LevelChunkSection section = sections[s];
         if (section != null && !section.hasOnlyAir()) {
            int bottom = minSectionY + s << 4;
            if (bandFloor == null || bottom + 15 >= minCut) {
               for (int ly = 0; ly < 16; ly++) {
                  int y = bottom + ly;

                  for (int z = 0; z < 16; z++) {
                     for (int x = 0; x < 16; x++) {
                        if (bandFloor == null || y >= bandFloor[z << 4 | x]) {
                           BlockState state = section.getBlockState(x, ly, z);
                           if (!state.isAir()) {
                              BlockState below = y > worldMinY ? stateAt(sections, minSectionY, x, y - 1, z) : null;
                              BlockState above = y >= worldMaxY ? null : stateAt(sections, minSectionY, x, y + 1, z);
                              boolean northKnown = z > 0 || north != null;
                              boolean southKnown = z < 15 || south != null;
                              boolean westKnown = x > 0 || west != null;
                              boolean eastKnown = x < 15 || east != null;
                              BlockState nNorth = z > 0 ? stateAt(sections, minSectionY, x, y, z - 1) : stateAt(north, minSectionY, x, y, 15);
                              BlockState nSouth = z < 15 ? stateAt(sections, minSectionY, x, y, z + 1) : stateAt(south, minSectionY, x, y, 0);
                              BlockState nWest = x > 0 ? stateAt(sections, minSectionY, x - 1, y, z) : stateAt(west, minSectionY, 15, y, z);
                              BlockState nEast = x < 15 ? stateAt(sections, minSectionY, x + 1, y, z) : stateAt(east, minSectionY, 0, y, z);
                              boolean airAbove = above == null || above.isAir();
                              int mask = 0;
                              if (y > worldMinY && exposed(state, Direction.DOWN, below)) {
                                 mask |= 1;
                              }

                              if (exposed(state, Direction.UP, above)) {
                                 mask |= 2;
                              }

                              if (z == 0 && north == null && northStrip != null
                                 ? exposedAgainstStrip(state, northStrip, x, y)
                                 : exposedLateral(state, Direction.NORTH, nNorth, northKnown)) {
                                 mask |= 4;
                              }

                              if (z == 15 && south == null && southStrip != null
                                 ? exposedAgainstStrip(state, southStrip, x, y)
                                 : exposedLateral(state, Direction.SOUTH, nSouth, southKnown)) {
                                 mask |= 8;
                              }

                              if (x == 0 && west == null && westStrip != null
                                 ? exposedAgainstStrip(state, westStrip, z, y)
                                 : exposedLateral(state, Direction.WEST, nWest, westKnown)) {
                                 mask |= 16;
                              }

                              if (x == 15 && east == null && eastStrip != null
                                 ? exposedAgainstStrip(state, eastStrip, z, y)
                                 : exposedLateral(state, Direction.EAST, nEast, eastKnown)) {
                                 mask |= 32;
                              }

                              if (mask != 0 && (keepUnderwaterPlants || !standsInFluidOnly(state, below, above, nNorth, nSouth, nWest, nEast))) {
                                 int pi = pal.indexOf(state, tintLevel, baseX, y, baseZ);
                                 if (pi >= 0) {
                                    raw.add((long)y << 32 | ShellCodec.packCell(x, 0, z, pi, mask));
                                    if (rawLight != null) {
                                       int probeMask = mask;
                                       if (z == 0 && !northLightOk) {
                                          probeMask &= -5;
                                       }

                                       if (z == 15 && !southLightOk) {
                                          probeMask &= -9;
                                       }

                                       if (x == 0 && !westLightOk) {
                                          probeMask &= -17;
                                       }

                                       if (x == 15 && !eastLightOk) {
                                          probeMask &= -33;
                                       }

                                       int lightByte = sampleCellLight(light, probeMask, baseX + x, y, baseZ + z);
                                       if (lightByte < 0) {
                                          farLightProbeGateRefusals.increment();
                                          anyProbeRefused = true;
                                          lightByte = 240;
                                       }

                                       rawLight.add((byte)lightByte);
                                    }

                                    if (airAbove) {
                                       FluidState fluid = state.getFluidState();
                                       if (!fluid.isEmpty()) {
                                          BlockState fluidBlock = fluid.createLegacyBlock();
                                          if (fluidBlock.getBlock() != state.getBlock()) {
                                             int fi = pal.indexOf(fluidBlock, tintLevel, baseX, y, baseZ);
                                             if (fi >= 0) {
                                                raw.add((long)y << 32 | ShellCodec.packCell(x, 0, z, fi, 2));
                                                if (rawLight != null) {
                                                   int sheetByte = sampleCellLight(light, 2, baseX + x, y, baseZ + z);
                                                   if (sheetByte < 0) {
                                                      farLightProbeGateRefusals.increment();
                                                      anyProbeRefused = true;
                                                      sheetByte = 240;
                                                   }

                                                   rawLight.add((byte)sheetByte);
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      if (raw.isEmpty()) {
         return null;
      }

      int minY = (int)(raw.getLong(0) >> 32);
      int maxY = (int)(raw.getLong(raw.size() - 1) >> 32);
      int shellMinY = minY;
      int start = 0;
      if (maxY - minY > 255) {
         shellMinY = maxY - 255;

         while (start < raw.size() && (int)(raw.getLong(start) >> 32) < shellMinY) {
            start++;
         }
      }

      int[] cells = new int[raw.size() - start];

      for (int i = start; i < raw.size(); i++) {
         long entry = raw.getLong(i);
         cells[i - start] = (int)entry | (int)(entry >> 32) - shellMinY << 8;
      }

      byte[] cellLight = null;
      if (rawLight != null) {
         cellLight = new byte[cells.length];

         for (int i = 0; i < cells.length; i++) {
            cellLight[i] = rawLight.getByte(start + i);
         }

         int verdict = planeVerdict(cellLight, cells.length, req.hasSkyLight);
         if (anyProbeRefused && verdict == 1) {
            verdict = 2;
         }

         if (verdict != 0) {
            cellLight = null;
            lightUntrusted = verdict == 2;
         } else if (anyProbeRefused) {
            lightUntrusted = true;
         }
      }

      req.lightPendingOut = lightUntrusted;
      int[] columnY = pal.columnHeights(cells, cells.length, shellMinY);
      int finalTintSide = pal.rebuildTints(tintSide, tintLevel, baseX, baseZ, columnY);
      return new ShellCodec.Shell(
         cells.length,
         cells,
         pal.names(),
         pal.states(),
         pal.signatures(),
         tintLevel == null ? null : pal.tints(),
         finalTintSide,
         cellLight,
         (byte)2,
         (byte)5,
         surfaceBand ? (byte)bandOffset : -1,
         (short)shellMinY,
         baseX >> 4,
         baseZ >> 4
      );
   }

   private static void sampleCellField(IntArrayList out, BlockState state, BlockAndTintGetter level, int baseX, int baseZ, int[] columnY, int base) {
      int side = 16;
      int nodes = side * side;
      if (level != null && SpriteUvResolver.hasTintSource(state)) {
         MutableBlockPos probe = new MutableBlockPos();

         for (int gz = 0; gz < side; gz++) {
            for (int gx = 0; gx < side; gx++) {
               out.add(SpriteUvResolver.sampleTint(state, level, probe.set(baseX + gx, columnY[base + (gz << 4) + gx], baseZ + gz)));
            }
         }
      } else {
         for (int n = 0; n < nodes; n++) {
            out.add(16777215);
         }
      }
   }

   private static int sampleCellLight(ShellExtractor.LightView light, int mask, int wx, int y, int wz) {
      if ((mask & 2) != 0) {
         int up = probeFaceLight(light, 1, wx, y, wz);
         if (up >= 0) {
            return up;
         }

         mask &= -3;
      }

      if (mask == 0) {
         return -1;
      }

      if ((mask & mask - 1) == 0) {
         return probeFaceLight(light, Integer.numberOfTrailingZeros(mask), wx, y, wz);
      }

      farLightBrightestFacePicks.increment();
      int best = -1;

      for (int m = mask; m != 0; m &= m - 1) {
         int sample = probeFaceLight(light, Integer.numberOfTrailingZeros(m), wx, y, wz);
         if (sample > best) {
            best = sample;
         }
      }

      return best;
   }

   private static int probeFaceLight(ShellExtractor.LightView light, int face, int wx, int y, int wz) {
      int dx = 0;
      int dy = 0;
      int dz = 0;
      switch (face) {
         case 0:
            dy = -1;
            break;
         case 1:
            dy = 1;
            break;
         case 2:
            dz = -1;
            break;
         case 3:
            dz = 1;
            break;
         case 4:
            dx = -1;
            break;
         default:
            dx = 1;
      }

      return light.skyBlock(wx + dx, y + dy, wz + dz);
   }

   private static int clampNibble(int light) {
      return light < 0 ? 0 : Math.min(light, 15);
   }

   private static int planeVerdict(byte[] light, int count, boolean skyLightDimension) {
      boolean anyNonFlat = false;
      boolean anyLit = false;
      boolean anyFullSky = false;

      for (int i = 0; i < count; i++) {
         int b = light[i] & 255;
         if (b != 240) {
            anyNonFlat = true;
         }

         if (b != 0) {
            anyLit = true;
         }

         if ((b & 240) == 240) {
            anyFullSky = true;
         }
      }

      if (!anyLit) {
         return 2;
      } else if (skyLightDimension && !anyFullSky) {
         return 2;
      } else {
         return !anyNonFlat ? 1 : 0;
      }
   }

   private static BlockState stateAt(LevelChunkSection[] sections, int minSectionY, int x, int y, int z) {
      if (sections == null) {
         return null;
      } else {
         int idx = (y >> 4) - minSectionY;
         if (idx >= 0 && idx < sections.length) {
            LevelChunkSection section = sections[idx];
            return section != null && !section.hasOnlyAir() ? section.getBlockState(x, y & 15, z) : null;
         } else {
            return null;
         }
      }
   }

   private static boolean exposed(BlockState owner, Direction dir, BlockState neighbor) {
      if (neighbor == null) {
         return true;
      } else {
         return !owner.canOcclude() && neighbor.getBlock() == owner.getBlock() ? false : Block.shouldRenderFace(owner, neighbor, dir);
      }
   }

   private static boolean standsInFluidOnly(
      BlockState state, BlockState below, BlockState above, BlockState north, BlockState south, BlockState west, BlockState east
   ) {
      if (state.canOcclude()) {
         return false;
      }

      FluidState fluid = state.getFluidState();
      return !fluid.isEmpty() && fluid.createLegacyBlock().getBlock() != state.getBlock()
         ? !airLike(below) && !airLike(above) && !airLike(north) && !airLike(south) && !airLike(west) && !airLike(east)
         : false;
   }

   private static boolean airLike(BlockState neighbor) {
      return neighbor == null || neighbor.isAir();
   }

   private static boolean exposedLateral(BlockState owner, Direction dir, BlockState neighbor, boolean known) {
      return !known ? owner.canOcclude() : exposed(owner, dir, neighbor);
   }

   private static int cutTopAt(ChunkAccess chunk, LevelChunkSection[] sections, int minSectionY, int worldMinY, int x, int z) {
      int top = chunk.getHeight(Types.WORLD_SURFACE, x, z);
      if (top >= worldMinY) {
         BlockState topState = stateAt(sections, minSectionY, x, top, z);
         if (topState != null && !topState.getFluidState().isEmpty()) {
            top = chunk.getHeight(Types.OCEAN_FLOOR, x, z);
         }
      }

      int solid = chunk.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, x, z);
      return Math.min(top, solid);
   }

   private static int[] computeBandFloors(
      LevelChunk chunk,
      LevelChunkSection[] sections,
      int minSectionY,
      int worldMinY,
      int spanFloor,
      int bandOffset,
      int[] westEdge,
      int[] eastEdge,
      int[] northEdge,
      int[] southEdge
   ) {
      int[] tops = new int[256];

      for (int z = 0; z < 16; z++) {
         for (int x = 0; x < 16; x++) {
            tops[z << 4 | x] = cutTopAt(chunk, sections, minSectionY, worldMinY, x, z);
         }
      }

      int ownFallback = Integer.MAX_VALUE;

      for (int i = 0; i < 256; i++) {
         if (tops[i] >= worldMinY) {
            ownFallback = Math.min(ownFallback, tops[i]);
         }
      }

      int degraded = (westEdge == null ? 1 : 0) + (eastEdge == null ? 1 : 0) + (northEdge == null ? 1 : 0) + (southEdge == null ? 1 : 0);
      if (degraded > 0) {
         farBandDegradedPlanes.add(degraded);
      }

      int[] floors = new int[256];

      for (int z = 0; z < 16; z++) {
         for (int x = 0; x < 16; x++) {
            int idx = z << 4 | x;
            int own = tops[idx];
            int lowest = own;
            lowest = Math.min(lowest, x > 0 ? tops[idx - 1] : (westEdge == null ? ownFallback : westEdge[z]));
            lowest = Math.min(lowest, x < 15 ? tops[idx + 1] : (eastEdge == null ? ownFallback : eastEdge[z]));
            lowest = Math.min(lowest, z > 0 ? tops[idx - 16] : (northEdge == null ? ownFallback : northEdge[x]));
            lowest = Math.min(lowest, z < 15 ? tops[idx + 16] : (southEdge == null ? ownFallback : southEdge[x]));
            floors[idx] = Math.max(spanFloor, lowest - bandOffset);
         }
      }

      return floors;
   }

   private static void closeLeaks(
      LevelChunkSection[] sections,
      int minSectionY,
      int worldMinY,
      int worldMaxY,
      int surfaceMax,
      int spanFloor,
      int[] floors,
      int[] westEdge,
      int[] eastEdge,
      int[] northEdge,
      int[] southEdge,
      LevelChunkSection[][] domain,
      int[][] domainCap
   ) {
      int seedY = Math.min(surfaceMax + 1, worldMaxY);
      if (seedY > worldMinY) {
         int deepest = Integer.MAX_VALUE;

         for (int i = 0; i < 256; i++) {
            deepest = Math.min(deepest, floors[i]);
         }

         int ownLimit = Math.max(spanFloor, deepest - 64);
         int crossLimit = Math.max(spanFloor, deepest - 32);
         int lowest = Math.min(seedY, ownLimit);
         ShellExtractor.LeakFlood flood = new ShellExtractor.LeakFlood(domain, domainCap, minSectionY, floors, ownLimit, lowest, seedY);

         for (int z = 0; z < 16; z++) {
            for (int x = 0; x < 16; x++) {
               flood.offer(4, x, seedY, z);
            }
         }

         seedFromNeighbourSky(flood, westEdge, 0, -1, seedY);
         seedFromNeighbourSky(flood, eastEdge, 15, -1, seedY);
         seedFromNeighbourSky(flood, northEdge, -1, 0, seedY);
         seedFromNeighbourSky(flood, southEdge, -1, 15, seedY);
         flood.run();
         flood.beginCrossPass(crossLimit);

         for (int z = 0; z < 16; z++) {
            for (int x = 0; x < 16; x++) {
               flood.offer(4, x, seedY, z);
            }
         }

         flood.seedConduits();
         flood.run();
      }
   }

   private static void seedFromNeighbourSky(ShellExtractor.LeakFlood flood, int[] edge, int fixedX, int fixedZ, int seedY) {
      if (edge != null) {
         for (int i = 0; i < 16; i++) {
            int x = fixedX < 0 ? i : fixedX;
            int z = fixedZ < 0 ? i : fixedZ;

            for (int y = Math.max(edge[i] + 1, flood.lowest); y < seedY; y++) {
               flood.offer(4, x, y, z);
            }
         }
      }
   }

   private static int[] columnSurfaces(ChunkAccess chunk) {
      if (chunk == null) {
         return null;
      }

      int[] out = new int[256];

      for (int z = 0; z < 16; z++) {
         for (int x = 0; x < 16; x++) {
            out[z << 4 | x] = chunk.getHeight(Types.WORLD_SURFACE, x, z);
         }
      }

      return out;
   }

   private static int[] conduitCaps(ChunkAccess chunk, int worldMinY) {
      int[] caps = columnSurfaces(chunk);
      if (caps == null) {
         return null;
      }

      for (int i = 0; i < 256; i++) {
         caps[i] = caps[i] < worldMinY ? Integer.MAX_VALUE : caps[i] + 1;
      }

      return caps;
   }

   private static int[] edgeCutTops(ChunkAccess neighbor, int minSectionY, int worldMinY, int fixedX, int fixedZ) {
      if (neighbor == null) {
         return null;
      }

      LevelChunkSection[] sections = neighbor.getSections();
      int[] tops = new int[16];

      for (int i = 0; i < 16; i++) {
         tops[i] = cutTopAt(neighbor, sections, minSectionY, worldMinY, fixedX < 0 ? i : fixedX, fixedZ < 0 ? i : fixedZ);
      }

      return tops;
   }

   static final class CapturedStrip {
      final int[] edgeCutTops;
      final int yLo;
      final int rows;
      final byte[] cells;
      final Block[] transparents;

      CapturedStrip(int[] edgeCutTops, int yLo, int rows, byte[] cells, Block[] transparents) {
         this.edgeCutTops = edgeCutTops;
         this.yLo = yLo;
         this.rows = rows;
         this.cells = cells;
         this.transparents = transparents;
      }
   }

   private static final class LeakFlood {
      static final int CENTRE = 4;
      private final LevelChunkSection[][] sections;
      private final int[][] cap;
      private final int[] slot = new int[9];
      private final int[] slotAll = new int[9];
      private final int width;
      private final int minSectionY;
      private final int[] floors;
      private int limit;
      private int levels = 16384;
      final int lowest;
      private final int seedY;
      private final long[] seen;
      private final IntArrayList stack = new IntArrayList(1024);

      LeakFlood(LevelChunkSection[][] sections, int[][] cap, int minSectionY, int[] floors, int limit, int lowest, int seedY) {
         this.sections = sections;
         this.cap = cap;
         this.minSectionY = minSectionY;
         this.floors = floors;
         this.limit = limit;
         this.lowest = lowest;
         this.seedY = seedY;
         int w = 0;

         for (int p = 0; p < 9; p++) {
            boolean present = sections[p] != null && (p == 4 || cap[p] != null);
            this.slotAll[p] = present ? w++ : -1;
            this.slot[p] = p == 4 ? this.slotAll[p] : -1;
         }

         this.width = w;
         this.seen = new long[(seedY - lowest + 1) * w * 256 + 63 >> 6];
      }

      void offer(int p, int x, int y, int z) {
         if (y >= this.lowest && y <= this.seedY) {
            int s = this.slot[p];
            if (s >= 0) {
               int column = z << 4 | x;
               if (p == 4) {
                  if (y < this.floors[column]) {
                     if (y < this.limit || this.floors[column] - y > this.levels) {
                        ShellExtractor.farBandLeakRefusals.increment();
                        return;
                     }

                     this.levels = this.levels - (this.floors[column] - y);
                     this.floors[column] = y;
                  }
               } else if (y > this.cap[p][column]) {
                  return;
               }

               int idx = ((y - this.lowest) * this.width + s) * 256 + column;
               long bit = 1L << idx;
               int word = idx >> 6;
               if ((this.seen[word] & bit) == 0L) {
                  this.seen[word] = this.seen[word] | bit;
                  BlockState state = ShellExtractor.stateAt(this.sections[p], this.minSectionY, x, y, z);
                  if (state == null || !state.isSolidRender()) {
                     this.stack.add(p << 24 | y - this.lowest << 8 | column);
                  }
               }
            }
         }
      }

      void beginCrossPass(int crossLimit) {
         System.arraycopy(this.slotAll, 0, this.slot, 0, 9);
         this.limit = crossLimit;
         Arrays.fill(this.seen, 0L);
      }

      void seedConduits() {
         for (int p = 0; p < 9; p++) {
            if (p != 4 && this.slot[p] >= 0) {
               int[] caps = this.cap[p];

               for (int z = 0; z < 16; z++) {
                  for (int x = 0; x < 16; x++) {
                     this.offer(p, x, Math.min(caps[z << 4 | x], this.seedY), z);
                  }
               }
            }
         }
      }

      void run() {
         while (!this.stack.isEmpty()) {
            int packed = this.stack.removeInt(this.stack.size() - 1);
            int p = packed >>> 24;
            int y = (packed >> 8 & 511) + this.lowest;
            int column = packed & 0xFF;
            int x = column & 15;
            int z = column >> 4;
            this.offer(p, x, y - 1, z);
            this.offer(p, x, y + 1, z);
            this.step(p, x, y, z, -1, 0);
            this.step(p, x, y, z, 1, 0);
            this.step(p, x, y, z, 0, -1);
            this.step(p, x, y, z, 0, 1);
         }
      }

      private void step(int p, int x, int y, int z, int dx, int dz) {
         int nx = x + dx;
         int nz = z + dz;
         if (nx >= 0 && nx <= 15 && nz >= 0 && nz <= 15) {
            this.offer(p, nx, y, nz);
         } else {
            int px = p % 3 + (nx < 0 ? -1 : (nx > 15 ? 1 : 0));
            int pz = p / 3 + (nz < 0 ? -1 : (nz > 15 ? 1 : 0));
            if (px >= 0 && px <= 2 && pz >= 0 && pz <= 2) {
               this.offer(pz * 3 + px, nx & 15, y, nz & 15);
            }
         }
      }
   }

   interface LightView {
      boolean sideAdmissible(int var1);

      int skyBlock(int var1, int var2, int var3);
   }

   interface NeighborView {
      ChunkAccess lateral(int var1);

      ChunkAccess diagonal(int var1);

      ShellExtractor.CapturedStrip strip(int var1);
   }

   public static final class Palette {
      private final boolean storeStates;
      private final IdentityHashMap<BlockState, Integer> byState = new IdentityHashMap<>();
      private final IdentityHashMap<Block, IntArrayList> byBlock = new IdentityHashMap<>();
      private final List<String> names = new ArrayList<>();
      private final List<BlockState> entryStates = new ArrayList<>();
      private final IntArrayList stateIndices = new IntArrayList();
      private final IntArrayList signatures = new IntArrayList();
      private final IntArrayList tints = new IntArrayList(288);
      private final IntArrayList mintY = new IntArrayList();
      private static final int COLUMN_NODES = 256;
      private static final int NO_CELL = Integer.MIN_VALUE;

      public Palette(boolean storeStates) {
         this.storeStates = storeStates;
      }

      public int indexOf(BlockState state, BlockAndTintGetter tintLevel, int baseX, int y, int baseZ) {
         Integer known = this.byState.get(state);
         if (known != null) {
            return known;
         }

         Block block = state.getBlock();
         IntArrayList siblings = this.byBlock.get(block);
         if (siblings != null) {
            for (int i = 0; i < siblings.size(); i++) {
               int e = siblings.getInt(i);
               BlockState seen = this.entryStates.get(e);
               if (!this.storeStates || SpriteUvResolver.sameAppearance(seen, state)) {
                  this.byState.put(state, e);
                  return e;
               }
            }
         }

         if (this.names.size() >= 256) {
            if (siblings != null && !siblings.isEmpty()) {
               int fallback = siblings.getInt(0);
               this.byState.put(state, fallback);
               return fallback;
            } else {
               return -1;
            }
         } else {
            int index = this.names.size();
            this.names.add(BuiltInRegistries.BLOCK.getKey(block).toString());
            this.entryStates.add(state);
            this.stateIndices.add(this.storeStates ? SpriteUvResolver.stateIndexOf(state) : -1);
            this.signatures.add(this.storeStates ? SpriteUvResolver.stateSignatureOf(block) : 0);
            this.appendTint(state, tintLevel, baseX, y, baseZ);
            this.mintY.add(y);
            this.byState.put(state, index);
            if (siblings == null) {
               siblings = new IntArrayList(2);
               this.byBlock.put(block, siblings);
            }

            siblings.add(index);
            return index;
         }
      }

      private void appendTint(BlockState state, BlockAndTintGetter tintLevel, int baseX, int y, int baseZ) {
         this.tints.add(tintLevel == null ? 16777215 : SpriteUvResolver.sampleTint(state, tintLevel, new BlockPos(baseX, y, baseZ)));
      }

      public int rebuildTints(int tintSide, BlockAndTintGetter tintLevel, int baseX, int baseZ, int[] columnY) {
         if (tintLevel != null && !this.names.isEmpty() && columnY != null && columnY.length == this.names.size() * 256) {
            if (tintSide != 16) {
               this.rebuildChunkTints(tintLevel, baseX, baseZ, columnY);
               return tintSide;
            }

            int cellNodes = 256;
            IntArrayList rebuilt = new IntArrayList(this.names.size() * cellNodes);
            MutableBlockPos probe = new MutableBlockPos();
            IdentityHashMap<Block, Integer> firstOfBlock = new IdentityHashMap<>();

            for (int e = 0; e < this.names.size(); e++) {
               BlockState state = this.entryStates.get(e);
               int base = e * cellNodes;
               fillColumnHeights(columnY, base, this.mintY.getInt(e));
               Block block = state.getBlock();
               Integer prior = firstOfBlock.get(block);
               if (prior != null) {
                  int priorBase = prior * cellNodes;
                  if (sameHeights(columnY, base, priorBase)) {
                     int firstNode = SpriteUvResolver.sampleTint(state, tintLevel, probe.set(baseX, columnY[base], baseZ));
                     if (firstNode == rebuilt.getInt(priorBase)) {
                        for (int n = 0; n < cellNodes; n++) {
                           rebuilt.add(rebuilt.getInt(priorBase + n));
                        }
                        continue;
                     }
                  }
               }

               ShellExtractor.sampleCellField(rebuilt, state, tintLevel, baseX, baseZ, columnY, base);
               firstOfBlock.putIfAbsent(block, e);
            }

            this.tints.clear();
            this.tints.addAll(rebuilt);
            return 16;
         } else {
            return tintSide;
         }
      }

      private void rebuildChunkTints(BlockAndTintGetter tintLevel, int baseX, int baseZ, int[] columnY) {
         MutableBlockPos probe = new MutableBlockPos();

         for (int e = 0; e < this.names.size(); e++) {
            int base = e * 256;
            int topY = Integer.MIN_VALUE;
            int topNode = -1;

            for (int n = 0; n < 256; n++) {
               int y = columnY[base + n];
               if (y != Integer.MIN_VALUE && (topNode < 0 || y > topY)) {
                  topY = y;
                  topNode = n;
               }
            }

            if (topNode >= 0) {
               this.tints
                  .set(e, SpriteUvResolver.sampleTint(this.entryStates.get(e), tintLevel, probe.set(baseX + (topNode & 15), topY, baseZ + (topNode >> 4))));
            }
         }
      }

      private static int fillColumnHeights(int[] columnY, int base, int fallback) {
         int top = Integer.MIN_VALUE;

         for (int n = 0; n < 256; n++) {
            int y = columnY[base + n];
            if (y != Integer.MIN_VALUE && (top == Integer.MIN_VALUE || y > top)) {
               top = y;
            }
         }

         if (top == Integer.MIN_VALUE) {
            top = fallback;
         }

         for (int n = 0; n < 256; n++) {
            if (columnY[base + n] == Integer.MIN_VALUE) {
               columnY[base + n] = top;
            }
         }

         return top;
      }

      private static boolean sameHeights(int[] columnY, int aBase, int bBase) {
         for (int n = 0; n < 256; n++) {
            if (columnY[aBase + n] != columnY[bBase + n]) {
               return false;
            }
         }

         return true;
      }

      public int[] columnHeights(int[] cells, int cellCount, int minY) {
         int[] field = new int[this.names.size() * 256];
         Arrays.fill(field, Integer.MIN_VALUE);

         for (int i = 0; i < cellCount; i++) {
            int cell = cells[i];
            int index = ShellCodec.cellPaletteIndex(cell) * 256 + (ShellCodec.cellZ(cell) << 4) + ShellCodec.cellX(cell);
            if (index >= 0 && index < field.length) {
               field[index] = minY + ShellCodec.cellYRel(cell);
            }
         }

         return field;
      }

      String[] names() {
         return this.names.toArray(new String[0]);
      }

      int[] states() {
         return this.storeStates ? this.stateIndices.toIntArray() : null;
      }

      int[] signatures() {
         return this.storeStates ? this.signatures.toIntArray() : null;
      }

      public int[] tints() {
         return this.tints.toIntArray();
      }
   }

   static final class WalkRequest {
      LevelChunk chunk;
      ShellExtractor.NeighborView neighbors;
      ShellExtractor.LightView light;
      BlockAndTintGetter tint;
      boolean hasSkyLight;
      boolean surfaceBand;
      int bandOffset;
      int blendDivisor;
      boolean keepUnderwaterPlants;
      boolean realLight;
      boolean lightPendingOut;
   }
}
