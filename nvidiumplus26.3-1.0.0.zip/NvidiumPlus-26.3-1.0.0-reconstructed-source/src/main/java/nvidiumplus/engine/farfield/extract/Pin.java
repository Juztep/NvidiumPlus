package nvidiumplus.engine.farfield.extract;

import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.core.SectionPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.world.level.CardinalLighting;
import net.minecraft.world.level.ColorResolver;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.DataLayer;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.lighting.LayerLightEventListener;
import net.minecraft.world.level.lighting.LevelLightEngine;
import net.minecraft.world.level.material.FluidState;
import nvidiumplus.engine.farfield.FarField;
import nvidiumplus.engine.farfield.FarFieldConfig;

final class Pin implements ShellExtractor.NeighborView, ShellExtractor.LightView {
   final long key;
   final int chunkX;
   final int chunkZ;
   final LevelChunk chunk;
   final boolean live;
   final long storeGeneration;
   final boolean hasSkyLight;
   final int minLightSection;
   final CardinalLighting cardinal;
   final DataLayer[] ownSky;
   final DataLayer[] ownBlock;
   private final boolean ownLightCaptured;
   final boolean surfaceBand;
   final int bandOffset;
   final int blendDivisor;
   final boolean keepUnderwaterPlants;
   final boolean realLight;
   final int biomeBlendRadius;
   final BiomeManager levelBiomes;
   final Pin[] sidePin = new Pin[4];
   final Pin[] diagPin = new Pin[4];
   final ShellExtractor.CapturedStrip[] strips = new ShellExtractor.CapturedStrip[4];
   final DataLayer[][] sideSky = new DataLayer[4][];
   final DataLayer[][] sideBlock = new DataLayer[4][];
   final boolean[] sideLightCaptured = new boolean[4];
   final ColumnSnapshot.TintBiomes[] sideTint = new ColumnSnapshot.TintBiomes[4];
   final ColumnSnapshot.TintBiomes[] diagTint = new ColumnSnapshot.TintBiomes[4];
   long version;
   int finishSide;
   volatile boolean released;
   boolean walkLightPending;
   byte walkQuality;
   byte walkOutcome;
   private Pin.PinTintView tintView;

   private Pin(long key, LevelChunk chunk, boolean live, boolean lightPublished, boolean captureLight, Pin.Settings settings, long storeGeneration) {
      this.key = key;
      this.chunkX = chunk.getPos().x();
      this.chunkZ = chunk.getPos().z();
      this.chunk = chunk;
      this.live = live;
      this.storeGeneration = storeGeneration;
      this.hasSkyLight = chunk.getLevel().dimensionType().hasSkyLight();
      this.cardinal = chunk.getLevel() instanceof BlockAndTintGetter tinted ? tinted.cardinalLighting() : CardinalLighting.DEFAULT;
      this.surfaceBand = settings.surfaceBand();
      this.bandOffset = settings.bandOffset();
      this.blendDivisor = settings.blendDivisor();
      this.keepUnderwaterPlants = settings.keepUnderwaterPlants();
      this.realLight = settings.realLight();
      this.biomeBlendRadius = settings.biomeBlendRadius();
      this.levelBiomes = chunk.getLevel().getBiomeManager();
      LevelLightEngine engine = chunk.getLevel().getLightEngine();
      this.minLightSection = engine.getMinLightSection();
      if (lightPublished && captureLight && this.realLight) {
         int sections = engine.getMaxLightSection() - this.minLightSection + 1;
         DataLayer[] sky = grabLayers(engine, LightLayer.SKY, this.chunkX, this.chunkZ, this.minLightSection, sections);
         DataLayer[] block = grabLayers(engine, LightLayer.BLOCK, this.chunkX, this.chunkZ, this.minLightSection, sections);
         if (!anyLayer(sky) && !anyLayer(block)) {
            this.ownSky = null;
            this.ownBlock = null;
            this.ownLightCaptured = false;
         } else {
            this.ownSky = sky;
            this.ownBlock = block;
            this.ownLightCaptured = true;
         }
      } else {
         this.ownSky = null;
         this.ownBlock = null;
         this.ownLightCaptured = false;
      }
   }

   static Pin capture(long key, LevelChunk chunk, boolean lightPublished, boolean captureLight, Pin.Settings settings) {
      return new Pin(key, chunk, false, lightPublished, captureLight, settings, FarField.storeGeneration());
   }

   static Pin captureLive(long key, LevelChunk liveChunk, boolean lightPublished, Pin.Settings settings) {
      return new Pin(key, ColumnSnapshot.freeze(liveChunk), true, lightPublished, true, settings, FarField.storeGeneration());
   }

   private static DataLayer[] grabLayers(LevelLightEngine engine, LightLayer layer, int cx, int cz, int minSection, int count) {
      LayerLightEventListener listener = engine.getLayerListener(layer);
      DataLayer[] grabbed = new DataLayer[count];

      for (int i = 0; i < count; i++) {
         grabbed[i] = listener.getDataLayerData(SectionPos.of(cx, minSection + i, cz));
      }

      return grabbed;
   }

   private static boolean anyLayer(DataLayer[] layers) {
      for (DataLayer layer : layers) {
         if (layer != null) {
            return true;
         }
      }

      return false;
   }

   void captureSideLight(int side, LevelChunk neighbor, boolean published) {
      if (published && this.realLight) {
         LevelLightEngine engine = neighbor.getLevel().getLightEngine();
         int sections = engine.getMaxLightSection() - this.minLightSection + 1;
         DataLayer[] sky = grabLayers(engine, LightLayer.SKY, neighbor.getPos().x(), neighbor.getPos().z(), this.minLightSection, sections);
         DataLayer[] block = grabLayers(engine, LightLayer.BLOCK, neighbor.getPos().x(), neighbor.getPos().z(), this.minLightSection, sections);
         if (anyLayer(sky) || anyLayer(block)) {
            this.sideSky[side] = sky;
            this.sideBlock[side] = block;
            this.sideLightCaptured[side] = true;
         }
      }
   }

   void captureSideTint(int side, ChunkAccess neighbor) {
      this.sideTint[side] = ColumnSnapshot.biomeRefs(neighbor);
   }

   void captureDiagTint(int corner, ChunkAccess neighbor) {
      this.diagTint[corner] = ColumnSnapshot.biomeRefs(neighbor);
   }

   boolean ownLightReady() {
      return this.ownLightCaptured;
   }

   BlockAndTintGetter tintView() {
      Pin.PinTintView view = this.tintView;
      if (view == null) {
         view = new Pin.PinTintView();
         this.tintView = view;
      }

      return view;
   }

   @Override
   public ChunkAccess lateral(int side) {
      Pin neighbor = this.sidePin[side];
      return neighbor == null ? null : neighbor.chunk;
   }

   @Override
   public ChunkAccess diagonal(int corner) {
      Pin neighbor = this.diagPin[corner];
      return neighbor == null ? null : neighbor.chunk;
   }

   @Override
   public ShellExtractor.CapturedStrip strip(int side) {
      return this.strips[side];
   }

   @Override
   public boolean sideAdmissible(int side) {
      Pin neighbor = this.sidePin[side];
      return neighbor != null ? neighbor.ownLightReady() : this.sideLightCaptured[side];
   }

   @Override
   public int skyBlock(int wx, int y, int wz) {
      int dx = (wx >> 4) - this.chunkX;
      int dz = (wz >> 4) - this.chunkZ;
      DataLayer[] sky;
      DataLayer[] block;
      if (dx == 0 && dz == 0) {
         if (!this.ownLightCaptured) {
            return -1;
         }

         sky = this.ownSky;
         block = this.ownBlock;
      } else {
         int side = sideOf(dx, dz);
         if (side < 0) {
            return -1;
         }

         Pin neighbor = this.sidePin[side];
         if (neighbor != null) {
            if (!neighbor.ownLightCaptured) {
               return -1;
            }

            sky = neighbor.ownSky;
            block = neighbor.ownBlock;
         } else {
            if (!this.sideLightCaptured[side]) {
               return -1;
            }

            sky = this.sideSky[side];
            block = this.sideBlock[side];
         }
      }

      int idx = (y >> 4) - this.minLightSection;
      int lx = wx & 15;
      int lz = wz & 15;
      int skyValue = this.hasSkyLight ? skyValue(sky, idx, lx, y & 15, lz) : 0;
      int blockValue = 0;
      if (idx >= 0 && idx < block.length) {
         DataLayer layer = block[idx];
         if (layer != null) {
            blockValue = layer.get(lx, y & 15, lz);
         }
      }

      return nibble(skyValue) << 4 | nibble(blockValue);
   }

   private static int skyValue(DataLayer[] sky, int idx, int lx, int ly, int lz) {
      if (idx >= sky.length) {
         return 15;
      }

      if (idx >= 0) {
         DataLayer layer = sky[idx];
         if (layer != null) {
            return layer.get(lx, ly, lz);
         }
      }

      for (int i = Math.max(0, idx + 1); i < sky.length; i++) {
         if (sky[i] != null) {
            return sky[i].get(lx, 0, lz);
         }
      }

      return 15;
   }

   private static int nibble(int value) {
      return value < 0 ? 0 : Math.min(value, 15);
   }

   private static int sideOf(int dx, int dz) {
      if (dz == 0) {
         if (dx == -1) {
            return 0;
         }

         if (dx == 1) {
            return 1;
         }
      } else if (dx == 0) {
         if (dz == -1) {
            return 2;
         }

         if (dz == 1) {
            return 3;
         }
      }

      return -1;
   }

   private ChunkAccess chunkFor(int bx, int bz) {
      int dx = (bx >> 4) - this.chunkX;
      int dz = (bz >> 4) - this.chunkZ;
      if (dx == 0 && dz == 0) {
         return this.chunk;
      }

      int side = sideOf(dx, dz);
      if (side >= 0) {
         return this.lateral(side);
      }

      for (int corner = 0; corner < 4; corner++) {
         if (ShellExtractor.CORNER_DX[corner] == dx && ShellExtractor.CORNER_DZ[corner] == dz) {
            return this.diagonal(corner);
         }
      }

      return null;
   }

   private final class PinTintView implements BlockAndTintGetter {
      private BiomeManager pinBiomes;
      private final MutableBlockPos biomeProbe = new MutableBlockPos();
      private ColorResolver warmResolver;
      private int warmY = Integer.MIN_VALUE;
      private ColorResolver satResolver;
      private int satY;
      private int[] satRed;
      private int[] satGreen;
      private int[] satBlue;

      public CardinalLighting cardinalLighting() {
         return Pin.this.cardinal;
      }

      public int getBlockTint(BlockPos pos, ColorResolver resolver) {
         int x = pos.getX();
         int y = pos.getY();
         int z = pos.getZ();
         int r = Pin.this.biomeBlendRadius;
         if (r <= 0) {
            return this.rawColor(resolver, x, y, z);
         }

         int homeX = Pin.this.chunkX << 4;
         int homeZ = Pin.this.chunkZ << 4;
         if (x >= homeX && x < homeX + 16 && z >= homeZ && z < homeZ + 16) {
            if (this.satRed == null || resolver != this.satResolver || y != this.satY) {
               if (resolver != this.warmResolver || y != this.warmY) {
                  this.warmResolver = resolver;
                  this.warmY = y;
                  return this.boxMean(resolver, x, y, z, r);
               }

               this.buildSat(resolver, y, r);
            }

            int w = 16 + 2 * r + 1;
            int lx = x - homeX + r;
            int lz = z - homeZ + r;
            int count = (2 * r + 1) * (2 * r + 1);
            return ARGB.color(
               rectSum(this.satRed, w, lx - r, lz - r, lx + r, lz + r) / count,
               rectSum(this.satGreen, w, lx - r, lz - r, lx + r, lz + r) / count,
               rectSum(this.satBlue, w, lx - r, lz - r, lx + r, lz + r) / count
            );
         } else {
            return this.boxMean(resolver, x, y, z, r);
         }
      }

      private int boxMean(ColorResolver resolver, int x, int y, int z, int r) {
         int count = (2 * r + 1) * (2 * r + 1);
         int red = 0;
         int green = 0;
         int blue = 0;

         for (int dz = -r; dz <= r; dz++) {
            for (int dx = -r; dx <= r; dx++) {
               int c = this.rawColor(resolver, x + dx, y, z + dz);
               red += ARGB.red(c);
               green += ARGB.green(c);
               blue += ARGB.blue(c);
            }
         }

         return ARGB.color(red / count, green / count, blue / count);
      }

      private void buildSat(ColorResolver resolver, int y, int r) {
         int pad = 16 + 2 * r;
         int w = pad + 1;
         int minX = (Pin.this.chunkX << 4) - r;
         int minZ = (Pin.this.chunkZ << 4) - r;
         int[] red = new int[w * w];
         int[] green = new int[w * w];
         int[] blue = new int[w * w];

         for (int j = 0; j < pad; j++) {
            for (int i = 0; i < pad; i++) {
               int c = this.rawColor(resolver, minX + i, y, minZ + j);
               int at = (j + 1) * w + i + 1;
               red[at] = ARGB.red(c) + red[at - 1] + red[at - w] - red[at - w - 1];
               green[at] = ARGB.green(c) + green[at - 1] + green[at - w] - green[at - w - 1];
               blue[at] = ARGB.blue(c) + blue[at - 1] + blue[at - w] - blue[at - w - 1];
            }
         }

         this.satRed = red;
         this.satGreen = green;
         this.satBlue = blue;
         this.satResolver = resolver;
         this.satY = y;
      }

      private static int rectSum(int[] sat, int w, int x0, int z0, int x1, int z1) {
         return sat[(z1 + 1) * w + x1 + 1] - sat[z0 * w + x1 + 1] - sat[(z1 + 1) * w + x0] + sat[z0 * w + x0];
      }

      private int rawColor(ColorResolver resolver, int x, int y, int z) {
         return resolver.getColor((Biome)this.pinBiomes().getBiome(this.biomeProbe.set(x, y, z)).value(), x, z);
      }

      private BiomeManager pinBiomes() {
         BiomeManager built = this.pinBiomes;
         if (built == null) {
            built = Pin.this.levelBiomes.withDifferentSource(this::pinNoiseBiome);
            this.pinBiomes = built;
         }

         return built;
      }

      private Holder<Biome> pinNoiseBiome(int qx, int qy, int qz) {
         int dx = Mth.clamp(QuartPos.toSection(qx) - Pin.this.chunkX, -1, 1);
         int dz = Mth.clamp(QuartPos.toSection(qz) - Pin.this.chunkZ, -1, 1);
         ColumnSnapshot.TintBiomes captured = this.tintAt(dx, dz);
         if (captured != null) {
            Holder<Biome> exact = captured.noiseBiome(qx, qy, qz);
            if (exact != null) {
               return exact;
            }
         }

         ChunkAccess owner;
         for (owner = this.graphAt(dx, dz); owner == null && (dx != 0 || dz != 0); owner = this.graphAt(dx, dz)) {
            if (dx != 0) {
               dx -= Integer.signum(dx);
            } else {
               dz -= Integer.signum(dz);
            }
         }

         if (owner == null) {
            owner = Pin.this.chunk;
            dx = 0;
            dz = 0;
         }

         int baseQx = QuartPos.fromSection(Pin.this.chunkX + dx);
         int baseQz = QuartPos.fromSection(Pin.this.chunkZ + dz);
         return owner.getNoiseBiome(Mth.clamp(qx, baseQx, baseQx + 3), qy, Mth.clamp(qz, baseQz, baseQz + 3));
      }

      private ChunkAccess graphAt(int dx, int dz) {
         return Pin.this.chunkFor(Pin.this.chunkX + dx << 4, Pin.this.chunkZ + dz << 4);
      }

      private ColumnSnapshot.TintBiomes tintAt(int dx, int dz) {
         if (dx == 0 && dz == 0) {
            return null;
         }

         if (dx != 0 && dz != 0) {
            for (int corner = 0; corner < 4; corner++) {
               if (ShellExtractor.CORNER_DX[corner] == dx && ShellExtractor.CORNER_DZ[corner] == dz) {
                  return Pin.this.diagTint[corner];
               }
            }

            return null;
         } else {
            int side = Pin.sideOf(dx, dz);
            return side < 0 ? null : Pin.this.sideTint[side];
         }
      }

      public LevelLightEngine getLightEngine() {
         throw new IllegalStateException("pinned extraction must not read the light engine");
      }

      public BlockEntity getBlockEntity(BlockPos pos) {
         return null;
      }

      public BlockState getBlockState(BlockPos pos) {
         ChunkAccess owner = Pin.this.chunkFor(pos.getX(), pos.getZ());
         return owner == null ? Blocks.AIR.defaultBlockState() : owner.getBlockState(pos);
      }

      public FluidState getFluidState(BlockPos pos) {
         return this.getBlockState(pos).getFluidState();
      }

      public int getHeight() {
         return Pin.this.chunk.getHeight();
      }

      public int getMinY() {
         return Pin.this.chunk.getMinY();
      }
   }

   record Settings(boolean surfaceBand, int bandOffset, int blendDivisor, boolean keepUnderwaterPlants, boolean realLight, int biomeBlendRadius) {
      static Pin.Settings snapshot() {
         return new Pin.Settings(
            FarFieldConfig.surfaceBandEnabled(),
            FarFieldConfig.bandOffset(),
            FarFieldConfig.layerColourBlend(FarFieldConfig.Layer.L1),
            FarFieldConfig.layerFlag(FarFieldConfig.Layer.L1, FarFieldConfig.Control.UNDERWATER_PLANTS),
            FarFieldConfig.layerLighting(FarFieldConfig.Layer.L1) == 2,
            FarFieldConfig.biomeBlendRadius()
         );
      }
   }
}
