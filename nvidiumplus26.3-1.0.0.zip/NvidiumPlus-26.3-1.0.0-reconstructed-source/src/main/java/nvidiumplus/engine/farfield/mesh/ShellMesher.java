package nvidiumplus.engine.farfield.mesh;

import it.unimi.dsi.fastutil.ints.Int2FloatOpenHashMap;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectAVLTreeMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectBidirectionalIterator;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import nvidiumplus.engine.farfield.FarFieldConfig;
import nvidiumplus.engine.farfield.store.ShellCodec;
import nvidiumplus.engine.terrain.EncodedSectionMesh;
import nvidiumplus.engine.terrain.GreedyMesher;
import nvidiumplus.engine.terrain.QuadFacing;
import nvidiumplus.engine.terrain.SectionMeshEncoder;
import nvidiumplus.engine.terrain.TerrainQuad;
import nvidiumplus.engine.terrain.TerrainVertex;

public final class ShellMesher {
   static final int BLOCK_LIGHT_RAW = 8;
   static final int SKY_LIGHT_RAW = 248;
   private static final int FLAT_LIGHT = 63496;
   private static final int SKY_LEVEL_MAX = 15;
   private static final int NO_WATER = Integer.MIN_VALUE;
   private static final int CUTOFF_CUTOUT = 2;
   private static final int CUTOFF_NONE = 0;
   static final float FLUID_SURFACE_HEIGHT = 0.8888889F;
   private static final float SPAN_EPSILON = 1.0E-4F;
   private static final int SHADE_UP = 255;
   private static final int SHADE_DOWN = 128;
   private static final int SHADE_NZ = 204;
   private static final int SHADE_EW = 153;
   private static final int SHADE_CROSS = 255;
   private static final float CONTACT_SHADE_MAX = 0.5F;
   static final int CONTACT_SHADE_FULL = 100;
   private static final float PLANE_EPSILON = 0.001F;
   private static final int BUCKET_OPAQUE = 0;
   private static final int BUCKET_TRANS = 1;
   private static final int BUCKETS = 2;
   private static final int APRON_UP = 1024;
   private static final int FAMILY_SHIFT = 19;
   private static final long LCG_MASK = 281474976710655L;
   private static final long LCG_MULT = 25214903917L;
   private static final float AMBIENT_STEP = 0.2F;
   private static final float NUDGE_TOLERANCE = 0.0078125F;
   private static final int DARK_LIGHT = 2056;
   private static final int LATERAL_FACES = 60;
   private static final float CORNER_EPSILON = 1.0E-4F;
   private static final long FLOW_NONE = 0L;
   private static final int MAX_SHIFT_QUADS = 256;

   private ShellMesher() {
   }

   private static int apronKey(int x, int yRel, int z) {
      return yRel + 1 << 10 | z + 1 << 5 | x + 1;
   }

   private static Int2IntOpenHashMap airLight(ShellCodec.Shell shell, ShellMesher.Apron apron) {
      Int2IntOpenHashMap donors = new Int2IntOpenHashMap(Math.max(16, shell.cellCount));
      donors.defaultReturnValue(-1);
      if (apron != null) {
         for (int d = 0; d < 9; d++) {
            ShellCodec.Shell nb = apron.shells[d];
            if (d != 4 && nb != null && nb.cellLight != null && nb.cellLight.length >= nb.cellCount) {
               int[] edge = apron.edgeCells[d];
               int dyRel = nb.minY - shell.minY;
               int ddx = d % 3 - 1 << 4;
               int ddz = d / 3 - 1 << 4;

               for (int k = 0; k < edge.length; k++) {
                  int idx = edge[k];
                  donateCell(donors, nb.cells[idx], nb.cellLight[idx] & 255, ddx, dyRel, ddz);
               }
            }
         }
      }

      for (int i = 0; i < shell.cellCount; i++) {
         donateCell(donors, shell.cells[i], shell.cellLight[i] & 255, 0, 0, 0);
      }

      return donors;
   }

   private static void donateCell(Int2IntOpenHashMap donors, int cell, int lightByte, int dx, int dyRel, int dz) {
      int mask = ShellCodec.cellFaceMask(cell);
      int face;
      if ((mask & 2) != 0) {
         face = 1;
      } else {
         if ((mask & mask - 1) != 0 || mask == 0) {
            return;
         }

         face = Integer.numberOfTrailingZeros(mask);
      }

      int x = ShellCodec.cellX(cell) + dx;
      int yRel = ShellCodec.cellYRel(cell) + dyRel;
      int z = ShellCodec.cellZ(cell) + dz;
      switch (face) {
         case 0:
            yRel--;
            break;
         case 1:
            yRel++;
            break;
         case 2:
            z--;
            break;
         case 3:
            z++;
            break;
         case 4:
            x--;
            break;
         default:
            x++;
      }

      if (x >= -1 && x <= 16 && z >= -1 && z <= 16 && yRel >= -1 && yRel <= 256) {
         donors.put(apronKey(x, yRel, z), lightByte);
      }
   }

   private static IntOpenHashSet glassyCells(
      ShellCodec.Shell shell, SpriteUvResolver.ResolvedPalette palette, boolean[] upperHalf, int[] upperRow, ShellMesher.Apron apron
   ) {
      boolean any = palette.anyGlassy;
      if (!any && apron != null) {
         for (int d = 0; d < 9 && !any; d++) {
            any = d != 4 && apron.palettes[d] != null && apron.palettes[d].anyGlassy;
         }
      }

      if (!any) {
         return null;
      }

      IntOpenHashSet glassy = new IntOpenHashSet(64);
      int paletteSize = palette.size();

      for (int i = 0; i < shell.cellCount; i++) {
         int cell = shell.cells[i];
         int pi = ShellCodec.cellPaletteIndex(cell);
         if (pi < paletteSize) {
            int pe = upperHalf != null && upperHalf[i] ? upperRow[pi] : pi;
            if (palette.glassy[pe]) {
               glassy.add(apronKey(ShellCodec.cellX(cell), ShellCodec.cellYRel(cell), ShellCodec.cellZ(cell)));
            }
         }
      }

      if (apron != null) {
         for (int d = 0; d < 9; d++) {
            ShellCodec.Shell nb = apron.shells[d];
            if (d != 4 && nb != null) {
               SpriteUvResolver.ResolvedPalette np = apron.palettes[d];
               if (np.anyGlassy) {
                  boolean[] nbUpper = apron.upperHalf[d];
                  int[] nbUpperRow = np.upperRow;
                  int npSize = np.size();
                  int[] edge = apron.edgeCells[d];
                  int dyRel = nb.minY - shell.minY;
                  int ddx = d % 3 - 1 << 4;
                  int ddz = d / 3 - 1 << 4;

                  for (int k = 0; k < edge.length; k++) {
                     int idx = edge[k];
                     int cell = nb.cells[idx];
                     int ourY = ShellCodec.cellYRel(cell) + dyRel;
                     if (ourY >= -1 && ourY <= 256) {
                        int pi = ShellCodec.cellPaletteIndex(cell);
                        if (pi < npSize) {
                           int pe = nbUpper != null && nbUpper[idx] ? nbUpperRow[pi] : pi;
                           if (np.glassy[pe]) {
                              glassy.add(apronKey(ShellCodec.cellX(cell) + ddx, ourY, ShellCodec.cellZ(cell) + ddz));
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return glassy.isEmpty() ? null : glassy;
   }

   public static int variantDraw(long seed, int bound) {
      long s = (seed ^ 25214903917L) & 281474976710655L;
      s = s * 25214903917L + 11L & 281474976710655L;
      int bits = (int)(s >>> 17);
      if ((bound & bound - 1) == 0) {
         return (int)((long)bound * bits >> 31);
      }

      int r;
      for (r = bits % bound; bits - r + (bound - 1) < 0; r = bits % bound) {
         s = s * 25214903917L + 11L & 281474976710655L;
         bits = (int)(s >>> 17);
      }

      return r;
   }

   private static ShellMesher.Occluders occluders(
      ShellCodec.Shell shell, SpriteUvResolver.ResolvedPalette palette, boolean[] upperHalf, int[] upperRow, int paletteSize, ShellMesher.Apron apron
   ) {
      int maxYRel = -1;

      for (int i = 0; i < shell.cellCount; i++) {
         int yRel = ShellCodec.cellYRel(shell.cells[i]);
         if (yRel > maxYRel) {
            maxYRel = yRel;
         }
      }

      if (maxYRel < 0) {
         return null;
      }

      int span = maxYRel + 1;
      ShellMesher.Occluders occ = new ShellMesher.Occluders(ShellMesher.Occluders.allocate(span), span);
      boolean any = false;

      for (int i = 0; i < shell.cellCount; i++) {
         int cell = shell.cells[i];
         int pi = ShellCodec.cellPaletteIndex(cell);
         if (pi < paletteSize && palette.kind[pi] != 0) {
            int pe = upperHalf != null && upperHalf[i] ? upperRow[pi] : pi;
            if (solidCube(palette, pe)) {
               occ.set(ShellCodec.cellX(cell), ShellCodec.cellYRel(cell), ShellCodec.cellZ(cell));
               any = true;
            }
         }
      }

      if (apron != null) {
         for (int d = 0; d < 9; d++) {
            ShellCodec.Shell nb = apron.shells[d];
            if (d != 4 && nb != null) {
               SpriteUvResolver.ResolvedPalette np = apron.palettes[d];
               boolean[] nbUpper = apron.upperHalf[d];
               int[] nbUpperRow = np.upperRow;
               int npSize = np.size();
               int[] edge = apron.edgeCells[d];
               int dyRel = nb.minY - shell.minY;
               int dx = d % 3 - 1 << 4;
               int dz = d / 3 - 1 << 4;

               for (int k = 0; k < edge.length; k++) {
                  int idx = edge[k];
                  int cell = nb.cells[idx];
                  int ourY = ShellCodec.cellYRel(cell) + dyRel;
                  if (ourY >= -1 && ourY <= span) {
                     int pi = ShellCodec.cellPaletteIndex(cell);
                     if (pi < npSize && np.kind[pi] != 0) {
                        int pe = nbUpper != null && nbUpper[idx] ? nbUpperRow[pi] : pi;
                        if (solidCube(np, pe)) {
                           occ.set(ShellCodec.cellX(cell) + dx, ourY, ShellCodec.cellZ(cell) + dz);
                           any = true;
                        }
                     }
                  }
               }
            }
         }
      }

      return any ? occ : null;
   }

   private static int ambientCorners(ShellMesher.Occluders occ, QuadFacing facing, int ox, int oy, int oz) {
      int ax = 0;
      int ay = 0;
      int az = 0;
      int bx = 0;
      int by = 0;
      int bz = 0;
      switch (facing) {
         case POS_Y:
         case NEG_Y:
            ax = 1;
            bz = 1;
            break;
         case POS_X:
         case NEG_X:
            ay = 1;
            bz = 1;
            break;
         case POS_Z:
         case NEG_Z:
            ax = 1;
            by = 1;
            break;
         default:
            return 0;
      }

      boolean aLow = occ.solid(ox - ax, oy - ay, oz - az);
      boolean aHigh = occ.solid(ox + ax, oy + ay, oz + az);
      boolean bLow = occ.solid(ox - bx, oy - by, oz - bz);
      boolean bHigh = occ.solid(ox + bx, oy + by, oz + bz);
      int packed = 0;

      for (int slot = 0; slot < 4; slot++) {
         boolean high = (slot & 2) != 0;
         boolean far = (slot & 1) != 0;
         boolean side1 = high ? aHigh : aLow;
         boolean side2 = far ? bHigh : bLow;
         int count = (side1 ? 1 : 0) + (side2 ? 1 : 0);
         if (side1 && side2) {
            count++;
         } else {
            int sa = high ? 1 : -1;
            int sb = far ? 1 : -1;
            if (occ.solid(ox + ax * sa + bx * sb, oy + ay * sa + by * sb, oz + az * sa + bz * sb)) {
               count++;
            }
         }

         packed |= count << slot * 2;
      }

      return packed;
   }

   private static float inPlaneA(QuadFacing facing, float[] pos, int vb) {
      return switch (facing) {
         case POS_Y, NEG_Y, POS_Z, NEG_Z -> clamp01(pos[vb]);
         case POS_X, NEG_X -> clamp01(pos[vb + 1]);
         default -> 0.0F;
      };
   }

   private static float inPlaneB(QuadFacing facing, float[] pos, int vb) {
      return switch (facing) {
         case POS_Y, NEG_Y, POS_X, NEG_X -> clamp01(pos[vb + 2]);
         case POS_Z, NEG_Z -> clamp01(pos[vb + 1]);
         default -> 0.0F;
      };
   }

   private static float clamp01(float v) {
      return v < 0.0F ? 0.0F : (v > 1.0F ? 1.0F : v);
   }

   private static boolean faceAtCellBoundary(QuadFacing facing, float[] pos, int pb) {
      return switch (facing) {
         case POS_Y -> Math.abs(pos[pb + 1] - 1.0F) <= 0.0078125F;
         case NEG_Y -> Math.abs(pos[pb + 1]) <= 0.0078125F;
         case POS_X -> Math.abs(pos[pb] - 1.0F) <= 0.0078125F;
         case NEG_X -> Math.abs(pos[pb]) <= 0.0078125F;
         case POS_Z -> Math.abs(pos[pb + 2] - 1.0F) <= 0.0078125F;
         case NEG_Z -> Math.abs(pos[pb + 2]) <= 0.0078125F;
         default -> false;
      };
   }

   private static int ambientRgb(int rgb, float level, float strength) {
      if (level <= 0.0F) {
         return rgb;
      }

      float factor = 1.0F - strength * 0.2F * level;
      int r = Math.round((rgb >>> 16 & 0xFF) * factor);
      int g = Math.round((rgb >>> 8 & 0xFF) * factor);
      int b = Math.round((rgb & 0xFF) * factor);
      return r << 16 | g << 8 | b;
   }

   private static int rawLevel(int level) {
      return (Math.max(0, level) << 4) + 8;
   }

   private static int smoothBlend(int a, int b, int c, int d) {
      if (d >>> 12 > 2 || (d & 0xFF) >>> 4 > 2) {
         a = substituteDark(a, d);
         b = substituteDark(b, d);
         c = substituteDark(c, d);
      }

      int sky = (a >>> 8) + (b >>> 8) + (c >>> 8) + (d >>> 8) >> 2;
      int block = (a & 0xFF) + (b & 0xFF) + (c & 0xFF) + (d & 0xFF) >> 2;
      return sky << 8 | block;
   }

   private static int substituteDark(int probe, int reference) {
      if (probe == 2056) {
         return reference;
      } else {
         return probe >>> 8 == 8 ? reference & 0xFF00 | probe & 0xFF : probe;
      }
   }

   private static int probeLight(Int2IntOpenHashMap donors, ShellMesher.Occluders occ, ShellMesher.Style style, int px, int py, int pz, int reference) {
      if (px >= -1 && px <= 16 && pz >= -1 && pz <= 16 && py >= -1 && py <= 256) {
         int donor = donors.get(apronKey(px, py, pz));
         if (donor >= 0) {
            return style.lightRaw(donor);
         }
      }

      return occ != null && occ.solid(px, py, pz) ? 2056 : reference;
   }

   private static long cornerLights(
      Int2IntOpenHashMap donors, ShellMesher.Occluders occ, ShellMesher.Style style, QuadFacing facing, int ox, int oy, int oz, int reference, int ambient
   ) {
      int ax = 0;
      int ay = 0;
      int az = 0;
      int bx = 0;
      int by = 0;
      int bz = 0;
      switch (facing) {
         case POS_Y:
         case NEG_Y:
            ax = 1;
            bz = 1;
            break;
         case POS_X:
         case NEG_X:
            ay = 1;
            bz = 1;
            break;
         case POS_Z:
         case NEG_Z:
            ax = 1;
            by = 1;
            break;
         default:
            return 0L;
      }

      int aLow = probeLight(donors, occ, style, ox - ax, oy - ay, oz - az, reference);
      int aHigh = probeLight(donors, occ, style, ox + ax, oy + ay, oz + az, reference);
      int bLow = probeLight(donors, occ, style, ox - bx, oy - by, oz - bz, reference);
      int bHigh = probeLight(donors, occ, style, ox + bx, oy + by, oz + bz, reference);
      long packed = 0L;

      for (int slot = 0; slot < 4; slot++) {
         boolean high = (slot & 2) != 0;
         boolean far = (slot & 1) != 0;
         int side1 = high ? aHigh : aLow;
         int side2 = far ? bHigh : bLow;
         int diag;
         if ((ambient >>> slot * 2 & 3) == 3) {
            diag = side1;
         } else {
            int sa = high ? 1 : -1;
            int sb = far ? 1 : -1;
            diag = probeLight(donors, occ, style, ox + ax * sa + bx * sb, oy + ay * sa + by * sb, oz + az * sa + bz * sb, reference);
         }

         packed |= (long)(smoothBlend(side1, side2, diag, reference) & 65535) << slot * 16;
      }

      return packed;
   }

   private static int vertexLight(long cornerLight, QuadFacing facing, float[] pos, int vb) {
      float fa = inPlaneA(facing, pos, vb);
      float fb = inPlaneB(facing, pos, vb);
      float w00 = (1.0F - fa) * (1.0F - fb);
      float w01 = (1.0F - fa) * fb;
      float w10 = fa * (1.0F - fb);
      float w11 = fa * fb;
      int c00 = (int)(cornerLight & 65535L);
      int c01 = (int)(cornerLight >>> 16 & 65535L);
      int c10 = (int)(cornerLight >>> 32 & 65535L);
      int c11 = (int)(cornerLight >>> 48 & 65535L);
      int sky = (int)((c00 >>> 8) * w00 + (c01 >>> 8) * w01 + (c10 >>> 8) * w10 + (c11 >>> 8) * w11);
      int block = (int)((c00 & 0xFF) * w00 + (c01 & 0xFF) * w01 + (c10 & 0xFF) * w10 + (c11 & 0xFF) * w11);
      return sky << 8 | block;
   }

   private static boolean darkening(SpriteUvResolver.ResolvedPalette p, int pi) {
      return p.kind[pi] == 2 && p.emission[pi] == 0;
   }

   private static boolean solidCube(SpriteUvResolver.ResolvedPalette p, int row) {
      return p.kind[row] == 1 && p.fullCube[row];
   }

   private static ShellMesher.WaterColumns waterColumns(ShellCodec.Shell shell, SpriteUvResolver.ResolvedPalette palette) {
      int paletteSize = palette.size();
      boolean anyFluid = false;

      for (int e = 0; e < paletteSize && !anyFluid; e++) {
         anyFluid = darkening(palette, e);
      }

      if (!anyFluid) {
         return null;
      }

      int[] surface = new int[256];
      int[] floor = new int[256];
      Arrays.fill(surface, Integer.MIN_VALUE);
      Arrays.fill(floor, Integer.MIN_VALUE);
      boolean anySurface = false;

      for (int i = 0; i < shell.cellCount; i++) {
         int cell = shell.cells[i];
         int pi = ShellCodec.cellPaletteIndex(cell);
         if (pi < paletteSize && darkening(palette, pi) && (ShellCodec.cellFaceMask(cell) & 2) != 0) {
            int column = ShellCodec.cellZ(cell) << 4 | ShellCodec.cellX(cell);
            int y = shell.minY + ShellCodec.cellYRel(cell);
            if (y > surface[column]) {
               surface[column] = y;
               anySurface = true;
            }
         }
      }

      if (!anySurface) {
         return null;
      }

      if (!narrowSurfaces(surface)) {
         return null;
      }

      for (int i = 0; i < shell.cellCount; i++) {
         int cell = shell.cells[i];
         int pi = ShellCodec.cellPaletteIndex(cell);
         if (pi < paletteSize && solidCube(palette, pi)) {
            int column = ShellCodec.cellZ(cell) << 4 | ShellCodec.cellX(cell);
            int y = shell.minY + ShellCodec.cellYRel(cell);
            if (y < surface[column] && y > floor[column]) {
               floor[column] = y;
            }
         }
      }

      return new ShellMesher.WaterColumns(surface, relaxFloors(surface, floor));
   }

   private static boolean narrowSurfaces(int[] surface) {
      int[] seen = (int[])surface.clone();
      boolean any = false;

      for (int z = 0; z < 16; z++) {
         for (int x = 0; x < 16; x++) {
            int c = z << 4 | x;
            int here = seen[c];
            if (here != Integer.MIN_VALUE) {
               boolean broad = (x == 0 || seen[c - 1] == here)
                  && (x == 15 || seen[c + 1] == here)
                  && (z == 0 || seen[c - 16] == here)
                  && (z == 15 || seen[c + 16] == here);
               if (broad) {
                  any = true;
               } else {
                  surface[c] = Integer.MIN_VALUE;
               }
            }
         }
      }

      return any;
   }

   private static int[] relaxFloors(int[] surface, int[] floor) {
      int[] out = new int[256];

      for (int z = 0; z < 16; z++) {
         for (int x = 0; x < 16; x++) {
            int c = z << 4 | x;
            int lowest = floor[c];
            if (surface[c] != Integer.MIN_VALUE && lowest != Integer.MIN_VALUE) {
               if (x > 0) {
                  lowest = borrowFloor(surface, floor, c, c - 1, lowest);
               }

               if (x < 15) {
                  lowest = borrowFloor(surface, floor, c, c + 1, lowest);
               }

               if (z > 0) {
                  lowest = borrowFloor(surface, floor, c, c - 16, lowest);
               }

               if (z < 15) {
                  lowest = borrowFloor(surface, floor, c, c + 16, lowest);
               }

               out[c] = lowest;
            } else {
               out[c] = lowest;
            }
         }
      }

      return out;
   }

   private static int borrowFloor(int[] surface, int[] floor, int c, int n, int lowest) {
      return lowest != Integer.MIN_VALUE && surface[n] == surface[c] && floor[n] != Integer.MIN_VALUE ? Math.min(lowest, floor[n]) : lowest;
   }

   private static boolean openFluid(boolean fluid, int mask) {
      return fluid && (mask & 60) != 0;
   }

   private static int submergedLight(int light, int surfaceY, int floorY, int y) {
      if (surfaceY != Integer.MIN_VALUE && floorY != Integer.MIN_VALUE && y <= surfaceY) {
         int depth = surfaceY - Math.max(y, floorY);
         if (depth <= 0) {
            return light;
         }

         int sky = rawLevel(15 - depth);
         return Math.min(sky, light >>> 8 & 0xFF) << 8 | light & 0xFF;
      } else {
         return light;
      }
   }

   private static boolean[] upperHalves(ShellCodec.Shell shell, SpriteUvResolver.ResolvedPalette palette) {
      int[] upperRow = palette.upperRow;
      if (upperRow == null) {
         return null;
      }

      int paletteSize = palette.size();
      IntOpenHashSet placed = new IntOpenHashSet(64);

      for (int i = 0; i < shell.cellCount; i++) {
         int cell = shell.cells[i];
         int pi = ShellCodec.cellPaletteIndex(cell);
         if (pi < paletteSize && upperRow[pi] != pi) {
            placed.add(halfKey(cell, pi));
         }
      }

      if (placed.isEmpty()) {
         return null;
      }

      boolean[] upper = new boolean[shell.cellCount];
      boolean any = false;

      for (int i = 0; i < shell.cellCount; i++) {
         int cell = shell.cells[i];
         int pi = ShellCodec.cellPaletteIndex(cell);
         if (pi < paletteSize && upperRow[pi] != pi && ShellCodec.cellYRel(cell) != 0 && placed.contains(halfKey(cell, pi) - 1)) {
            upper[i] = true;
            any = true;
         }
      }

      return any ? upper : null;
   }

   private static int halfKey(int cell, int paletteIndex) {
      return paletteIndex << 16 | ShellCodec.cellZ(cell) << 12 | ShellCodec.cellX(cell) << 8 | ShellCodec.cellYRel(cell);
   }

   private static boolean[] uniformTints(ShellCodec.Shell shell, int paletteSize) {
      boolean[] uniform = new boolean[paletteSize];
      int side = shell.tintGridSide;
      int[] tint = shell.paletteTint;
      if (tint != null && side > 1) {
         int nodes = side * side;

         for (int e = 0; e < paletteSize; e++) {
            int base = e * nodes;
            if (base + nodes > tint.length) {
               uniform[e] = true;
            } else {
               boolean same = true;
               int first = tint[base];

               for (int n = 1; n < nodes && same; n++) {
                  same = tint[base + n] == first;
               }

               uniform[e] = same;
            }
         }

         return uniform;
      } else {
         Arrays.fill(uniform, true);
         return uniform;
      }
   }

   private static int cellTint(ShellCodec.Shell shell, int pi, int x, int z, boolean uniform) {
      int side = shell.tintGridSide;
      if (uniform || side <= 1) {
         return shell.tintNode(pi, 0, 0);
      }

      if (side == 16) {
         return shell.tintNode(pi, x, z);
      }

      int spans = side - 1;
      int fx = (2 * x + 1) * spans;
      int fz = (2 * z + 1) * spans;
      int gx = Math.min(fx >> 5, spans - 1);
      int gz = Math.min(fz >> 5, spans - 1);
      int wx = fx - (gx << 5) << 8 >> 5;
      int wz = fz - (gz << 5) << 8 >> 5;
      int c00 = shell.tintNode(pi, gx, gz);
      int c10 = shell.tintNode(pi, gx + 1, gz);
      int c01 = shell.tintNode(pi, gx, gz + 1);
      int c11 = shell.tintNode(pi, gx + 1, gz + 1);
      int r = bilinear(c00 >>> 16, c10 >>> 16, c01 >>> 16, c11 >>> 16, wx, wz);
      int g = bilinear(c00 >>> 8 & 0xFF, c10 >>> 8 & 0xFF, c01 >>> 8 & 0xFF, c11 >>> 8 & 0xFF, wx, wz);
      int b = bilinear(c00 & 0xFF, c10 & 0xFF, c01 & 0xFF, c11 & 0xFF, wx, wz);
      return r << 16 | g << 8 | b;
   }

   private static int bilinear(int c00, int c10, int c01, int c11, int wx, int wz) {
      int top = ((c00 & 0xFF) << 8) + ((c10 & 0xFF) - (c00 & 0xFF)) * wx;
      int bottom = ((c01 & 0xFF) << 8) + ((c11 & 0xFF) - (c01 & 0xFF)) * wx;
      return top + ((bottom - top) * wz >> 8) >> 8;
   }

   private static Int2FloatOpenHashMap fluidField(
      ShellCodec.Shell shell, SpriteUvResolver.ResolvedPalette palette, boolean[] upperHalf, int[] upperRow, ShellMesher.Apron apron
   ) {
      int paletteSize = palette.size();
      boolean any = false;

      for (int e = 0; e < paletteSize && !any; e++) {
         any = palette.kind[e] == 2;
      }

      if (!any) {
         return null;
      }

      Int2FloatOpenHashMap field = new Int2FloatOpenHashMap(Math.max(16, shell.cellCount / 2));
      field.defaultReturnValue(0.0F);

      for (int i = 0; i < shell.cellCount; i++) {
         int cell = shell.cells[i];
         int pi = ShellCodec.cellPaletteIndex(cell);
         if (pi < paletteSize) {
            int pe = upperHalf != null && upperHalf[i] ? upperRow[pi] : pi;
            int key = apronKey(ShellCodec.cellX(cell), ShellCodec.cellYRel(cell), ShellCodec.cellZ(cell));
            if (palette.kind[pe] == 2) {
               field.put(key | familyOf(palette, pe) << 19, palette.fluidHeight[pe]);
            } else if (solidCube(palette, pe)) {
               field.put(key, -1.0F);
            }
         }
      }

      if (apron != null) {
         for (int d = 0; d < 9; d++) {
            ShellCodec.Shell nb = apron.shells[d];
            if (d != 4 && nb != null) {
               SpriteUvResolver.ResolvedPalette np = apron.palettes[d];
               boolean[] nbUpper = apron.upperHalf[d];
               int[] nbUpperRow = np.upperRow;
               int npSize = np.size();
               int[] edge = apron.edgeCells[d];
               int dyRel = nb.minY - shell.minY;
               int dx = d % 3 - 1 << 4;
               int dz = d / 3 - 1 << 4;

               for (int k = 0; k < edge.length; k++) {
                  int idx = edge[k];
                  int cell = nb.cells[idx];
                  int ourY = ShellCodec.cellYRel(cell) + dyRel;
                  if (ourY >= -1 && ourY <= 257) {
                     int pi = ShellCodec.cellPaletteIndex(cell);
                     if (pi < npSize) {
                        int pe = nbUpper != null && nbUpper[idx] ? nbUpperRow[pi] : pi;
                        int key = apronKey(ShellCodec.cellX(cell) + dx, ourY, ShellCodec.cellZ(cell) + dz);
                        if (np.kind[pe] == 2) {
                           field.put(key | familyOf(np, pe) << 19, np.fluidHeight[pe]);
                        } else if (solidCube(np, pe)) {
                           field.put(key, -1.0F);
                        }
                     }
                  }
               }
            }
         }
      }

      return field;
   }

   private static int familyOf(SpriteUvResolver.ResolvedPalette palette, int row) {
      SpriteUvResolver.FluidLook look = palette.fluidLook[row];
      int family = look == null ? 1 : look.family();
      return family > 0 && family <= 3 ? family : 1;
   }

   private static float fluidSample(Int2FloatOpenHashMap field, int[] apronLo, int family, int x, int yRel, int z) {
      if (x >= -1 && x <= 16 && z >= -1 && z <= 16 && yRel >= 0 && yRel <= 255) {
         int d = (z < 0 ? 0 : (z > 15 ? 2 : 1)) * 3 + (x < 0 ? 0 : (x > 15 ? 2 : 1));
         boolean inApron = d != 4;
         if (!inApron || apronLo != null && apronLo[d] != Integer.MAX_VALUE && yRel >= apronLo[d]) {
            int key = apronKey(x, yRel, z);
            float h = field.get(key | family << 19);
            if (!(h > 0.0F)) {
               float stored = field.get(key);
               if (stored < 0.0F) {
                  return -1.0F;
               } else {
                  return inApron && field.get(key + 1024 | family << 19) > 0.0F ? 1.0F : stored;
               }
            } else {
               return field.get(key + 1024 | family << 19) > 0.0F ? 1.0F : h;
            }
         } else {
            return -1.0F;
         }
      } else {
         return -1.0F;
      }
   }

   private static float fluidCorner(Int2FloatOpenHashMap field, int[] apronLo, int family, int x, int yRel, int z, int dx, int dz, float own) {
      float hA = fluidSample(field, apronLo, family, x + dx, yRel, z);
      float hB = fluidSample(field, apronLo, family, x, yRel, z + dz);
      if (!(hA >= 1.0F) && !(hB >= 1.0F)) {
         float sum = 0.0F;
         float weight = 0.0F;
         if (hA > 0.0F || hB > 0.0F) {
            float hD = fluidSample(field, apronLo, family, x + dx, yRel, z + dz);
            if (hD >= 1.0F) {
               return 1.0F;
            }

            if (hD >= 0.8F) {
               sum += hD * 10.0F;
               weight += 10.0F;
            } else if (hD >= 0.0F) {
               sum += hD;
               weight++;
            }
         }

         if (own >= 0.8F) {
            sum += own * 10.0F;
            weight += 10.0F;
         } else if (own >= 0.0F) {
            sum += own;
            weight++;
         }

         if (hA >= 0.8F) {
            sum += hA * 10.0F;
            weight += 10.0F;
         } else if (hA >= 0.0F) {
            sum += hA;
            weight++;
         }

         if (hB >= 0.8F) {
            sum += hB * 10.0F;
            weight += 10.0F;
         } else if (hB >= 0.0F) {
            sum += hB;
            weight++;
         }

         return weight <= 0.0F ? own : sum / weight;
      } else {
         return 1.0F;
      }
   }

   private static long fluidFlow(Int2FloatOpenHashMap field, int[] apronLo, int family, int x, int yRel, int z, float own) {
      double dx = 0.0;
      double dz = 0.0;

      for (int dir = 0; dir < 4; dir++) {
         int sx = dir == 0 ? -1 : (dir == 1 ? 1 : 0);
         int sz = dir == 2 ? -1 : (dir == 3 ? 1 : 0);
         int nx = x + sx;
         int nz = z + sz;
         int d = (nz < 0 ? 0 : (nz > 15 ? 2 : 1)) * 3 + (nx < 0 ? 0 : (nx > 15 ? 2 : 1));
         boolean inApron = d != 4;
         if (!inApron || apronLo != null && apronLo[d] != Integer.MAX_VALUE && yRel >= apronLo[d]) {
            int key = apronKey(nx, yRel, nz);
            float h = field.get(key | family << 19);
            float delta = 0.0F;
            if (h > 0.0F) {
               delta = own - h;
            } else {
               if (inApron && field.get(key + 1024 | family << 19) > 0.0F) {
                  continue;
               }

               if (!foreignFluidAt(field, key, family) && field.get(key) >= 0.0F && yRel > 0) {
                  float below = field.get(key - 1024 | family << 19);
                  if (below > 0.0F) {
                     delta = own - (below - 0.8888889F);
                  }
               }
            }

            if (delta != 0.0F) {
               dx += (double)sx * delta;
               dz += (double)sz * delta;
            }
         }
      }

      if (dx == 0.0 && dz == 0.0) {
         return 0L;
      }

      double theta = Math.atan2(dz, dx) - (Math.PI / 2);
      float c = (float)(Math.cos(theta) * 0.25);
      float s = (float)(Math.sin(theta) * 0.25);
      return (long)Float.floatToRawIntBits(c) << 32 | Float.floatToRawIntBits(s) & 4294967295L;
   }

   private static boolean foreignFluidAt(Int2FloatOpenHashMap field, int key, int family) {
      for (int f = 1; f <= 3; f++) {
         if (f != family && field.get(key | f << 19) > 0.0F) {
            return true;
         }
      }

      return false;
   }

   public static long positionSeed(int x, int y, int z) {
      long l = x * 3129871 ^ z * 116129781L ^ y;
      l = l * l * 42317861L + l * 11L;
      return l >> 16;
   }

   private static long offsetXZ(long seed, float maxH) {
      double rawX = ((float)(seed & 15L) / 15.0F - 0.5) * 0.5;
      double rawZ = ((float)(seed >>> 8 & 15L) / 15.0F - 0.5) * 0.5;
      float dx = (float)Math.max(-maxH, Math.min(maxH, rawX));
      float dz = (float)Math.max(-maxH, Math.min(maxH, rawZ));
      return (long)Float.floatToRawIntBits(dx) << 32 | Float.floatToRawIntBits(dz) & 4294967295L;
   }

   private static float offsetY(long seed, float maxV) {
      return maxV == 0.0F ? 0.0F : (float)(((float)(seed >>> 4 & 15L) / 15.0F - 1.0) * maxV);
   }

   private static int shiftKey(int row, int quadIndex, boolean translucent) {
      return row << 9 | (quadIndex & 0xFF) << 1 | (translucent ? 1 : 0);
   }

   public static ShellMesher.Result mesh(ShellCodec.Shell shell, SpriteUvResolver.ResolvedPalette palette) {
      return mesh(shell, palette, null);
   }

   public static ShellMesher.Result mesh(ShellCodec.Shell shell, SpriteUvResolver.ResolvedPalette palette, ShellMesher.NeighborColumn[] neighbors) {
      Int2ObjectAVLTreeMap<ShellMesher.Section> bySection = new Int2ObjectAVLTreeMap();
      int skipped = 0;
      int fluidQuads = 0;
      int paletteSize = palette.size();
      int[] storedTint = shell.paletteTint;
      ShellMesher.Style style = ShellMesher.Style.current(shell, palette);
      boolean[] uniformTint = uniformTints(shell, paletteSize);
      ShellMesher.WaterColumns water = style.waterDepth() ? waterColumns(shell, palette) : null;
      boolean[] upperHalf = upperHalves(shell, palette);
      int[] upperRow = palette.upperRow;
      ShellMesher.Apron apron = ShellMesher.Apron.of(shell, neighbors);
      int[] apronLo = apron == null ? null : apron.loYRel;
      ShellMesher.Occluders occ = !(style.contactShade() > 0.0F) && !(style.ambient() > 0.0F)
         ? null
         : occluders(shell, palette, upperHalf, upperRow, paletteSize, apron);
      boolean offsets = palette.anyOffset && shell.hasOrigin();
      boolean variants = style.variants() && palette.anyVariants && shell.hasOrigin();
      boolean positioned = offsets || variants;
      int originX = positioned ? shell.chunkX << 4 : 0;
      int originZ = positioned ? shell.chunkZ << 4 : 0;
      Int2FloatOpenHashMap field = fluidField(shell, palette, upperHalf, upperRow, apron);
      Int2IntOpenHashMap faceLight = style.realLight() ? airLight(shell, apron) : null;
      IntOpenHashSet glassy = field == null ? null : glassyCells(shell, palette, upperHalf, upperRow, apron);

      for (int i = 0; i < shell.cellCount; i++) {
         int cell = shell.cells[i];
         int pi = ShellCodec.cellPaletteIndex(cell);
         if (pi < paletteSize && palette.kind[pi] != 0) {
            int pe = upperHalf != null && upperHalf[i] ? upperRow[pi] : pi;
            int mask = ShellCodec.cellFaceMask(cell);
            if (mask != 0) {
               int x = ShellCodec.cellX(cell);
               int z = ShellCodec.cellZ(cell);
               int y = shell.minY + ShellCodec.cellYRel(cell);
               int sy = y >> 4;
               int ly = y & 15;
               ShellMesher.Section section = (ShellMesher.Section)bySection.get(sy);
               if (section == null) {
                  section = new ShellMesher.Section();
                  section.yBase = (sy << 4) - shell.minY;
                  bySection.put(sy, section);
               }

               int tint = storedTint == null ? palette.fallbackTint[pe] : cellTint(shell, pi, x, z, uniformTint[pi]);
               int light = style.lightFor(shell, palette, pe, i);
               boolean fluid = palette.kind[pe] == 2;
               if (water != null && !openFluid(fluid, mask)) {
                  int column = z << 4 | x;
                  light = submergedLight(light, water.surface()[column], water.floor()[column], y);
               }

               boolean surface = fluid && (mask & 2) != 0;
               float[] corners = null;
               long flow = 0L;
               if (surface && field != null) {
                  float own = palette.fluidHeight[pe];
                  int yRel = ShellCodec.cellYRel(cell);
                  int family = familyOf(palette, pe);
                  float c00 = fluidCorner(field, apronLo, family, x, yRel, z, -1, -1, own);
                  float c10 = fluidCorner(field, apronLo, family, x, yRel, z, 1, -1, own);
                  float c01 = fluidCorner(field, apronLo, family, x, yRel, z, -1, 1, own);
                  float c11 = fluidCorner(field, apronLo, family, x, yRel, z, 1, 1, own);
                  if (Math.abs(c00 - own) > 1.0E-4F || Math.abs(c10 - own) > 1.0E-4F || Math.abs(c01 - own) > 1.0E-4F || Math.abs(c11 - own) > 1.0E-4F) {
                     corners = new float[]{c00, c10, c01, c11};
                     flow = fluidFlow(field, apronLo, family, x, yRel, z, own);
                  }
               }

               float offX = 0.0F;
               float offY = 0.0F;
               float offZ = 0.0F;
               if (offsets && (palette.offsetH[pe] != 0.0F || palette.offsetV[pe] != 0.0F)) {
                  long seed = positionSeed(originX + x, 0, originZ + z);
                  long xz = offsetXZ(seed, palette.offsetH[pe]);
                  offX = Float.intBitsToFloat((int)(xz >>> 32));
                  offZ = Float.intBitsToFloat((int)xz);
                  offY = offsetY(seed, palette.offsetV[pe]);
               }

               SpriteUvResolver.Quads variantTable = null;
               boolean variantUniform = true;
               if (variants && palette.variantQuads[pe] != null) {
                  SpriteUvResolver.Quads[] table = palette.variantQuads[pe];
                  variantTable = table[variantDraw(positionSeed(originX + x, y, originZ + z), table.length)];
                  variantUniform = palette.variantUniform[pe];
               }

               fluidQuads += emitQuads(
                  section,
                  mask,
                  x,
                  ly,
                  z,
                  palette,
                  pe,
                  tint,
                  light,
                  fluid,
                  surface,
                  style,
                  occ,
                  ShellCodec.cellYRel(cell),
                  offX,
                  offY,
                  offZ,
                  corners,
                  flow,
                  variantTable,
                  variantUniform,
                  faceLight,
                  glassy
               );
            }
         } else {
            skipped++;
         }
      }

      if (bySection.isEmpty()) {
         return new ShellMesher.Result(new ShellMesher.SectionMesh[0], skipped, fluidQuads);
      }

      List<ShellMesher.SectionMesh> out = new ArrayList<>(bySection.size());
      ObjectBidirectionalIterator var50 = bySection.int2ObjectEntrySet().iterator();

      while (var50.hasNext()) {
         Entry<ShellMesher.Section> entry = (Entry<ShellMesher.Section>)var50.next();
         ShellMesher.Section section = (ShellMesher.Section)entry.getValue();
         List<TerrainQuad>[] buckets = section.buckets;
         int total = 0;

         for (List<TerrainQuad> bucket : buckets) {
            total += bucket == null ? 0 : bucket.size();
         }

         if (section.boxBuckets != null) {
            ObjectIterator var56 = section.boxBuckets.values().iterator();

            while (var56.hasNext()) {
               List<TerrainQuad> bucket = (List<TerrainQuad>)var56.next();
               total += bucket.size();
            }
         }

         if (section.surfaceBuckets != null) {
            ObjectIterator var57 = section.surfaceBuckets.values().iterator();

            while (var57.hasNext()) {
               List<TerrainQuad> bucket = (List<TerrainQuad>)var57.next();
               total += bucket.size();
            }
         }

         List<TerrainQuad> quads = new ArrayList<>(total);
         addMerged(quads, buckets[0], false, style.contactShade(), occ, section.yBase);
         addMerged(quads, buckets[1], true, 0.0F, null, 0);
         if (section.surfaceBuckets != null) {
            ObjectIterator var62 = section.surfaceBuckets.int2ObjectEntrySet().iterator();

            while (var62.hasNext()) {
               Entry<List<TerrainQuad>> surf = (Entry<List<TerrainQuad>>)var62.next();
               int key = surf.getIntKey();
               addMergedSurface(quads, (List<TerrainQuad>)surf.getValue(), fluidHeightOfRow(palette, key >>> 1), (key & 1) != 0);
            }
         }

         if (section.boxBuckets != null) {
            ObjectIterator var63 = section.boxBuckets.int2ObjectEntrySet().iterator();

            while (var63.hasNext()) {
               Entry<List<TerrainQuad>> box = (Entry<List<TerrainQuad>>)var63.next();
               int key = box.getIntKey();
               addMergedShifted(quads, (List<TerrainQuad>)box.getValue(), palette, key >>> 9, key >>> 1 & 0xFF, (key & 1) != 0);
            }
         }

         if (!quads.isEmpty()) {
            out.add(new ShellMesher.SectionMesh(entry.getIntKey(), SectionMeshEncoder.encode(orderTranslucent(quads))));
         }
      }

      return new ShellMesher.Result(out.toArray(new ShellMesher.SectionMesh[0]), skipped, fluidQuads);
   }

   private static List<TerrainQuad> orderTranslucent(List<TerrainQuad> quads) {
      int trans = 0;

      for (TerrainQuad q : quads) {
         if (q.translucent()) {
            trans++;
         }
      }

      if (trans < 2) {
         return quads;
      }

      List<TerrainQuad> ordered = new ArrayList<>(quads.size());
      List<TerrainQuad> solid = new ArrayList<>(quads.size() - trans);

      for (TerrainQuad q : quads) {
         if (q.translucent()) {
            ordered.add(q);
         } else {
            solid.add(q);
         }
      }

      ordered.sort((a, b) -> Float.compare(lowestY(a), lowestY(b)));
      ordered.addAll(solid);
      return ordered;
   }

   private static float lowestY(TerrainQuad q) {
      return min4(q.v0().y(), q.v1().y(), q.v2().y(), q.v3().y());
   }

   private static void addMerged(List<TerrainQuad> out, List<TerrainQuad> bucket, boolean translucent, float contact, ShellMesher.Occluders occ, int yBase) {
      if (bucket != null && !bucket.isEmpty()) {
         List<TerrainQuad> merged = GreedyMesher.mergeFar(bucket);
         boolean shade = contact > 0.0F && occ != null;

         for (TerrainQuad q : merged) {
            TerrainQuad r = shade ? contactShade(q, contact, occ, yBase) : q;
            out.add(translucent ? asTranslucent(r) : r);
         }
      }
   }

   private static void addMergedSurface(List<TerrainQuad> out, List<TerrainQuad> bucket, float height, boolean translucent) {
      if (!bucket.isEmpty()) {
         float drop = 1.0F - height;

         for (TerrainQuad q : GreedyMesher.mergeFar(bucket)) {
            TerrainQuad r = drop <= 0.0F ? q : lowerFluidSurface(q, drop);
            out.add(translucent ? asTranslucent(r) : r);
         }
      }
   }

   private static float fluidHeightOfRow(SpriteUvResolver.ResolvedPalette p, int row) {
      float[] heights = p.fluidHeight;
      return row >= 0 && row < heights.length && heights[row] > 0.0F ? heights[row] : 0.8888889F;
   }

   private static TerrainQuad contactShade(TerrainQuad q, float contact, ShellMesher.Occluders occ, int yBase) {
      float x0 = min4(q.v0().x(), q.v1().x(), q.v2().x(), q.v3().x());
      float x1 = max4(q.v0().x(), q.v1().x(), q.v2().x(), q.v3().x());
      float y0 = min4(q.v0().y(), q.v1().y(), q.v2().y(), q.v3().y());
      float y1 = max4(q.v0().y(), q.v1().y(), q.v2().y(), q.v3().y());
      float z0 = min4(q.v0().z(), q.v1().z(), q.v2().z(), q.v3().z());
      float z1 = max4(q.v0().z(), q.v1().z(), q.v2().z(), q.v3().z());
      if (integral(x0) && integral(x1) && integral(y0) && integral(y1) && integral(z0) && integral(z1)) {
         int ix0 = Math.round(x0);
         int ix1 = Math.round(x1);
         int iy0 = Math.round(y0);
         int iy1 = Math.round(y1);
         int iz0 = Math.round(z0);
         int iz1 = Math.round(z1);
         int fx = 0;
         int fy = 0;
         int fz = 0;
         int ax = 0;
         int ay = 0;
         int az = 0;
         int bx = 0;
         int by = 0;
         int bz = 0;
         int a0;
         int a1;
         int b0;
         int b1;
         switch (q.facing()) {
            case POS_Y:
            case NEG_Y:
               fy = q.facing() == QuadFacing.POS_Y ? iy0 : iy0 - 1;
               ax = 1;
               bz = 1;
               a0 = ix0;
               a1 = ix1;
               b0 = iz0;
               b1 = iz1;
               break;
            case POS_X:
            case NEG_X:
               fx = q.facing() == QuadFacing.POS_X ? ix0 : ix0 - 1;
               ay = 1;
               bz = 1;
               a0 = iy0;
               a1 = iy1;
               b0 = iz0;
               b1 = iz1;
               break;
            case POS_Z:
            case NEG_Z:
               fz = q.facing() == QuadFacing.POS_Z ? iz0 : iz0 - 1;
               ax = 1;
               by = 1;
               a0 = ix0;
               a1 = ix1;
               b0 = iy0;
               b1 = iy1;
               break;
            default:
               return q;
         }

         if (a1 > a0 && b1 > b0) {
            boolean aLow = edgeOccluded(occ, yBase, fx, fy, fz, ax, ay, az, bx, by, bz, a0 - 1, b0, b1);
            boolean aHigh = edgeOccluded(occ, yBase, fx, fy, fz, ax, ay, az, bx, by, bz, a1, b0, b1);
            boolean bLow = edgeOccluded(occ, yBase, fx, fy, fz, bx, by, bz, ax, ay, az, b0 - 1, a0, a1);
            boolean bHigh = edgeOccluded(occ, yBase, fx, fy, fz, bx, by, bz, ax, ay, az, b1, a0, a1);
            return !aLow && !aHigh && !bLow && !bHigh
               ? q
               : new TerrainQuad(
                  q.facing(),
                  q.translucent(),
                  q.alphaCutoffIndex(),
                  q.mip(),
                  shaded(q.v0(), contact, ax, ay, az, bx, by, bz, a0, a1, b0, b1, aLow, aHigh, bLow, bHigh),
                  shaded(q.v1(), contact, ax, ay, az, bx, by, bz, a0, a1, b0, b1, aLow, aHigh, bLow, bHigh),
                  shaded(q.v2(), contact, ax, ay, az, bx, by, bz, a0, a1, b0, b1, aLow, aHigh, bLow, bHigh),
                  shaded(q.v3(), contact, ax, ay, az, bx, by, bz, a0, a1, b0, b1, aLow, aHigh, bLow, bHigh),
                  q.repeatU(),
                  q.repeatV()
               );
         } else {
            return q;
         }
      } else {
         return q;
      }
   }

   private static boolean edgeOccluded(
      ShellMesher.Occluders occ, int yBase, int fx, int fy, int fz, int ex, int ey, int ez, int wx, int wy, int wz, int edge, int from, int to
   ) {
      for (int w = from; w < to; w++) {
         if (!occ.solid(fx + ex * edge + wx * w, yBase + fy + ey * edge + wy * w, fz + ez * edge + wz * w)) {
            return false;
         }
      }

      return true;
   }

   private static TerrainVertex shaded(
      TerrainVertex v,
      float contact,
      int ax,
      int ay,
      int az,
      int bx,
      int by,
      int bz,
      int a0,
      int a1,
      int b0,
      int b1,
      boolean aLow,
      boolean aHigh,
      boolean bLow,
      boolean bHigh
   ) {
      float a = ax * v.x() + ay * v.y() + az * v.z();
      float b = bx * v.x() + by * v.y() + bz * v.z();
      int touched = 0;
      if (aLow && Math.abs(a - a0) < 0.001F) {
         touched++;
      }

      if (aHigh && Math.abs(a - a1) < 0.001F) {
         touched++;
      }

      if (bLow && Math.abs(b - b0) < 0.001F) {
         touched++;
      }

      if (bHigh && Math.abs(b - b1) < 0.001F) {
         touched++;
      }

      if (touched == 0) {
         return v;
      }

      int colour = v.colorAbgr();
      int alpha = colour >>> 24 & 0xFF;
      int lit = Math.round(alpha * (1.0F - contact * touched * 0.5F));
      return new TerrainVertex(v.x(), v.y(), v.z(), v.u(), v.v(), Math.max(0, Math.min(255, lit)) << 24 | colour & 16777215, v.blockLight(), v.skyLight());
   }

   private static boolean integral(float value) {
      return Math.abs(value - Math.round(value)) < 0.001F;
   }

   private static float min4(float a, float b, float c, float d) {
      return Math.min(Math.min(a, b), Math.min(c, d));
   }

   private static float max4(float a, float b, float c, float d) {
      return Math.max(Math.max(a, b), Math.max(c, d));
   }

   private static void addMergedShifted(
      List<TerrainQuad> out, List<TerrainQuad> bucket, SpriteUvResolver.ResolvedPalette p, int row, int quadIndex, boolean translucent
   ) {
      if (!bucket.isEmpty()) {
         SpriteUvResolver.Quads q = p.quads[row];
         float by = quadIndex < q.count() ? q.shift()[quadIndex] : 0.0F;
         QuadFacing facing = quadIndex < q.count() ? QuadFacing.byIndex(q.facing()[quadIndex]) : QuadFacing.UNASSIGNED;
         float dx = facing != QuadFacing.POS_X && facing != QuadFacing.NEG_X ? 0.0F : by;
         float dy = facing != QuadFacing.POS_Y && facing != QuadFacing.NEG_Y ? 0.0F : by;
         float dz = facing != QuadFacing.POS_Z && facing != QuadFacing.NEG_Z ? 0.0F : by;

         for (TerrainQuad merged : GreedyMesher.mergeFar(bucket)) {
            TerrainQuad r = dx == 0.0F && dy == 0.0F && dz == 0.0F ? merged : shiftBy(merged, dx, dy, dz);
            out.add(translucent ? asTranslucent(r) : r);
         }
      }
   }

   private static TerrainQuad shiftBy(TerrainQuad q, float dx, float dy, float dz) {
      return new TerrainQuad(
         q.facing(),
         q.translucent(),
         q.alphaCutoffIndex(),
         q.mip(),
         moved(q.v0(), dx, dy, dz),
         moved(q.v1(), dx, dy, dz),
         moved(q.v2(), dx, dy, dz),
         moved(q.v3(), dx, dy, dz),
         q.repeatU(),
         q.repeatV()
      );
   }

   private static TerrainVertex moved(TerrainVertex v, float dx, float dy, float dz) {
      return new TerrainVertex(v.x() + dx, v.y() + dy, v.z() + dz, v.u(), v.v(), v.colorAbgr(), v.blockLight(), v.skyLight());
   }

   private static TerrainQuad asTranslucent(TerrainQuad q) {
      return new TerrainQuad(q.facing(), true, q.alphaCutoffIndex(), q.mip(), q.v0(), q.v1(), q.v2(), q.v3(), q.repeatU(), q.repeatV());
   }

   private static TerrainQuad lowerFluidSurface(TerrainQuad q, float drop) {
      QuadFacing facing = q.facing();
      if (facing == QuadFacing.NEG_Y) {
         return q;
      }

      if (facing == QuadFacing.POS_Y) {
         return new TerrainQuad(
            facing,
            q.translucent(),
            q.alphaCutoffIndex(),
            q.mip(),
            lowered(q.v0(), drop),
            lowered(q.v1(), drop),
            lowered(q.v2(), drop),
            lowered(q.v3(), drop),
            q.repeatU(),
            q.repeatV()
         );
      }

      float minY = Float.MAX_VALUE;
      float maxY = -Float.MAX_VALUE;

      for (int i = 0; i < 4; i++) {
         float vy = q.vertex(i).y();
         minY = Math.min(minY, vy);
         maxY = Math.max(maxY, vy);
      }

      if (Math.abs(maxY - minY - 1.0F) > 1.0E-4F) {
         return q;
      }

      float vTop = Float.NaN;
      float vBottom = Float.NaN;

      for (int i = 0; i < 4; i++) {
         TerrainVertex vx = q.vertex(i);
         if (Math.abs(vx.y() - maxY) <= 1.0E-4F) {
            vTop = vx.v();
         } else {
            vBottom = vx.v();
         }
      }

      float height = 1.0F - drop;
      float croppedV = !Float.isNaN(vTop) && !Float.isNaN(vBottom) ? vBottom + height * (vTop - vBottom) : Float.NaN;
      return new TerrainQuad(
         facing,
         q.translucent(),
         q.alphaCutoffIndex(),
         q.mip(),
         loweredIfTop(q.v0(), maxY, drop, croppedV),
         loweredIfTop(q.v1(), maxY, drop, croppedV),
         loweredIfTop(q.v2(), maxY, drop, croppedV),
         loweredIfTop(q.v3(), maxY, drop, croppedV),
         q.repeatU(),
         q.repeatV()
      );
   }

   private static TerrainVertex lowered(TerrainVertex v, float drop) {
      return new TerrainVertex(v.x(), v.y() - drop, v.z(), v.u(), v.v(), v.colorAbgr(), v.blockLight(), v.skyLight());
   }

   private static TerrainVertex loweredIfTop(TerrainVertex v, float topY, float drop, float croppedV) {
      return Math.abs(v.y() - topY) > 1.0E-4F
         ? v
         : new TerrainVertex(v.x(), v.y() - drop, v.z(), v.u(), Float.isNaN(croppedV) ? v.v() : croppedV, v.colorAbgr(), v.blockLight(), v.skyLight());
   }

   private static int emitQuads(
      ShellMesher.Section section,
      int mask,
      int x,
      int y,
      int z,
      SpriteUvResolver.ResolvedPalette p,
      int row,
      int tint,
      int light,
      boolean fluid,
      boolean surface,
      ShellMesher.Style style,
      ShellMesher.Occluders occ,
      int yRel,
      float offX,
      float offY,
      float offZ,
      float[] corners,
      long flow,
      SpriteUvResolver.Quads variant,
      boolean variantUniform,
      Int2IntOpenHashMap faceLight,
      IntOpenHashSet glassy
   ) {
      boolean moved = offX != 0.0F || offY != 0.0F || offZ != 0.0F;
      SpriteUvResolver.Quads q = variant != null ? variant : p.quads[row];
      if (q != null && q.count() != 0) {
         float[] pos = q.pos();
         float[] uv = q.uv();
         int emitted = 0;

         for (int i = 0; i < q.count(); i++) {
            byte cull = q.cull()[i];
            if (cull == -1 || (mask & 1 << cull) != 0) {
               QuadFacing facing = QuadFacing.byIndex(q.facing()[i]);
               boolean unit = q.unit()[i];
               float shift = q.shift()[i];
               int pb = i * 12;
               int ub = i * 8;
               boolean shifted = unit && shift != 0.0F && i < 256 && !moved && (variant == null || variantUniform);
               boolean trans = q.translucent()[i];
               boolean lower = surface && facing != QuadFacing.NEG_Y && corners == null;
               List<TerrainQuad> out;
               if (lower) {
                  out = section.surfaceBucket(row << 1 | (trans ? 1 : 0));
               } else if (shifted) {
                  out = section.boxBucket(shiftKey(row, i, trans));
               } else {
                  out = section.bucket(trans ? 1 : 0);
               }

               int cutoff = style.cutoffFor(q.cutoff()[i], !p.fullCube[row] || !unit || q.overlay()[i]);
               int rgb = q.tinted()[i] ? tint : 16777215;
               int shadeAlpha = q.shaded()[i] ? shadeFor(facing) : 255;
               int c = color(rgb, shadeAlpha);
               boolean litFace = !fluid && !moved && facing != QuadFacing.UNASSIGNED;
               boolean smooth = litFace && !trans && p.emission[row] == 0;
               int ox = x;
               int oy = yRel;
               int oz = z;
               if (smooth && (faceAtCellBoundary(facing, pos, pb) || p.fullCube[row])) {
                  ox += stepX(facing);
                  oy += stepY(facing);
                  oz += stepZ(facing);
               }

               int ambient = smooth && occ != null && style.ambient() > 0.0F ? ambientCorners(occ, facing, ox, oy, oz) : 0;
               int faceLightValue = light;
               long cornerLight = 0L;
               if (faceLight != null && litFace) {
                  int donor = -1;
                  int nx = x + stepX(facing);
                  int ny = yRel + stepY(facing);
                  int nz = z + stepZ(facing);
                  if (nx >= -1 && nx <= 16 && nz >= -1 && nz <= 16 && ny >= -1 && ny <= 256) {
                     donor = faceLight.get(apronKey(nx, ny, nz));
                  }

                  if (donor >= 0) {
                     faceLightValue = style.lightFromByte(donor, p, row);
                  }

                  if (smooth && style.smoothLight()) {
                     cornerLight = cornerLights(faceLight, occ, style, facing, ox, oy, oz, donor >= 0 ? style.lightRaw(donor) : light, ambient);
                  }
               }

               int lv0 = faceLightValue;
               int lv1 = faceLightValue;
               int lv2 = faceLightValue;
               int lv3 = faceLightValue;
               if (cornerLight != 0L) {
                  lv0 = style.withGlow(vertexLight(cornerLight, facing, pos, pb), p, row);
                  lv1 = style.withGlow(vertexLight(cornerLight, facing, pos, pb + 3), p, row);
                  lv2 = style.withGlow(vertexLight(cornerLight, facing, pos, pb + 6), p, row);
                  lv3 = style.withGlow(vertexLight(cornerLight, facing, pos, pb + 9), p, row);
               }

               float dx = offX;
               float dy = offY;
               float dz = offZ;
               if (shifted) {
                  switch (facing) {
                     case POS_Y:
                     case NEG_Y:
                        dy = -shift;
                        break;
                     case POS_X:
                     case NEG_X:
                        dx = -shift;
                        break;
                     case POS_Z:
                     case NEG_Z:
                        dz = -shift;
                  }
               }

               float[] uvq = uv;
               int ubq = ub;
               if (fluid && surface && corners != null) {
                  float[] over = fluidUv(p, row, facing, pos, pb, uv, ub, corners, flow);
                  if (over != null) {
                     uvq = over;
                     ubq = 0;
                  }
               }

               if (fluid && glassy != null && facing != QuadFacing.POS_Y && facing != QuadFacing.NEG_Y && facing != QuadFacing.UNASSIGNED) {
                  SpriteUvResolver.FluidLook look = p.fluidLook[row];
                  if (look != null && look.hasOverlay() && glassy.contains(apronKey(x + stepX(facing), yRel + stepY(facing), z + stepZ(facing)))) {
                     float[] over = new float[8];

                     for (int k = 0; k < 4; k++) {
                        over[k * 2] = look.overlayU(uvq[ubq + k * 2]);
                        over[k * 2 + 1] = look.overlayV(uvq[ubq + k * 2 + 1]);
                     }

                     uvq = over;
                     ubq = 0;
                  }
               }

               out.add(
                  quad(
                     facing,
                     cutoff,
                     v(
                        x + pos[pb] + dx,
                        y + rampY(corners, pos, pb) + dy,
                        z + pos[pb + 2] + dz,
                        uvq[ubq],
                        uvq[ubq + 1],
                        cornerColor(c, ambient, facing, rgb, shadeAlpha, style.ambient(), pos, pb),
                        lv0
                     ),
                     v(
                        x + pos[pb + 3] + dx,
                        y + rampY(corners, pos, pb + 3) + dy,
                        z + pos[pb + 5] + dz,
                        uvq[ubq + 2],
                        uvq[ubq + 3],
                        cornerColor(c, ambient, facing, rgb, shadeAlpha, style.ambient(), pos, pb + 3),
                        lv1
                     ),
                     v(
                        x + pos[pb + 6] + dx,
                        y + rampY(corners, pos, pb + 6) + dy,
                        z + pos[pb + 8] + dz,
                        uvq[ubq + 4],
                        uvq[ubq + 5],
                        cornerColor(c, ambient, facing, rgb, shadeAlpha, style.ambient(), pos, pb + 6),
                        lv2
                     ),
                     v(
                        x + pos[pb + 9] + dx,
                        y + rampY(corners, pos, pb + 9) + dy,
                        z + pos[pb + 11] + dz,
                        uvq[ubq + 6],
                        uvq[ubq + 7],
                        cornerColor(c, ambient, facing, rgb, shadeAlpha, style.ambient(), pos, pb + 9),
                        lv3
                     )
                  )
               );
               if (fluid) {
                  emitted++;
               }
            }
         }

         return emitted;
      } else {
         return 0;
      }
   }

   private static int cornerColor(int cellColor, int ambient, QuadFacing facing, int rgb, int shadeAlpha, float strength, float[] pos, int vb) {
      if (ambient == 0) {
         return cellColor;
      }

      float fa = inPlaneA(facing, pos, vb);
      float fb = inPlaneB(facing, pos, vb);
      float level = (ambient & 3) * (1.0F - fa) * (1.0F - fb)
         + (ambient >>> 2 & 3) * (1.0F - fa) * fb
         + (ambient >>> 4 & 3) * fa * (1.0F - fb)
         + (ambient >>> 6 & 3) * fa * fb;
      return level <= 0.0F ? cellColor : color(ambientRgb(rgb, level, strength), shadeAlpha);
   }

   private static int stepX(QuadFacing facing) {
      return facing == QuadFacing.POS_X ? 1 : (facing == QuadFacing.NEG_X ? -1 : 0);
   }

   private static int stepY(QuadFacing facing) {
      return facing == QuadFacing.POS_Y ? 1 : (facing == QuadFacing.NEG_Y ? -1 : 0);
   }

   private static int stepZ(QuadFacing facing) {
      return facing == QuadFacing.POS_Z ? 1 : (facing == QuadFacing.NEG_Z ? -1 : 0);
   }

   private static int shadeFor(QuadFacing facing) {
      return switch (facing) {
         case POS_Y -> 255;
         case NEG_Y -> 128;
         case POS_X, NEG_X -> 153;
         case POS_Z, NEG_Z -> 204;
         default -> 255;
      };
   }

   private static float rampY(float[] corners, float[] pos, int vb) {
      float py = pos[vb + 1];
      return corners != null && !(py < 0.9999F) ? corners[(pos[vb + 2] >= 0.5F ? 2 : 0) + (pos[vb] >= 0.5F ? 1 : 0)] : py;
   }

   private static float[] fluidUv(
      SpriteUvResolver.ResolvedPalette p, int row, QuadFacing facing, float[] pos, int pb, float[] uv, int ub, float[] corners, long flow
   ) {
      if (facing == QuadFacing.POS_Y) {
         if (flow == 0L) {
            return null;
         }

         SpriteUvResolver.FluidLook look = p.fluidLook[row];
         if (look == null) {
            return null;
         }

         float c = Float.intBitsToFloat((int)(flow >>> 32));
         float s = Float.intBitsToFloat((int)flow);
         float[] over = new float[8];

         for (int k = 0; k < 4; k++) {
            boolean xHigh = pos[pb + k * 3] >= 0.5F;
            boolean zHigh = pos[pb + k * 3 + 2] >= 0.5F;
            float fu = 0.5F + (xHigh ? c : -c) + (zHigh ? s : -s);
            float fv = 0.5F + (zHigh ? c : -c) - (xHigh ? s : -s);
            over[k * 2] = look.flowU0() + fu * (look.flowU1() - look.flowU0());
            over[k * 2 + 1] = look.flowV0() + fv * (look.flowV1() - look.flowV0());
         }

         return over;
      } else if (facing != QuadFacing.NEG_Y && facing != QuadFacing.UNASSIGNED) {
         float vBottom = Float.NaN;

         for (int k = 0; k < 4; k++) {
            if (pos[pb + k * 3 + 1] < 0.5F) {
               vBottom = uv[ub + k * 2 + 1];
               break;
            }
         }

         if (Float.isNaN(vBottom)) {
            return null;
         }

         float[] over = null;

         for (int k = 0; k < 4; k++) {
            if (!(pos[pb + k * 3 + 1] < 0.9999F)) {
               if (over == null) {
                  over = new float[8];
                  System.arraycopy(uv, ub, over, 0, 8);
               }

               float h = rampY(corners, pos, pb + k * 3);
               over[k * 2 + 1] = vBottom + h * (uv[ub + k * 2 + 1] - vBottom);
            }
         }

         return over;
      } else {
         return null;
      }
   }

   private static TerrainQuad quad(QuadFacing facing, int cutoff, TerrainVertex v0, TerrainVertex v1, TerrainVertex v2, TerrainVertex v3) {
      return new TerrainQuad(facing, false, cutoff, true, v0, v1, v2, v3);
   }

   private static TerrainVertex v(float x, float y, float z, float u, float vv, int colorAbgr, int light) {
      return new TerrainVertex(x, y, z, u, vv, colorAbgr, light & 0xFF, light >>> 8 & 0xFF);
   }

   private static int color(int rgb, int shadeAlpha) {
      int r = rgb >>> 16 & 0xFF;
      int g = rgb >>> 8 & 0xFF;
      int b = rgb & 0xFF;
      return shadeAlpha << 24 | b << 16 | g << 8 | r;
   }

   private static final class Apron {
      static final int CENTER = 4;
      final ShellCodec.Shell[] shells = new ShellCodec.Shell[9];
      final SpriteUvResolver.ResolvedPalette[] palettes = new SpriteUvResolver.ResolvedPalette[9];
      final boolean[][] upperHalf = new boolean[9][];
      final int[][] edgeCells = new int[9][];
      final int[] loYRel = new int[9];

      private Apron() {
         Arrays.fill(this.loYRel, Integer.MAX_VALUE);
      }

      static ShellMesher.Apron of(ShellCodec.Shell shell, ShellMesher.NeighborColumn[] neighbors) {
         if (neighbors == null) {
            return null;
         }

         ShellMesher.Apron apron = null;

         for (int d = 0; d < 9 && d < neighbors.length; d++) {
            ShellMesher.NeighborColumn nc = neighbors[d];
            if (d != 4 && nc != null && nc.shell() != null && nc.palette() != null) {
               ShellCodec.Shell nb = nc.shell();
               int dx = d % 3 - 1 << 4;
               int dz = d / 3 - 1 << 4;
               int count = 0;
               int[] edge = new int[nb.cellCount];

               for (int i = 0; i < nb.cellCount; i++) {
                  int cell = nb.cells[i];
                  int ox = ShellCodec.cellX(cell) + dx;
                  int oz = ShellCodec.cellZ(cell) + dz;
                  if (ox >= -1 && ox <= 16 && oz >= -1 && oz <= 16) {
                     edge[count++] = i;
                  }
               }

               if (count != 0) {
                  if (apron == null) {
                     apron = new ShellMesher.Apron();
                  }

                  apron.shells[d] = nb;
                  apron.palettes[d] = nc.palette();
                  apron.upperHalf[d] = ShellMesher.upperHalves(nb, nc.palette());
                  apron.edgeCells[d] = Arrays.copyOf(edge, count);
                  apron.loYRel[d] = nb.minY - shell.minY;
               }
            }
         }

         return apron;
      }
   }

   public record NeighborColumn(ShellCodec.Shell shell, SpriteUvResolver.ResolvedPalette palette) {
   }

   private static final class Occluders {
      private static final int SIDE = 18;
      private final long[] bits;
      private final int span;

      Occluders(long[] bits, int span) {
         this.bits = bits;
         this.span = span;
      }

      static long[] allocate(int span) {
         return new long[(span + 2) * 18 * 18 + 63 >>> 6];
      }

      static int bitOf(int x, int yRel, int z) {
         return ((yRel + 1) * 18 + z + 1) * 18 + x + 1;
      }

      void set(int x, int yRel, int z) {
         int bit = bitOf(x, yRel, z);
         this.bits[bit >>> 6] = this.bits[bit >>> 6] | 1L << (bit & 63);
      }

      boolean solid(int x, int yRel, int z) {
         if (x >= -1 && x <= 16 && z >= -1 && z <= 16 && yRel >= -1 && yRel <= this.span) {
            int bit = bitOf(x, yRel, z);
            return (this.bits[bit >>> 6] & 1L << (bit & 63)) != 0L;
         } else {
            return false;
         }
      }
   }

   public record Result(ShellMesher.SectionMesh[] sections, int skippedCells, int fluidQuads) {
   }

   private static final class Section {
      final List<TerrainQuad>[] buckets = new List[2];
      Int2ObjectOpenHashMap<List<TerrainQuad>> boxBuckets;
      Int2ObjectOpenHashMap<List<TerrainQuad>> surfaceBuckets;
      int yBase;

      List<TerrainQuad> bucket(int index) {
         List<TerrainQuad> list = this.buckets[index];
         if (list == null) {
            list = new ArrayList<>(64);
            this.buckets[index] = list;
         }

         return list;
      }

      List<TerrainQuad> boxBucket(int key) {
         if (this.boxBuckets == null) {
            this.boxBuckets = new Int2ObjectOpenHashMap(4);
         }

         List<TerrainQuad> list = (List<TerrainQuad>)this.boxBuckets.get(key);
         if (list == null) {
            list = new ArrayList<>(64);
            this.boxBuckets.put(key, list);
         }

         return list;
      }

      List<TerrainQuad> surfaceBucket(int key) {
         if (this.surfaceBuckets == null) {
            this.surfaceBuckets = new Int2ObjectOpenHashMap(2);
         }

         List<TerrainQuad> list = (List<TerrainQuad>)this.surfaceBuckets.get(key);
         if (list == null) {
            list = new ArrayList<>(64);
            this.surfaceBuckets.put(key, list);
         }

         return list;
      }
   }

   public record SectionMesh(int sy, EncodedSectionMesh mesh) {
   }

   private record Style(boolean solidLeaves, boolean glow, boolean realLight, boolean waterDepth, float contactShade, float ambient, boolean variants) {
      static ShellMesher.Style current(ShellCodec.Shell shell, SpriteUvResolver.ResolvedPalette palette) {
         int lighting = FarFieldConfig.layerLighting(FarFieldConfig.Layer.L1);
         boolean real = lighting >= 2 && shell.cellLight != null && shell.cellLight.length >= shell.cellCount && palette != null;
         int strength = FarFieldConfig.layerContactShade(FarFieldConfig.Layer.L1);
         int step = strength <= 0 ? 0 : FarFieldConfig.layerSmoothLight(FarFieldConfig.Layer.L1);
         return new ShellMesher.Style(
            FarFieldConfig.layerFlag(FarFieldConfig.Layer.L1, FarFieldConfig.Control.SOLID_LEAVES),
            lighting >= 1,
            real,
            !real && FarFieldConfig.layerFlag(FarFieldConfig.Layer.L1, FarFieldConfig.Control.WATER_LOOK),
            step == 1 ? 0.5F * strength / 100.0F : 0.0F,
            step == 2 ? strength / 100.0F : 0.0F,
            FarFieldConfig.layerFlag(FarFieldConfig.Layer.L1, FarFieldConfig.Control.BLOCK_VARIANTS)
         );
      }

      int cutoffFor(int resolved, boolean partialBox) {
         if (resolved != 2) {
            return resolved;
         } else {
            return this.solidLeaves && !partialBox ? 0 : resolved;
         }
      }

      int lightFor(ShellCodec.Shell shell, SpriteUvResolver.ResolvedPalette p, int pi, int cellIndex) {
         int light = 63496;
         if (this.realLight) {
            int packed = shell.cellLight[cellIndex] & 255;
            light = ShellMesher.rawLevel(packed >>> 4) << 8 | ShellMesher.rawLevel(packed & 15);
         }

         if (this.glow) {
            int emission = p.emission[pi];
            if (emission > 0) {
               light = light & 0xFF00 | Math.max(light & 0xFF, ShellMesher.rawLevel(emission));
            }
         }

         return light;
      }

      int lightFromByte(int packed, SpriteUvResolver.ResolvedPalette p, int pi) {
         return this.withGlow(this.lightRaw(packed), p, pi);
      }

      int lightRaw(int packed) {
         return ShellMesher.rawLevel(packed >>> 4) << 8 | ShellMesher.rawLevel(packed & 15);
      }

      int withGlow(int light, SpriteUvResolver.ResolvedPalette p, int pi) {
         if (this.glow) {
            int emission = p.emission[pi];
            if (emission > 0) {
               return light & 0xFF00 | Math.max(light & 0xFF, ShellMesher.rawLevel(emission));
            }
         }

         return light;
      }

      boolean smoothLight() {
         return this.ambient > 0.0F;
      }
   }

   private record WaterColumns(int[] surface, int[] floor) {
   }
}
