package nvidiumplus.engine.farfield.store;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.atomic.LongAdder;
import java.util.stream.Stream;

public final class FarFieldStore {
   private static final int REGION_CHUNKS = 32;
   private static final int SLOTS = 1024;
   private static final int HEADER_BYTES = 8192;
   private static final int MAX_OPEN_REGIONS = 4;
   private static final long SIZE_CACHE_MILLIS = 5000L;
   private static final long MAX_REGION_FILE_BYTES = 2147483647L;
   private static final long COMPACT_MIN_DEAD_BYTES = 65536L;
   private final Path farfieldBase;
   private final Path root;
   private final LongAdder errorCounter;
   private final LinkedHashMap<Long, FarFieldStore.Region> openRegions = new LinkedHashMap<>(8, 0.75F, true);
   private Thread owner;
   private boolean closed;
   private long cachedSizeBytes;
   private long sizeCachedAtMillis;

   public FarFieldStore(Path gameDir, String worldKey, String dimensionKey, LongAdder errorCounter) {
      this.errorCounter = errorCounter;
      requireSafeKey(worldKey, "worldKey");
      requireSafeKey(dimensionKey, "dimensionKey");
      this.farfieldBase = gameDir.toAbsolutePath().normalize().resolve("nvidiumplus").resolve("farfield");
      Path candidate = this.farfieldBase.resolve(worldKey).resolve(dimensionKey).normalize();
      if (!candidate.startsWith(this.farfieldBase)) {
         throw new IllegalArgumentException("Far-field store path escapes nvidiumplus/farfield: " + candidate);
      }

      this.root = candidate;
   }

   private static void requireSafeKey(String key, String what) {
      if (key != null && !key.isEmpty()) {
         boolean allDots = true;

         for (int i = 0; i < key.length(); i++) {
            char c = key.charAt(i);
            boolean ok = c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '.' || c == '_' || c == '-';
            if (!ok) {
               throw new IllegalArgumentException(what + " contains unsanitized character: " + key);
            }

            allDots &= c == '.';
         }

         if (allDots) {
            throw new IllegalArgumentException(what + " is all dots: " + key);
         }
      } else {
         throw new IllegalArgumentException(what + " is null or empty");
      }
   }

   public Path rootFolder() {
      return this.root;
   }

   public byte[] read(int chunkX, int chunkZ) throws IOException {
      this.checkOwner();
      if (this.closed) {
         return null;
      }

      FarFieldStore.Region region = this.regionFor(chunkX, chunkZ, false);
      return region == null ? null : region.read(slotIndex(chunkX, chunkZ));
   }

   public boolean write(int chunkX, int chunkZ, int tier, byte[] record) throws IOException {
      this.checkOwner();
      if (this.closed) {
         return false;
      }

      if (tier < 0 || tier > 2) {
         throw new IllegalArgumentException("Unknown truth tier: " + tier);
      }

      if (record != null && record.length != 0) {
         FarFieldStore.Region region = this.regionFor(chunkX, chunkZ, true);
         boolean written = region.write(slotIndex(chunkX, chunkZ), tier, record);
         if (written) {
            this.sizeCachedAtMillis = 0L;
         }

         return written;
      } else {
         throw new IllegalArgumentException("Empty record");
      }
   }

   public long sizeBytes() {
      this.checkOwner();
      long now = System.currentTimeMillis();
      if (this.sizeCachedAtMillis != 0L && now - this.sizeCachedAtMillis < 5000L) {
         return this.cachedSizeBytes;
      }

      long total = 0L;
      if (Files.isDirectory(this.root)) {
         try (Stream<Path> files = Files.walk(this.root)) {
            total = files.filter(x$0 -> Files.isRegularFile(x$0)).mapToLong(p -> {
               try {
                  return Files.size(p);
               } catch (IOException e) {
                  return 0L;
               }
            }).sum();
         } catch (IOException e) {
            this.errorCounter.increment();
            return Math.max(this.cachedSizeBytes, 0L);
         }
      }

      this.cachedSizeBytes = total;
      this.sizeCachedAtMillis = now;
      return total;
   }

   public void clearAll() throws IOException {
      this.checkOwner();
      if (!this.root.startsWith(this.farfieldBase)) {
         throw new IOException("Refusing to clear a folder outside nvidiumplus/farfield: " + this.root);
      }

      this.closeRegions();
      if (Files.isDirectory(this.root)) {
         List<Path> contents = new ArrayList<>();

         try (Stream<Path> files = Files.walk(this.root)) {
            files.sorted(Comparator.reverseOrder()).filter(px -> !px.equals(this.root)).forEach(contents::add);
         }

         for (Path p : contents) {
            if (!p.toAbsolutePath().normalize().startsWith(this.farfieldBase)) {
               throw new IOException("Refusing to delete outside nvidiumplus/farfield: " + p);
            }

            Files.deleteIfExists(p);
         }
      }

      this.cachedSizeBytes = 0L;
      this.sizeCachedAtMillis = System.currentTimeMillis();
   }

   public void close() {
      this.checkOwner();
      this.closed = true;
      this.closeRegions();
   }

   private void closeRegions() {
      for (FarFieldStore.Region region : this.openRegions.values()) {
         try {
            region.close();
         } catch (IOException e) {
            this.errorCounter.increment();
         }
      }

      this.openRegions.clear();
   }

   private void checkOwner() {
      Thread current = Thread.currentThread();
      if (this.owner == null) {
         this.owner = current;
      } else if (this.owner != current) {
         throw new IllegalStateException("FarFieldStore is confined to its IO thread (owner=" + this.owner.getName() + ", caller=" + current.getName() + ")");
      }
   }

   private static int slotIndex(int chunkX, int chunkZ) {
      return (chunkZ & 31) * 32 + (chunkX & 31);
   }

   private FarFieldStore.Region regionFor(int chunkX, int chunkZ, boolean create) throws IOException {
      int regionX = chunkX >> 5;
      int regionZ = chunkZ >> 5;
      long key = (long)regionX << 32 | regionZ & 4294967295L;
      FarFieldStore.Region region = this.openRegions.get(key);
      if (region != null) {
         return region;
      }

      Path file = this.root.resolve("r." + regionX + "." + regionZ + ".mfr");
      if (!create && !Files.isRegularFile(file)) {
         return null;
      }

      if (create) {
         Files.createDirectories(this.root);
      }

      region = new FarFieldStore.Region(file);
      this.openRegions.put(key, region);

      while (this.openRegions.size() > 4) {
         Iterator<Entry<Long, FarFieldStore.Region>> eldest = this.openRegions.entrySet().iterator();
         FarFieldStore.Region evicted = eldest.next().getValue();
         eldest.remove();

         try {
            evicted.close();
         } catch (IOException e) {
            this.errorCounter.increment();
         }
      }

      return region;
   }

   private static int readInt(byte[] bytes, int at) {
      return (bytes[at] & 0xFF) << 24 | (bytes[at + 1] & 0xFF) << 16 | (bytes[at + 2] & 0xFF) << 8 | bytes[at + 3] & 0xFF;
   }

   private static void writeInt(byte[] bytes, int at, int value) {
      bytes[at] = (byte)(value >>> 24);
      bytes[at + 1] = (byte)(value >>> 16);
      bytes[at + 2] = (byte)(value >>> 8);
      bytes[at + 3] = (byte)value;
   }

   private final class Region {
      private final Path file;
      private RandomAccessFile raf;
      private final int[] offsets = new int[1024];
      private final int[] lengths = new int[1024];
      private long liveBytes;

      Region(Path file) throws IOException {
         this.file = file;
         this.open();
      }

      private void open() throws IOException {
         this.raf = new RandomAccessFile(this.file.toFile(), "rw");
         long fileLength = this.raf.length();
         if (fileLength == 0L) {
            this.writeEmptyHeader();
         } else if (fileLength < 8192L) {
            FarFieldStore.this.errorCounter.increment();
            this.raf.setLength(0L);
            this.writeEmptyHeader();
         } else {
            byte[] header = new byte[8192];
            this.raf.seek(0L);
            this.raf.readFully(header);
            this.liveBytes = 0L;

            for (int i = 0; i < 1024; i++) {
               int offset = FarFieldStore.readInt(header, i * 4);
               int length = FarFieldStore.readInt(header, 4096 + i * 4);
               if (offset != 0 || length != 0) {
                  boolean sane = offset >= 8192 && length >= 1 && (long)offset + length <= fileLength;
                  if (!sane) {
                     FarFieldStore.this.errorCounter.increment();
                     this.offsets[i] = 0;
                     this.lengths[i] = 0;
                  } else {
                     this.offsets[i] = offset;
                     this.lengths[i] = length;
                     this.liveBytes += length;
                  }
               }
            }
         }
      }

      private void writeEmptyHeader() throws IOException {
         this.raf.seek(0L);
         this.raf.write(new byte[8192]);
         this.liveBytes = 0L;
      }

      byte[] read(int slot) throws IOException {
         int offset = this.offsets[slot];
         if (offset == 0) {
            return null;
         }

         int length = this.lengths[slot];
         byte[] payload = new byte[length - 1];
         this.raf.seek(offset + 1L);
         this.raf.readFully(payload);
         return payload;
      }

      boolean write(int slot, int tier, byte[] record) throws IOException {
         if (this.offsets[slot] != 0) {
            int existingTier = this.tierAt(slot);
            if (existingTier > tier) {
               return false;
            }
         }

         long end = this.raf.length();
         if (end + 1L + record.length > 2147483647L) {
            this.compact();
            end = this.raf.length();
            if (end + 1L + record.length > 2147483647L) {
               throw new IOException("Region file full: " + this.file);
            }
         }

         this.raf.seek(end);
         this.raf.write(tier);
         this.raf.write(record);
         int oldLength = this.lengths[slot];
         this.offsets[slot] = (int)end;
         this.lengths[slot] = 1 + record.length;
         this.liveBytes = this.liveBytes + (this.lengths[slot] - oldLength);
         this.raf.seek(slot * 4L);
         this.raf.writeInt(this.offsets[slot]);
         this.raf.seek(4096L + slot * 4L);
         this.raf.writeInt(this.lengths[slot]);
         long dead = this.deadBytes();
         if (dead >= 65536L && dead * 2L > this.dataBytes()) {
            this.compact();
         }

         return true;
      }

      private int tierAt(int slot) throws IOException {
         this.raf.seek(this.offsets[slot]);
         int tier = this.raf.read();
         if (tier < 0) {
            FarFieldStore.this.errorCounter.increment();
            this.liveBytes = this.liveBytes - this.lengths[slot];
            this.offsets[slot] = 0;
            this.lengths[slot] = 0;
            return -1;
         } else {
            return tier;
         }
      }

      private long dataBytes() throws IOException {
         return Math.max(0L, this.raf.length() - 8192L);
      }

      private long deadBytes() throws IOException {
         return Math.max(0L, this.dataBytes() - this.liveBytes);
      }

      private void compact() throws IOException {
         Path tmp = this.file.resolveSibling(this.file.getFileName() + ".tmp");
         int[] newOffsets = new int[1024];
         int[] newLengths = new int[1024];
         long newLive = 0L;

         try (RandomAccessFile out = new RandomAccessFile(tmp.toFile(), "rw")) {
            out.setLength(0L);
            out.seek(8192L);
            long cursor = 8192L;

            for (int i = 0; i < 1024; i++) {
               if (this.offsets[i] != 0) {
                  byte[] recordBytes = new byte[this.lengths[i]];
                  this.raf.seek(this.offsets[i]);
                  this.raf.readFully(recordBytes);
                  out.write(recordBytes);
                  newOffsets[i] = (int)cursor;
                  newLengths[i] = this.lengths[i];
                  cursor += this.lengths[i];
                  newLive += this.lengths[i];
               }
            }

            byte[] header = new byte[8192];

            for (int i = 0; i < 1024; i++) {
               FarFieldStore.writeInt(header, i * 4, newOffsets[i]);
               FarFieldStore.writeInt(header, 4096 + i * 4, newLengths[i]);
            }

            out.seek(0L);
            out.write(header);
         }

         this.raf.close();

         try {
            Files.move(tmp, this.file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
         } catch (IOException notAtomicHere) {
            Files.move(tmp, this.file, StandardCopyOption.REPLACE_EXISTING);
         }

         this.raf = new RandomAccessFile(this.file.toFile(), "rw");
         System.arraycopy(newOffsets, 0, this.offsets, 0, 1024);
         System.arraycopy(newLengths, 0, this.lengths, 0, 1024);
         this.liveBytes = newLive;
      }

      void close() throws IOException {
         this.raf.close();
      }
   }
}
