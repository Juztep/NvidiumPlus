package nvidiumplus.engine.farfield.extract;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.lang.ref.WeakReference;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.atomic.LongAdder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.chunk.ChunkSource;
import net.minecraft.world.level.chunk.LevelChunk;
import nvidiumplus.engine.farfield.FarField;
import nvidiumplus.engine.farfield.FarFieldConfig;

public final class ExtractDispatch {
   public static final LongAdder farExtracts = new LongAdder();
   public static final LongAdder farExtractCells = new LongAdder();
   public static final LongAdder farSaveLost = new LongAdder();
   public static final LongAdder farSaveEditsCoalesced = new LongAdder();
   public static final LongAdder farSaveDegradedLeft = new LongAdder();
   public static final LongAdder farSaveLeftUnsaved = new LongAdder();
   public static final LongAdder farSaveGaugeUnderflow = new LongAdder();
   public static final LongAdder farExtractOnDemand = new LongAdder();
   public static final LongAdder farSavePins = new LongAdder();
   public static final LongAdder farSavePinReleases = new LongAdder();
   public static final LongAdder farSaveCaptureSkipped = new LongAdder();
   public static final LongAdder farSaveLightUncaptured = new LongAdder();
   public static final LongAdder farSavePinTripwire = new LongAdder();
   public static final LongAdder farExtractSweepExtracts = new LongAdder();
   public static final LongAdder farExtractIncomplete = new LongAdder();
   public static final LongAdder farExtractUpgrades = new LongAdder();
   public static final LongAdder farExtractBudgetRefusals = new LongAdder();
   public static final LongAdder farExtractNanos = new LongAdder();
   public static final LongAdder farExtractSlicesSpent = new LongAdder();
   public static final LongAdder farExtractSlices = new LongAdder();
   public static final LongAdder farExtractIdleBoosts = new LongAdder();
   public static final LongAdder farBudgetGrantedNanos = new LongAdder();
   public static final LongAdder farBudgetFrameNanos = new LongAdder();
   public static final LongAdder farBudgetCapBound = new LongAdder();
   public static final LongAdder farBudgetFloorBound = new LongAdder();
   public static final LongAdder farBudgetNoFitRefusals = new LongAdder();
   public static final LongAdder farBudgetOverrunNanos = new LongAdder();
   public static final LongAdder farCaptures = new LongAdder();
   public static final LongAdder farCaptureNanos = new LongAdder();
   public static final LongAdder farCaptureWorkerFull = new LongAdder();
   public static final LongAdder farCaptureDeferrals = new LongAdder();
   public static final LongAdder farWalksOffWorker = new LongAdder();
   public static final LongAdder farExtractSweepOwed = new LongAdder();
   public static final LongAdder farExtractStaleFiled = new LongAdder();
   public static final LongAdder farExtractStaleRefreshes = new LongAdder();
   public static final LongAdder farLightCrossChunkDirty = new LongAdder();
   public static final LongAdder farExtractWriteLost = new LongAdder();
   private static final long ASSUMED_FRAME_NANOS = 2500000L;
   private static final long MIN_FRAME_SAMPLE_NANOS = 200000L;
   private static final long MAX_FRAME_SAMPLE_NANOS = 100000000L;
   private static final long MAX_SLICE_NANOS = 16000000L;
   private static final int BUDGET_PERMILLE = 100;
   private static final long BUDGET_CAP_NANOS = 2000000L;
   private static final long BUDGET_FLOOR_NANOS = 250000L;
   private static final int LEAVE_RESERVE_PERMILLE = 100;
   private static final long LEAVE_RESERVE_CAP_NANOS = 2000000L;
   private static final long LEAVE_RESERVE_FLOOR_NANOS = 250000L;
   private static final int FRAME_EMA_SHIFT = 3;
   private static final int COST_EMA_SHIFT = 3;
   private static final long SEED_CAPTURE_COST_NANOS = 40000L;
   private static final long MIN_CAPTURE_COST_NANOS = 2000L;
   private static final long MAX_CAPTURE_COST_NANOS = 500000L;
   private static final int MAX_WORKER_BACKLOG = 32;
   private static final int PIN_HARD_CAP = 65536;
   private static final int E9_HEAP_FLOOR_DIVISOR = 10;
   private static final long E9_CONFIRM_NANOS = 100000000L;
   private static final int E9_RELEASE_BATCH = 64;
   private static final int SWEEP_PROBES_PER_PUMP = 1024;
   private static final int SWEEP_PROBES_PER_PUMP_BUSY = 128;
   private static final int MAX_TRACKED_COLUMNS = 262144;
   private static final long EDIT_COALESCE_MILLIS = 250L;
   private static final int RING_BUCKETS = 256;
   private static volatile boolean armed = resolveEnabled();
   private static int lastViewRadius = -1;
   private static int lastViewCenterX;
   private static int lastViewCenterZ;
   private static boolean viewCenterKnown;
   static final byte STATE_LIVE_CLEAN = 0;
   static final byte STATE_LIVE_DIRTY = 1;
   static final byte STATE_PINNED = 2;
   static final byte STATE_GONE_SAVED = 3;
   static final byte STATE_GONE_BEHIND = 4;
   static final byte JOB_NONE = 0;
   static final byte JOB_EDIT = 1;
   static final byte JOB_FILL = 2;
   static final byte QUALITY_WHOLE = 1;
   static final byte QUALITY_SIDE_WEST = 2;
   static final byte QUALITY_SIDE_EAST = 4;
   static final byte QUALITY_SIDE_NORTH = 8;
   static final byte QUALITY_SIDE_SOUTH = 16;
   static final byte QUALITY_LIGHT_PARTIAL = 32;
   static final byte QUALITY_EMPTY = 64;
   private static Long2ObjectOpenHashMap<ExtractDispatch.ColumnRecord> columns;
   private static long nextStamp;
   private static long farSaveBehindGauge;
   private static boolean evictionTriedThisSlice;
   private static final ExtractDispatch.JobQueue editQueue = new ExtractDispatch.JobQueue((byte)1, true);
   private static final ExtractDispatch.JobQueue fillQueue = new ExtractDispatch.JobQueue((byte)2, false);
   private static LongArrayList editPendingKeys;
   private static LongArrayList editPendingDue;
   private static int editPendingHead;
   private static ArrayList<Pin> leavingPins;
   private static int leavingHead;
   private static final int LEAVING_TRIAGE_PER_PUMP = 4096;
   private static ArrayList<Pin> liveCaptures;
   private static int liveCaptureHead;
   private static final long E6_CAPTURE_HARD_DEADLINE_NANOS = 400000000L;
   private static final long E6_LIGHT_DEADLINE_NANOS = 250000000L;
   private static long frameMillis;
   private static long lightRun = 1L;
   private static final int LIGHT_NOISE_RADIUS = 2;
   private static long sliceSpentNanos;
   private static boolean sliceOpen;
   private static long sliceBudgetNanos;
   private static long sliceLeaveBudgetNanos;
   private static long sliceFrameNanos;
   private static long worstSliceNanos;
   private static long worstOverrunNanos;
   private static final long[] recentWriteLossRing = new long[16];
   private static long recentWriteLossFiled;
   private static long frameNanosEma;
   private static long captureCostNanosEma = 40000L;
   private static int eventsThisSlice;
   private static int eventsLastSlice;
   private static int lastSliceCameraX;
   private static int lastSliceCameraZ;
   private static Long2ObjectOpenHashMap<Pin> pinIndex;
   private static ArrayDeque<Pin> admittedPins;
   private static int pinnedGauge;
   private static int liveCaptureGauge;
   private static long e9BreachSinceNanos = Long.MIN_VALUE;
   private static volatile boolean standDown;
   private static int sweepRing;
   private static int sweepIndex;
   private static int sweepOwedThisPass;
   private static ExtractDispatch.SaveCensus censusCache;
   private static long censusCacheMillis = Long.MIN_VALUE;
   private static WeakReference<Object> lastLevel = new WeakReference<>(null);
   private static final int[] pinCaptureNanosBuckets = new int[40];
   private static long pinCaptureMaxNanos;
   private static long pinCaptureSamples;
   public static final boolean PERF_STATS = Boolean.getBoolean("nvidiumplus.farfield.perfStats");
   private static final int PERF_SUB_BITS = 3;
   private static final int PERF_SUB = 8;
   private static final int PERF_OCTAVES = 40;
   private static final int PERF_BUCKETS = 320;
   private static final ExtractDispatch.PerfHistogram captureCostHistogram = new ExtractDispatch.PerfHistogram();
   private static final ExtractDispatch.PerfHistogram sliceSpendHistogram = new ExtractDispatch.PerfHistogram();
   private static final ExtractDispatch.PerfHistogram sliceOverrunHistogram = new ExtractDispatch.PerfHistogram();
   private static final ExtractDispatch.PerfHistogram sliceBudgetHistogram = new ExtractDispatch.PerfHistogram();

   private static void settleGoneSaved(ExtractDispatch.ColumnRecord rec) {
      releaseLiveCapture(rec);
      rec.state = 3;
      rec.jobClass = 0;
   }

   private static void leaveBehind(ExtractDispatch.ColumnRecord rec) {
      releaseLiveCapture(rec);
      rec.state = 4;
      rec.jobClass = 0;
      farSaveBehindGauge++;
   }

   private static void repairBehind(ExtractDispatch.ColumnRecord rec) {
      if (--farSaveBehindGauge < 0L) {
         farSaveBehindGauge = 0L;
         farSaveGaugeUnderflow.increment();
      }
   }

   private static void drainWriteAcks() {
      FarField.WriteAck ack;
      while ((ack = FarField.pollWriteAck()) != null) {
         long key = columnKey(ack.chunkX(), ack.chunkZ());
         ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(key);
         boolean ours = rec != null && rec.writingVersion != 0L && rec.writingVersion == ack.version();
         if (!ack.ok()) {
            farExtractWriteLost.increment();
            recentWriteLossRing[(int)(recentWriteLossFiled++ % recentWriteLossRing.length)] = key;
            if (ours) {
               rec.writingVersion = 0L;
               if (rec.state == 1) {
                  if (rec.pin != null && rec.pin.live) {
                     releasePin(rec);
                  }

                  refileJob(rec, key);
               } else if (rec.state == 3) {
                  leaveBehind(rec);
               } else if (rec.state == 2 && rec.pin != null && !rec.pin.released) {
                  rec.writingVersion = rec.pin.version;
                  PinWorker.enqueue(rec.pin);
               }
            }
         } else if (ours) {
            boolean hadStored = rec.storedVersion > 0L;
            boolean wasDegraded = hadStored && (rec.quality & 65) == 0;
            rec.storedVersion = Math.max(rec.storedVersion, ack.version());
            rec.quality = rec.writingQuality;
            rec.writingVersion = 0L;
            if (hadStored) {
               farExtractStaleRefreshes.increment();
            }

            if (wasDegraded && (rec.quality & 1) != 0) {
               farExtractUpgrades.increment();
            }

            if (rec.state == 1) {
               if (rec.pin != null && rec.pin.live) {
                  releasePin(rec);
                  FarField.onPinShellAcked(ack.chunkX(), ack.chunkZ());
               }

               if (rec.liveVersion <= rec.storedVersion) {
                  rec.state = 0;
                  rec.jobClass = 0;
               } else {
                  refileJob(rec, key);
               }
            } else if (rec.state == 3 && rec.liveVersion > rec.storedVersion) {
               leaveBehind(rec);
            } else if (rec.state == 2) {
               if (rec.liveVersion <= rec.storedVersion) {
                  settleGoneSaved(rec);
                  releasePin(rec);
                  FarField.onPinShellAcked(ack.chunkX(), ack.chunkZ());
               } else if (rec.pin != null && !rec.pin.released) {
                  rec.writingVersion = rec.pin.version;
                  PinWorker.enqueue(rec.pin);
               }
            }
         }
      }
   }

   private static void refileJob(ExtractDispatch.ColumnRecord rec, long key) {
      if (rec.jobClass == 1) {
         fileEdit(rec, key);
      } else {
         rec.jobClass = 2;
         fileFill(rec, key);
      }
   }

   public static long[] recentWriteLossKeys() {
      int live = (int)Math.min(recentWriteLossFiled, recentWriteLossRing.length);
      long[] copy = new long[live];
      System.arraycopy(recentWriteLossRing, 0, copy, 0, live);
      return copy;
   }

   public static ExtractDispatch.SaveCensus saveCensus() {
      long now = System.currentTimeMillis();
      ExtractDispatch.SaveCensus cached = censusCache;
      if (cached != null && now - censusCacheMillis < 1000L) {
         return cached;
      }

      int savedWhole = 0;
      int savedDegraded = 0;
      int waiting = 0;
      int stale = 0;
      Long2ObjectOpenHashMap<ExtractDispatch.ColumnRecord> map = columns;
      if (map != null) {
         ObjectIterator var8 = map.values().iterator();

         while (var8.hasNext()) {
            ExtractDispatch.ColumnRecord rec = (ExtractDispatch.ColumnRecord)var8.next();
            if (rec.liveVersion > rec.storedVersion) {
               if (rec.state == 1) {
                  waiting++;
                  if (rec.storedVersion > 0L) {
                     stale++;
                  }
               }
            } else if (rec.storedVersion > 0L) {
               if ((rec.quality & 65) != 0) {
                  savedWhole++;
               } else {
                  savedDegraded++;
               }
            }
         }
      }

      cached = new ExtractDispatch.SaveCensus(savedWhole, savedDegraded, waiting, stale);
      censusCache = cached;
      censusCacheMillis = now;
      return cached;
   }

   private ExtractDispatch() {
   }

   public static boolean armed() {
      return armed;
   }

   public static void refreshArmed() {
      armed = resolveEnabled();
      if (!armed) {
         dropLeavingCaptures();
         dropLiveCaptures();
         abandonPins();
         standDown = false;
      }

      sliceOpen = false;
      eventsThisSlice = 0;
      eventsLastSlice = 0;
   }

   private static boolean resolveEnabled() {
      try {
         return FarFieldConfig.enabled();
      } catch (Throwable t) {
         return false;
      }
   }

   public static void onChunkReceived(LevelChunk chunk) {
      if (armed) {
         noteLevel(chunk);
         eventsThisSlice++;
         ChunkSource source = chunk.getLevel().getChunkSource();
         int cx = chunk.getPos().x();
         int cz = chunk.getPos().z();
         long key = columnKey(cx, cz);
         ExtractDispatch.ColumnRecord rec = ensureRecord(key);
         if (rec.state == 4) {
            repairBehind(rec);
         } else if (rec.state == 2) {
            releasePin(rec);
         }

         if (rec.storedVersion > 0L && rec.liveVersion <= rec.storedVersion) {
            farExtractStaleFiled.increment();
         }

         rec.liveVersion = ++nextStamp;
         rec.state = 1;
         boolean wasLightReady = rec.lightReady;
         rec.lightReady = true;
         if (!wasLightReady && rec.jobClass != 0 && !rec.filedEdit && !rec.filedFill) {
            refileJob(rec, key);
         }

         LevelChunk west = source.getChunk(cx - 1, cz, false);
         LevelChunk east = source.getChunk(cx + 1, cz, false);
         LevelChunk north = source.getChunk(cx, cz - 1, false);
         LevelChunk south = source.getChunk(cx, cz + 1, false);
         if (west != null && east != null && north != null && south != null) {
            fileFill(rec, key);
         }

         fanOutNeighbour(source, cx - 1, cz, (byte)4, west);
         fanOutNeighbour(source, cx + 1, cz, (byte)2, east);
         fanOutNeighbour(source, cx, cz - 1, (byte)16, north);
         fanOutNeighbour(source, cx, cz + 1, (byte)8, south);
         stampLightNoise(cx, cz);
      }
   }

   private static void fanOutNeighbour(ChunkSource source, int x, int z, byte sideBit, LevelChunk held) {
      if (held != null) {
         long key = columnKey(x, z);
         ExtractDispatch.ColumnRecord rec = (ExtractDispatch.ColumnRecord)columns.get(key);
         if (rec == null) {
            if (plusCompleteExcept(source, x, z, sideBit)) {
               rec = ensureRecord(key);
               fileFill(rec, key);
            }
         } else if (rec.state == 1) {
            if (rec.jobClass != 1 && !rec.filedFill && plusCompleteExcept(source, x, z, sideBit)) {
               fileFill(rec, key);
            }
         } else if (rec.state == 0) {
            if ((rec.quality & 65) == 0) {
               if ((rec.quality & (sideBit | 32)) != 0) {
                  if (plusCompleteExcept(source, x, z, sideBit)) {
                     rec.liveVersion = ++nextStamp;
                     rec.state = 1;
                     fileFill(rec, key);
                  }
               }
            }
         }
      }
   }

   private static boolean plusCompleteExcept(ChunkSource source, int x, int z, byte knownSide) {
      return (knownSide == 2 || source.getChunk(x - 1, z, false) != null)
         && (knownSide == 4 || source.getChunk(x + 1, z, false) != null)
         && (knownSide == 8 || source.getChunk(x, z - 1, false) != null)
         && (knownSide == 16 || source.getChunk(x, z + 1, false) != null);
   }

   public static void onBlockChanged(LevelChunk chunk) {
      if (armed) {
         noteLevel(chunk);
         long key = columnKey(chunk.getPos().x(), chunk.getPos().z());
         ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(key);
         if (rec == null) {
            rec = ensureRecord(key);
         } else if (rec.state == 4) {
            repairBehind(rec);
         } else if (rec.state == 2) {
            releasePin(rec);
         }

         if (rec.storedVersion > 0L && rec.liveVersion <= rec.storedVersion) {
            farExtractStaleFiled.increment();
         }

         rec.liveVersion = ++nextStamp;
         rec.state = 1;
         fileEdit(rec, key);
      }
   }

   public static void onLightChanged(int chunkX, int chunkZ) {
      if (armed) {
         Long2ObjectOpenHashMap<ExtractDispatch.ColumnRecord> map = columns;
         if (map != null) {
            long key = columnKey(chunkX, chunkZ);
            ExtractDispatch.ColumnRecord rec = (ExtractDispatch.ColumnRecord)map.get(key);
            if (rec != null) {
               if (rec.lightNoiseRun != lightRun) {
                  if (rec.state == 0 || rec.state == 1) {
                     if (rec.liveVersion <= rec.storedVersion || rec.liveVersion <= rec.writingVersion) {
                        if (rec.storedVersion > 0L && rec.liveVersion <= rec.storedVersion) {
                           farExtractStaleFiled.increment();
                        }

                        farLightCrossChunkDirty.increment();
                        rec.liveVersion = ++nextStamp;
                        rec.state = 1;
                        fileEdit(rec, key);
                     }
                  }
               }
            }
         }
      }
   }

   private static void stampLightNoise(int cx, int cz) {
      Long2ObjectOpenHashMap<ExtractDispatch.ColumnRecord> map = columns;
      if (map != null && !map.isEmpty()) {
         long run = lightRun;

         for (int dz = -2; dz <= 2; dz++) {
            for (int dx = -2; dx <= 2; dx++) {
               ExtractDispatch.ColumnRecord neighbour = (ExtractDispatch.ColumnRecord)map.get(columnKey(cx + dx, cz + dz));
               if (neighbour != null) {
                  neighbour.lightNoiseRun = run;
               }
            }
         }
      }
   }

   private static void beginSlice(long frameNanos, int cameraX, int cameraZ) {
      long now = System.nanoTime();
      if (frameNanos > 0L) {
         long sample = Math.max(200000L, Math.min(100000000L, frameNanos));
         frameNanosEma = frameNanosEma == 0L ? sample : frameNanosEma + (sample - frameNanosEma >> 3);
      }

      lastSliceCameraX = cameraX;
      lastSliceCameraZ = cameraZ;
      openSlice(now, frameNanosEma == 0L ? 2500000L : frameNanosEma);
   }

   private static void openSlice(long now, long frameNanos) {
      if (sliceOpen) {
         if (sliceSpentNanos >= sliceBudgetNanos && sliceBudgetNanos > 0L) {
            farExtractSlicesSpent.increment();
         }

         if (sliceSpentNanos > worstSliceNanos) {
            worstSliceNanos = sliceSpentNanos;
         }

         long overrun = sliceSpentNanos - sliceBudgetNanos;
         if (overrun > 0L) {
            farBudgetOverrunNanos.add(overrun);
            if (overrun > worstOverrunNanos) {
               worstOverrunNanos = overrun;
            }
         }
      }

      if (PERF_STATS && sliceOpen) {
         recordClosingSlice();
      }

      sliceOpen = true;
      sliceSpentNanos = 0L;
      frameMillis = now / 1000000L;
      evictionTriedThisSlice = false;
      eventsLastSlice = eventsThisSlice;
      eventsThisSlice = 0;
      sliceFrameNanos = frameNanos;
      int cacheSpeed = resolveCacheSpeed();
      long ceiling = resolveCeilingNanos();
      if (resolveAdaptive()) {
         sliceBudgetNanos = sliceBudgetFor(frameNanos, cacheSpeed, ceiling);
         long share = budgetShareNanos(frameNanos, cacheSpeed);
         if (share > budgetCapNanos(cacheSpeed)) {
            farBudgetCapBound.increment();
         } else if (share < budgetFloorNanos(cacheSpeed)) {
            farBudgetFloorBound.increment();
         }
      } else {
         sliceBudgetNanos = Math.max(0L, ceiling);
      }

      sliceLeaveBudgetNanos = Math.min(16000000L, sliceBudgetNanos + leaveReserveNanosFor(frameNanos));
      farBudgetGrantedNanos.add(sliceBudgetNanos);
      farBudgetFrameNanos.add(frameNanos);
      farExtractSlices.increment();
   }

   private static long projectedCaptureNanos() {
      return captureCostNanosEma;
   }

   private static long leaveReserveNanosFor(long frameNanos) {
      long share = Math.max(0L, frameNanos) * 100L / 1000L;
      return Math.max(250000L, Math.min(2000000L, share));
   }

   public static long sliceBudgetFor(long frameNanos, int cacheSpeed, long userCeilingNanos) {
      if (userCeilingNanos <= 0L) {
         return 0L;
      }

      long budget = Math.max(budgetFloorNanos(cacheSpeed), Math.min(budgetCapNanos(cacheSpeed), budgetShareNanos(frameNanos, cacheSpeed)));
      return Math.min(budget, userCeilingNanos);
   }

   private static long budgetShareNanos(long frameNanos, int cacheSpeed) {
      long share = Math.max(0L, frameNanos) * 100L / 1000L;
      return share * dialScalePermille(cacheSpeed) / 1000L;
   }

   private static long budgetCapNanos(int cacheSpeed) {
      return 2000000L * dialScalePermille(cacheSpeed) / 1000L;
   }

   private static long budgetFloorNanos(int cacheSpeed) {
      return 250000L * dialScalePermille(cacheSpeed) / 1000L;
   }

   private static int dialScalePermille(int cacheSpeed) {
      if (cacheSpeed <= 0) {
         return 300;
      } else {
         return cacheSpeed >= 2 ? 1000 : 600;
      }
   }

   public static boolean backlogged() {
      return leavingCount() > 0 || liveCaptureCount() > 0 || jobsQueued() > 0;
   }

   private static long resolveCeilingNanos() {
      try {
         return FarFieldConfig.extractBudgetNanos();
      } catch (Throwable t) {
         return 3000000L;
      }
   }

   private static boolean resolveAdaptive() {
      try {
         return FarFieldConfig.adaptiveExtraction();
      } catch (Throwable t) {
         return false;
      }
   }

   private static int resolveCacheSpeed() {
      try {
         return FarFieldConfig.layerCacheSpeed(FarFieldConfig.Layer.L1);
      } catch (Throwable t) {
         return 2;
      }
   }

   public static int pinnedCount() {
      return pinnedGauge;
   }

   public static int pendingCaptureCount() {
      return leavingCount();
   }

   public static long[] liveColumnKeys() {
      Long2ObjectOpenHashMap<ExtractDispatch.ColumnRecord> map = columns;
      if (map == null) {
         return new long[0];
      }

      LongArrayList keys = new LongArrayList(map.size());
      ObjectIterator<Entry<ExtractDispatch.ColumnRecord>> it = map.long2ObjectEntrySet().fastIterator();

      while (it.hasNext()) {
         Entry<ExtractDispatch.ColumnRecord> entry = (Entry<ExtractDispatch.ColumnRecord>)it.next();
         ExtractDispatch.ColumnRecord rec = (ExtractDispatch.ColumnRecord)entry.getValue();
         if ((rec.state == 0 || rec.state == 1) && (rec.quality & 64) == 0) {
            keys.add(entry.getLongKey());
         }
      }

      return keys.toLongArray();
   }

   private static void chargeSlice(long cost) {
      sliceSpentNanos += cost;
   }

   private static void chargeCapture(long cost) {
      chargeSlice(cost);
      farCaptureNanos.add(cost);
      if (PERF_STATS) {
         captureCostHistogram.record(cost);
      }

      long clamped = Math.max(2000L, Math.min(500000L, cost));
      captureCostNanosEma = captureCostNanosEma + (clamped - captureCostNanosEma >> 3);
   }

   private static boolean budgetRemains() {
      return sliceSpentNanos + projectedCaptureNanos() <= sliceBudgetNanos;
   }

   private static boolean budgetLeft() {
      return !standDown && budgetRemains();
   }

   private static boolean workerHasRoom() {
      if (PinWorker.pendingCount() < 32) {
         return true;
      }

      farCaptureWorkerFull.increment();
      return false;
   }

   private static boolean leaveBudgetLeft() {
      return sliceSpentNanos < sliceLeaveBudgetNanos;
   }

   public static long budgetMicrosNow() {
      return sliceBudgetNanos / 1000L;
   }

   public static long captureCostMicros() {
      return captureCostNanosEma / 1000L;
   }

   public static long frameMicrosNow() {
      return sliceFrameNanos / 1000L;
   }

   public static long budgetPermilleNow() {
      long frame = sliceFrameNanos;
      return frame <= 0L ? 0L : sliceBudgetNanos * 1000L / frame;
   }

   public static int workerBacklogNow() {
      return PinWorker.pendingCount();
   }

   public static int liveCaptureCount() {
      return liveCaptures == null ? 0 : liveCaptures.size() - liveCaptureHead;
   }

   public static long worstSliceMicros() {
      return worstSliceNanos / 1000L;
   }

   public static long worstOverrunMicros() {
      return worstOverrunNanos / 1000L;
   }

   public static int chunkEventsLastSlice() {
      return eventsLastSlice;
   }

   public static void resetBudgetPeaks() {
      worstSliceNanos = 0L;
      worstOverrunNanos = 0L;
   }

   private static byte missingSideBits(ChunkSource source, int x, int z) {
      byte q = 0;
      if (source.getChunk(x - 1, z, false) == null) {
         q = (byte)(q | 2);
      }

      if (source.getChunk(x + 1, z, false) == null) {
         q = (byte)(q | 4);
      }

      if (source.getChunk(x, z - 1, false) == null) {
         q = (byte)(q | 8);
      }

      if (source.getChunk(x, z + 1, false) == null) {
         q = (byte)(q | 16);
      }

      return q;
   }

   private static boolean neighborsLoaded(ChunkSource source, int x, int z) {
      return missingSideBits(source, x, z) == 0;
   }

   private static void fileFill(ExtractDispatch.ColumnRecord rec, long key) {
      if (rec.jobClass != 1) {
         rec.jobClass = 2;
         fillQueue.file(rec, key, cameraRing(columnX(key), columnZ(key)));
      }
   }

   private static void fileEdit(ExtractDispatch.ColumnRecord rec, long key) {
      if (rec.jobClass == 1 && rec.filedEdit) {
         farSaveEditsCoalesced.increment();
      } else {
         rec.jobClass = 1;
         if (!rec.filedEdit) {
            rec.editStampMs = frameMillis;
            rec.filedEdit = true;
            if (editPendingKeys == null) {
               editPendingKeys = new LongArrayList(64);
               editPendingDue = new LongArrayList(64);
            }

            editPendingKeys.add(key);
            editPendingDue.add(frameMillis + 250L);
         }
      }
   }

   private static void ripenEdits() {
      LongArrayList keys = editPendingKeys;
      if (keys != null && editPendingHead < keys.size()) {
         LongArrayList due = editPendingDue;

         while (editPendingHead < keys.size() && due.getLong(editPendingHead) <= frameMillis) {
            long key = keys.getLong(editPendingHead++);
            ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(key);
            if (rec != null && rec.filedEdit) {
               rec.filedEdit = false;
               if (rec.jobClass == 1 && rec.state == 1) {
                  editQueue.file(rec, key, cameraRing(columnX(key), columnZ(key)));
               }
            }
         }

         if (editPendingHead >= keys.size()) {
            keys.clear();
            due.clear();
            editPendingHead = 0;
         } else if (editPendingHead > 256 && editPendingHead * 2 >= keys.size()) {
            keys.removeElements(0, editPendingHead);
            due.removeElements(0, editPendingHead);
            editPendingHead = 0;
         }
      }
   }

   private static int chebyshev(int x, int z, int camX, int camZ) {
      return Math.max(Math.abs(x - camX), Math.abs(z - camZ));
   }

   private static int cameraRing(int x, int z) {
      return Math.min(chebyshev(x, z, lastSliceCameraX, lastSliceCameraZ), 255);
   }

   public static int jobsQueued() {
      return editQueue.queued + fillQueue.queued;
   }

   public static int editsPending() {
      LongArrayList keys = editPendingKeys;
      return keys == null ? 0 : keys.size() - editPendingHead;
   }

   private static boolean storeBacklogged() {
      return FarField.writeQueueSaturated();
   }

   private static void drainJobs(ExtractDispatch.JobQueue q, ChunkSource source) {
      int budget = q.queued;
      if (budget > 0) {
         boolean edit = q.edit;

         while (budget-- > 0) {
            if (!workerHasRoom()) {
               farExtractBudgetRefusals.increment();
               break;
            }

            if (edit ? !budgetRemains() : !budgetLeft()) {
               farExtractBudgetRefusals.increment();
               if (sliceSpentNanos > 0L) {
                  farBudgetNoFitRefusals.increment();
               }
               break;
            }

            long key = q.pop();
            if (key == Long.MIN_VALUE) {
               break;
            }

            q.queued--;
            ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(key);
            if (rec != null) {
               q.setFiled(rec, false);
               if (rec.jobClass == q.jobClass
                  && rec.state == 1
                  && rec.liveVersion > rec.storedVersion
                  && rec.writingVersion == 0L
                  && rec.pin == null
                  && rec.lightReady) {
                  int x = columnX(key);
                  int z = columnZ(key);
                  int trueRing = cameraRing(x, z);
                  if (Math.abs(trueRing - q.poppedRing) > 2) {
                     q.file(rec, key, trueRing);
                  } else {
                     LevelChunk chunk = source.getChunk(x, z, false);
                     if (chunk == null) {
                        if (leavingCount() == 0) {
                           leaveBehind(rec);
                        }
                     } else {
                        rec.jobClass = 0;
                        beginLiveCapture(rec, chunk);
                     }
                  }
               }
            }
         }
      }
   }

   private static void beginLiveCapture(ExtractDispatch.ColumnRecord rec, LevelChunk chunk) {
      long start = System.nanoTime();
      Pin pin = Pin.captureLive(columnKey(chunk.getPos().x(), chunk.getPos().z()), chunk, rec.lightReady, Pin.Settings.snapshot());
      registerPin(pin);
      pin.version = rec.liveVersion;
      rec.pin = pin;
      liveCaptureGauge++;
      farCaptures.increment();
      if (chunk.getLevel().isClientSide()) {
         chunk.tryMarkSaved();
      }

      chargeCapture(Math.max(0L, System.nanoTime() - start));
      if (!finishPin(rec, pin)) {
         ArrayList<Pin> pending = liveCaptures;
         if (pending == null) {
            pending = new ArrayList<>(64);
            liveCaptures = pending;
         }

         pending.add(pin);
      }
   }

   private static void drainLiveCaptures() {
      ArrayList<Pin> pending = liveCaptures;
      if (pending != null && liveCaptureHead < pending.size()) {
         while (liveCaptureHead < pending.size()) {
            Pin pin = pending.get(liveCaptureHead);
            ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(pin.key);
            if (rec != null
               && rec.pin == pin
               && !pin.released
               && rec.state == 1
               && rec.writingVersion == 0L
               && pinIndex != null
               && pinIndex.get(pin.key) == pin) {
               if (!finishPin(rec, pin)) {
                  return;
               }

               liveCaptureHead++;
            } else {
               if (rec != null && rec.pin == pin) {
                  releasePin(rec);
               } else {
                  dismissPin(pin);
               }

               liveCaptureHead++;
            }
         }

         pending.clear();
         liveCaptureHead = 0;
      }
   }

   public static void onChunkDropping(LevelChunk chunk) {
      if (armed) {
         noteLevel(chunk);
         eventsThisSlice++;
         long key = columnKey(chunk.getPos().x(), chunk.getPos().z());
         ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(key);
         if (rec == null || rec.state == 0 || rec.state == 1) {
            if (rec != null && rec.liveVersion <= rec.storedVersion) {
               if ((rec.quality & 65) == 0) {
                  farSaveDegradedLeft.increment();
               }

               settleGoneSaved(rec);
            } else {
               long startNanos = System.nanoTime();
               Pin pin = Pin.capture(key, chunk, rec != null && rec.lightReady, true, Pin.Settings.snapshot());
               registerPin(pin);
               recordPinCaptureNanos(System.nanoTime() - startNanos);
               ArrayList<Pin> pending = leavingPins;
               if (pending == null) {
                  pending = new ArrayList<>(256);
                  leavingPins = pending;
               }

               pending.add(pin);
            }
         }
      }
   }

   public static boolean tryExtractLoaded(int chunkX, int chunkZ) {
      if (!armed) {
         return false;
      }

      try {
         long key = columnKey(chunkX, chunkZ);
         Minecraft minecraft = Minecraft.getInstance();
         ClientLevel level = minecraft == null ? null : minecraft.level;
         if (level == null) {
            return false;
         }

         LevelChunk chunk = level.getChunkSource().getChunk(chunkX, chunkZ, false);
         if (chunk == null) {
            return false;
         }

         noteLevel(chunk);
         ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(key);
         if (rec != null && rec.liveVersion <= rec.storedVersion) {
            if ((rec.quality & 64) != 0) {
               return false;
            }

            rec.liveVersion = ++nextStamp;
         }

         if (rec == null) {
            rec = ensureRecord(key);
         } else if (rec.state == 4) {
            repairBehind(rec);
         } else if (rec.state == 2) {
            releasePin(rec);
         }

         rec.state = 1;
         if (rec.writingVersion == 0L && rec.jobClass == 0 && !rec.filedFill && !rec.filedEdit) {
            fileFill(rec, key);
            farExtractOnDemand.increment();
         }

         return true;
      } catch (Throwable t) {
         return false;
      }
   }

   public static void setStandDown(boolean value) {
      standDown = value;
   }

   public static void pumpGameThread(int centerChunkX, int centerChunkZ, int radiusChunks, boolean nearFieldBusy) {
      if (armed) {
         lightRun++;

         try {
            if (FarField.consumeStoreInvalidated()) {
               forgetExtractedColumns();
            }

            drainPinResults();
            drainWriteAcks();
            beginSlice(frameNanos(), centerChunkX, centerChunkZ);
            drainLeavingCaptures();
            drainLiveCaptures();
            if (jobsQueued() > 0 || leavingCount() > 0 || liveCaptureCount() > 0) {
               FarField.ensureStoreOpenForCapture();
            }

            ClientLevel level = Minecraft.getInstance() == null ? null : Minecraft.getInstance().level;
            if (level == null) {
               return;
            }

            ChunkSource source = level.getChunkSource();
            ripenEdits();
            boolean backpressure = storeBacklogged();
            if (!backpressure) {
               drainJobs(editQueue, source);
            }

            if (standDown) {
               return;
            }

            if (!backpressure) {
               drainJobs(fillQueue, source);
            }

            sweepLoadedWindow(centerChunkX, centerChunkZ, radiusChunks, nearFieldBusy ? 128 : 1024);
         } catch (Throwable t) {
            FarField.farStoreErrors.increment();
         }
      }
   }

   private static long frameNanos() {
      Minecraft minecraft = Minecraft.getInstance();
      return minecraft == null ? 0L : minecraft.getFrameTimeNs();
   }

   private static void registerPin(Pin pin) {
      Long2ObjectOpenHashMap<Pin> index = pinIndex;
      if (index == null) {
         index = new Long2ObjectOpenHashMap(256);
         pinIndex = index;
      }

      index.put(pin.key, pin);
   }

   private static void releasePin(ExtractDispatch.ColumnRecord rec) {
      detachPin(rec, true);
   }

   private static void detachPin(ExtractDispatch.ColumnRecord rec, boolean dropIndexEntry) {
      Pin pin = rec.pin;
      if (pin != null) {
         pin.released = true;
         rec.pin = null;
         if (dropIndexEntry && pinIndex != null) {
            pinIndex.remove(pin.key);
         }

         if (pin.live) {
            liveCaptureGauge--;
         } else {
            pinnedGauge--;
         }

         farSavePinReleases.increment();
      }
   }

   private static void releaseLiveCapture(ExtractDispatch.ColumnRecord rec) {
      Pin pin = rec.pin;
      if (pin != null && pin.live) {
         if (rec.writingVersion != pin.version) {
            releasePin(rec);
         }
      }
   }

   private static boolean finishPin(ExtractDispatch.ColumnRecord rec, Pin pin) {
      Minecraft minecraft = Minecraft.getInstance();
      ClientLevel level = minecraft == null ? null : minecraft.level;
      ChunkSource source = level == null ? null : level.getChunkSource();
      int resumedAt = pin.finishSide;

      for (int side = pin.finishSide; side < 4; side++) {
         long neighborKey = columnKey(pin.chunkX + ShellExtractor.SIDE_DX[side], pin.chunkZ + ShellExtractor.SIDE_DZ[side]);
         Pin neighborPin = pinIndex == null ? null : (Pin)pinIndex.get(neighborKey);
         if (neighborPin != null && neighborPin != pin) {
            pin.sidePin[side] = neighborPin;
            pin.finishSide = side + 1;
         } else {
            LevelChunk live = source == null
               ? null
               : source.getChunk(pin.chunkX + ShellExtractor.SIDE_DX[side], pin.chunkZ + ShellExtractor.SIDE_DZ[side], false);
            if (live == null) {
               pin.finishSide = side + 1;
            } else {
               boolean funded = side == resumedAt || (pin.live ? budgetRemains() : leaveBudgetLeft());
               if (!funded) {
                  farCaptureDeferrals.increment();
                  return false;
               }

               long start = System.nanoTime();
               pin.strips[side] = ShellExtractor.captureStrip(pin.chunk, live, side, pin.bandOffset);
               ExtractDispatch.ColumnRecord neighborRec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(neighborKey);
               pin.captureSideLight(side, live, neighborRec != null && neighborRec.lightReady);
               pin.captureSideTint(side, live);
               pin.finishSide = side + 1;
               chargeCapture(Math.max(0L, System.nanoTime() - start));
            }
         }
      }

      for (int corner = 0; corner < 4; corner++) {
         long cornerKey = columnKey(pin.chunkX + ShellExtractor.CORNER_DX[corner], pin.chunkZ + ShellExtractor.CORNER_DZ[corner]);
         Pin cornerPin = pinIndex == null ? null : (Pin)pinIndex.get(cornerKey);
         if (cornerPin != null && cornerPin != pin) {
            pin.diagPin[corner] = cornerPin;
         } else {
            LevelChunk liveCorner = source == null
               ? null
               : source.getChunk(pin.chunkX + ShellExtractor.CORNER_DX[corner], pin.chunkZ + ShellExtractor.CORNER_DZ[corner], false);
            if (liveCorner != null) {
               pin.captureDiagTint(corner, liveCorner);
            }
         }
      }

      if (!pin.live) {
         pin.version = rec.liveVersion;
      }

      if (rec.pin != pin) {
         detachPin(rec, false);
      }

      rec.pin = pin;
      rec.jobClass = 0;
      if (pin.live) {
         rec.writingVersion = pin.version;
         PinWorker.enqueue(pin);
         return true;
      }

      rec.state = 2;
      pinnedGauge++;
      farSavePins.increment();
      admitHeapBackstop();
      ArrayDeque<Pin> admitted = admittedPins;
      if (admitted == null) {
         admitted = new ArrayDeque<>(64);
         admittedPins = admitted;
      }

      admitted.addLast(pin);

      while (!admitted.isEmpty() && admitted.peekFirst().released) {
         admitted.pollFirst();
      }

      if (pinnedGauge > 65536) {
         farSavePinTripwire.increment();
         assert false : "pin population past PIN_HARD_CAP: settles are leaking";
      }

      if (rec.writingVersion == 0L) {
         rec.writingVersion = pin.version;
         PinWorker.enqueue(pin);
      }

      return true;
   }

   private static void admitHeapBackstop() {
      Runtime runtime = Runtime.getRuntime();
      long free = runtime.maxMemory() - runtime.totalMemory() + runtime.freeMemory();
      if (free >= runtime.maxMemory() / 10L) {
         e9BreachSinceNanos = Long.MIN_VALUE;
      } else {
         long now = System.nanoTime();
         if (e9BreachSinceNanos == Long.MIN_VALUE) {
            e9BreachSinceNanos = now;
         } else if (now - e9BreachSinceNanos >= 100000000L) {
            ArrayDeque<Pin> admitted = admittedPins;
            if (admitted != null) {
               int released = 0;

               while (released < 64 && !admitted.isEmpty()) {
                  Pin oldest = admitted.pollFirst();
                  ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(oldest.key);
                  if (rec != null && rec.pin == oldest) {
                     releasePin(rec);
                     leaveBehind(rec);
                     farSaveLost.increment();
                     released++;
                  }
               }
            }
         }
      }
   }

   private static void drainPinResults() {
      Pin pin;
      while ((pin = PinWorker.pollResult()) != null) {
         ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(pin.key);
         if (rec != null && rec.pin == pin) {
            switch (pin.walkOutcome) {
               case 0:
                  rec.writingQuality = pin.walkQuality;
                  break;
               case 1:
                  rec.storedVersion = Math.max(rec.storedVersion, pin.version);
                  rec.quality = (byte)(pin.walkQuality | 64);
                  rec.writingVersion = 0L;
                  if (rec.state == 2 && rec.liveVersion <= rec.storedVersion) {
                     settleGoneSaved(rec);
                  } else if (rec.state == 1) {
                     if (rec.liveVersion <= rec.storedVersion) {
                        rec.state = 0;
                        rec.jobClass = 0;
                     } else {
                        refileJob(rec, pin.key);
                     }
                  }

                  releasePin(rec);
                  break;
               case 2:
                  rec.writingVersion = 0L;
                  if (rec.state == 2) {
                     leaveBehind(rec);
                  } else if (rec.state == 1) {
                     refileJob(rec, pin.key);
                  }

                  releasePin(rec);
                  break;
               default:
                  throw new IllegalStateException("unknown pin outcome " + pin.walkOutcome);
            }
         }
      }
   }

   static boolean lateralLightReady(int x, int z) {
      ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(columnKey(x, z));
      return rec != null && rec.lightReady;
   }

   private static void recordPinCaptureNanos(long nanos) {
      long clamped = Math.max(1L, nanos);
      int bucket = Math.min(pinCaptureNanosBuckets.length - 1, 64 - Long.numberOfLeadingZeros(clamped));
      pinCaptureNanosBuckets[bucket]++;
      pinCaptureSamples++;
      if (nanos > pinCaptureMaxNanos) {
         pinCaptureMaxNanos = nanos;
      }
   }

   public static String pinCaptureNanosSummary() {
      long n = pinCaptureSamples;
      return n == 0L
         ? "no pins captured"
         : "n="
            + n
            + " p50<="
            + formatNanos(captureRankUpperBound(n / 2L + 1L))
            + " p95<="
            + formatNanos(captureRankUpperBound((n * 95L + 99L) / 100L))
            + " max="
            + formatNanos(pinCaptureMaxNanos);
   }

   private static long captureRankUpperBound(long rank) {
      long seen = 0L;

      for (int i = 0; i < pinCaptureNanosBuckets.length; i++) {
         seen += pinCaptureNanosBuckets[i];
         if (seen >= rank) {
            return 1L << i;
         }
      }

      return pinCaptureMaxNanos;
   }

   private static String formatNanos(long nanos) {
      if (nanos >= 1000000L) {
         return nanos / 1000000L + "ms";
      } else {
         return nanos >= 1000L ? nanos / 1000L + "us" : nanos + "ns";
      }
   }

   public static ExtractDispatch.PerfStats captureCostStats() {
      return captureCostHistogram.stats();
   }

   public static ExtractDispatch.PerfStats sliceSpendStats() {
      return sliceSpendHistogram.stats();
   }

   public static ExtractDispatch.PerfStats sliceOverrunStats() {
      return sliceOverrunHistogram.stats();
   }

   public static ExtractDispatch.PerfStats sliceBudgetStats() {
      return sliceBudgetHistogram.stats();
   }

   public static void resetPerfStats() {
      captureCostHistogram.reset();
      sliceSpendHistogram.reset();
      sliceOverrunHistogram.reset();
      sliceBudgetHistogram.reset();
   }

   private static void recordClosingSlice() {
      if (sliceBudgetNanos > 0L) {
         sliceBudgetHistogram.record(sliceBudgetNanos);
      }

      if (sliceSpentNanos > 0L) {
         sliceSpendHistogram.record(sliceSpentNanos);
         long overrun = sliceSpentNanos - sliceBudgetNanos;
         if (overrun > 0L) {
            sliceOverrunHistogram.record(overrun);
         }
      }
   }

   private static void sweepLoadedWindow(int centerChunkX, int centerChunkZ, int radiusChunks, int probes) {
      if (radiusChunks > 0) {
         Minecraft minecraft = Minecraft.getInstance();
         ClientLevel level = minecraft == null ? null : minecraft.level;
         if (level != null) {
            ChunkSource source = level.getChunkSource();
            noteLevelObject(level);
            if (sweepRing > radiusChunks || sweepRing < 0) {
               wrapSweep();
            }

            for (int probe = 0; probe < probes; probe++) {
               int r = sweepRing;
               int perimeter = r == 0 ? 1 : 8 * r;
               if (sweepIndex >= perimeter || sweepIndex < 0) {
                  sweepIndex = 0;
               }

               int x = centerChunkX + ringDx(r, sweepIndex);
               int z = centerChunkZ + ringDz(r, sweepIndex);
               if (++sweepIndex >= perimeter) {
                  sweepIndex = 0;
                  if (++sweepRing > radiusChunks) {
                     wrapSweep();
                  }
               }

               long key = columnKey(x, z);
               LevelChunk chunk = source.getChunk(x, z, false);
               if (chunk == null) {
                  if (leavingCount() == 0) {
                     ExtractDispatch.ColumnRecord stale = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(key);
                     if (stale != null && stale.writingVersion == 0L) {
                        if (stale.state == 0) {
                           settleGoneSaved(stale);
                        } else if (stale.state == 1) {
                           leaveBehind(stale);
                        }
                     }
                  }
               } else {
                  ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(key);
                  if (rec == null) {
                     if (neighborsLoaded(source, x, z)) {
                        rec = ensureRecord(key);
                        fileFill(rec, key);
                        farExtractSweepExtracts.increment();
                        sweepOwedThisPass++;
                     }
                  } else {
                     boolean dirty = rec.liveVersion > rec.storedVersion;
                     if (!dirty) {
                        boolean whole = (rec.quality & 65) != 0;
                        if (rec.state == 0 && rec.writingVersion == 0L) {
                           if (chunk.isUnsaved()) {
                              rec.liveVersion = ++nextStamp;
                              rec.state = 1;
                              fileFill(rec, key);
                              farExtractStaleFiled.increment();
                              farExtractSweepExtracts.increment();
                              sweepOwedThisPass++;
                           } else if (!whole && rec.lightReady && neighborsLoaded(source, x, z)) {
                              rec.liveVersion = ++nextStamp;
                              rec.state = 1;
                              fileFill(rec, key);
                              farExtractSweepExtracts.increment();
                              sweepOwedThisPass++;
                           }
                        }
                     } else if (rec.state == 1
                        && rec.jobClass == 0
                        && rec.writingVersion == 0L
                        && rec.pin == null
                        && (rec.storedVersion > 0L || neighborsLoaded(source, x, z))) {
                        fileFill(rec, key);
                        farExtractSweepExtracts.increment();
                        sweepOwedThisPass++;
                     }
                  }
               }
            }
         }
      }
   }

   private static void resetSweep() {
      sweepRing = 0;
      sweepIndex = 0;
      sweepOwedThisPass = 0;
      farExtractSweepOwed.reset();
      censusCache = null;
      censusCacheMillis = Long.MIN_VALUE;
   }

   private static void wrapSweep() {
      sweepRing = 0;
      sweepIndex = 0;
      farExtractSweepOwed.reset();
      farExtractSweepOwed.add(sweepOwedThisPass);
      sweepOwedThisPass = 0;
   }

   private static int ringDx(int r, int i) {
      if (r == 0) {
         return 0;
      } else {
         int top = 2 * r + 1;
         int side = 2 * r - 1;
         if (i < top) {
            return -r + i;
         } else if (i < top + side) {
            return r;
         } else {
            return i < top + side + top ? r - (i - top - side) : -r;
         }
      }
   }

   private static int ringDz(int r, int i) {
      if (r == 0) {
         return 0;
      } else {
         int top = 2 * r + 1;
         int side = 2 * r - 1;
         if (i < top) {
            return -r;
         } else if (i < top + side) {
            return -r + 1 + (i - top);
         } else {
            return i < top + side + top ? r : r - 1 - (i - top - side - top);
         }
      }
   }

   public static void onViewRadiusShrink(int newRadius) {
      if (armed) {
         int prev = lastViewRadius;
         lastViewRadius = newRadius;
         if (prev >= 0 && newRadius < prev) {
            if (viewCenterKnown) {
               Minecraft minecraft = Minecraft.getInstance();
               ClientLevel level = minecraft == null ? null : minecraft.level;
               if (level != null) {
                  captureLeaving(
                     level.getChunkSource(),
                     lastViewCenterX,
                     lastViewCenterZ,
                     Math.max(2, prev) + 3,
                     lastViewCenterX,
                     lastViewCenterZ,
                     Math.max(2, newRadius) + 3
                  );
               }
            }
         }
      }
   }

   private static void captureLeaving(ChunkSource source, int oldCx, int oldCz, int oldRange, int keepCx, int keepCz, int keepRange) {
      ArrayList<Pin> pending = leavingPins;
      if (pending == null) {
         pending = new ArrayList<>(256);
         leavingPins = pending;
      }

      long start = System.nanoTime();
      long lightDeadline = start + 250000000L;
      long hardDeadline = start + 400000000L;
      Pin.Settings settings = Pin.Settings.snapshot();
      boolean lightOpen = true;
      boolean open = true;
      int cells = 0;
      if (oldCx == keepCx && oldCz == keepCz) {
         for (int r = keepRange + 1; r <= oldRange && open; r++) {
            int perimeter = 8 * r;

            for (int i = 0; i < perimeter; i++) {
               if ((++cells & 0xFF) == 0) {
                  long now = System.nanoTime();
                  lightOpen = now <= lightDeadline;
                  if (now > hardDeadline) {
                     open = false;
                     farSaveCaptureSkipped.add(annulusCells(oldRange, keepRange) - cells);
                     break;
                  }
               }

               captureLeavingCell(source, oldCx + ringDx(r, i), oldCz + ringDz(r, i), pending, lightOpen, settings);
            }
         }
      } else {
         int lowKeepX = Math.max(oldCx - oldRange, keepCx - keepRange);
         int highKeepX = Math.min(oldCx + oldRange, keepCx + keepRange);

         for (int x = oldCx - oldRange; x <= oldCx + oldRange; x++) {
            boolean keptColumn = x >= lowKeepX && x <= highKeepX;

            for (int z = oldCz - oldRange; z <= oldCz + oldRange; z++) {
               if (keptColumn && z >= keepCz - keepRange && z <= keepCz + keepRange) {
                  z = keepCz + keepRange;
               } else {
                  if ((++cells & 0xFF) == 0) {
                     long now = System.nanoTime();
                     lightOpen = now <= lightDeadline;
                     if (now > hardDeadline) {
                        farSaveCaptureSkipped.increment();
                        return;
                     }
                  }

                  captureLeavingCell(source, x, z, pending, lightOpen, settings);
               }
            }
         }
      }
   }

   private static long annulusCells(int oldRange, int keepRange) {
      long outer = (2L * oldRange + 1L) * (2L * oldRange + 1L);
      long inner = (2L * keepRange + 1L) * (2L * keepRange + 1L);
      return outer - inner;
   }

   private static void captureLeavingCell(ChunkSource source, int x, int z, ArrayList<Pin> pending, boolean captureLight, Pin.Settings settings) {
      LevelChunk leaving = source.getChunk(x, z, false);
      if (leaving != null) {
         long key = columnKey(x, z);
         ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(key);
         if (rec == null || rec.state == 0 || rec.state == 1) {
            if (rec != null && rec.liveVersion <= rec.storedVersion) {
               if ((rec.quality & 65) == 0) {
                  farSaveDegradedLeft.increment();
               }

               settleGoneSaved(rec);
            } else {
               if (!captureLight) {
                  farSaveLightUncaptured.increment();
               }

               long startNanos = System.nanoTime();
               Pin pin = Pin.capture(key, leaving, rec != null && rec.lightReady, captureLight, settings);
               registerPin(pin);
               recordPinCaptureNanos(System.nanoTime() - startNanos);
               pending.add(pin);
            }
         }
      }
   }

   private static void drainLeavingCaptures() {
      ArrayList<Pin> pending = leavingPins;
      if (pending != null && !pending.isEmpty()) {
         Object level = lastLevel.get();
         int drained = 0;

         while (leavingHead < pending.size() && drained++ < 4096) {
            Pin pin = pending.get(leavingHead);
            if (pinIndex == null || pinIndex.get(pin.key) != pin) {
               pin.released = true;
               leavingHead++;
            } else if (pin.chunk.getLevel() != level) {
               dismissPin(pin);
               leavingHead++;
            } else {
               ChunkSource source = pin.chunk.getLevel().getChunkSource();
               if (source.getChunk(pin.chunkX, pin.chunkZ, false) != null) {
                  dismissPin(pin);
                  leavingHead++;
               } else {
                  ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(pin.key);
                  if (rec != null && rec.state != 0 && rec.state != 1) {
                     dismissPin(pin);
                     leavingHead++;
                  } else if (rec != null && rec.liveVersion <= rec.storedVersion) {
                     if ((rec.quality & 65) == 0) {
                        farSaveDegradedLeft.increment();
                     }

                     settleGoneSaved(rec);
                     dismissPin(pin);
                     leavingHead++;
                  } else {
                     if (rec == null) {
                        rec = ensureRecord(pin.key);
                        rec.lightReady = false;
                     }

                     if (!finishPin(rec, pin)) {
                        return;
                     }

                     leavingHead++;
                  }
               }
            }
         }

         if (leavingHead >= pending.size()) {
            pending.clear();
            leavingHead = 0;
         } else if (leavingHead > 4096 && leavingHead * 2 >= pending.size()) {
            pending.subList(0, leavingHead).clear();
            leavingHead = 0;
         }
      }
   }

   private static void dropLiveCaptures() {
      ArrayList<Pin> pending = liveCaptures;
      if (pending != null && !pending.isEmpty()) {
         for (int i = liveCaptureHead; i < pending.size(); i++) {
            Pin pin = pending.get(i);
            ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(pin.key);
            if (rec != null && rec.pin == pin) {
               releasePin(rec);
            } else {
               dismissPin(pin);
            }
         }

         pending.clear();
         liveCaptureHead = 0;
      }
   }

   private static void dismissPin(Pin pin) {
      pin.released = true;
      if (pinIndex != null && pinIndex.get(pin.key) == pin) {
         pinIndex.remove(pin.key);
      }
   }

   private static int leavingCount() {
      ArrayList<Pin> pending = leavingPins;
      return pending == null ? 0 : pending.size() - leavingHead;
   }

   private static void dropLeavingCaptures() {
      ArrayList<Pin> pending = leavingPins;
      if (pending != null && !pending.isEmpty()) {
         for (int i = leavingHead; i < pending.size(); i++) {
            Pin pin = pending.get(i);
            if (pinIndex != null && pinIndex.get(pin.key) != pin) {
               pin.released = true;
            } else {
               ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(pin.key);
               if (rec == null || rec.liveVersion > rec.storedVersion) {
                  farSaveLeftUnsaved.increment();
               }

               dismissPin(pin);
            }
         }

         pending.clear();
         leavingHead = 0;
      }
   }

   private static void countUnsavedAtReset() {
      Long2ObjectOpenHashMap<ExtractDispatch.ColumnRecord> map = columns;
      if (map != null && !map.isEmpty()) {
         int unsaved = 0;
         ObjectIterator<Entry<ExtractDispatch.ColumnRecord>> it = map.long2ObjectEntrySet().fastIterator();

         while (it.hasNext()) {
            byte state = ((ExtractDispatch.ColumnRecord)((Entry)it.next()).getValue()).state;
            if (state == 1 || state == 4) {
               unsaved++;
            }
         }

         if (unsaved > 0) {
            farSaveLeftUnsaved.add(unsaved);
         }
      }
   }

   public static void onViewCenterMove(int newCenterX, int newCenterZ) {
      if (armed) {
         boolean known = viewCenterKnown;
         int prevX = lastViewCenterX;
         int prevZ = lastViewCenterZ;
         lastViewCenterX = newCenterX;
         lastViewCenterZ = newCenterZ;
         viewCenterKnown = true;
         if (known && lastViewRadius >= 0 && (prevX != newCenterX || prevZ != newCenterZ)) {
            Minecraft minecraft = Minecraft.getInstance();
            ClientLevel level = minecraft == null ? null : minecraft.level;
            if (level != null) {
               int range = Math.max(2, lastViewRadius) + 3;
               captureLeaving(level.getChunkSource(), prevX, prevZ, range, newCenterX, newCenterZ, range);
            }
         }
      }
   }

   public static void onLevelSwap() {
      dropLeavingCaptures();
      dropLiveCaptures();
      if (FarField.ioDead()) {
         abandonPins();
      } else {
         handHeldPinsToWorker();
      }

      countUnsavedAtReset();
      resetRecords();
      resetSweep();
      lastViewRadius = -1;
      viewCenterKnown = false;
   }

   private static void handHeldPinsToWorker() {
      Long2ObjectOpenHashMap<ExtractDispatch.ColumnRecord> map = columns;
      if (map != null && pinnedGauge != 0) {
         ObjectIterator<Entry<ExtractDispatch.ColumnRecord>> it = map.long2ObjectEntrySet().fastIterator();

         while (it.hasNext()) {
            ExtractDispatch.ColumnRecord rec = (ExtractDispatch.ColumnRecord)((Entry)it.next()).getValue();
            if (rec.state == 2 && rec.pin != null && rec.writingVersion != rec.pin.version) {
               PinWorker.enqueue(rec.pin);
            }
         }
      }
   }

   private static void noteLevel(LevelChunk chunk) {
      noteLevelObject(chunk.getLevel());
   }

   private static void noteLevelObject(Object level) {
      if (level != lastLevel.get()) {
         lastLevel = new WeakReference<>(level);
         dropLeavingCaptures();
         if (FarField.ioDead()) {
            abandonPins();
         } else {
            handHeldPinsToWorker();
         }

         countUnsavedAtReset();
         resetRecords();
         resetSweep();
      }
   }

   private static void resetRecords() {
      if (columns != null) {
         columns.clear();
      }

      editQueue.reset();
      fillQueue.reset();
      if (editPendingKeys != null) {
         editPendingKeys.clear();
         editPendingDue.clear();
         editPendingHead = 0;
      }

      farSaveBehindGauge = 0L;
      if (pinIndex != null) {
         pinIndex.clear();
      }

      if (admittedPins != null) {
         admittedPins.clear();
      }

      pinnedGauge = 0;
      if (liveCaptures != null) {
         liveCaptures.clear();
      }

      liveCaptureHead = 0;
      liveCaptureGauge = 0;
      e9BreachSinceNanos = Long.MIN_VALUE;
   }

   private static ExtractDispatch.ColumnRecord ensureRecord(long key) {
      Long2ObjectOpenHashMap<ExtractDispatch.ColumnRecord> map = columns;
      if (map == null) {
         map = new Long2ObjectOpenHashMap(4096);
         columns = map;
      }

      ExtractDispatch.ColumnRecord rec = (ExtractDispatch.ColumnRecord)map.get(key);
      if (rec != null) {
         return rec;
      }

      if (map.size() >= 262144 && !evictionTriedThisSlice) {
         evictionTriedThisSlice = true;
         evictFarthestSaved(map);
      }

      rec = new ExtractDispatch.ColumnRecord();
      rec.liveVersion = ++nextStamp;
      rec.state = 1;
      rec.lightReady = true;
      map.put(key, rec);
      return rec;
   }

   private static void evictFarthestSaved(Long2ObjectOpenHashMap<ExtractDispatch.ColumnRecord> map) {
      int camX = lastSliceCameraX;
      int camZ = lastSliceCameraZ;
      int savedCount = 0;
      ObjectIterator<Entry<ExtractDispatch.ColumnRecord>> it = map.long2ObjectEntrySet().fastIterator();

      while (it.hasNext()) {
         ExtractDispatch.ColumnRecord rec = (ExtractDispatch.ColumnRecord)((Entry)it.next()).getValue();
         if (rec.state == 3 && rec.writingVersion == 0L) {
            savedCount++;
         }
      }

      if (savedCount != 0) {
         long[] keys = new long[savedCount];
         long[] order = new long[savedCount];
         int n = 0;
         ObjectIterator<Entry<ExtractDispatch.ColumnRecord>> itx = map.long2ObjectEntrySet().fastIterator();

         while (itx.hasNext()) {
            Entry<ExtractDispatch.ColumnRecord> entry = (Entry<ExtractDispatch.ColumnRecord>)itx.next();
            ExtractDispatch.ColumnRecord rec = (ExtractDispatch.ColumnRecord)entry.getValue();
            if (rec.state == 3 && rec.writingVersion == 0L) {
               long key = entry.getLongKey();
               long dist = chebyshev(columnX(key), columnZ(key), camX, camZ);
               keys[n] = key;
               order[n] = Math.min(dist, 4194303L) << 24 | n;
               n++;
            }
         }

         Arrays.sort(order, 0, n);
         int evict = Math.max(1, n / 4);

         for (int i = n - evict; i < n; i++) {
            map.remove(keys[(int)(order[i] & 16777215L)]);
         }
      }
   }

   private static void abandonPins() {
      Long2ObjectOpenHashMap<ExtractDispatch.ColumnRecord> map = columns;
      if (map != null && (pinnedGauge != 0 || liveCaptureGauge != 0)) {
         ObjectIterator<Entry<ExtractDispatch.ColumnRecord>> it = map.long2ObjectEntrySet().fastIterator();

         while (it.hasNext()) {
            ExtractDispatch.ColumnRecord rec = (ExtractDispatch.ColumnRecord)((Entry)it.next()).getValue();
            if (rec.pin != null) {
               if (rec.pin.live) {
                  releasePin(rec);
                  rec.writingVersion = 0L;
               } else if (rec.state == 2) {
                  releasePin(rec);
                  leaveBehind(rec);
                  farSaveLost.increment();
               }
            }
         }

         if (admittedPins != null) {
            admittedPins.clear();
         }
      }
   }

   public static boolean columnDirty(long key) {
      ExtractDispatch.ColumnRecord rec = columns == null ? null : (ExtractDispatch.ColumnRecord)columns.get(key);
      return rec != null && rec.liveVersion > rec.storedVersion;
   }

   public static long farSaveBehind() {
      return farSaveBehindGauge;
   }

   public static void forgetExtractedColumns() {
      Long2ObjectOpenHashMap<ExtractDispatch.ColumnRecord> map = columns;
      if (map != null) {
         ObjectIterator<Entry<ExtractDispatch.ColumnRecord>> it = map.long2ObjectEntrySet().fastIterator();

         while (it.hasNext()) {
            Entry<ExtractDispatch.ColumnRecord> entry = (Entry<ExtractDispatch.ColumnRecord>)it.next();
            ExtractDispatch.ColumnRecord rec = (ExtractDispatch.ColumnRecord)entry.getValue();
            switch (rec.state) {
               case 2:
                  rec.storedVersion = 0L;
                  rec.quality = 0;
                  break;
               case 3:
                  it.remove();
                  break;
               case 4:
                  repairBehind(rec);
                  farSaveLeftUnsaved.increment();
                  it.remove();
                  break;
               default:
                  rec.storedVersion = 0L;
                  rec.quality = 0;
                  rec.writingVersion = 0L;
                  if (rec.state == 0) {
                     rec.state = 1;
                  }

                  rec.jobClass = 0;
                  rec.filedEdit = false;
                  rec.filedFill = false;
            }
         }
      }

      editQueue.reset();
      fillQueue.reset();
      if (editPendingKeys != null) {
         editPendingKeys.clear();
         editPendingDue.clear();
         editPendingHead = 0;
      }

      resetSweep();
   }

   private static long columnKey(int x, int z) {
      return (long)x << 32 | z & 4294967295L;
   }

   private static int columnX(long key) {
      return (int)(key >> 32);
   }

   private static int columnZ(long key) {
      return (int)key;
   }

   static final class ColumnRecord {
      long liveVersion;
      long storedVersion;
      long writingVersion;
      byte writingQuality;
      byte quality;
      byte state;
      byte jobClass;
      boolean filedEdit;
      boolean filedFill;
      long editStampMs;
      boolean lightReady;
      long lightNoiseRun;
      Pin pin;
   }

   private static final class JobQueue {
      final byte jobClass;
      final boolean edit;
      LongArrayList[] rings;
      int[] heads;
      int queued;
      int minRing;
      int poppedRing;

      JobQueue(byte jobClass, boolean edit) {
         this.jobClass = jobClass;
         this.edit = edit;
      }

      boolean filed(ExtractDispatch.ColumnRecord rec) {
         return this.edit ? rec.filedEdit : rec.filedFill;
      }

      void setFiled(ExtractDispatch.ColumnRecord rec, boolean value) {
         if (this.edit) {
            rec.filedEdit = value;
         } else {
            rec.filedFill = value;
         }
      }

      void file(ExtractDispatch.ColumnRecord rec, long key, int ring) {
         if (!this.filed(rec)) {
            if (this.rings == null) {
               this.rings = new LongArrayList[256];
               this.heads = new int[256];
            }

            LongArrayList bucket = this.rings[ring];
            if (bucket == null) {
               bucket = new LongArrayList(16);
               this.rings[ring] = bucket;
            }

            bucket.add(key);
            this.setFiled(rec, true);
            this.queued++;
            if (ring < this.minRing) {
               this.minRing = ring;
            }
         }
      }

      long pop() {
         LongArrayList[] r = this.rings;
         if (r != null) {
            for (int i = this.minRing; i < 256; i++) {
               LongArrayList bucket = r[i];
               if (bucket != null) {
                  int head = this.heads[i];
                  if (head < bucket.size()) {
                     long key = bucket.getLong(head++);
                     if (head >= bucket.size()) {
                        bucket.clear();
                        this.heads[i] = 0;
                     } else if (head * 2 >= bucket.size()) {
                        bucket.removeElements(0, head);
                        this.heads[i] = 0;
                     } else {
                        this.heads[i] = head;
                     }

                     this.poppedRing = i;
                     this.minRing = i;
                     return key;
                  }

                  bucket.clear();
                  this.heads[i] = 0;
               }
            }
         }

         this.minRing = 255;
         return Long.MIN_VALUE;
      }

      void reset() {
         this.rings = null;
         this.heads = null;
         this.queued = 0;
         this.minRing = 0;
      }
   }

   private static final class PerfHistogram {
      private final int[] buckets = new int[320];
      private long samples;
      private long min = Long.MAX_VALUE;
      private long max;
      private long total;

      void record(long nanos) {
         long value = Math.max(1L, nanos);
         int exp = 63 - Long.numberOfLeadingZeros(value);
         int sub = exp >= 3 ? (int)(value >>> exp - 3 & 7L) : (int)(value << 3 - exp & 7L);
         this.buckets[Math.min(319, exp * 8 + sub)]++;
         this.samples++;
         this.total += nanos;
         if (nanos < this.min) {
            this.min = nanos;
         }

         if (nanos > this.max) {
            this.max = nanos;
         }
      }

      void reset() {
         Arrays.fill(this.buckets, 0);
         this.samples = 0L;
         this.min = Long.MAX_VALUE;
         this.max = 0L;
         this.total = 0L;
      }

      ExtractDispatch.PerfStats stats() {
         return this.samples == 0L
            ? new ExtractDispatch.PerfStats(0L, 0L, 0L, 0L, 0L, 0L, 0L)
            : new ExtractDispatch.PerfStats(
               this.samples,
               this.min,
               this.rankUpperBound(this.samples / 2L + 1L),
               this.rankUpperBound((this.samples * 95L + 99L) / 100L),
               this.rankUpperBound((this.samples * 99L + 99L) / 100L),
               this.max,
               this.total
            );
      }

      private long rankUpperBound(long rank) {
         long seen = 0L;

         for (int i = 0; i < this.buckets.length; i++) {
            seen += this.buckets[i];
            if (seen >= rank) {
               return Math.min(this.max, bucketUpperBound(i));
            }
         }

         return this.max;
      }

      private static long bucketUpperBound(int index) {
         int exp = index / 8;
         int sub = index % 8;
         return (long)(8 + sub + 1) << exp >>> 3;
      }
   }

   public record PerfStats(long samples, long minNanos, long p50Nanos, long p95Nanos, long p99Nanos, long maxNanos, long totalNanos) {
   }

   public static final class SaveCensus {
      public final int savedWhole;
      public final int savedDegraded;
      public final int waiting;
      public final int stale;

      SaveCensus(int savedWhole, int savedDegraded, int waiting, int stale) {
         this.savedWhole = savedWhole;
         this.savedDegraded = savedDegraded;
         this.waiting = waiting;
         this.stale = stale;
      }
   }
}
