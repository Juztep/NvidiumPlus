package nvidiumplus.engine.farfield.extract;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.PalettedContainerRO;
import net.minecraft.world.level.chunk.UpgradeData;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.ticks.LevelChunkTicks;

final class ColumnSnapshot {
   private static final Types[] CAPTURED_HEIGHTMAPS = new Types[]{
      Types.WORLD_SURFACE, Types.MOTION_BLOCKING, Types.MOTION_BLOCKING_NO_LEAVES, Types.OCEAN_FLOOR
   };

   private ColumnSnapshot() {
   }

   static LevelChunk freeze(LevelChunk live) {
      LevelChunkSection[] liveSections = live.getSections();
      LevelChunkSection[] copies = new LevelChunkSection[liveSections.length];

      for (int i = 0; i < liveSections.length; i++) {
         LevelChunkSection section = liveSections[i];
         copies[i] = section == null ? null : section.copy();
      }

      LevelChunk snapshot = new LevelChunk(
         live.getLevel(), live.getPos(), UpgradeData.EMPTY, new LevelChunkTicks(), new LevelChunkTicks(), 0L, copies, null, null
      );

      for (Types type : CAPTURED_HEIGHTMAPS) {
         snapshot.setHeightmap(type, live.getOrCreateHeightmapUnprimed(type).getRawData());
      }

      return snapshot;
   }

   static ColumnSnapshot.TintBiomes biomeRefs(ChunkAccess live) {
      LevelChunkSection[] sections = live.getSections();
      List<PalettedContainerRO<Holder<Biome>>> refs = new ArrayList<>(sections.length);

      for (LevelChunkSection section : sections) {
         refs.add(section == null ? null : section.getBiomes());
      }

      return new ColumnSnapshot.TintBiomes(live.getMinSectionY(), live.getMinY(), live.getHeight(), refs);
   }

   static final class TintBiomes {
      private final int minSectionY;
      private final int minY;
      private final int height;
      private final List<PalettedContainerRO<Holder<Biome>>> bySection;

      TintBiomes(int minSectionY, int minY, int height, List<PalettedContainerRO<Holder<Biome>>> bySection) {
         this.minSectionY = minSectionY;
         this.minY = minY;
         this.height = height;
         this.bySection = bySection;
      }

      Holder<Biome> noiseBiome(int qx, int qy, int qz) {
         int lowQuart = QuartPos.fromBlock(this.minY);
         int highQuart = lowQuart + QuartPos.fromBlock(this.height) - 1;
         int quartY = Mth.clamp(qy, lowQuart, highQuart);
         int index = (QuartPos.toBlock(quartY) >> 4) - this.minSectionY;
         if (index >= 0 && index < this.bySection.size()) {
            PalettedContainerRO<Holder<Biome>> container = this.bySection.get(index);
            return container == null ? null : (Holder)container.get(qx & 3, quartY & 3, qz & 3);
         } else {
            return null;
         }
      }
   }
}
