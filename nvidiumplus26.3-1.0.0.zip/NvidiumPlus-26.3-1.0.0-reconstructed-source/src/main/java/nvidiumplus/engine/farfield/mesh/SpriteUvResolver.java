package nvidiumplus.engine.farfield.mesh;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.color.block.BlockTintSource;
import net.minecraft.client.model.geom.builders.UVPair;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.block.FluidModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.client.resources.model.geometry.BakedQuad.MaterialInfo;
import net.minecraft.client.resources.model.sprite.Material.Baked;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HalfTransparentBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import nvidiumplus.engine.compat.McCompat;
import nvidiumplus.engine.farfield.store.ShellCodec;
import nvidiumplus.engine.terrain.QuadFacing;
import org.joml.Vector3fc;

public final class SpriteUvResolver {
   public static final int FACES = 6;
   public static final int FACE_IDX_DOWN = 0;
   public static final int FACE_IDX_UP = 1;
   public static final int FACE_IDX_NORTH = 2;
   public static final int FACE_IDX_SOUTH = 3;
   public static final int FACE_IDX_WEST = 4;
   public static final int FACE_IDX_EAST = 5;
   public static final byte KIND_MISSING = 0;
   public static final byte KIND_BLOCK = 1;
   public static final byte KIND_FLUID = 2;
   public static final int WHITE_RGB = 16777215;
   static final float OVERLAY_NUDGE = 9.765625E-4F;
   static final float CELL_EPSILON = 2.0E-4F;
   static final float AXIS_EPSILON = 0.001F;
   private static final long MODEL_SEED = 42L;
   public static final int POS_STRIDE = 12;
   public static final int UV_STRIDE = 8;
   public static final byte NO_CULL = -1;
   public static final int NO_TINT_INDEX = -1;
   private static final Map<String, SpriteUvResolver.Entry> CACHE = new ConcurrentHashMap<>();
   private static final Map<BlockState, SpriteUvResolver.Entry> STATE_CACHE = new ConcurrentHashMap<>();
   private static final Map<BlockState, Integer> STATE_INDEX = new ConcurrentHashMap<>();
   private static final Map<Block, Integer> STATE_SIG = new ConcurrentHashMap<>();
   private static final SpriteUvResolver.Entry MISSING = new SpriteUvResolver.Entry(
      (byte)0, (byte)0, 16777215, -1, SpriteUvResolver.Quads.empty(), 0.0F, 0.0F, null
   );
   private static final int MAX_VARIANT_DRAWS = 64;
   public static final LongAdder farVariantProbeThrew = new LongAdder();
   public static final LongAdder farVariantMultiDraw = new LongAdder();
   public static final LongAdder farVariantOverBound = new LongAdder();
   public static final LongAdder farVariantNoGeometry = new LongAdder();
   private static final int OFFSET_PROBE_LIMIT = 4096;

   private static byte fluidFamilyOf(FluidState fluid) {
      if (fluid.isEmpty()) {
         return 0;
      } else if (fluid.getType().isSame(Fluids.WATER)) {
         return 1;
      } else {
         return (byte)(fluid.getType().isSame(Fluids.LAVA) ? 2 : 3);
      }
   }

   private SpriteUvResolver() {
   }

   public static SpriteUvResolver.ResolvedPalette resolve(ShellCodec.Shell shell) {
      String[] palette = shell.palette;
      SpriteUvResolver.Entry[] resolved = new SpriteUvResolver.Entry[palette.length];

      for (int i = 0; i < palette.length; i++) {
         resolved[i] = entryFor(palette[i], shell.stateIndex(i), shell.stateSig(i));
      }

      return assemble(palette.length, resolved);
   }

   public static SpriteUvResolver.ResolvedPalette resolve(String[] palette) {
      SpriteUvResolver.Entry[] resolved = new SpriteUvResolver.Entry[palette.length];

      for (int i = 0; i < palette.length; i++) {
         resolved[i] = entryFor(palette[i], -1, 0);
      }

      return assemble(palette.length, resolved);
   }

   private static SpriteUvResolver.Entry entryFor(String name, int stateIndex, int stateSig) {
      BlockState state = stateIndex == -1 ? null : storedState(name, stateIndex, stateSig);
      return state == null ? CACHE.computeIfAbsent(name, SpriteUvResolver::resolveOne) : entryOf(state);
   }

   private static SpriteUvResolver.Entry entryOf(BlockState state) {
      SpriteUvResolver.Entry known = STATE_CACHE.get(state);
      if (known != null) {
         return known;
      }

      SpriteUvResolver.Entry made;
      try {
         made = resolveState(state, Minecraft.getInstance().getModelManager());
      } catch (Throwable t) {
         made = MISSING;
      }

      if (made != MISSING) {
         STATE_CACHE.put(state, made);
      }

      return made;
   }

   private static BlockState storedState(String name, int stateIndex, int stateSig) {
      try {
         Identifier id = Identifier.tryParse(name);
         if (id == null) {
            return null;
         } else {
            Optional<Block> block = BuiltInRegistries.BLOCK.getOptional(id);
            if (block.isEmpty()) {
               return null;
            } else {
               Block b = block.get();
               if (stateSig != 0 && stateSig == stateSignatureOf(b)) {
                  BlockState state = stateAtIndex(b, stateIndex);
                  return state != null && !state.isAir() ? state : null;
               } else {
                  return null;
               }
            }
         }
      } catch (Throwable t) {
         return null;
      }
   }

   private static SpriteUvResolver.ResolvedPalette assemble(int entries, SpriteUvResolver.Entry[] resolved) {
      int doubling = 0;

      for (SpriteUvResolver.Entry e : resolved) {
         if (e.upper() != null) {
            doubling++;
         }
      }

      SpriteUvResolver.ResolvedPalette out = new SpriteUvResolver.ResolvedPalette(entries, doubling);
      int nextRow = entries;

      for (int i = 0; i < entries; i++) {
         SpriteUvResolver.Entry e = resolved[i];
         copyRow(out, i, e);
         if (out.upperRow != null) {
            if (e.upper() == null) {
               out.upperRow[i] = i;
            } else {
               out.upperRow[i] = nextRow;
               copyRow(out, nextRow++, e.upper());
            }
         }
      }

      return out;
   }

   private static void copyRow(SpriteUvResolver.ResolvedPalette out, int row, SpriteUvResolver.Entry e) {
      out.kind[row] = e.kind();
      out.emission[row] = e.emission();
      out.fallbackTint[row] = e.fallbackTint();
      out.quads[row] = e.quads();
      out.fluidHeight[row] = e.fluidHeight();
      out.fluidLook[row] = e.fluid();
      out.fullCube[row] = fillsCell(e.quads());
      out.offsetH[row] = e.offsetH();
      out.offsetV[row] = e.offsetV();
      if (e.offsetH() != 0.0F || e.offsetV() != 0.0F) {
         out.anyOffset = true;
      }

      out.variantQuads[row] = e.variants();
      out.variantUniform[row] = e.variantsUniform();
      out.glassy[row] = e.glassy();
      if (e.variants() != null) {
         out.anyVariants = true;
      }

      if (e.glassy()) {
         out.anyGlassy = true;
      }
   }

   private static boolean fillsCell(SpriteUvResolver.Quads q) {
      int seen = 0;

      for (int i = 0; i < q.count(); i++) {
         if (q.unit()[i] && q.shift()[i] == 0.0F && !q.overlay()[i]) {
            int f = q.facing()[i];
            if (f != QuadFacing.UNASSIGNED.ordinal()) {
               seen |= 1 << f;
            }
         }
      }

      return seen == 63;
   }

   public static void clearCache() {
      CACHE.clear();
      STATE_CACHE.clear();
   }

   public static boolean stateStorageAvailable() {
      try {
         Minecraft mc = Minecraft.getInstance();
         return mc != null && mc.getModelManager() != null;
      } catch (Throwable t) {
         return false;
      }
   }

   public static boolean sameAppearance(BlockState a, BlockState b) {
      if (a == b) {
         return true;
      }

      try {
         return !Minecraft.getInstance().getModelManager().requiresRender(a, b);
      } catch (Throwable t) {
         return false;
      }
   }

   public static int stateIndexOf(BlockState state) {
      try {
         Block block = state.getBlock();
         if (!STATE_INDEX.containsKey(state)) {
            List<BlockState> all = block.getStateDefinition().getPossibleStates();

            for (int i = 0; i < all.size(); i++) {
               STATE_INDEX.put(all.get(i), i);
            }
         }

         return STATE_INDEX.getOrDefault(state, -1);
      } catch (Throwable t) {
         return -1;
      }
   }

   private static BlockState stateAtIndex(Block block, int index) {
      try {
         List<BlockState> all = block.getStateDefinition().getPossibleStates();
         return index >= 0 && index < all.size() ? all.get(index) : null;
      } catch (Throwable t) {
         return null;
      }
   }

   public static int stateSignatureOf(Block block) {
      Integer known = STATE_SIG.get(block);
      if (known != null) {
         return known;
      }

      int hash = 0;

      try {
         StateDefinition<Block, BlockState> definition = block.getStateDefinition();
         hash = definition.getPossibleStates().size() * 31;

         for (Property<?> property : definition.getProperties()) {
            hash = hash * 31 + property.getName().hashCode();
            hash = hash * 31 + property.getPossibleValues().size();
         }
      } catch (Throwable t) {
         hash = 0;
      }

      int sig = hash & 65535;
      if (sig == 0) {
         sig = 1;
      }

      STATE_SIG.put(block, sig);
      return sig;
   }

   public static int sampleTint(BlockState state, BlockAndTintGetter level, BlockPos pos) {
      try {
         FluidState fluid = state.getFluidState();
         if (!fluid.isEmpty() && drawsAsFluid(state)) {
            return fluidTint(state, fluid, level, pos);
         }

         BlockColors colors = Minecraft.getInstance().getBlockColors();
         List<BlockTintSource> sources = colors.getTintSources(state);
         BlockTintSource source = tintSourceFor(sources, tintIndexOf(state));
         if (source != null) {
            return source.colorInWorld(state, level, pos) & 16777215;
         }

         if (!fluid.isEmpty()) {
            return fluidTint(state, fluid, level, pos);
         }
      } catch (Throwable var7) {
      }

      return 16777215;
   }

   public static int tintIndexOf(BlockState state) {
      try {
         return entryOf(state).tintIndex();
      } catch (Throwable t) {
         return -1;
      }
   }

   public static boolean hasTintSource(BlockState state) {
      try {
         FluidState fluid = state.getFluidState();
         if (!fluid.isEmpty() && drawsAsFluid(state)) {
            return fluidTintSource(fluid) != null;
         }

         BlockColors colors = Minecraft.getInstance().getBlockColors();
         List<BlockTintSource> sources = colors.getTintSources(state);
         return tintSourceFor(sources, tintIndexOf(state)) != null ? true : !fluid.isEmpty() && fluidTintSource(fluid) != null;
      } catch (Throwable t) {
         return false;
      }
   }

   private static int fluidTint(BlockState state, FluidState fluid, BlockAndTintGetter level, BlockPos pos) {
      BlockTintSource src = fluidTintSource(fluid);
      return src == null ? 16777215 : src.colorInWorld(state, level, pos) & 16777215;
   }

   private static BlockTintSource fluidTintSource(FluidState fluid) {
      FluidModel model = Minecraft.getInstance().getModelManager().getFluidStateModelSet().get(fluid);
      return model.tintSource();
   }

   private static boolean drawsAsFluid(BlockState state) {
      return kindOf(state) == 2;
   }

   public static byte kindOf(BlockState state) {
      try {
         Identifier id = BuiltInRegistries.BLOCK.getKey(state.getBlock());
         if (id == null) {
            return 0;
         }

         String name = id.toString();
         SpriteUvResolver.Entry entry = CACHE.get(name);
         if (entry == null) {
            entry = resolveOne(name);
            if (entry != MISSING) {
               CACHE.put(name, entry);
            }
         }

         return entry.kind();
      } catch (Throwable t) {
         return 0;
      }
   }

   private static SpriteUvResolver.Entry resolveOne(String name) {
      try {
         Identifier id = Identifier.tryParse(name);
         if (id == null) {
            return MISSING;
         }

         Optional<Block> block = BuiltInRegistries.BLOCK.getOptional(id);
         if (block.isEmpty()) {
            return MISSING;
         }

         BlockState state = block.get().defaultBlockState();
         if (state.isAir()) {
            return MISSING;
         }

         ModelManager models = Minecraft.getInstance().getModelManager();
         if (!state.hasProperty(BlockStateProperties.DOUBLE_BLOCK_HALF)) {
            return resolveState(state, models);
         }

         SpriteUvResolver.Entry lower = resolveState((BlockState)state.setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.LOWER), models);
         if (lower.kind() == 0) {
            return lower;
         }

         SpriteUvResolver.Entry upper;
         try {
            upper = resolveState((BlockState)state.setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.UPPER), models);
         } catch (Throwable t) {
            return lower;
         }

         return upper.kind() == lower.kind() ? lower.withUpper(upper) : lower;
      } catch (Throwable t) {
         return MISSING;
      }
   }

   private static SpriteUvResolver.Entry resolveState(BlockState state, ModelManager models) {
      SpriteUvResolver.Entry fromModel = resolveFromModel(state, models);
      if (fromModel != null) {
         return fromModel;
      }

      FluidState fluid = state.getFluidState();
      return fluid.isEmpty() ? MISSING : resolveFluid(state, fluid, models);
   }

   private static SpriteUvResolver.Entry resolveFromModel(BlockState state, ModelManager models) {
      BlockStateModel model = models.getBlockStateModelSet().get(state);
      List<BlockStateModelPart> parts = new ArrayList<>(4);
      model.collectParts(RandomSource.create(42L), parts);
      if (parts.isEmpty()) {
         return null;
      }

      List<BakedQuad> found = new ArrayList<>(16);
      List<Byte> culls = new ArrayList<>(16);
      collectQuads(parts, found, culls);
      if (found.isEmpty()) {
         return null;
      }

      int tintIndex = modelTintIndex(found);
      long offsets = offsetMagnitudes(state);
      SpriteUvResolver.Quads[] variants = enumerateVariants(model);
      Block block = state.getBlock();
      boolean glassy = block instanceof HalfTransparentBlock || block instanceof LeavesBlock;
      return new SpriteUvResolver.Entry(
         (byte)1,
         lightEmission(state),
         defaultBlockTint(state, tintIndex),
         tintIndex,
         buildQuads(found, culls),
         1.0F,
         Float.intBitsToFloat((int)(offsets >>> 32)),
         Float.intBitsToFloat((int)offsets),
         null,
         null,
         variants,
         variants == null || variantsUniform(variants),
         glassy
      );
   }

   private static void collectQuads(List<BlockStateModelPart> parts, List<BakedQuad> found, List<Byte> culls) {
      Direction[] dirs = Direction.values();
      Iterator var4 = parts.iterator();

      while (true) {
         List<BakedQuad> unculled;
         while (true) {
            if (!var4.hasNext()) {
               return;
            }

            BlockStateModelPart part = (BlockStateModelPart)var4.next();

            for (int f = 0; f < 6; f++) {
               for (BakedQuad q : part.getQuads(dirs[f])) {
                  found.add(q);
                  culls.add((byte)f);
               }
            }

            try {
               unculled = part.getQuads(null);
               break;
            } catch (Throwable t) {
            }
         }

         for (BakedQuad q : unculled) {
            found.add(q);
            culls.add((byte)-1);
         }
      }
   }

   private static SpriteUvResolver.Quads[] enumerateVariants(BlockStateModel model) {
      SpriteUvResolver.ForcedRandom probe = new SpriteUvResolver.ForcedRandom();
      List<BlockStateModelPart> parts = new ArrayList<>(4);

      try {
         probe.forced = 0;
         model.collectParts(probe, parts);
      } catch (Throwable t) {
         farVariantProbeThrew.increment();
         return null;
      }

      if (probe.draws == 0 && probe.others == 0) {
         return null;
      }

      if (probe.draws == 1 && probe.others == 0) {
         int bound = probe.bound;
         if (bound < 2) {
            return null;
         }

         if (bound > 64) {
            farVariantOverBound.increment();
            return null;
         }

         SpriteUvResolver.Quads[] variants = new SpriteUvResolver.Quads[bound];
         List<List<BlockStateModelPart>> seenParts = new ArrayList<>(4);
         List<SpriteUvResolver.Quads> seenTables = new ArrayList<>(4);
         int i = 0;

         label76:
         while (i < bound) {
            probe.forced = i;
            probe.draws = 0;
            probe.others = 0;
            parts = new ArrayList<>(4);

            try {
               model.collectParts(probe, parts);
            } catch (Throwable t) {
               farVariantProbeThrew.increment();
               return null;
            }

            if (probe.draws == 1 && probe.others == 0 && probe.bound == bound) {
               SpriteUvResolver.Quads table = null;
               int s = 0;

               while (true) {
                  if (s < seenParts.size()) {
                     if (!seenParts.get(s).equals(parts)) {
                        s++;
                        continue;
                     }

                     table = seenTables.get(s);
                  }

                  if (table == null) {
                     List<BakedQuad> found = new ArrayList<>(16);
                     List<Byte> culls = new ArrayList<>(16);
                     collectQuads(parts, found, culls);
                     if (found.isEmpty()) {
                        farVariantNoGeometry.increment();
                        return null;
                     }

                     table = buildQuads(found, culls);
                     seenParts.add(parts);
                     seenTables.add(table);
                  }

                  variants[i] = table;
                  i++;
                  continue label76;
               }
            }

            farVariantMultiDraw.increment();
            return null;
         }

         return seenTables.size() < 2 ? null : variants;
      } else {
         farVariantMultiDraw.increment();
         return null;
      }
   }

   private static boolean variantsUniform(SpriteUvResolver.Quads[] variants) {
      SpriteUvResolver.Quads first = variants[0];

      for (int i = 1; i < variants.length; i++) {
         SpriteUvResolver.Quads v = variants[i];
         if (v != first
            && (
               v.count() != first.count()
                  || !Arrays.equals(v.cull(), first.cull())
                  || !Arrays.equals(v.facing(), first.facing())
                  || !Arrays.equals(v.unit(), first.unit())
                  || !Arrays.equals(v.shift(), first.shift())
                  || !Arrays.equals(v.translucent(), first.translucent())
            )) {
            return false;
         }
      }

      return true;
   }

   private static long offsetMagnitudes(BlockState state) {
      try {
         if (!state.hasOffsetFunction()) {
            return 0L;
         }

         float maxH = 0.25F;
         float maxV = 0.0F;
         boolean gotH = false;
         boolean gotV = false;

         for (int x = 0; x < 4096 && (!gotH || !gotV); x++) {
            long s = ShellMesher.positionSeed(x, 0, 0);
            if (!gotH && (s & 15L) == 15L) {
               maxH = (float)state.getOffset(new BlockPos(x, 0, 0)).x;
               gotH = true;
            }

            if (!gotV && (s >>> 4 & 15L) == 0L) {
               maxV = (float)(-state.getOffset(new BlockPos(x, 0, 0)).y);
               gotV = true;
            }
         }

         if (!gotV) {
            maxV = 0.2F;
         }

         return (long)Float.floatToIntBits(Math.abs(maxH)) << 32 | Float.floatToIntBits(Math.abs(maxV)) & 4294967295L;
      } catch (Throwable t) {
         return 0L;
      }
   }

   private static int modelTintIndex(List<BakedQuad> found) {
      int best = -1;

      for (BakedQuad q : found) {
         int index = q.materialInfo().tintIndex();
         if (index >= 0 && (best == -1 || index < best)) {
            best = index;
         }
      }

      return best;
   }

   private static SpriteUvResolver.Quads buildQuads(List<BakedQuad> found, List<Byte> culls) {
      int n = found.size();
      float[] pos = new float[n * 12];
      float[] uv = new float[n * 8];
      byte[] cull = new byte[n];
      byte[] facing = new byte[n];
      byte[] cutoff = new byte[n];
      boolean[] translucent = new boolean[n];
      boolean[] tinted = new boolean[n];
      boolean[] shaded = new boolean[n];
      boolean[] unit = new boolean[n];
      boolean[] overlay = new boolean[n];
      float[] shift = new float[n];
      boolean[] flush = new boolean[n];

      for (int i = 0; i < n; i++) {
         BakedQuad q = found.get(i);
         int pb = i * 12;
         int ub = i * 8;

         for (int v = 0; v < 4; v++) {
            Vector3fc p = q.position(v);
            pos[pb + v * 3] = p.x();
            pos[pb + v * 3 + 1] = p.y();
            pos[pb + v * 3 + 2] = p.z();
            long packed = q.packedUV(v);
            uv[ub + v * 2] = UVPair.unpackU(packed);
            uv[ub + v * 2 + 1] = UVPair.unpackV(packed);
         }

         cull[i] = culls.get(i);
         QuadFacing f = facingOf(pos, pb);
         if (cull[i] != -1 && f != QuadFacing.UNASSIGNED && f.ordinal() != facingOrdinalOf(cull[i])) {
            reverseWinding(pos, pb, uv, ub);
            f = facingOf(pos, pb);
         }

         facing[i] = (byte)f.ordinal();
         MaterialInfo info = q.materialInfo();
         ChunkSectionLayer layer = info.layer();
         translucent[i] = layer == ChunkSectionLayer.TRANSLUCENT;
         cutoff[i] = (byte)(layer == ChunkSectionLayer.CUTOUT ? 2 : 0);
         tinted[i] = info.tintIndex() >= 0;
         shaded[i] = McCompat.quadShaded(info, q.direction());
         unit[i] = unitFace(pos, pb, f);
         shift[i] = unit[i] ? planeShift(pos, pb, f) : 0.0F;
         flush[i] = unit[i] && shift[i] == 0.0F;
      }

      float[] plane = new float[n];

      for (int i = 0; i < n; i++) {
         plane[i] = planeOf(pos, i * 12, facing[i]);
      }

      for (int i = 0; i < n; i++) {
         if (facing[i] != QuadFacing.UNASSIGNED.ordinal()) {
            int layers = 0;

            for (int j = 0; j < i; j++) {
               if (facing[j] == facing[i] && Math.abs(plane[j] - plane[i]) <= 2.0E-4F) {
                  layers++;
               }
            }

            if (layers != 0) {
               overlay[i] = true;
               nudge(pos, i * 12, facing[i], layers * 9.765625E-4F);
               if (unit[i]) {
                  shift[i] = planeShift(pos, i * 12, QuadFacing.byIndex(facing[i]));
               }
            }
         }
      }

      return new SpriteUvResolver.Quads(n, pos, uv, cull, facing, cutoff, translucent, tinted, shaded, unit, overlay, shift, flush);
   }

   private static QuadFacing facingOf(float[] pos, int base) {
      float ax = pos[base + 3] - pos[base];
      float ay = pos[base + 4] - pos[base + 1];
      float az = pos[base + 5] - pos[base + 2];
      float bx = pos[base + 6] - pos[base];
      float by = pos[base + 7] - pos[base + 1];
      float bz = pos[base + 8] - pos[base + 2];
      float nx = ay * bz - az * by;
      float ny = az * bx - ax * bz;
      float nz = ax * by - ay * bx;
      float mx = Math.abs(nx);
      float my = Math.abs(ny);
      float mz = Math.abs(nz);
      float max = Math.max(mx, Math.max(my, mz));
      if (max <= 0.0F) {
         return QuadFacing.UNASSIGNED;
      } else {
         float tol = max * 0.001F;
         if (mx == max && my <= tol && mz <= tol) {
            return nx > 0.0F ? QuadFacing.POS_X : QuadFacing.NEG_X;
         } else if (my == max && mx <= tol && mz <= tol) {
            return ny > 0.0F ? QuadFacing.POS_Y : QuadFacing.NEG_Y;
         } else if (mz == max && mx <= tol && my <= tol) {
            return nz > 0.0F ? QuadFacing.POS_Z : QuadFacing.NEG_Z;
         } else {
            return QuadFacing.UNASSIGNED;
         }
      }
   }

   private static int facingOrdinalOf(int faceIndex) {
      return switch (faceIndex) {
         case 0 -> QuadFacing.NEG_Y.ordinal();
         case 1 -> QuadFacing.POS_Y.ordinal();
         case 2 -> QuadFacing.NEG_Z.ordinal();
         case 3 -> QuadFacing.POS_Z.ordinal();
         case 4 -> QuadFacing.NEG_X.ordinal();
         default -> QuadFacing.POS_X.ordinal();
      };
   }

   private static void reverseWinding(float[] pos, int pb, float[] uv, int ub) {
      for (int c = 0; c < 3; c++) {
         float t = pos[pb + 3 + c];
         pos[pb + 3 + c] = pos[pb + 9 + c];
         pos[pb + 9 + c] = t;
      }

      for (int c = 0; c < 2; c++) {
         float t = uv[ub + 2 + c];
         uv[ub + 2 + c] = uv[ub + 6 + c];
         uv[ub + 6 + c] = t;
      }
   }

   private static int axisOf(QuadFacing facing) {
      return switch (facing) {
         case POS_X, NEG_X -> 0;
         case POS_Y, NEG_Y -> 1;
         case POS_Z, NEG_Z -> 2;
         default -> -1;
      };
   }

   private static boolean positive(QuadFacing facing) {
      return facing == QuadFacing.POS_X || facing == QuadFacing.POS_Y || facing == QuadFacing.POS_Z;
   }

   private static float planeOf(float[] pos, int base, int facingOrdinal) {
      int axis = axisOf(QuadFacing.byIndex(facingOrdinal));
      return axis < 0 ? 0.0F : pos[base + axis];
   }

   private static void nudge(float[] pos, int base, int facingOrdinal, float by) {
      QuadFacing facing = QuadFacing.byIndex(facingOrdinal);
      int axis = axisOf(facing);
      if (axis >= 0) {
         float delta = positive(facing) ? by : -by;

         for (int v = 0; v < 4; v++) {
            pos[base + v * 3 + axis] = pos[base + v * 3 + axis] + delta;
         }
      }
   }

   private static boolean unitFace(float[] pos, int base, QuadFacing facing) {
      int axis = axisOf(facing);
      if (axis < 0) {
         return false;
      }

      float plane = pos[base + axis];

      for (int v = 1; v < 4; v++) {
         if (Math.abs(pos[base + v * 3 + axis] - plane) > 2.0E-4F) {
            return false;
         }
      }

      for (int a = 0; a < 3; a++) {
         if (a != axis) {
            float lo = Float.MAX_VALUE;
            float hi = -Float.MAX_VALUE;

            for (int v = 0; v < 4; v++) {
               float c = pos[base + v * 3 + a];
               lo = Math.min(lo, c);
               hi = Math.max(hi, c);
            }

            if (Math.abs(lo) > 2.0E-4F || Math.abs(hi - 1.0F) > 2.0E-4F) {
               return false;
            }
         }
      }

      return true;
   }

   private static float planeShift(float[] pos, int base, QuadFacing facing) {
      int axis = axisOf(facing);
      return axis < 0 ? 0.0F : pos[base + axis] - (positive(facing) ? 1.0F : 0.0F);
   }

   private static SpriteUvResolver.Entry resolveFluid(BlockState state, FluidState fluid, ModelManager models) {
      FluidModel model = models.getFluidStateModelSet().get(fluid);
      TextureAtlasSprite still = model.stillMaterial().sprite();
      TextureAtlasSprite flowing = flowingSprite(model, still);
      float u0 = still.getU0();
      float v0 = still.getV0();
      float u1 = still.getU1();
      float v1 = still.getV1();
      float tu0 = u0;
      float tv0 = v0;
      float tu1 = u1;
      float tv1 = v1;
      float su0 = flowing.getU(0.0F);
      float sv0 = flowing.getV(0.0F);
      float su1 = flowing.getU(0.5F);
      float sv1 = flowing.getV(0.5F);
      boolean trans = model.layer() == ChunkSectionLayer.TRANSLUCENT;
      float[] pos = new float[]{
         0.0F,
         0.0F,
         0.0F,
         1.0F,
         0.0F,
         0.0F,
         1.0F,
         0.0F,
         1.0F,
         0.0F,
         0.0F,
         1.0F,
         0.0F,
         1.0F,
         0.0F,
         0.0F,
         1.0F,
         1.0F,
         1.0F,
         1.0F,
         1.0F,
         1.0F,
         1.0F,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         1.0F,
         0.0F,
         1.0F,
         1.0F,
         0.0F,
         1.0F,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         1.0F,
         1.0F,
         0.0F,
         1.0F,
         1.0F,
         1.0F,
         1.0F,
         0.0F,
         1.0F,
         1.0F,
         0.0F,
         0.0F,
         1.0F,
         0.0F,
         1.0F,
         1.0F,
         0.0F,
         1.0F,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         1.0F,
         0.0F,
         0.0F,
         1.0F,
         1.0F,
         0.0F,
         1.0F,
         1.0F,
         1.0F,
         1.0F,
         0.0F,
         1.0F
      };
      float[] uv = new float[]{
         u0,
         v0,
         u1,
         v0,
         u1,
         v1,
         u0,
         v1,
         tu0,
         tv0,
         tu0,
         tv1,
         tu1,
         tv1,
         tu1,
         tv0,
         su0,
         sv1,
         su0,
         sv0,
         su1,
         sv0,
         su1,
         sv1,
         su0,
         sv1,
         su1,
         sv1,
         su1,
         sv0,
         su0,
         sv0,
         su1,
         sv1,
         su1,
         sv0,
         su0,
         sv0,
         su0,
         sv1,
         su0,
         sv1,
         su0,
         sv0,
         su1,
         sv0,
         su1,
         sv1
      };
      byte[] cull = new byte[6];
      byte[] facing = new byte[6];
      byte[] cutoff = new byte[6];
      boolean[] translucent = new boolean[6];
      boolean[] tinted = new boolean[6];
      boolean[] shaded = new boolean[6];
      boolean[] unit = new boolean[6];
      boolean[] overlay = new boolean[6];
      float[] shift = new float[6];
      boolean[] flush = new boolean[6];

      for (int f = 0; f < 6; f++) {
         cull[f] = (byte)f;
         facing[f] = (byte)facingOf(pos, f * 12).ordinal();
         cutoff[f] = 0;
         translucent[f] = trans;
         tinted[f] = true;
         shaded[f] = true;
         unit[f] = true;
         overlay[f] = false;
         shift[f] = 0.0F;
         flush[f] = true;
      }

      int fallback = 16777215;

      try {
         fallback = model.tintSource().color(state) & 16777215;
      } catch (Throwable var35) {
      }

      TextureAtlasSprite overlaySprite = null;

      try {
         Baked overlayMat = model.overlayMaterial();
         overlaySprite = overlayMat == null ? null : overlayMat.sprite();
      } catch (Throwable var34) {
      }

      return new SpriteUvResolver.Entry(
         (byte)2,
         lightEmission(state),
         fallback,
         -1,
         new SpriteUvResolver.Quads(6, pos, uv, cull, facing, cutoff, translucent, tinted, shaded, unit, overlay, shift, flush),
         fluidHeightOf(fluid),
         0.0F,
         0.0F,
         new SpriteUvResolver.FluidLook(
            fluidFamilyOf(fluid),
            flowing.getU0(),
            flowing.getV0(),
            flowing.getU1(),
            flowing.getV1(),
            overlaySprite != null,
            overlaySprite == null ? 0.0F : overlaySprite.getU0(),
            overlaySprite == null ? 0.0F : overlaySprite.getV0(),
            overlaySprite == null ? 0.0F : overlaySprite.getU1(),
            overlaySprite == null ? 0.0F : overlaySprite.getV1()
         ),
         null,
         null,
         true,
         false
      );
   }

   private static TextureAtlasSprite flowingSprite(FluidModel model, TextureAtlasSprite still) {
      try {
         Baked material = model.flowingMaterial();
         TextureAtlasSprite sprite = material == null ? null : material.sprite();
         return sprite == null ? still : sprite;
      } catch (Throwable t) {
         return still;
      }
   }

   private static float fluidHeightOf(FluidState fluid) {
      try {
         float h = fluid.getOwnHeight();
         return !(h > 0.0F) ? 0.8888889F : Math.min(h, 1.0F);
      } catch (Throwable t) {
         return 0.8888889F;
      }
   }

   private static byte lightEmission(BlockState state) {
      try {
         return (byte)Math.max(0, Math.min(15, state.getLightEmission()));
      } catch (Throwable t) {
         return 0;
      }
   }

   private static int defaultBlockTint(BlockState state, int tintIndex) {
      try {
         List<BlockTintSource> sources = Minecraft.getInstance().getBlockColors().getTintSources(state);
         BlockTintSource source = tintSourceFor(sources, tintIndex);
         if (source != null) {
            return source.color(state) & 16777215;
         }
      } catch (Throwable var4) {
      }

      return 16777215;
   }

   private static BlockTintSource tintSourceFor(List<BlockTintSource> sources, int tintIndex) {
      return sources.isEmpty() ? null : sources.get(tintIndex >= 0 && tintIndex < sources.size() ? tintIndex : 0);
   }

   private record Entry(
      byte kind,
      byte emission,
      int fallbackTint,
      int tintIndex,
      SpriteUvResolver.Quads quads,
      float fluidHeight,
      float offsetH,
      float offsetV,
      SpriteUvResolver.FluidLook fluid,
      SpriteUvResolver.Entry upper,
      SpriteUvResolver.Quads[] variants,
      boolean variantsUniform,
      boolean glassy
   ) {
      Entry(byte kind, byte emission, int fallbackTint, int tintIndex, SpriteUvResolver.Quads quads, float offsetH, float offsetV, SpriteUvResolver.Entry upper) {
         this(kind, emission, fallbackTint, tintIndex, quads, 1.0F, offsetH, offsetV, null, upper, null, true, false);
      }

      SpriteUvResolver.Entry withUpper(SpriteUvResolver.Entry half) {
         return new SpriteUvResolver.Entry(
            this.kind,
            this.emission,
            this.fallbackTint,
            this.tintIndex,
            this.quads,
            this.fluidHeight,
            this.offsetH,
            this.offsetV,
            this.fluid,
            half,
            this.variants,
            this.variantsUniform,
            this.glassy
         );
      }
   }

   public record FluidLook(
      byte family,
      float flowU0,
      float flowV0,
      float flowU1,
      float flowV1,
      boolean hasOverlay,
      float overlayU0,
      float overlayV0,
      float overlayU1,
      float overlayV1
   ) {
      float overlayU(float u) {
         return this.overlayU0 + (u - this.flowU0) / (this.flowU1 - this.flowU0) * (this.overlayU1 - this.overlayU0);
      }

      float overlayV(float v) {
         return this.overlayV0 + (v - this.flowV0) / (this.flowV1 - this.flowV0) * (this.overlayV1 - this.overlayV0);
      }
   }

   private static final class ForcedRandom implements RandomSource {
      int forced;
      int draws;
      int others;
      int bound;

      public RandomSource fork() {
         this.others++;
         return this;
      }

      public PositionalRandomFactory forkPositional() {
         this.others++;
         throw new UnsupportedOperationException("far-field variant probe has no positional fork");
      }

      public void setSeed(long seed) {
      }

      public int nextInt() {
         this.others++;
         return 0;
      }

      public int nextInt(int b) {
         this.draws++;
         this.bound = b;
         return Math.min(this.forced, Math.max(0, b - 1));
      }

      public long nextLong() {
         this.others++;
         return 0L;
      }

      public boolean nextBoolean() {
         this.others++;
         return false;
      }

      public float nextFloat() {
         this.others++;
         return 0.0F;
      }

      public double nextDouble() {
         this.others++;
         return 0.0;
      }

      public double nextGaussian() {
         this.others++;
         return 0.0;
      }
   }

   public record Quads(
      int count,
      float[] pos,
      float[] uv,
      byte[] cull,
      byte[] facing,
      byte[] cutoff,
      boolean[] translucent,
      boolean[] tinted,
      boolean[] shaded,
      boolean[] unit,
      boolean[] overlay,
      float[] shift,
      boolean[] flush
   ) {
      static SpriteUvResolver.Quads empty() {
         return new SpriteUvResolver.Quads(
            0,
            new float[0],
            new float[0],
            new byte[0],
            new byte[0],
            new byte[0],
            new boolean[0],
            new boolean[0],
            new boolean[0],
            new boolean[0],
            new boolean[0],
            new float[0],
            new boolean[0]
         );
      }
   }

   public static final class ResolvedPalette {
      private final int entries;
      final int[] upperRow;
      final byte[] kind;
      final byte[] emission;
      final int[] fallbackTint;
      final SpriteUvResolver.Quads[] quads;
      final float[] fluidHeight;
      final SpriteUvResolver.FluidLook[] fluidLook;
      final boolean[] fullCube;
      final float[] offsetH;
      final float[] offsetV;
      boolean anyOffset;
      final SpriteUvResolver.Quads[][] variantQuads;
      final boolean[] variantUniform;
      final boolean[] glassy;
      boolean anyVariants;
      boolean anyGlassy;

      ResolvedPalette(int entries, int doublingCount) {
         this.entries = entries;
         this.upperRow = doublingCount > 0 ? new int[entries] : null;
         int rows = entries + doublingCount;
         this.kind = new byte[rows];
         this.emission = new byte[rows];
         this.fallbackTint = new int[rows];
         this.quads = new SpriteUvResolver.Quads[rows];
         this.fluidHeight = new float[rows];
         this.fluidLook = new SpriteUvResolver.FluidLook[rows];
         this.fullCube = new boolean[rows];
         this.offsetH = new float[rows];
         this.offsetV = new float[rows];
         this.variantQuads = new SpriteUvResolver.Quads[rows][];
         this.variantUniform = new boolean[rows];
         this.glassy = new boolean[rows];
      }

      public int size() {
         return this.entries;
      }

      public SpriteUvResolver.Quads[] variantTables(int row) {
         return this.variantQuads[row];
      }

      public boolean variantTablesUniform(int row) {
         return this.variantUniform[row];
      }
   }
}
