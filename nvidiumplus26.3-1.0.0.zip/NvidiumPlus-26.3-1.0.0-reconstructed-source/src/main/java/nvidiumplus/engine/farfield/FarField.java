package nvidiumplus.engine.farfield;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.LongConsumer;
import java.util.stream.Stream;
import net.minecraft.client.Minecraft;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusPlatform;
import nvidiumplus.engine.farfield.store.FarFieldStore;
import nvidiumplus.engine.farfield.store.ShellCodec;

public final class FarField {
   public static final LongAdder farStoreWrites = new LongAdder();
   public static final LongAdder farStoreReads = new LongAdder();
   public static final LongAdder farStoreErrors = new LongAdder();
   public static final LongAdder farApronReads = new LongAdder();
   public static final LongAdder farApronHits = new LongAdder();
   public static final LongAdder farApronAbsent = new LongAdder();
   public static final LongAdder farStoreStaleRecords = new LongAdder();
   public static final LongAdder farStoreBytesWritten = new LongAdder();
   private static volatile int saveSignature;
   private static volatile boolean saveSignatureKnown;
   public static final LongAdder farStoreDroppedWrites = new LongAdder();
   public static final LongAdder farStoreDroppedNoStore = new LongAdder();
   public static final LongAdder farSaveAckOk = new LongAdder();
   public static final LongAdder farSaveAckFailed = new LongAdder();
   private static volatile boolean worldOpen;
   private static final ConcurrentLinkedQueue<FarField.WriteAck> writeAcks = new ConcurrentLinkedQueue<>();
   private static final AtomicBoolean storeInvalidated = new AtomicBoolean();
   private static final AtomicLong storeGeneration = new AtomicLong();
   private static volatile BooleanSupplier pinDrainIdle;
   private static final long PIN_DRAIN_DEADLINE_NANOS = 5000000000L;
   private static volatile long joinGeneration;
   private static final int WRITE_QUEUE_CAP = 512;
   private static final int READ_QUEUE_CAP = 4096;
   private static final int ERROR_LOG_BUDGET = 8;
   private static volatile FarField.Io io;
   private static final AtomicBoolean sizeWalkInFlight = new AtomicBoolean();

   public static void noteSaveSignature(int signature) {
      saveSignature = signature;
      saveSignatureKnown = true;
   }

   static int saveSignature() {
      if (!saveSignatureKnown) {
         noteSaveSignature(FarFieldConfig.farSaveSignature());
      }

      return saveSignature;
   }

   private static void postWriteAck(int chunkX, int chunkZ, long version, boolean ok) {
      if (ok) {
         farSaveAckOk.increment();
      } else {
         farSaveAckFailed.increment();
      }

      writeAcks.add(new FarField.WriteAck(chunkX, chunkZ, version, ok));
   }

   public static FarField.WriteAck pollWriteAck() {
      return writeAcks.poll();
   }

   public static boolean writeQueueSaturated() {
      FarField.Io running = io;
      return running != null && running.queuedWrites > 384;
   }

   public static boolean consumeStoreInvalidated() {
      return storeInvalidated.getAndSet(false);
   }

   public static long storeGeneration() {
      return storeGeneration.get();
   }

   public static boolean ioDead() {
      FarField.Io running = io;
      return running != null && running.dead;
   }

   public static void registerPinDrainIdle(BooleanSupplier idle) {
      pinDrainIdle = idle;
   }

   private FarField() {
   }

   public static void onWorldJoin(String worldKey, String dimensionKey) {
      if (FarFieldConfig.enabled()) {
         if (worldKey != null && !worldKey.isEmpty() && dimensionKey != null && !dimensionKey.isEmpty()) {
            joinGeneration++;
            ensureIo().enqueueLifecycle(new FarField.JoinTask(worldKey, dimensionKey));
            worldOpen = true;
            FarFieldResidency.onWorldJoin();
         }
      }
   }

   private static boolean openForCurrentWorld() {
      if (!FarFieldConfig.enabled()) {
         return false;
      }

      if (worldOpen && io != null) {
         return true;
      }

      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft != null && minecraft.level != null) {
         String worldKey = CacheKeys.worldKey(minecraft);
         String dimensionKey = CacheKeys.dimensionKey(minecraft.level);
         if (worldKey != null && !worldKey.isEmpty() && dimensionKey != null && !dimensionKey.isEmpty()) {
            onWorldJoin(worldKey, dimensionKey);
            return worldOpen && io != null;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static void onWorldLeave() {
      worldOpen = false;
      FarField.Io running = io;
      if (running != null) {
         FarFieldResidency.onWorldLeave();
         BooleanSupplier drainIdle = pinDrainIdle;
         if (drainIdle != null && !drainIdle.getAsBoolean() && !running.dead) {
            running.enqueueLifecycle(new FarField.DrainThenLeaveTask(drainIdle, System.nanoTime() + 5000000000L, joinGeneration));
         } else {
            running.enqueueLifecycle(new FarField.LeaveTask());
         }
      }
   }

   public static void submitShell(int chunkX, int chunkZ, int tier, ShellCodec.Shell shell, long version) {
      if (shell != null) {
         if (!FarFieldConfig.enabled()) {
            postWriteAck(chunkX, chunkZ, version, false);
         } else {
            FarField.Io running = io;
            if (running == null || !worldOpen) {
               if (!openForCurrentWorld()) {
                  farStoreDroppedNoStore.increment();
                  postWriteAck(chunkX, chunkZ, version, false);
                  return;
               }

               running = io;
               if (running == null) {
                  farStoreDroppedNoStore.increment();
                  postWriteAck(chunkX, chunkZ, version, false);
                  return;
               }
            }

            running.enqueueWrite(new FarField.WriteTask(chunkX, chunkZ, tier, shell, version));
            FarFieldResidency.onShellWritten(chunkX, chunkZ);
         }
      }
   }

   public static void submitShellFromWorker(int chunkX, int chunkZ, int tier, ShellCodec.Shell shell, long version) {
      if (shell != null) {
         if (!FarFieldConfig.enabled()) {
            postWriteAck(chunkX, chunkZ, version, false);
         } else {
            FarField.Io running = io;
            if (running == null) {
               farStoreDroppedNoStore.increment();
               postWriteAck(chunkX, chunkZ, version, false);
            } else {
               running.enqueueWrite(new FarField.WriteTask(chunkX, chunkZ, tier, shell, version));
            }
         }
      }
   }

   public static void ensureStoreOpenForCapture() {
      if (io == null || !worldOpen) {
         if (FarFieldConfig.enabled()) {
            openForCurrentWorld();
         }
      }
   }

   public static void onPinShellAcked(int chunkX, int chunkZ) {
      if (io != null) {
         FarFieldResidency.onShellWritten(chunkX, chunkZ);
      }
   }

   public static void requestShell(int chunkX, int chunkZ, Consumer<ShellCodec.Shell> consumer) {
      if (consumer != null) {
         if (!FarFieldConfig.enabled()) {
            consumer.accept(null);
         } else {
            FarField.Io running = io;
            if (running == null) {
               consumer.accept(null);
            } else {
               running.enqueueRead(new FarField.ReadTask(chunkX, chunkZ, consumer, null));
            }
         }
      }
   }

   public static void requestShellNeighborhood(int chunkX, int chunkZ, Consumer<FarField.Neighborhood> consumer) {
      if (consumer != null) {
         if (!FarFieldConfig.enabled()) {
            consumer.accept(null);
         } else {
            FarField.Io running = io;
            if (running == null) {
               consumer.accept(null);
            } else {
               running.enqueueRead(new FarField.ReadTask(chunkX, chunkZ, null, consumer));
            }
         }
      }
   }

   static boolean submitCompute(Runnable job) {
      if (job != null && FarFieldConfig.enabled()) {
         FarField.Io running = io;
         if (running != null && !running.dead) {
            running.enqueueLifecycle(new FarField.ComputeTask(job));
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static Path cacheFolder() {
      return NvidiumPlusPlatform.gameDir().toAbsolutePath().normalize().resolve("nvidiumplus").resolve("farfield");
   }

   public static boolean requestCacheSizeBytes(LongConsumer consumer) {
      if (consumer != null && sizeWalkInFlight.compareAndSet(false, true)) {
         Thread walker = new Thread(() -> {
            long total;
            try {
               total = folderBytes(cacheFolder());
            } catch (Throwable t) {
               farStoreErrors.increment();
               total = -1L;
            } finally {
               sizeWalkInFlight.set(false);
            }

            consumer.accept(total);
         }, "nvidiumplus-farfield-size");
         walker.setDaemon(true);
         walker.start();
         return true;
      } else {
         return false;
      }
   }

   private static long folderBytes(Path folder) throws IOException {
      if (!Files.isDirectory(folder)) {
         return 0L;
      }

      try (Stream<Path> files = Files.walk(folder)) {
         return files.filter(x$0 -> Files.isRegularFile(x$0)).mapToLong(file -> {
            try {
               return Files.size(file);
            } catch (IOException vanished) {
               return 0L;
            }
         }).sum();
      }
   }

   public static void requestCacheClear(Consumer<Boolean> done) {
      FarField.Io running = io;
      if (running == null) {
         Thread cleaner = new Thread(() -> {
            boolean ok;
            try {
               ok = clearCacheFolder();
            } catch (Throwable t) {
               farStoreErrors.increment();
               NvidiumPlusLog.LOGGER.warn("Far-field cache clear failed", t);
               ok = false;
            }

            if (ok) {
               storeInvalidated.set(true);
            }

            if (done != null) {
               done.accept(ok);
            }
         }, "nvidiumplus-farfield-clear");
         cleaner.setDaemon(true);
         cleaner.start();
      } else {
         running.enqueueClear(new FarField.ClearTask(done));
      }
   }

   private static boolean clearCacheFolder() {
      Path base = cacheFolder();
      if (!Files.isDirectory(base)) {
         return true;
      }

      List<Path> victims = new ArrayList<>();

      try (Stream<Path> walk = Files.walk(base)) {
         walk.sorted(Comparator.reverseOrder()).forEach(victims::add);
      } catch (IOException | RuntimeException e) {
         farStoreErrors.increment();
         NvidiumPlusLog.LOGGER.warn("Could not list {} to clear it", base, e);
         return false;
      }

      boolean ok = true;

      for (Path victim : victims) {
         Path normalized = victim.toAbsolutePath().normalize();
         if (!normalized.startsWith(base)) {
            farStoreErrors.increment();
            NvidiumPlusLog.LOGGER.error("Refusing to delete {}: outside {}", normalized, base);
            return false;
         }

         try {
            Files.deleteIfExists(normalized);
         } catch (IOException | RuntimeException e) {
            ok = false;
            farStoreErrors.increment();
         }
      }

      return ok;
   }

   public static boolean isCompletelyIdle() {
      return io == null;
   }

   private static FarField.Io ensureIo() {
      FarField.Io running = io;
      if (running == null) {
         synchronized (FarField.class) {
            running = io;
            if (running == null) {
               running = new FarField.Io();
               io = running;
            }
         }
      }

      return running;
   }

   private static void warnThrottled(FarField.Io io, String message, Throwable t) {
      if (io.errorLogBudget > 0) {
         io.errorLogBudget--;
         NvidiumPlusLog.LOGGER.warn("{} ({} more of these will be logged this world)", new Object[]{message, io.errorLogBudget, t});
      }
   }

   static boolean apronEnabled() {
      String override = System.getProperty("nvidiumplus.farfield.apron");
      return override == null || !"false".equalsIgnoreCase(override.trim());
   }

   private static final class ClearTask extends FarField.Task {
      final Consumer<Boolean> done;

      ClearTask(Consumer<Boolean> done) {
         this.done = done;
      }

      @Override
      void run(FarField.Io io) {
         boolean ok = false;
         io.decoded.clear();

         try {
            if (io.store != null) {
               io.store.close();
               io.store = null;
            }

            ok = FarField.clearCacheFolder();
         } catch (Throwable t) {
            FarField.farStoreErrors.increment();
            FarField.warnThrottled(io, "Far-field cache clear failed", t);
         }

         try {
            if (io.worldKey != null && io.dimensionKey != null) {
               io.store = new FarFieldStore(NvidiumPlusPlatform.gameDir(), io.worldKey, io.dimensionKey, FarField.farStoreErrors);
            }
         } catch (Throwable t) {
            FarField.farStoreErrors.increment();
            FarField.warnThrottled(io, "Far-field store did not reopen after a cache clear", t);
         }

         if (ok) {
            FarField.storeInvalidated.set(true);
         }

         if (this.done != null) {
            this.done.accept(ok);
         }
      }
   }

   private static final class ComputeTask extends FarField.Task {
      final Runnable job;

      ComputeTask(Runnable job) {
         this.job = job;
      }

      @Override
      void run(FarField.Io io) {
         this.job.run();
      }
   }

   private static final class DrainThenLeaveTask extends FarField.Task {
      final BooleanSupplier drainIdle;
      final long deadlineNanos;
      final long joinGenerationAtLeave;

      DrainThenLeaveTask(BooleanSupplier drainIdle, long deadlineNanos, long joinGenerationAtLeave) {
         this.drainIdle = drainIdle;
         this.deadlineNanos = deadlineNanos;
         this.joinGenerationAtLeave = joinGenerationAtLeave;
      }

      @Override
      void run(FarField.Io io) throws InterruptedException {
         if (FarField.joinGeneration == this.joinGenerationAtLeave) {
            if (!this.drainIdle.getAsBoolean() && System.nanoTime() < this.deadlineNanos && !io.dead) {
               Thread.sleep(5L);
               io.enqueueLifecycle(this);
            } else {
               io.decoded.clear();
               if (io.store != null) {
                  io.store.close();
                  io.store = null;
               }

               FarField.storeGeneration.incrementAndGet();
               io.worldKey = null;
               io.dimensionKey = null;
            }
         }
      }
   }

   private static final class Io implements Runnable {
      final ArrayDeque<FarField.Task> queue = new ArrayDeque<>();
      final Thread thread;
      volatile int queuedWrites;
      int queuedReads;
      FarFieldStore store;
      String worldKey;
      String dimensionKey;
      int errorLogBudget = 8;
      volatile boolean dead;
      static final int DECODED_CACHE = 128;
      static final Object ABSENT = new Object();
      final LinkedHashMap<Long, Object> decoded = new LinkedHashMap<Long, Object>(32, 0.75F, true) {
         @Override
         protected boolean removeEldestEntry(Entry<Long, Object> eldest) {
            return this.size() > 128;
         }
      };

      ShellCodec.Shell readDecoded(int chunkX, int chunkZ, boolean amplified) {
         long key = (long)chunkX << 32 | chunkZ & 4294967295L;
         Object cached = this.decoded.get(key);
         if (cached != null) {
            if (amplified) {
               FarField.farApronHits.increment();
            }

            return cached == ABSENT ? null : (ShellCodec.Shell)cached;
         } else {
            ShellCodec.Shell result = null;
            if (this.store != null) {
               try {
                  byte[] record = this.store.read(chunkX, chunkZ);
                  FarField.farStoreReads.increment();
                  if (amplified) {
                     FarField.farApronReads.increment();
                  }

                  if (record != null) {
                     result = ShellCodec.decode(record, chunkX, chunkZ);
                     if (result == null) {
                        FarField.farStoreErrors.increment();
                        FarField.warnThrottled(this, "Corrupt far-field record ignored", null);
                     } else if (!result.signatureMatches(FarField.saveSignature())) {
                        result = null;
                        FarField.farStoreStaleRecords.increment();
                     }
                  }
               } catch (IOException e) {
                  FarField.farStoreErrors.increment();
                  FarField.warnThrottled(this, "Far-field read failed", e);
                  return null;
               }
            }

            if (result == null && amplified) {
               FarField.farApronAbsent.increment();
            }

            this.decoded.put(key, result == null ? ABSENT : result);
            return result;
         }
      }

      void invalidateDecoded(int chunkX, int chunkZ) {
         this.decoded.remove((long)chunkX << 32 | chunkZ & 4294967295L);
      }

      Io() {
         this.thread = new Thread(this, "nvidiumplus-farfield-io");
         this.thread.setDaemon(true);
         this.thread.setUncaughtExceptionHandler((t, e) -> {
            FarField.farStoreErrors.increment();
            this.dead = true;
            NvidiumPlusLog.LOGGER.error("Far-field IO thread died; the far field is parked until the game restarts", e);
         });
         this.thread.start();
      }

      void enqueueLifecycle(FarField.Task task) {
         synchronized (this.queue) {
            this.queue.addLast(task);
            this.queue.notify();
         }
      }

      void enqueueWrite(FarField.WriteTask task) {
         if (this.dead) {
            FarField.farStoreDroppedWrites.increment();
            FarField.postWriteAck(task.chunkX, task.chunkZ, task.version, false);
         } else {
            FarField.WriteTask victim = null;
            boolean newcomerDropped = false;
            synchronized (this.queue) {
               if (this.queuedWrites >= 512) {
                  Iterator<FarField.Task> pending = this.queue.iterator();

                  while (pending.hasNext()) {
                     if (pending.next() instanceof FarField.WriteTask evicted) {
                        pending.remove();
                        this.queuedWrites--;
                        FarField.farStoreDroppedWrites.increment();
                        victim = evicted;
                        break;
                     }
                  }

                  if (this.queuedWrites >= 512) {
                     FarField.farStoreDroppedWrites.increment();
                     newcomerDropped = true;
                  }
               }

               if (!newcomerDropped) {
                  this.queue.addLast(task);
                  this.queuedWrites++;
                  this.queue.notify();
               }
            }

            if (victim != null) {
               FarField.postWriteAck(victim.chunkX, victim.chunkZ, victim.version, false);
            }

            if (newcomerDropped) {
               FarField.postWriteAck(task.chunkX, task.chunkZ, task.version, false);
            }
         }
      }

      void enqueueClear(FarField.Task task) {
         List<FarField.WriteTask> discarded = new ArrayList<>();
         synchronized (this.queue) {
            Iterator<FarField.Task> pending = this.queue.iterator();

            while (pending.hasNext()) {
               if (pending.next() instanceof FarField.WriteTask write) {
                  pending.remove();
                  this.queuedWrites--;
                  FarField.farStoreDroppedWrites.increment();
                  discarded.add(write);
               }
            }

            this.queue.addLast(task);
            this.queue.notify();
         }

         for (FarField.WriteTask write : discarded) {
            FarField.postWriteAck(write.chunkX, write.chunkZ, write.version, false);
         }
      }

      void enqueueRead(FarField.ReadTask task) {
         boolean queued = false;
         if (!this.dead) {
            synchronized (this.queue) {
               if (this.queuedReads < 4096) {
                  this.queue.addLast(task);
                  this.queuedReads++;
                  this.queue.notify();
                  queued = true;
               }
            }
         }

         if (!queued) {
            task.answerNull();
         }
      }

      @Override
      public void run() {
         while (true) {
            FarField.Task task;
            synchronized (this.queue) {
               while (this.queue.isEmpty()) {
                  try {
                     this.queue.wait();
                  } catch (InterruptedException interrupted) {
                     Thread.currentThread().interrupt();
                     this.dead = true;
                     return;
                  }
               }

               task = this.queue.removeFirst();
               if (task instanceof FarField.WriteTask) {
                  this.queuedWrites--;
               } else if (task instanceof FarField.ReadTask) {
                  this.queuedReads--;
               }
            }

            try {
               task.run(this);
            } catch (Throwable t) {
               FarField.farStoreErrors.increment();
               FarField.warnThrottled(this, "Far-field store task failed", t);
            }
         }
      }
   }

   private static final class JoinTask extends FarField.Task {
      final String worldKey;
      final String dimensionKey;

      JoinTask(String worldKey, String dimensionKey) {
         this.worldKey = worldKey;
         this.dimensionKey = dimensionKey;
      }

      @Override
      void run(FarField.Io io) throws IOException {
         io.decoded.clear();
         if (io.store != null) {
            io.store.close();
            io.store = null;
            FarField.storeGeneration.incrementAndGet();
         }

         Path gameDir = NvidiumPlusPlatform.gameDir();
         io.store = new FarFieldStore(gameDir, this.worldKey, this.dimensionKey, FarField.farStoreErrors);
         io.worldKey = this.worldKey;
         io.dimensionKey = this.dimensionKey;
         io.errorLogBudget = 8;
      }
   }

   private static final class LeaveTask extends FarField.Task {
      @Override
      void run(FarField.Io io) {
         io.decoded.clear();
         if (io.store != null) {
            io.store.close();
            io.store = null;
         }

         FarField.storeGeneration.incrementAndGet();
         io.worldKey = null;
         io.dimensionKey = null;
      }
   }

   public record Neighborhood(ShellCodec.Shell center, ShellCodec.Shell[] ring) {
   }

   private static final class ReadTask extends FarField.Task {
      final int chunkX;
      final int chunkZ;
      final Consumer<ShellCodec.Shell> consumer;
      final Consumer<FarField.Neighborhood> neighborhood;

      ReadTask(int chunkX, int chunkZ, Consumer<ShellCodec.Shell> consumer, Consumer<FarField.Neighborhood> neighborhood) {
         this.chunkX = chunkX;
         this.chunkZ = chunkZ;
         this.consumer = consumer;
         this.neighborhood = neighborhood;
      }

      void answerNull() {
         if (this.consumer != null) {
            this.consumer.accept(null);
         } else if (this.neighborhood != null) {
            this.neighborhood.accept(null);
         }
      }

      @Override
      void run(FarField.Io io) {
         ShellCodec.Shell result = io.readDecoded(this.chunkX, this.chunkZ, false);
         if (this.consumer != null) {
            this.consumer.accept(result);
         } else if (result == null) {
            this.neighborhood.accept(null);
         } else {
            ShellCodec.Shell[] ring = null;
            if (FarField.apronEnabled()) {
               ring = new ShellCodec.Shell[9];

               for (int dz = -1; dz <= 1; dz++) {
                  for (int dx = -1; dx <= 1; dx++) {
                     if (dx != 0 || dz != 0) {
                        ring[(dz + 1) * 3 + dx + 1] = io.readDecoded(this.chunkX + dx, this.chunkZ + dz, true);
                     }
                  }
               }
            }

            this.neighborhood.accept(new FarField.Neighborhood(result, ring));
         }
      }
   }

   private abstract static class Task {
      abstract void run(FarField.Io var1) throws Exception;
   }

   public record WriteAck(int chunkX, int chunkZ, long version, boolean ok) {
   }

   private static final class WriteTask extends FarField.Task {
      final int chunkX;
      final int chunkZ;
      final int tier;
      final ShellCodec.Shell shell;
      final long version;

      WriteTask(int chunkX, int chunkZ, int tier, ShellCodec.Shell shell, long version) {
         this.chunkX = chunkX;
         this.chunkZ = chunkZ;
         this.tier = tier;
         this.shell = shell;
         this.version = version;
      }

      @Override
      void run(FarField.Io io) throws IOException {
         boolean ok = false;

         try {
            FarFieldStore store = io.store;
            if (store == null) {
               FarField.farStoreDroppedWrites.increment();
               return;
            }

            if (this.tier != this.shell.tier) {
               FarField.farStoreErrors.increment();
               FarField.warnThrottled(io, "submitShell tier disagrees with shell.tier; shell discarded", null);
               return;
            }

            byte[] record = ShellCodec.encode(this.shell.withSaveSignature(FarField.saveSignature()));
            if (record != null) {
               io.invalidateDecoded(this.chunkX, this.chunkZ);
               if (store.write(this.chunkX, this.chunkZ, this.tier, record)) {
                  FarField.farStoreWrites.increment();
                  FarField.farStoreBytesWritten.add(1L + record.length);
               }

               ok = true;
               return;
            }

            FarField.farStoreErrors.increment();
            FarField.warnThrottled(io, "Unencodable shell discarded", null);
         } finally {
            FarField.postWriteAck(this.chunkX, this.chunkZ, this.version, ok);
         }
      }
   }
}
