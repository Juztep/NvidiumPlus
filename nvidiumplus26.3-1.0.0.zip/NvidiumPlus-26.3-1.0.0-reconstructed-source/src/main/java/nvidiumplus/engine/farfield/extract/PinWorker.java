package nvidiumplus.engine.farfield.extract;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.LockSupport;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.farfield.FarField;
import nvidiumplus.engine.farfield.store.ShellCodec;

final class PinWorker {
   static final String WORKER_THREAD_NAME = "nvidiumplus-pin-extract";
   static final byte OUTCOME_SUBMITTED = 0;
   static final byte OUTCOME_EMPTY = 1;
   static final byte OUTCOME_FAILED = 2;
   private static final ConcurrentLinkedQueue<Pin> queue = new ConcurrentLinkedQueue<>();
   private static final ConcurrentLinkedQueue<Pin> results = new ConcurrentLinkedQueue<>();
   private static final AtomicInteger pending = new AtomicInteger();
   private static volatile Thread thread;

   private PinWorker() {
   }

   static void enqueue(Pin pin) {
      pending.incrementAndGet();
      queue.add(pin);
      Thread running = ensureThread();
      LockSupport.unpark(running);
   }

   static int pendingCount() {
      return pending.get();
   }

   static Pin pollResult() {
      return results.poll();
   }

   private static Thread ensureThread() {
      Thread running = thread;
      if (running == null) {
         synchronized (PinWorker.class) {
            running = thread;
            if (running == null) {
               running = new Thread(PinWorker::run, "nvidiumplus-pin-extract");
               running.setDaemon(true);
               running.setPriority(1);
               running.setUncaughtExceptionHandler((t, e) -> {
                  FarField.farStoreErrors.increment();
                  thread = null;
                  NvidiumPlusLog.LOGGER.error("Far-field pin worker died; it restarts on the next pin", e);
               });
               thread = running;
               FarField.registerPinDrainIdle(() -> pending.get() == 0);
               running.start();
            }
         }
      }

      return running;
   }

   private static void run() {
      while (true) {
         Pin pin = queue.poll();
         if (pin == null) {
            LockSupport.parkNanos(50000000L);
         } else {
            try {
               drainOne(pin);
            } catch (Throwable t) {
               FarField.farStoreErrors.increment();
            } finally {
               pending.decrementAndGet();
            }
         }
      }
   }

   private static void drainOne(Pin pin) {
      if (!pin.released) {
         if (FarField.ioDead()) {
            if (!pin.live) {
               ExtractDispatch.farSaveLost.increment();
            }

            pin.walkOutcome = 2;
            results.add(pin);
         } else if (FarField.storeGeneration() != pin.storeGeneration) {
            if (!pin.live) {
               ExtractDispatch.farSaveLost.increment();
            }
         } else {
            while (FarField.writeQueueSaturated() && !pin.released) {
               LockSupport.parkNanos(50000000L);
            }

            if (!pin.released) {
               long start = System.nanoTime();

               ShellCodec.Shell shell;
               label135: {
                  try {
                     shell = ShellExtractor.extractCaptured(pin);
                     break label135;
                  } catch (Throwable t) {
                     FarField.farStoreErrors.increment();
                     pin.walkOutcome = 2;
                     results.add(pin);
                  } finally {
                     ExtractDispatch.farExtractNanos.add(Math.max(0L, System.nanoTime() - start));
                  }

                  return;
               }

               byte quality = 0;
               if (pin.sidePin[0] == null && pin.strips[0] == null) {
                  quality = (byte)(quality | 2);
               }

               if (pin.sidePin[1] == null && pin.strips[1] == null) {
                  quality = (byte)(quality | 4);
               }

               if (pin.sidePin[2] == null && pin.strips[2] == null) {
                  quality = (byte)(quality | 8);
               }

               if (pin.sidePin[3] == null && pin.strips[3] == null) {
                  quality = (byte)(quality | 16);
               }

               if (pin.walkLightPending) {
                  quality = (byte)(quality | 32);
               }

               if (quality == 0) {
                  quality = 1;
               }

               pin.walkQuality = quality;
               if (shell == null) {
                  pin.walkOutcome = 1;
                  results.add(pin);
               } else {
                  ExtractDispatch.farExtracts.increment();
                  ExtractDispatch.farExtractCells.add(shell.cellCount);
                  if ((quality & 1) == 0) {
                     ExtractDispatch.farExtractIncomplete.increment();
                  }

                  pin.walkOutcome = 0;
                  results.add(pin);
                  FarField.submitShellFromWorker(pin.chunkX, pin.chunkZ, 2, shell, pin.version);
               }
            }
         }
      }
   }
}
