package nvidiumplus.engine.farfield;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.client.Minecraft;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusPlatform;

public final class FarFieldConfig {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static volatile FarFieldConfig instance;
   private static final String PROPERTY_PREFIX = "nvidiumplus.farfield.";
   public boolean enabled = false;
   public int l1RadiusChunks = 64;
   public int extractBudgetMillis = 3;
   public boolean adaptiveExtraction = true;
   public int extractFrameRateFloor = 60;
   public boolean surfaceBand = true;
   public int bandOffset = 8;
   public String preset = FarFieldConfig.Preset.CUSTOM.id;
   public FarFieldConfig.LayerSettings layer1 = FarFieldConfig.LayerSettings.layer1Defaults();
   public FarFieldConfig.LayerSettings layer2 = new FarFieldConfig.LayerSettings();
   public FarFieldConfig.LayerSettings layer3 = new FarFieldConfig.LayerSettings();
   public int configVersion = 0;
   private static final int CURRENT_CONFIG_VERSION = 8;
   public static final int MIN_L1_RADIUS_CHUNKS = 0;
   public static final int MAX_L1_RADIUS_CHUNKS = 192;
   public static final int DEFAULT_L1_RADIUS_CHUNKS = 64;
   public static final int MAX_HONEST_PRESET_RADIUS_CHUNKS = 64;
   public static final int MIN_BAND_OFFSET = 4;
   public static final int MAX_BAND_OFFSET = 32;
   public static final int DEFAULT_BAND_OFFSET = 8;
   public static final int MIN_EXTRACT_BUDGET_MILLIS = 0;
   public static final int MAX_EXTRACT_BUDGET_MILLIS = 8;
   public static final int DEFAULT_EXTRACT_BUDGET_MILLIS = 3;
   public static final int MIN_EXTRACT_FRAME_RATE_FLOOR = 30;
   public static final int MAX_EXTRACT_FRAME_RATE_FLOOR = 240;
   public static final int DEFAULT_EXTRACT_FRAME_RATE_FLOOR = 60;
   public static final int CACHE_GENTLE = 0;
   public static final int CACHE_BALANCED = 1;
   public static final int CACHE_FAST = 2;
   public static final int DEFAULT_CACHE_SPEED = 2;
   public static final int SCALE_FULL = 1;
   public static final int SCALE_HALF = 2;
   public static final int SCALE_QUARTER = 4;
   public static final int TEXTURE_FULL = 0;
   public static final int TEXTURE_FLAT = 4;
   public static final int BLEND_PER_CHUNK = 0;
   public static final int BLEND_COARSE = 2;
   public static final int BLEND_FINE = 4;
   public static final int LIGHT_FLAT = 0;
   public static final int LIGHT_GLOW = 1;
   public static final int LIGHT_REAL = 2;
   public static final int SMOOTH_OFF = 0;
   public static final int SMOOTH_EDGES = 1;
   public static final int SMOOTH_FULL = 2;
   public static final int DEFAULT_SMOOTH_LIGHT = 2;
   public static final int MIN_CONTACT_SHADE = 0;
   public static final int MAX_CONTACT_SHADE = 100;
   public static final int DEFAULT_CONTACT_SHADE = 100;
   public static final boolean FEATURE_ENABLED = false;
   private static volatile boolean gateReported;
   private static final int BAND_RULE_REVISION = 5;
   private static final int HEAL_BLACK_RECORDS_REVISION = Boolean.getBoolean("nvidiumplus.farfield.healBlackRecords") ? 1 : 0;

   private static int normalizeBlend(int blend) {
      return switch (blend) {
         case 2, 4 -> 2;
         default -> 0;
      };
   }

   private static int normalizeScale(int scale) {
      return switch (scale) {
         case 2 -> 2;
         case 4 -> 4;
         default -> 1;
      };
   }

   public static boolean isWired(FarFieldConfig.Layer layer, FarFieldConfig.Control control) {
      if (layer != FarFieldConfig.Layer.L1) {
         return false;
      }

      return switch (control) {
         case LAYER_ENABLED, DISTANCE, SOLID_LEAVES, UNDERWATER_PLANTS, COLOUR_BLEND, LIGHTING, WATER_LOOK, SMOOTH_LIGHT, CONTACT_SHADE, BLOCK_VARIANTS, CACHE_SPEED -> true;
         case SCALE, FLAT_WATER, TEXTURE_SIMPLIFY, COARSE_SHADING, HEIGHTFIELD, SMALL_DETAIL -> false;
      };
   }

   public static boolean isRetired(FarFieldConfig.Layer layer, FarFieldConfig.Control control) {
      return layer == FarFieldConfig.Layer.L1 && control == FarFieldConfig.Control.SMALL_DETAIL;
   }

   public static boolean isSuperseded(FarFieldConfig.Layer layer, FarFieldConfig.Control control) {
      return false;
   }

   public static boolean isLayerWired(FarFieldConfig.Layer layer) {
      for (FarFieldConfig.Control control : FarFieldConfig.Control.values()) {
         if (isWired(layer, control)) {
            return true;
         }
      }

      return false;
   }

   public FarFieldConfig.LayerSettings layer(FarFieldConfig.Layer layer) {
      return switch (layer) {
         case L1 -> this.layer1;
         case L2 -> this.layer2;
         case L3 -> this.layer3;
      };
   }

   public boolean markCustom() {
      if (FarFieldConfig.Preset.CUSTOM.id.equals(this.preset)) {
         return false;
      }

      this.preset = FarFieldConfig.Preset.CUSTOM.id;
      return true;
   }

   public void applyPreset(FarFieldConfig.Preset preset) {
      this.preset = preset.id;
      if (preset.managesValues()) {
         this.enabled = preset.farFieldOn();
         this.surfaceBand = true;
         this.bandOffset = 8;
         this.layer1 = FarFieldConfig.LayerSettings.layer1Defaults();
         this.layer1.radiusChunks = Math.min(preset.l1RadiusChunks(), 64);
         this.layer2 = new FarFieldConfig.LayerSettings();
         this.layer3 = new FarFieldConfig.LayerSettings();
         this.l1RadiusChunks = this.layer1.radiusChunks;
      }
   }

   private boolean migrate() {
      if (this.configVersion >= 8) {
         return false;
      }

      if (this.configVersion < 2) {
         this.layer1.enabled = true;
         this.layer1.radiusChunks = Math.max(0, Math.min(192, this.l1RadiusChunks));
      }

      if (this.configVersion < 3) {
         FarFieldConfig.LayerSettings shipped = FarFieldConfig.LayerSettings.layer1Defaults();
         this.layer1.underwaterPlants = shipped.underwaterPlants;
         this.layer1.smallDetail = shipped.smallDetail;
         this.layer1.colourBlend = shipped.colourBlend;
         this.layer1.lighting = shipped.lighting;
      }

      if (this.configVersion < 4) {
         this.layer1.waterDepth = FarFieldConfig.LayerSettings.layer1Defaults().waterDepth;
      }

      if (this.configVersion < 5) {
         this.layer1.contactShade = FarFieldConfig.LayerSettings.layer1Defaults().contactShade;
      }

      if (this.configVersion < 6) {
         FarFieldConfig.LayerSettings shipped = FarFieldConfig.LayerSettings.layer1Defaults();
         this.layer1.smoothLight = shipped.smoothLight;
         if (this.layer1.lighting == 1) {
            this.layer1.lighting = shipped.lighting;
         }

         if (this.layer1.contactShade == 50) {
            this.layer1.contactShade = shipped.contactShade;
         }
      }

      if (this.configVersion < 7) {
         this.layer1.cacheSpeed = FarFieldConfig.LayerSettings.layer1Defaults().cacheSpeed;
      }

      if (this.configVersion < 8) {
         this.layer1.blockVariants = FarFieldConfig.LayerSettings.layer1Defaults().blockVariants;
      }

      this.configVersion = 8;
      return true;
   }

   private void normalize() {
      if (this.layer1 == null) {
         this.layer1 = FarFieldConfig.LayerSettings.layer1Defaults();
      }

      if (this.layer2 == null) {
         this.layer2 = new FarFieldConfig.LayerSettings();
      }

      if (this.layer3 == null) {
         this.layer3 = new FarFieldConfig.LayerSettings();
      }

      this.layer1.normalize();
      this.layer2.normalize();
      this.layer3.normalize();
      this.bandOffset = Math.max(4, Math.min(32, this.bandOffset));
      this.extractBudgetMillis = Math.max(0, Math.min(8, this.extractBudgetMillis));
      this.extractFrameRateFloor = Math.max(30, Math.min(240, this.extractFrameRateFloor));
      if (FarFieldConfig.Preset.byId(this.preset) == FarFieldConfig.Preset.CUSTOM) {
         this.preset = FarFieldConfig.Preset.CUSTOM.id;
      }
   }

   public static FarFieldConfig get() {
      FarFieldConfig loaded = instance;
      if (loaded == null) {
         synchronized (FarFieldConfig.class) {
            loaded = instance;
            if (loaded == null) {
               loaded = load();
               instance = loaded;
            }
         }
      }

      return loaded;
   }

   public static boolean enabled() {
      if (!NvidiumPlusPlatform.isDevelopment()) {
         return false;
      }

      boolean on = propertyOr("enabled", get().enabled);
      if (on && !gateReported) {
         gateReported = true;
         NvidiumPlusLog.LOGGER
            .warn(
               "Far Terrain is UNRELEASED and has been armed anyway - this looks like a development environment. It ships disabled and its settings page is not built. If you are a player and did not expect this, you have -Dfabric.development set somewhere, and any bug you hit beyond here is in an unfinished feature."
            );
      }

      return on;
   }

   public static int l1RadiusChunks() {
      return layerRadiusChunks(FarFieldConfig.Layer.L1);
   }

   public static boolean layerEnabled(FarFieldConfig.Layer layer) {
      return propertyOr(layer.key + "Enabled", get().layer(layer).enabled);
   }

   public static int layerRadiusChunks(FarFieldConfig.Layer layer) {
      Integer override = Integer.getInteger("nvidiumplus.farfield." + layer.key + "RadiusChunks");
      int chunks = override != null ? override : get().layer(layer).radiusChunks;
      return !layerEnabled(layer) ? 0 : Math.max(0, Math.min(192, chunks));
   }

   public static int layerScale(FarFieldConfig.Layer layer) {
      Integer override = Integer.getInteger("nvidiumplus.farfield." + layer.key + "Scale");
      return normalizeScale(override != null ? override : get().layer(layer).scale);
   }

   public static int layerTextureSimplify(FarFieldConfig.Layer layer) {
      Integer override = Integer.getInteger("nvidiumplus.farfield." + layer.key + "TextureSimplify");
      int value = override != null ? override : get().layer(layer).textureSimplify;
      return Math.max(0, Math.min(4, value));
   }

   public static int layerColourBlend(FarFieldConfig.Layer layer) {
      Integer override = Integer.getInteger("nvidiumplus.farfield." + layer.key + "ColourBlend");
      return normalizeBlend(override != null ? override : get().layer(layer).colourBlend);
   }

   public static int layerSmoothLight(FarFieldConfig.Layer layer) {
      Integer override = Integer.getInteger("nvidiumplus.farfield." + layer.key + "SmoothLight");
      int value = override != null ? override : get().layer(layer).smoothLight;
      return Math.max(0, Math.min(2, value));
   }

   public static int layerContactShade(FarFieldConfig.Layer layer) {
      Integer override = Integer.getInteger("nvidiumplus.farfield." + layer.key + "ContactShade");
      int value = override != null ? override : get().layer(layer).contactShade;
      return Math.max(0, Math.min(100, value));
   }

   public static int layerLighting(FarFieldConfig.Layer layer) {
      Integer override = Integer.getInteger("nvidiumplus.farfield." + layer.key + "Lighting");
      int value = override != null ? override : get().layer(layer).lighting;
      return Math.max(0, Math.min(2, value));
   }

   public static int layerCacheSpeed(FarFieldConfig.Layer layer) {
      Integer override = Integer.getInteger("nvidiumplus.farfield." + layer.key + "CacheSpeed");
      int value = override != null ? override : get().layer(layer).cacheSpeed;
      return Math.max(0, Math.min(2, value));
   }

   public static boolean layerFlag(FarFieldConfig.Layer layer, FarFieldConfig.Control control) {
      FarFieldConfig.LayerSettings settings = get().layer(layer);

      return switch (control) {
         case LAYER_ENABLED -> layerEnabled(layer);
         case DISTANCE, SCALE, TEXTURE_SIMPLIFY, COLOUR_BLEND, LIGHTING, SMOOTH_LIGHT, CONTACT_SHADE, CACHE_SPEED -> throw new IllegalArgumentException(
            control
               + " is not a boolean control; use layerRadiusChunks/layerScale/layerTextureSimplify/layerColourBlend/layerLighting/layerSmoothLight/layerContactShade/layerCacheSpeed"
         );
         case SOLID_LEAVES -> propertyOr(layer.key + "SolidLeaves", settings.solidLeaves);
         case FLAT_WATER -> propertyOr(layer.key + "FlatWater", settings.flatWater);
         case COARSE_SHADING -> propertyOr(layer.key + "CoarseShading", settings.coarseShading);
         case HEIGHTFIELD -> propertyOr(layer.key + "Heightfield", settings.heightfield);
         case UNDERWATER_PLANTS -> propertyOr(layer.key + "UnderwaterPlants", settings.underwaterPlants);
         case SMALL_DETAIL -> propertyOr(layer.key + "SmallDetail", settings.smallDetail);
         case WATER_LOOK -> propertyOr(layer.key + "WaterDepth", settings.waterDepth);
         case BLOCK_VARIANTS -> propertyOr(layer.key + "BlockVariants", settings.blockVariants);
      };
   }

   public void setLayerFlag(FarFieldConfig.Layer layer, FarFieldConfig.Control control, boolean value) {
      FarFieldConfig.LayerSettings settings = this.layer(layer);
      switch (control) {
         case LAYER_ENABLED:
            settings.enabled = value;
            break;
         case DISTANCE:
         case SCALE:
         case TEXTURE_SIMPLIFY:
         case COLOUR_BLEND:
         case LIGHTING:
         case SMOOTH_LIGHT:
         case CONTACT_SHADE:
         case CACHE_SPEED:
            throw new IllegalArgumentException(control + " is not a boolean control");
         case SOLID_LEAVES:
            settings.solidLeaves = value;
            break;
         case FLAT_WATER:
            settings.flatWater = value;
            break;
         case COARSE_SHADING:
            settings.coarseShading = value;
            break;
         case HEIGHTFIELD:
            settings.heightfield = value;
            break;
         case UNDERWATER_PLANTS:
            settings.underwaterPlants = value;
            break;
         case SMALL_DETAIL:
            settings.smallDetail = value;
            break;
         case WATER_LOOK:
            settings.waterDepth = value;
            break;
         case BLOCK_VARIANTS:
            settings.blockVariants = value;
      }
   }

   public static FarFieldConfig.Preset selectedPreset() {
      String override = System.getProperty("nvidiumplus.farfield.preset");
      return FarFieldConfig.Preset.byId(override != null ? override : get().preset);
   }

   public static boolean anyLayerPropertyOverride(FarFieldConfig.Layer layer) {
      String[] suffixes = new String[]{
         "Enabled",
         "RadiusChunks",
         "Scale",
         "SolidLeaves",
         "FlatWater",
         "TextureSimplify",
         "CoarseShading",
         "Heightfield",
         "UnderwaterPlants",
         "SmallDetail",
         "ColourBlend",
         "Lighting",
         "WaterDepth",
         "SmoothLight",
         "ContactShade",
         "BlockVariants",
         "CacheSpeed"
      };

      for (String suffix : suffixes) {
         if (System.getProperty("nvidiumplus.farfield." + layer.key + suffix) != null) {
            return true;
         }
      }

      return false;
   }

   public static boolean isPropertyOverridden(FarFieldConfig.Layer layer, FarFieldConfig.Control control) {
      String suffix = switch (control) {
         case LAYER_ENABLED -> "Enabled";
         case DISTANCE -> "RadiusChunks";
         case SCALE -> "Scale";
         case SOLID_LEAVES -> "SolidLeaves";
         case FLAT_WATER -> "FlatWater";
         case TEXTURE_SIMPLIFY -> "TextureSimplify";
         case COARSE_SHADING -> "CoarseShading";
         case HEIGHTFIELD -> "Heightfield";
         case UNDERWATER_PLANTS -> "UnderwaterPlants";
         case SMALL_DETAIL -> "SmallDetail";
         case COLOUR_BLEND -> "ColourBlend";
         case LIGHTING -> "Lighting";
         case WATER_LOOK -> "WaterDepth";
         case SMOOTH_LIGHT -> "SmoothLight";
         case CONTACT_SHADE -> "ContactShade";
         case BLOCK_VARIANTS -> "BlockVariants";
         case CACHE_SPEED -> "CacheSpeed";
      };
      return System.getProperty("nvidiumplus.farfield." + layer.key + suffix) != null;
   }

   public static boolean surfaceBandEnabled() {
      return propertyOr("surfaceBand", get().surfaceBand);
   }

   public static int bandOffset() {
      Integer override = Integer.getInteger("nvidiumplus.farfield.bandOffset");
      int offset = override != null ? override : get().bandOffset;
      return Math.max(4, Math.min(32, offset));
   }

   public static int extractBudgetMillis() {
      Integer override = Integer.getInteger("nvidiumplus.farfield.extractBudgetMillis");
      int millis = override != null ? override : get().extractBudgetMillis;
      return Math.max(0, Math.min(8, millis));
   }

   public static long extractBudgetNanos() {
      return extractBudgetMillis() * 1000000L;
   }

   public static boolean adaptiveExtraction() {
      return propertyOr("adaptiveExtraction", get().adaptiveExtraction);
   }

   public static int extractFrameRateFloor() {
      Integer override = Integer.getInteger("nvidiumplus.farfield.extractFrameRateFloor");
      int fps = override != null ? override : get().extractFrameRateFloor;
      return Math.max(30, Math.min(240, fps));
   }

   public static long extractTargetFrameNanos() {
      return 1000000000L / extractFrameRateFloor();
   }

   public static int farMeshSignature() {
      int signature = layerLighting(FarFieldConfig.Layer.L1);
      signature = signature * 31 + (layerFlag(FarFieldConfig.Layer.L1, FarFieldConfig.Control.SOLID_LEAVES) ? 1 : 0);
      signature = signature * 31 + (layerFlag(FarFieldConfig.Layer.L1, FarFieldConfig.Control.WATER_LOOK) ? 1 : 0);
      signature = signature * 31 + layerSmoothLight(FarFieldConfig.Layer.L1);
      signature = signature * 31 + layerContactShade(FarFieldConfig.Layer.L1);
      return signature * 31 + (layerFlag(FarFieldConfig.Layer.L1, FarFieldConfig.Control.BLOCK_VARIANTS) ? 1 : 0);
   }

   public static int biomeBlendRadius() {
      try {
         Minecraft client = Minecraft.getInstance();
         if (client != null && client.options != null) {
            return Math.max(0, Math.min(7, (Integer)client.options.biomeBlendRadius().get()));
         }
      } catch (Throwable var1) {
      }

      return 2;
   }

   public static int farSaveSignature() {
      int signature = layerColourBlend(FarFieldConfig.Layer.L1);
      signature = signature * 31 + (layerFlag(FarFieldConfig.Layer.L1, FarFieldConfig.Control.UNDERWATER_PLANTS) ? 1 : 0);
      signature = signature * 31 + (layerLighting(FarFieldConfig.Layer.L1) == 2 ? 1 : 0);
      signature = signature * 31 + (surfaceBandEnabled() ? 1 : 0);
      signature = signature * 31 + bandOffset();
      signature = signature * 31 + 5;
      signature = signature * 31 + biomeBlendRadius();
      return signature + HEAL_BLACK_RECORDS_REVISION;
   }

   private static boolean propertyOr(String suffix, boolean configValue) {
      String property = System.getProperty("nvidiumplus.farfield." + suffix);
      return property != null ? Boolean.parseBoolean(property) : configValue;
   }

   private static Path path() {
      return NvidiumPlusPlatform.configDir().resolve("nvidiumplus-farfield.json");
   }

   private static FarFieldConfig load() {
      Path path = path();

      try {
         if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
               FarFieldConfig loaded = (FarFieldConfig)GSON.fromJson(reader, FarFieldConfig.class);
               if (loaded != null) {
                  loaded.normalize();
                  if (loaded.migrate()) {
                     NvidiumPlusLog.LOGGER.info("NvidiumPlus migrated {} to far-field settings schema v{}", path, 8);
                     loaded.save();
                  }

                  return loaded;
               }
            }
         }
      } catch (IOException | JsonParseException e) {
         NvidiumPlusLog.LOGGER.warn("Could not read {}; starting from defaults", path, e);
      }

      FarFieldConfig fresh = new FarFieldConfig();
      fresh.normalize();
      fresh.migrate();
      return fresh;
   }

   public void save() {
      this.l1RadiusChunks = this.layer1 != null ? this.layer1.radiusChunks : 64;
      Path path = path();

      try {
         Files.createDirectories(path.getParent());

         try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            GSON.toJson(this, writer);
         }
      } catch (IOException e) {
         NvidiumPlusLog.LOGGER.warn("Could not write {}; settings will not persist", path, e);
      }
   }

   public enum Control {
      LAYER_ENABLED,
      DISTANCE,
      SCALE,
      SOLID_LEAVES,
      FLAT_WATER,
      TEXTURE_SIMPLIFY,
      COARSE_SHADING,
      HEIGHTFIELD,
      UNDERWATER_PLANTS,
      SMALL_DETAIL,
      COLOUR_BLEND,
      LIGHTING,
      WATER_LOOK,
      SMOOTH_LIGHT,
      CONTACT_SHADE,
      BLOCK_VARIANTS,
      CACHE_SPEED;
   }

   public enum Layer {
      L1("l1", 1),
      L2("l2", 2),
      L3("l3", 3);

      public final String key;
      public final int number;

      Layer(String key, int number) {
         this.key = key;
         this.number = number;
      }
   }

   public static final class LayerSettings {
      public boolean enabled = false;
      public int radiusChunks = 0;
      public int scale = 1;
      public boolean solidLeaves = false;
      public boolean flatWater = false;
      public int textureSimplify = 0;
      public boolean coarseShading = false;
      public boolean heightfield = false;
      public boolean underwaterPlants = false;
      public boolean smallDetail = false;
      public boolean waterDepth = false;
      public int colourBlend = 0;
      public int lighting = 0;
      public int smoothLight = 0;
      public int contactShade = 0;
      public boolean blockVariants = false;
      public int cacheSpeed = 0;

      public static FarFieldConfig.LayerSettings layer1Defaults() {
         FarFieldConfig.LayerSettings settings = new FarFieldConfig.LayerSettings();
         settings.enabled = true;
         settings.radiusChunks = 64;
         settings.underwaterPlants = true;
         settings.smallDetail = true;
         settings.waterDepth = true;
         settings.colourBlend = 2;
         settings.lighting = 2;
         settings.smoothLight = 2;
         settings.contactShade = 100;
         settings.blockVariants = true;
         settings.cacheSpeed = 2;
         return settings;
      }

      void normalize() {
         this.radiusChunks = Math.max(0, Math.min(192, this.radiusChunks));
         this.scale = FarFieldConfig.normalizeScale(this.scale);
         this.textureSimplify = Math.max(0, Math.min(4, this.textureSimplify));
         this.colourBlend = FarFieldConfig.normalizeBlend(this.colourBlend);
         this.lighting = Math.max(0, Math.min(2, this.lighting));
         this.smoothLight = Math.max(0, Math.min(2, this.smoothLight));
         this.contactShade = Math.max(0, Math.min(100, this.contactShade));
         this.cacheSpeed = Math.max(0, Math.min(2, this.cacheSpeed));
      }
   }

   public enum Preset {
      CUSTOM("custom", -1, 64, false),
      NO_LOD("no_lod", 32, 64, false),
      HIGHEST_DETAIL("highest_detail", 32, 64, true),
      BALANCED("balanced", 16, 64, true),
      PERFORMANT("performant", 12, 48, true),
      ULTRA_PERFORMANT("ultra_performant", 8, 32, true);

      public final String id;
      private final int renderDistanceChunks;
      private final int l1RadiusChunks;
      private final boolean farFieldOn;
      public static final FarFieldConfig.Preset[] LADDER = new FarFieldConfig.Preset[]{CUSTOM, NO_LOD, HIGHEST_DETAIL, BALANCED, PERFORMANT, ULTRA_PERFORMANT};

      Preset(String id, int renderDistanceChunks, int l1RadiusChunks, boolean farFieldOn) {
         this.id = id;
         this.renderDistanceChunks = renderDistanceChunks;
         this.l1RadiusChunks = l1RadiusChunks;
         this.farFieldOn = farFieldOn;
      }

      public int renderDistanceChunks() {
         return this.renderDistanceChunks;
      }

      public int l1RadiusChunks() {
         return this.l1RadiusChunks;
      }

      public boolean farFieldOn() {
         return this.farFieldOn;
      }

      public boolean managesValues() {
         return this != CUSTOM;
      }

      public static FarFieldConfig.Preset byId(String id) {
         if (id != null) {
            for (FarFieldConfig.Preset preset : values()) {
               if (preset.id.equals(id)) {
                  return preset;
               }
            }
         }

         return CUSTOM;
      }
   }
}
