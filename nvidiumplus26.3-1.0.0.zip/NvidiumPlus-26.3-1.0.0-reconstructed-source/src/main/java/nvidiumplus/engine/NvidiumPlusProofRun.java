package nvidiumplus.engine;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.network.chat.Component;
import nvidiumplus.engine.vk.SodiumTerrainDrawer;

public final class NvidiumPlusProofRun {
   public static final String FRAMES_PROPERTY = "nvidiumplus.dev.proofFrames";
   public static final String SHOT_PROPERTY = "nvidiumplus.dev.proofShot";
   public static final String QUIT_PROPERTY = "nvidiumplus.dev.proofQuit";
   private static final int FRAMES = Integer.getInteger("nvidiumplus.dev.proofFrames", 0);
   public static final boolean ARMED = FRAMES > 0;
   private static final String SHOT = System.getProperty("nvidiumplus.dev.proofShot", "nvidiumplus-proof.png");
   private static final boolean QUIT = !"false".equalsIgnoreCase(System.getProperty("nvidiumplus.dev.proofQuit"));
   private static final int NOT_COUNTING_EVERY = 600;
   private static final DateTimeFormatter LOG_TIME = DateTimeFormatter.ofPattern("ddMMMyyyy HH:mm:ss.SSS", Locale.ROOT);
   private static long frame;
   private static long counted;
   private static long countingFrom = -1L;
   private static boolean begun;
   private static boolean captureScheduled;

   private NvidiumPlusProofRun() {
   }

   public static void onRenderFrame() {
      if (!captureScheduled) {
         long index = frame++;
         if (!begun) {
            begun = true;
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus proof: level frames begin (frame 0); capture after {} in-world frames, screenshot '{}', quit={}",
                  new Object[]{FRAMES, SHOT, QUIT}
               );
         }

         Minecraft mc = Minecraft.getInstance();
         Object screen = mc.gui.screen();
         Object overlay = mc.gui.overlay();
         boolean playerPresent = mc.player != null;
         boolean visible = screen == null && overlay == null && playerPresent;
         if (!visible) {
            if (index % 600L == 0L) {
               NvidiumPlusLog.LOGGER
                  .info(
                     "NvidiumPlus proof: not counting yet at frame {}: screen={} overlay={} player={} ({} counted so far)",
                     new Object[]{index, name(screen), name(overlay), playerPresent, counted}
                  );
            }
         } else {
            if (countingFrom < 0L) {
               countingFrom = index;
               NvidiumPlusLog.LOGGER.info("NvidiumPlus proof: counting from render frame {} (screen=null, overlay=null, player present)", index);
            }

            if (++counted >= FRAMES) {
               captureScheduled = true;
               mc.schedule(NvidiumPlusProofRun::capture);
            }
         }
      }
   }

   private static void capture() {
      Minecraft mc = Minecraft.getInstance();
      NvidiumPlusGate.State state = NvidiumPlusGate.state();
      NvidiumPlusGate.State backend = NvidiumPlusGate.backend();
      NvidiumPlusLog.LOGGER
         .info(
            "NvidiumPlus proof: frame {} reached ({} in-world frames counted from frame {}); gate state={} backend={} sodiumAdapterArmed={} sodiumAdapterConfigured={}",
            new Object[]{frame, counted, countingFrom, state, backend, NvidiumPlusGate.sodiumAdapterArmed(), NvidiumPlusGate.sodiumAdapterConfigured()}
         );
      if (backend == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         try {
            NvidiumPlusLog.LOGGER.info(NvidiumPlusProofRun.SodiumCounters.line());
         } catch (Throwable t) {
            NvidiumPlusLog.LOGGER.warn("NvidiumPlus proof: the SodiumTerrainDrawer counters could not be read", t);
         }
      } else {
         NvidiumPlusLog.LOGGER.info("NvidiumPlus proof: backend is {}, not VULKAN_MESH_SHADERS; no drawer counters", backend);
      }

      Object screen = mc.gui.screen();
      Object overlay = mc.gui.overlay();
      if (screen != null || overlay != null) {
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus proof: a screen or overlay is up at capture time (screen={} overlay={}); the PNG shows it, not the world, and is void",
               name(screen),
               name(overlay)
            );
      }

      Path target = shotPath(mc);

      try {
         Files.deleteIfExists(target);
      } catch (IOException e) {
         NvidiumPlusLog.LOGGER.warn("NvidiumPlus proof: could not delete the previous '{}'", target, e);
      }

      NvidiumPlusLog.LOGGER.info("NvidiumPlus proof: taking screenshot '{}' after {} in-world frames; waiting for the result line", SHOT, counted);

      try {
         Screenshot.grab(mc.gameDirectory, SHOT, mc.gameRenderer.mainRenderTarget(), 1, NvidiumPlusProofRun::onSaved);
      } catch (Throwable t) {
         NvidiumPlusLog.LOGGER.error("NvidiumPlus proof: Screenshot.grab threw; no PNG", t);
         finish(mc);
      }
   }

   private static void onSaved(Component message) {
      Minecraft mc = Minecraft.getInstance();
      Path target = shotPath(mc);

      String file;
      try {
         if (Files.exists(target)) {
            FileTime mtime = Files.getLastModifiedTime(target);
            file = target.toAbsolutePath()
               + " size="
               + Files.size(target)
               + " mtime="
               + LOG_TIME.format(mtime.toInstant().atZone(ZoneId.systemDefault()))
               + " ("
               + mtime
               + ")";
         } else {
            file = "absent";
         }
      } catch (IOException e) {
         file = "unreadable: " + e;
      }

      NvidiumPlusLog.LOGGER.info("NvidiumPlus proof: screenshot result: {}; file {}", message.getString(), file);
      finish(mc);
   }

   private static void finish(Minecraft mc) {
      if (!QUIT) {
         NvidiumPlusLog.LOGGER.info("NvidiumPlus proof: -D{}=false, leaving the client running", "nvidiumplus.dev.proofQuit");
      } else {
         NvidiumPlusLog.LOGGER.warn("NvidiumPlus proof: stopping the client. Everything logged after this line is teardown.");
         mc.schedule(mc::stop);
      }
   }

   private static Path shotPath(Minecraft mc) {
      return new File(new File(mc.gameDirectory, "screenshots"), SHOT).toPath();
   }

   private static String name(Object o) {
      return o == null ? "null" : o.getClass().getName();
   }

   static final class SodiumCounters {
      private SodiumCounters() {
      }

      static String line() {
         return "NvidiumPlus proof: SodiumTerrainDrawer rung="
            + SodiumTerrainDrawer.rung()
            + " framesOwned="
            + SodiumTerrainDrawer.framesOwned()
            + " framesAttempted="
            + SodiumTerrainDrawer.framesAttempted()
            + " occlusionFrames="
            + SodiumTerrainDrawer.occlusionFrames()
            + " framesDrawn="
            + SodiumTerrainDrawer.framesDrawn()
            + " totalSectionsDrawn="
            + SodiumTerrainDrawer.totalSectionsDrawn()
            + " lastSectionsDrawnFrame="
            + SodiumTerrainDrawer.lastSectionsDrawnFrame()
            + " lastRegionsDrawn="
            + SodiumTerrainDrawer.lastRegionsDrawn()
            + " lastDrawCommands="
            + SodiumTerrainDrawer.lastDrawCommands()
            + " frameDeclinesTotal="
            + SodiumTerrainDrawer.frameDeclinesTotal()
            + " declines="
            + SodiumTerrainDrawer.frameDeclines()
            + " broken="
            + SodiumTerrainDrawer.broken()
            + " error="
            + SodiumTerrainDrawer.error()
            + " gpuDrawBroken="
            + SodiumTerrainDrawer.gpuDrawBroken()
            + " gpuDrawError="
            + SodiumTerrainDrawer.gpuDrawError()
            + " occlusionBroken="
            + SodiumTerrainDrawer.occlusionBroken()
            + " occlusionError="
            + SodiumTerrainDrawer.occlusionError()
            + " gpuDrawEnabled="
            + SodiumTerrainDrawer.gpuDrawEnabled()
            + " occlusionEnabled="
            + SodiumTerrainDrawer.occlusionEnabled();
      }
   }
}
