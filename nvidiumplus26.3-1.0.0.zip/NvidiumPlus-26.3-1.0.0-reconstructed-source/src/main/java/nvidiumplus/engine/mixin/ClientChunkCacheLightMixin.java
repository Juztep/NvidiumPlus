package nvidiumplus.engine.mixin;

import net.minecraft.client.multiplayer.ClientChunkCache;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.LightLayer;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.farfield.extract.ExtractDispatch;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientChunkCache.class)
abstract class ClientChunkCacheLightMixin {
   @Unique
   private static boolean nvidiumplus$lightHookBroken;

   @Inject(method = "onLightUpdate(Lnet/minecraft/world/level/LightLayer;Lnet/minecraft/core/SectionPos;)V", at = @At("HEAD"))
   private void nvidiumplus$onLightUpdate(LightLayer layer, SectionPos pos, CallbackInfo ci) {
      if (ExtractDispatch.armed() && !nvidiumplus$lightHookBroken) {
         try {
            ExtractDispatch.onLightChanged(pos.x(), pos.z());
         } catch (Throwable t) {
            nvidiumplus$lightHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error(
                  "NvidiumPlus far-field light-change bookkeeping failed; disabling the hook for this session (lighting renders normally, horizon light edits fall back to the census repair)",
                  t
               );
         }
      }
   }
}
