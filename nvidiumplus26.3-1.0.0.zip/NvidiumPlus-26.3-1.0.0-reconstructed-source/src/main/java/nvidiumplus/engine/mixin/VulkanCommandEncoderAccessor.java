package nvidiumplus.engine.mixin;

import com.mojang.renderpearl.backend.vulkan.VulkanCommandEncoder;
import com.mojang.renderpearl.backend.vulkan.VulkanRenderPass;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(VulkanCommandEncoder.class)
public interface VulkanCommandEncoderAccessor {
   @Accessor("currentRenderPass")
   VulkanRenderPass nvidiumplus$currentRenderPass();

   @Invoker("commandBuffer")
   VkCommandBuffer nvidiumplus$commandBuffer();
}
