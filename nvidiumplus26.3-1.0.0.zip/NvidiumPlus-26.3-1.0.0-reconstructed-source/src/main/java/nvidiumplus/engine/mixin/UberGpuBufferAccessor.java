package nvidiumplus.engine.mixin;

import com.mojang.blaze3d.vertex.UberGpuBuffer;
import java.util.List;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(UberGpuBuffer.class)
public interface UberGpuBufferAccessor {
   @Accessor("nodes")
   List<?> nvidiumplus$nodes();

   @Accessor("heapSize")
   int nvidiumplus$heapSize();
}
