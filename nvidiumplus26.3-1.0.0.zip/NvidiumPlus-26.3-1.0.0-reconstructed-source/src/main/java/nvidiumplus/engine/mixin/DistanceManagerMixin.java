package nvidiumplus.engine.mixin;

import net.minecraft.server.level.DistanceManager;
import nvidiumplus.engine.NvidiumPlusExtendedRd;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(DistanceManager.class)
public abstract class DistanceManagerMixin {
   @ModifyConstant(method = "<init>", constant = @Constant(intValue = 32))
   private int nvidiumplus$widenPlayerTicketTrackerRange(int vanillaRange) {
      return Math.max(vanillaRange, NvidiumPlusExtendedRd.serverViewDistanceCap());
   }
}
