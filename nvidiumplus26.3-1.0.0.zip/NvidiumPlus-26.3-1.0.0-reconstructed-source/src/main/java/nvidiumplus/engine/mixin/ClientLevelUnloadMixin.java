package nvidiumplus.engine.mixin;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.chunk.LevelChunk;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.farfield.extract.ExtractDispatch;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientLevel.class)
abstract class ClientLevelUnloadMixin {
   @Unique
   private static boolean nvidiumplus$unloadHookBroken;

   @Inject(method = "unload(Lnet/minecraft/world/level/chunk/LevelChunk;)V", at = @At("HEAD"))
   private void nvidiumplus$beforeUnload(LevelChunk chunk, CallbackInfo ci) {
      if (ExtractDispatch.armed() && !nvidiumplus$unloadHookBroken) {
         try {
            ExtractDispatch.onChunkDropping(chunk);
         } catch (Throwable t) {
            nvidiumplus$unloadHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error(
                  "NvidiumPlus far-field extraction failed at the unload seam; disabling the hook for this session (chunks unload normally, the far field just stops growing)",
                  t
               );
         }
      }
   }
}
