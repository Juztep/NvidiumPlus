package nvidiumplus.engine.mixin;

import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import net.minecraft.client.renderer.ProjectionMatrixBuffer;
import nvidiumplus.engine.vk.NvidiumPlusProjectionCapture;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ProjectionMatrixBuffer.class)
abstract class ProjectionMatrixBufferMixin {
   @Inject(method = "getBuffer(Lorg/joml/Matrix4f;)Lcom/mojang/renderpearl/api/buffers/GpuBufferSlice;", at = @At("RETURN"))
   private void nvidiumplus$captureProjection(Matrix4f matrix, CallbackInfoReturnable<GpuBufferSlice> cir) {
      NvidiumPlusProjectionCapture.record(matrix, (GpuBufferSlice)cir.getReturnValue());
   }
}
