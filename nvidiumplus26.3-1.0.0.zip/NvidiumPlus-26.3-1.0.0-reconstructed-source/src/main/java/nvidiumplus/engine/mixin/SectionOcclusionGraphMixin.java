package nvidiumplus.engine.mixin;

import net.minecraft.client.renderer.SectionOcclusionGraph;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.state.level.ChunkLoadingRenderState;
import nvidiumplus.engine.NvidiumPlusCpuStages;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SectionOcclusionGraph.class)
abstract class SectionOcclusionGraphMixin {
   @Unique
   private static long nvidiumplus$updateT0;

   @Inject(
      method = "update(Lnet/minecraft/client/renderer/state/level/CameraRenderState;ILnet/minecraft/client/renderer/state/level/ChunkLoadingRenderState;)V",
      at = @At("HEAD")
   )
   private void nvidiumplus$updateHead(CameraRenderState cameraRenderState, int fov, ChunkLoadingRenderState chunkLoadingRenderState, CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED) {
         nvidiumplus$updateT0 = System.nanoTime();
      }
   }

   @Inject(
      method = "update(Lnet/minecraft/client/renderer/state/level/CameraRenderState;ILnet/minecraft/client/renderer/state/level/ChunkLoadingRenderState;)V",
      at = @At("RETURN")
   )
   private void nvidiumplus$updateReturn(CameraRenderState cameraRenderState, int fov, ChunkLoadingRenderState chunkLoadingRenderState, CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED) {
         NvidiumPlusCpuStages.record(2, System.nanoTime() - nvidiumplus$updateT0);
      }
   }
}
