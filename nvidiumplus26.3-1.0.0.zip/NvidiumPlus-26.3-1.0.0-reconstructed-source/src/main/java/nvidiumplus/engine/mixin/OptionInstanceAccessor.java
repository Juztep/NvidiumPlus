package nvidiumplus.engine.mixin;

import com.mojang.serialization.Codec;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.OptionInstance.ValueSet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(OptionInstance.class)
public interface OptionInstanceAccessor {
   @Accessor("values")
   ValueSet<?> nvidiumplus$values();

   @Mutable
   @Accessor("values")
   void nvidiumplus$setValues(ValueSet<?> var1);

   @Accessor("codec")
   Codec<?> nvidiumplus$codec();

   @Mutable
   @Accessor("codec")
   void nvidiumplus$setCodec(Codec<?> var1);
}
