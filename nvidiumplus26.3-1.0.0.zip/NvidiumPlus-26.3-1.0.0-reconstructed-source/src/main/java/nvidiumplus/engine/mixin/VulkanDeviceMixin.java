package nvidiumplus.engine.mixin;

import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.vk.NvidiumPlusDeviceTeardown;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(VulkanDevice.class)
abstract class VulkanDeviceMixin {
   @Inject(
      method = "close()V",
      at = @At(value = "INVOKE", target = "Lcom/mojang/renderpearl/backend/vulkan/VulkanCommandEncoder;destroy()V", shift = Shift.AFTER)
   )
   private void nvidiumplus$destroyDeviceObjects(CallbackInfo ci) {
      try {
         NvidiumPlusDeviceTeardown.onDeviceClose((VulkanDevice)this);
      } catch (Throwable t) {
         NvidiumPlusLog.LOGGER.error("NvidiumPlus device teardown failed; continuing vanilla shutdown (handles die with the device)", t);
      }
   }
}
