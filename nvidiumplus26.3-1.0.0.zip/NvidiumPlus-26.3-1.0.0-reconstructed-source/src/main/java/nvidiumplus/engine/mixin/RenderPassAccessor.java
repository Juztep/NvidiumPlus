package nvidiumplus.engine.mixin;

import com.mojang.renderpearl.api.commands.RenderPass.RenderArea;
import com.mojang.renderpearl.api.commands.RenderPassDescriptor.Attachment;
import com.mojang.renderpearl.backend.api.RenderPassBackend;
import com.mojang.renderpearl.frontend.FrontendRenderPass;
import java.util.List;
import java.util.Optional;
import org.joml.Vector4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(FrontendRenderPass.class)
public interface RenderPassAccessor {
   @Accessor("backend")
   RenderPassBackend nvidiumplus$backend();

   @Accessor("backend")
   @Mutable
   void nvidiumplus$setBackend(RenderPassBackend var1);

   @Accessor("isClosed")
   void nvidiumplus$setClosed(boolean var1);

   @Accessor("pushedDebugGroups")
   int nvidiumplus$pushedDebugGroups();

   @Accessor("colorAttachments")
   List<Attachment<Optional<Vector4fc>>> nvidiumplus$colorAttachments();

   @Accessor("hasDepthAttachment")
   boolean nvidiumplus$hasDepthAttachment();

   @Accessor("renderArea")
   RenderArea nvidiumplus$renderArea();
}
