package nvidiumplus.engine.mixin;

import com.mojang.renderpearl.backend.vulkan.VulkanCommandEncoder;
import nvidiumplus.engine.NvidiumPlusCpuStages;
import nvidiumplus.engine.vk.SodiumTerrainDrawer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(VulkanCommandEncoder.class)
abstract class VulkanCommandEncoderMixin {
   @Unique
   private static long nvidiumplus$submitT0;

   @Inject(method = "submit()V", at = @At("HEAD"))
   private void nvidiumplus$submitHead(CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED) {
         nvidiumplus$submitT0 = System.nanoTime();
      }
   }

   @Inject(method = "submit()V", at = @At("RETURN"))
   private void nvidiumplus$submitReturn(CallbackInfo ci) {
      SodiumTerrainDrawer.onEncoderSubmit();
      if (NvidiumPlusCpuStages.ARMED && nvidiumplus$submitT0 != 0L) {
         NvidiumPlusCpuStages.record(8, System.nanoTime() - nvidiumplus$submitT0);
         nvidiumplus$submitT0 = 0L;
      }
   }
}
