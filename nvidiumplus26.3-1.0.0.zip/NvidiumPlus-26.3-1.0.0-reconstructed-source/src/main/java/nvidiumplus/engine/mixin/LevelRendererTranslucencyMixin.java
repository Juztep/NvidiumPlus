package nvidiumplus.engine.mixin;

import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.renderpearl.api.textures.GpuSampler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.chunk.ChunkSectionLayerGroup;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;
import net.minecraft.client.renderer.feature.FeatureRenderDispatcher.PreparedFrame;
import nvidiumplus.engine.compat.McCompat;
import nvidiumplus.engine.vk.MainPassSuspension;
import nvidiumplus.engine.vk.TerrainKillSwitch;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelRenderer.class)
abstract class LevelRendererTranslucencyMixin {
   @Shadow
   private GpuSampler chunkLayerSampler;

   @Inject(
      method = "executeSolid(Lnet/minecraft/client/renderer/chunk/ChunkSectionsToRender;Lnet/minecraft/client/renderer/feature/FeatureRenderDispatcher$PreparedFrame;Lcom/mojang/renderpearl/api/commands/RenderPass;)V",
      at = @At("TAIL")
   )
   private void nvidiumplus$translucentBeforeOit(ChunkSectionsToRender sections, PreparedFrame frame, RenderPass pass, CallbackInfo ci) {
      if (Minecraft.getInstance().gameRenderer.useImprovedTransparency()) {
         if (TerrainKillSwitch.translucentWanted()) {
            try (MainPassSuspension suspended = MainPassSuspension.suspend(pass)) {
               if (suspended == null) {
                  return;
               }

               if (TerrainKillSwitch.beforeRenderGroup(sections, ChunkSectionLayerGroup.TRANSLUCENT, this.chunkLayerSampler, McCompat.blockAtlasView())) {
                  TerrainKillSwitch.noteTranslucentUnderImprovedTransparency();
               }
            }
         }
      }
   }
}
