package nvidiumplus.engine.mixin;

import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.world.level.chunk.LevelChunk;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.farfield.extract.ExtractDispatch;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
abstract class ClientPacketListenerChunkReceiveMixin {
   @Unique
   private static boolean nvidiumplus$receiveHookBroken;

   @Inject(method = "enableChunkLight(Lnet/minecraft/world/level/chunk/LevelChunk;II)V", at = @At("TAIL"))
   private void nvidiumplus$afterChunkLight(LevelChunk chunk, int chunkX, int chunkZ, CallbackInfo ci) {
      if (ExtractDispatch.armed() && !nvidiumplus$receiveHookBroken) {
         try {
            ExtractDispatch.onChunkReceived(chunk);
         } catch (Throwable t) {
            nvidiumplus$receiveHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error(
                  "NvidiumPlus far-field extraction failed at the chunk-receive seam; disabling the hook for this session (chunks load normally, the far field falls back to extracting at unload)",
                  t
               );
         }
      }
   }
}
