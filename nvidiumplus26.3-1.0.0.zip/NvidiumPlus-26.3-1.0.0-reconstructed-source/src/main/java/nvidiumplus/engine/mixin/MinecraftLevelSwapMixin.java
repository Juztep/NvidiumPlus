package nvidiumplus.engine.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.farfield.CacheKeys;
import nvidiumplus.engine.farfield.FarField;
import nvidiumplus.engine.farfield.extract.ExtractDispatch;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
abstract class MinecraftLevelSwapMixin {
   @Unique
   private static boolean nvidiumplus$levelSwapHookBroken;

   @Inject(method = "setLevel(Lnet/minecraft/client/multiplayer/ClientLevel;)V", at = @At("HEAD"))
   private void nvidiumplus$beforeSetLevel(ClientLevel newLevel, CallbackInfo ci) {
      if (!nvidiumplus$levelSwapHookBroken) {
         try {
            ExtractDispatch.refreshArmed();
            FarField.onWorldLeave();
            if (ExtractDispatch.armed()) {
               ExtractDispatch.onLevelSwap();
               Minecraft mc = (Minecraft)this;
               FarField.onWorldJoin(CacheKeys.worldKey(mc), CacheKeys.dimensionKey(newLevel));
            }
         } catch (Throwable t) {
            nvidiumplus$levelSwapHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus far-field level-swap bookkeeping failed; disabling the hook for this session", t);
         }
      }
   }

   @Inject(method = "clearClientLevel(Lnet/minecraft/client/gui/screens/Screen;)V", at = @At("HEAD"))
   private void nvidiumplus$beforeClearClientLevel(Screen screen, CallbackInfo ci) {
      if (!nvidiumplus$levelSwapHookBroken) {
         try {
            if (ExtractDispatch.armed()) {
               ExtractDispatch.onLevelSwap();
            }

            FarField.onWorldLeave();
         } catch (Throwable t) {
            nvidiumplus$levelSwapHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus far-field level-swap bookkeeping failed; disabling the hook for this session", t);
         }
      }
   }
}
