package nvidiumplus.engine.mixin;

import java.nio.ByteBuffer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.CompiledSectionMesh;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher.RenderSection;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.terrain.host.TerrainResidency;
import nvidiumplus.engine.terrain.host.VanillaUploadSeam;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(RenderSection.class)
abstract class RenderSectionMixin {
   @Unique
   private static boolean nvidiumplus$freeHookBroken;
   @Unique
   private static boolean nvidiumplus$resortHookBroken;
   private static boolean nvidiumplus$seamBroken;
   @Unique
   private static boolean nvidiumplus$resetHookBroken;

   @Inject(method = "reset()V", at = @At("HEAD"))
   private void nvidiumplus$onResetHead(CallbackInfo ci) {
      if (!nvidiumplus$resetHookBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         try {
            TerrainResidency.beginSlotReset();
         } catch (Throwable t) {
            nvidiumplus$resetHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus reset bracket failed; retention degrades to plain frees for this session", t);
         }
      }
   }

   @Inject(method = "reset()V", at = @At("RETURN"))
   private void nvidiumplus$onResetReturn(CallbackInfo ci) {
      if (!nvidiumplus$resetHookBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         try {
            TerrainResidency.endSlotReset();
         } catch (Throwable t) {
            nvidiumplus$resetHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus reset bracket failed; retention degrades to plain frees for this session", t);
         }
      }
   }

   @Inject(method = "releaseSectionMesh(Lnet/minecraft/client/renderer/chunk/SectionMesh;)V", at = @At("HEAD"))
   private void nvidiumplus$onReleaseSectionMesh(SectionMesh mesh, CallbackInfo ci) {
      if (!nvidiumplus$freeHookBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         try {
            TerrainResidency.onMeshReleased(mesh);
         } catch (Throwable t) {
            nvidiumplus$freeHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus mesh free hook failed; disabling for this session (residency will over-retain until dispose)", t);
         }
      }
   }

   @Inject(
      method = "addSectionBuffersToUberBuffer(Lnet/minecraft/client/renderer/chunk/ChunkSectionLayer;Lnet/minecraft/client/renderer/chunk/CompiledSectionMesh;Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;)Z",
      at = @At("HEAD"),
      cancellable = true
   )
   private void nvidiumplus$onTranslucentResortUpload(
      ChunkSectionLayer layer, CompiledSectionMesh mesh, ByteBuffer vertexBuffer, ByteBuffer indexBuffer, CallbackInfoReturnable<Boolean> cir
   ) {
      this.nvidiumplus$resortTap(layer, mesh, vertexBuffer, indexBuffer);
      this.nvidiumplus$suppressVanillaUpload(layer, mesh, vertexBuffer, indexBuffer, cir);
   }

   private void nvidiumplus$resortTap(ChunkSectionLayer layer, CompiledSectionMesh mesh, ByteBuffer vertexBuffer, ByteBuffer indexBuffer) {
      if (!nvidiumplus$resortHookBroken
         && layer == ChunkSectionLayer.TRANSLUCENT
         && vertexBuffer == null
         && indexBuffer != null
         && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         try {
            TerrainResidency.onTranslucentResort(mesh, indexBuffer);
         } catch (Throwable t) {
            nvidiumplus$resortHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error("NvidiumPlus resort tap failed; disabling for this session (translucent intra-section order will go stale as the camera moves)", t);
         }
      }
   }

   private void nvidiumplus$suppressVanillaUpload(
      ChunkSectionLayer layer, CompiledSectionMesh mesh, ByteBuffer vertexBuffer, ByteBuffer indexBuffer, CallbackInfoReturnable<Boolean> cir
   ) {
      if (!nvidiumplus$seamBroken && VanillaUploadSeam.armed()) {
         try {
            LevelRenderer levelRenderer = Minecraft.getInstance().levelRenderer;
            SectionRenderDispatcher dispatcher = levelRenderer == null ? null : levelRenderer.sectionRenderDispatcher();
            if (dispatcher != null) {
               dispatcher.lock();

               try {
                  if (mesh.getSectionDraw(layer) == null) {
                     cir.setReturnValue(Boolean.TRUE);
                     return;
                  }

                  if (vertexBuffer != null) {
                     mesh.setVertexBufferUploaded(layer);
                  }

                  mesh.setIndexBufferUploaded(layer);
                  ((RenderSectionInvoker)this).nvidiumplus$checkSectionMesh(mesh);
               } finally {
                  dispatcher.unlock();
               }

               VanillaUploadSeam.noteSuppressed();
               cir.setReturnValue(Boolean.TRUE);
            }
         } catch (Throwable t) {
            nvidiumplus$seamBroken = true;
            VanillaUploadSeam.demote("seam handler threw: " + t);
            NvidiumPlusLog.LOGGER.error("NvidiumPlus upload seam failed; vanilla's uploads resume for this session", t);
         }
      }
   }
}
