package nvidiumplus.engine.mixin;

import net.minecraft.client.multiplayer.ClientChunkCache;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.farfield.extract.ExtractDispatch;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientChunkCache.class)
abstract class ClientChunkCacheViewMixin {
   @Unique
   private static boolean nvidiumplus$viewRadiusHookBroken;
   @Unique
   private static boolean nvidiumplus$viewCenterHookBroken;

   @Inject(method = "updateViewRadius(I)V", at = @At("HEAD"))
   private void nvidiumplus$beforeUpdateViewRadius(int newRadius, CallbackInfo ci) {
      if (ExtractDispatch.armed() && !nvidiumplus$viewRadiusHookBroken) {
         try {
            ExtractDispatch.onViewRadiusShrink(newRadius);
         } catch (Throwable t) {
            nvidiumplus$viewRadiusHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus far-field view-radius bookkeeping failed; disabling the hook for this session", t);
         }
      }
   }

   @Inject(method = "updateViewCenter(II)V", at = @At("HEAD"))
   private void nvidiumplus$beforeUpdateViewCenter(int newCenterX, int newCenterZ, CallbackInfo ci) {
      if (ExtractDispatch.armed() && !nvidiumplus$viewCenterHookBroken) {
         try {
            ExtractDispatch.onViewCenterMove(newCenterX, newCenterZ);
         } catch (Throwable t) {
            nvidiumplus$viewCenterHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus far-field view-center bookkeeping failed; disabling the hook for this session", t);
         }
      }
   }
}
