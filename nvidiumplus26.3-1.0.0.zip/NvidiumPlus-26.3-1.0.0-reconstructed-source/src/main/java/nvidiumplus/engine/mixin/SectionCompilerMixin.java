package nvidiumplus.engine.mixin;

import com.mojang.blaze3d.vertex.VertexSorting;
import java.util.List;
import net.minecraft.client.renderer.SectionBufferBuilderPack;
import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.client.renderer.chunk.SectionCompiler;
import net.minecraft.client.renderer.chunk.SectionCompiler.Results;
import net.minecraft.core.SectionPos;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.terrain.host.SectionBuildTap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(SectionCompiler.class)
abstract class SectionCompilerMixin {
   @Unique
   private static boolean nvidiumplus$tapBroken;

   @Inject(
      method = "compile(Lnet/minecraft/core/SectionPos;Lnet/minecraft/client/renderer/chunk/RenderSectionRegion;Lcom/mojang/blaze3d/vertex/VertexSorting;Lnet/minecraft/client/renderer/SectionBufferBuilderPack;)Lnet/minecraft/client/renderer/chunk/SectionCompiler$Results;",
      at = @At("RETURN"),
      require = 0
   )
   private void nvidiumplus$afterCompile(
      SectionPos sectionPos, RenderSectionRegion region, VertexSorting vertexSorting, SectionBufferBuilderPack pack, CallbackInfoReturnable<Results> cir
   ) {
      nvidiumplus$tap(sectionPos, (Results)cir.getReturnValue());
   }

   @Inject(
      method = "compile(Lnet/minecraft/core/SectionPos;Lnet/minecraft/client/renderer/chunk/RenderSectionRegion;Lcom/mojang/blaze3d/vertex/VertexSorting;Lnet/minecraft/client/renderer/SectionBufferBuilderPack;Ljava/util/List;)Lnet/minecraft/client/renderer/chunk/SectionCompiler$Results;",
      at = @At("RETURN"),
      require = 0
   )
   private void nvidiumplus$afterCompileWithAddedGeometry(
      SectionPos sectionPos,
      RenderSectionRegion region,
      VertexSorting vertexSorting,
      SectionBufferBuilderPack pack,
      List<?> additionalRenderers,
      CallbackInfoReturnable<Results> cir
   ) {
      nvidiumplus$tap(sectionPos, (Results)cir.getReturnValue());
   }

   @Unique
   private static void nvidiumplus$tap(SectionPos sectionPos, Results results) {
      if (!nvidiumplus$tapBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS && NvidiumPlusConfig.terrainRenderingConfigured()) {
         try {
            SectionBuildTap.onCompileReturn(sectionPos, results);
         } catch (Throwable t) {
            nvidiumplus$tapBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus section tap failed outside its own guard; disabling for this session", t);
         }
      }
   }
}
