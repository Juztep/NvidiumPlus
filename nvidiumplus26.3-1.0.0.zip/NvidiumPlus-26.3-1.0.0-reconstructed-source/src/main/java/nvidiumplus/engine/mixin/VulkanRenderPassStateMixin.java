package nvidiumplus.engine.mixin;

import com.mojang.renderpearl.backend.vulkan.VulkanRenderPass;
import com.mojang.renderpearl.backend.vulkan.VulkanRenderPipeline;
import it.unimi.dsi.fastutil.objects.ReferenceList;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import nvidiumplus.engine.vk.NvidiumPlusPassState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(VulkanRenderPass.class)
abstract class VulkanRenderPassStateMixin implements NvidiumPlusPassState {
   @Shadow
   protected VulkanRenderPipeline pipeline;
   @Shadow
   @Final
   protected ReferenceList<Object> uniforms;
   @Unique
   private ByteBuffer nvidiumplus$lastConstants;

   @Inject(method = "pushConstants(Ljava/nio/ByteBuffer;)V", at = @At("HEAD"))
   private void nvidiumplus$rememberConstants(ByteBuffer constants, CallbackInfo ci) {
      int n = constants.remaining();
      ByteBuffer copy = this.nvidiumplus$lastConstants;
      if (copy == null || copy.capacity() < n) {
         copy = ByteBuffer.allocateDirect(Math.max(n, 256)).order(ByteOrder.nativeOrder());
         this.nvidiumplus$lastConstants = copy;
      }

      copy.clear();
      copy.put(constants.duplicate());
      copy.flip();
   }

   @Override
   public VulkanRenderPipeline nvidiumplus$pipeline() {
      return this.pipeline;
   }

   @Override
   public Object[] nvidiumplus$uniformsSnapshot() {
      return this.uniforms.toArray();
   }

   @Override
   public ByteBuffer nvidiumplus$lastPushConstants() {
      ByteBuffer copy = this.nvidiumplus$lastConstants;
      return copy != null && copy.limit() != 0 ? copy : null;
   }
}
