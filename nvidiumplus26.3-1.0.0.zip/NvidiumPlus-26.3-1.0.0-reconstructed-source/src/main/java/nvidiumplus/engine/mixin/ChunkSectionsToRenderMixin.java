package nvidiumplus.engine.mixin;

import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import net.minecraft.client.renderer.chunk.ChunkSectionLayerGroup;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;
import net.minecraft.client.renderer.oit.OitStage;
import net.minecraft.client.renderer.oit.OitRenderPassProvider.Parameters;
import nvidiumplus.engine.vk.MainPassSuspension;
import nvidiumplus.engine.vk.TerrainKillSwitch;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChunkSectionsToRender.class)
abstract class ChunkSectionsToRenderMixin {
   @Inject(
      method = "renderGroup(Lnet/minecraft/client/renderer/chunk/ChunkSectionLayerGroup;Lcom/mojang/renderpearl/api/commands/RenderPass;Lcom/mojang/renderpearl/api/textures/GpuSampler;Lcom/mojang/renderpearl/api/textures/GpuTextureView;Z)V",
      at = @At("HEAD"),
      cancellable = true
   )
   private void nvidiumplus$replaceTerrainGroups(
      ChunkSectionLayerGroup group, RenderPass pass, GpuSampler sampler, GpuTextureView atlasView, boolean wireframe, CallbackInfo ci
   ) {
      if (!wireframe && TerrainKillSwitch.armed()) {
         if (group != ChunkSectionLayerGroup.TRANSLUCENT || TerrainKillSwitch.translucentWanted()) {
            try (MainPassSuspension suspended = MainPassSuspension.suspend(pass)) {
               if (suspended == null) {
                  return;
               }

               if (TerrainKillSwitch.beforeRenderGroup((ChunkSectionsToRender)this, group, sampler, atlasView)) {
                  ci.cancel();
               }
            }
         }
      }
   }

   @Inject(
      method = "renderGroup(Lnet/minecraft/client/renderer/chunk/ChunkSectionLayerGroup;Lcom/mojang/renderpearl/api/commands/RenderPass;Lcom/mojang/renderpearl/api/textures/GpuSampler;Lcom/mojang/renderpearl/api/textures/GpuTextureView;Z)V",
      at = @At("TAIL")
   )
   private void nvidiumplus$afterOpaqueTerrain(
      ChunkSectionLayerGroup group, RenderPass pass, GpuSampler sampler, GpuTextureView atlasView, boolean wireframe, CallbackInfo ci
   ) {
      TerrainKillSwitch.afterRenderGroup(group);
   }

   @Inject(
      method = "renderOit(Lcom/mojang/renderpearl/api/textures/GpuSampler;Lnet/minecraft/client/renderer/oit/OitStage;Lnet/minecraft/client/renderer/oit/OitRenderPassProvider$Parameters;Lcom/mojang/renderpearl/api/textures/GpuTextureView;Lcom/mojang/renderpearl/api/textures/GpuTextureView;)V",
      at = @At("HEAD"),
      cancellable = true
   )
   private void nvidiumplus$skipOitTerrainWhenDrawn(
      GpuSampler sampler, OitStage stage, Parameters parameters, GpuTextureView atlasView, GpuTextureView lightmapView, CallbackInfo ci
   ) {
      if (TerrainKillSwitch.translucentOwnedThisFrame()) {
         ci.cancel();
      }
   }
}
