package nvidiumplus.engine.mixin;

import com.mojang.renderpearl.api.textures.GpuTextureView;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import net.minecraft.client.renderer.texture.TextureAtlas;
import nvidiumplus.engine.NvidiumPlusBenchRecorder;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusCpuStages;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusProofRun;
import nvidiumplus.engine.compat.McCompat;
import nvidiumplus.engine.terrain.host.TerrainResidency;
import nvidiumplus.engine.vk.NvidiumPlusProjectionCapture;
import nvidiumplus.engine.vk.NvidiumPlusTerrainPump;
import nvidiumplus.engine.vk.TerrainDrawer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LevelRenderer.class)
abstract class LevelRendererMixin {
   @Shadow
   @Final
   private LevelRenderState levelRenderState;
   @Unique
   private static boolean nvidiumplus$pumpHookBroken;
   @Unique
   private static boolean nvidiumplus$frameStateHookBroken;
   @Unique
   private static byte nvidiumplus$preBobGate;
   @Unique
   private static boolean nvidiumplus$preBobHookBroken;
   @Unique
   private static long nvidiumplus$levelRenderT0;
   @Unique
   private static long nvidiumplus$compileT0;
   @Unique
   private static boolean nvidiumplus$skipPrepBroken;
   @Unique
   private static long nvidiumplus$prepareT0;

   @Inject(
      method = "invalidateCompiledGeometry(Lnet/minecraft/client/multiplayer/ClientLevel;Lnet/minecraft/client/Options;Lnet/minecraft/client/Camera;Lnet/minecraft/client/color/block/BlockColors;)V",
      at = @At("HEAD")
   )
   private void nvidiumplus$beforeGeometryInvalidated(ClientLevel level, Options options, Camera camera, BlockColors blockColors, CallbackInfo ci) {
      if (NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         TerrainResidency.onVanillaGeometryInvalidated(options.getEffectiveRenderDistance());
      }
   }

   @Inject(method = "render", at = @At("HEAD"))
   private void nvidiumplus$captureFrameState(CallbackInfo ci) {
      CameraRenderState cameraRenderState = this.levelRenderState.cameraRenderState;
      if (NvidiumPlusBenchRecorder.ARMED) {
         NvidiumPlusBenchRecorder.onRenderFrame();
      }

      if (NvidiumPlusCpuStages.ARMED) {
         NvidiumPlusCpuStages.beginFrame();
         nvidiumplus$levelRenderT0 = System.nanoTime();
      }

      if (NvidiumPlusProofRun.ARMED) {
         NvidiumPlusProofRun.onRenderFrame();
      }

      if (nvidiumplus$preBobGate == 0 && NvidiumPlusGate.state() != NvidiumPlusGate.State.UNKNOWN) {
         nvidiumplus$preBobGate = (byte)(NvidiumPlusGate.state() != NvidiumPlusGate.State.VULKAN_MESH_SHADERS && !NvidiumPlusGate.sodiumAdapterArmed() ? 2 : 1);
      }

      if (nvidiumplus$preBobGate == 1 && !nvidiumplus$preBobHookBroken && cameraRenderState != null && cameraRenderState.projectionMatrix != null) {
         try {
            NvidiumPlusProjectionCapture.recordPreBob(cameraRenderState.projectionMatrix);
         } catch (Throwable t) {
            nvidiumplus$preBobHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error(
                  "NvidiumPlus pre-bob projection stash failed; the half-res occlusion lever will refuse every frame from here (counted as halfResArmSkipsNoPreBob if nothing ever stashed, halfResArmSkipsStale once one did) and terrain draws full-res",
                  t
               );
         }
      }

      if (!nvidiumplus$frameStateHookBroken
         && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS
         && NvidiumPlusConfig.terrainRenderingEnabled()) {
         try {
            TerrainDrawer.beginFrame(cameraRenderState);
         } catch (Throwable t) {
            nvidiumplus$frameStateHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error("NvidiumPlus frame-state capture failed; terrain drawing will stay off (drawOpaque never cancels without camera state)", t);
         }
      }
   }

   @Inject(method = "prepareChunkRenders", at = @At("HEAD"), cancellable = true)
   private void nvidiumplus$beforePrepareChunkRenders(CallbackInfoReturnable<ChunkSectionsToRender> cir) {
      if (NvidiumPlusCpuStages.ARMED) {
         nvidiumplus$prepareT0 = System.nanoTime();
         NvidiumPlusCpuStages.noteVisibleSections(((LevelRenderer)this).visibleSections().size());
      }

      if (NvidiumPlusConfig.skipVanillaPrepEnabled()
         && !nvidiumplus$skipPrepBroken
         && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS
         && NvidiumPlusConfig.terrainRenderingEnabled()) {
         try {
            if (!TerrainDrawer.wouldOwnFrame()) {
               return;
            }

            GpuTextureView atlasView = Minecraft.getInstance().getTextureManager().getTexture(TextureAtlas.LOCATION_BLOCKS).getTextureView();
            if (atlasView == null) {
               return;
            }

            ChunkSectionsToRender empty = McCompat.emptySectionsToRender(atlasView);
            if (empty == null) {
               return;
            }

            TerrainDrawer.notePrepSkipped();
            if (NvidiumPlusCpuStages.ARMED) {
               NvidiumPlusCpuStages.record(3, System.nanoTime() - nvidiumplus$prepareT0);
            }

            cir.setReturnValue(empty);
         } catch (Throwable t) {
            nvidiumplus$skipPrepBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus skipVanillaPrep failed; vanilla prepareChunkRenders resumes for this session (first and only report)", t);
         }
      }
   }

   @Inject(method = "prepareChunkRenders", at = @At("RETURN"))
   private void nvidiumplus$afterPrepareChunkRenders(CallbackInfoReturnable<ChunkSectionsToRender> cir) {
      if (NvidiumPlusCpuStages.ARMED) {
         NvidiumPlusCpuStages.record(3, System.nanoTime() - nvidiumplus$prepareT0);
      }
   }

   @Inject(
      method = "render",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/chunk/SectionRenderDispatcher;uploadTerrainBuffersToGpu()V", shift = Shift.AFTER)
   )
   private void nvidiumplus$afterTerrainUpload(CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED && nvidiumplus$compileT0 != 0L) {
         NvidiumPlusCpuStages.record(7, System.nanoTime() - nvidiumplus$compileT0);
         nvidiumplus$compileT0 = 0L;
      }

      if (!nvidiumplus$pumpHookBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         try {
            if (NvidiumPlusCpuStages.ARMED) {
               long t0 = System.nanoTime();
               NvidiumPlusTerrainPump.afterVanillaTerrainUpload();
               NvidiumPlusCpuStages.record(6, System.nanoTime() - t0);
            } else {
               NvidiumPlusTerrainPump.afterVanillaTerrainUpload();
            }
         } catch (Throwable t) {
            nvidiumplus$pumpHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus terrain pump hook failed outside the pump's own guard; disabling the hook for this session", t);
         }
      }
   }

   @Inject(
      method = "render",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/renderer/LevelRenderer;compileSections(Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V"
      )
   )
   private void nvidiumplus$beforeCompileSections(CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED) {
         nvidiumplus$compileT0 = System.nanoTime();
      }
   }

   @Inject(method = "render", at = @At("RETURN"))
   private void nvidiumplus$afterRender(CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED && nvidiumplus$levelRenderT0 != 0L) {
         NvidiumPlusCpuStages.record(9, System.nanoTime() - nvidiumplus$levelRenderT0);
         nvidiumplus$levelRenderT0 = 0L;
      }
   }
}
