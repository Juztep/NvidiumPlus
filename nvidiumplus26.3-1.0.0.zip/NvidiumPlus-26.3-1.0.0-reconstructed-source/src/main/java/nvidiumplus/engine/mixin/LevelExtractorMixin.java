package nvidiumplus.engine.mixin;

import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.extract.LevelExtractor;
import nvidiumplus.engine.NvidiumPlusCpuStages;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelExtractor.class)
abstract class LevelExtractorMixin {
   @Unique
   private static long nvidiumplus$extractT0;
   @Unique
   private static long nvidiumplus$applyT0;

   @Inject(method = "extract(Lnet/minecraft/client/DeltaTracker;Lnet/minecraft/client/Camera;F)V", at = @At("HEAD"))
   private void nvidiumplus$extractHead(DeltaTracker deltaTracker, Camera camera, float partialTick, CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED) {
         nvidiumplus$extractT0 = System.nanoTime();
      }
   }

   @Inject(method = "extract(Lnet/minecraft/client/DeltaTracker;Lnet/minecraft/client/Camera;F)V", at = @At("RETURN"))
   private void nvidiumplus$extractReturn(DeltaTracker deltaTracker, Camera camera, float partialTick, CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED) {
         NvidiumPlusCpuStages.record(0, System.nanoTime() - nvidiumplus$extractT0);
      }
   }

   @Inject(method = "applyFrustum(Lnet/minecraft/client/renderer/culling/Frustum;)V", at = @At("HEAD"))
   private void nvidiumplus$applyFrustumHead(Frustum frustum, CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED) {
         nvidiumplus$applyT0 = System.nanoTime();
      }
   }

   @Inject(method = "applyFrustum(Lnet/minecraft/client/renderer/culling/Frustum;)V", at = @At("RETURN"))
   private void nvidiumplus$applyFrustumReturn(Frustum frustum, CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED) {
         NvidiumPlusCpuStages.record(1, System.nanoTime() - nvidiumplus$applyT0);
         NvidiumPlusCpuStages.noteApplyFrustumRun();
      }
   }
}
