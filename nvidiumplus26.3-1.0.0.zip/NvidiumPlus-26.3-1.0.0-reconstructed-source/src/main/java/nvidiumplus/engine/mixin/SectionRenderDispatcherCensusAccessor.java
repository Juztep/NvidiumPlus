package nvidiumplus.engine.mixin;

import java.util.Map;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import nvidiumplus.engine.VanillaTerrainCensus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(SectionRenderDispatcher.class)
public interface SectionRenderDispatcherCensusAccessor extends VanillaTerrainCensus.SectionRenderDispatcherAccessorBridge {
   @Accessor("chunkUberBuffers")
   @Override
   Map<?, ?> nvidiumplus$chunkUberBuffers();
}
