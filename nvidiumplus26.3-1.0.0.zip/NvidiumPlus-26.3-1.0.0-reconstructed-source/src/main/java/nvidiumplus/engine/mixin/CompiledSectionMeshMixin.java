package nvidiumplus.engine.mixin;

import net.minecraft.client.renderer.chunk.CompiledSectionMesh;
import net.minecraft.client.renderer.chunk.TranslucencyPointOfView;
import net.minecraft.client.renderer.chunk.SectionCompiler.Results;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.terrain.host.SectionBuildTap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CompiledSectionMesh.class)
abstract class CompiledSectionMeshMixin {
   @Unique
   private static boolean nvidiumplus$rekeyBroken;

   @Inject(
      method = "<init>(Lnet/minecraft/client/renderer/chunk/TranslucencyPointOfView;Lnet/minecraft/client/renderer/chunk/SectionCompiler$Results;J)V",
      at = @At("TAIL")
   )
   private void nvidiumplus$onConstructed(TranslucencyPointOfView pointOfView, Results results, long compileTaskStartTimeNs, CallbackInfo ci) {
      if (!nvidiumplus$rekeyBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         try {
            SectionBuildTap.onMeshConstructed(this, results);
         } catch (Throwable t) {
            nvidiumplus$rekeyBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus mesh re-key hook failed; disabling for this session", t);
         }
      }
   }
}
