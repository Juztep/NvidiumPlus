package nvidiumplus.engine.mixin;

import net.minecraft.server.level.ChunkTaskPriorityQueue;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(ChunkTaskPriorityQueue.class)
public interface ChunkTaskPriorityQueueAccessor {
   @Accessor("PRIORITY_LEVEL_COUNT")
   static int nvidiumplus$priorityLevelCount() {
      throw new AssertionError("mixin accessor not applied");
   }

   @Mutable
   @Accessor("PRIORITY_LEVEL_COUNT")
   static void nvidiumplus$setPriorityLevelCount(int value) {
      throw new AssertionError("mixin accessor not applied");
   }
}
