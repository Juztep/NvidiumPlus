package nvidiumplus.engine.mixin;

import com.mojang.renderpearl.backend.vulkan.VulkanBackend;
import com.mojang.renderpearl.backend.vulkan.VulkanPhysicalDevice;
import com.mojang.renderpearl.backend.vulkan.init.FeatureSet;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.vk.MeshShaderFeatureSets;
import org.lwjgl.vulkan.VkDevice;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(VulkanBackend.class)
abstract class VulkanBackendMixin {
   @Inject(
      method = "createDevice(Lcom/mojang/renderpearl/backend/vulkan/init/FeatureSet;Lcom/mojang/renderpearl/backend/vulkan/VulkanPhysicalDevice;)Lorg/lwjgl/vulkan/VkDevice;",
      at = @At("HEAD")
   )
   private static void nvidiumplus$recordDeviceFeatures(FeatureSet enabled, VulkanPhysicalDevice physicalDevice, CallbackInfoReturnable<VkDevice> cir) {
      try {
         MeshShaderFeatureSets.onCreateDevice(enabled, physicalDevice);
      } catch (Throwable t) {
         NvidiumPlusLog.LOGGER.error("NvidiumPlus's mesh-shader probe failed; leaving vanilla device creation untouched", t);
      }
   }
}
