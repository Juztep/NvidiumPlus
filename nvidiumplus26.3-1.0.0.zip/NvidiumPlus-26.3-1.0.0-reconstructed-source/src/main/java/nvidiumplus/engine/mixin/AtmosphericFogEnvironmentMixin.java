package nvidiumplus.engine.mixin;

import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.fog.FogData;
import net.minecraft.client.renderer.fog.environment.AtmosphericFogEnvironment;
import nvidiumplus.engine.NvidiumPlusConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AtmosphericFogEnvironment.class)
public abstract class AtmosphericFogEnvironmentMixin {
   @Unique
   private static final float DELIBERATE_FOG_BLOCKS = 400.0F;
   @Unique
   private static final float NVIDIUMPLUS_OFF_MULTIPLE = 4.0F;

   @Inject(
      method = "setupFog(Lnet/minecraft/client/renderer/fog/FogData;Lnet/minecraft/client/Camera;Lnet/minecraft/client/multiplayer/ClientLevel;FLnet/minecraft/client/DeltaTracker;)V",
      at = @At("TAIL")
   )
   private void nvidiumplus$stretchHaze(FogData data, Camera camera, ClientLevel level, float renderDistanceBlocks, DeltaTracker deltaTracker, CallbackInfo ci) {
      NvidiumPlusConfig.FogMode mode = NvidiumPlusConfig.fogMode();
      if (mode != NvidiumPlusConfig.FogMode.VANILLA) {
         float end = data.environmentalEnd;
         if (end >= 400.0F && !(renderDistanceBlocks <= 0.0F)) {
            float target = mode == NvidiumPlusConfig.FogMode.OFF
               ? renderDistanceBlocks * 4.0F
               : renderDistanceBlocks * (NvidiumPlusConfig.fogEndPercent() / 100.0F);
            if (!(target <= end)) {
               float scale = target / end;
               data.environmentalStart *= scale;
               data.environmentalEnd = target;
               float skyTarget = Math.min(renderDistanceBlocks, target);
               data.skyEnd = Math.max(data.skyEnd, skyTarget);
               data.cloudEnd = Math.max(data.cloudEnd, skyTarget);
            }
         }
      }
   }
}
