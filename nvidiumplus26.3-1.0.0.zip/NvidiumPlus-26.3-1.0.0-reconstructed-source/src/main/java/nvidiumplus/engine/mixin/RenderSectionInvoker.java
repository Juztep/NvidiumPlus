package nvidiumplus.engine.mixin;

import net.minecraft.client.renderer.chunk.CompiledSectionMesh;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(targets = "net.minecraft.client.renderer.chunk.SectionRenderDispatcher$RenderSection")
public interface RenderSectionInvoker {
   @Invoker("checkSectionMesh")
   void nvidiumplus$checkSectionMesh(CompiledSectionMesh var1);
}
