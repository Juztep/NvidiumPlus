package nvidiumplus.engine.mixin;

import net.minecraft.client.Options;
import nvidiumplus.engine.NvidiumPlusExtendedRd;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Options.class)
public abstract class OptionsMixin {
   @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Options;load()V"))
   private void nvidiumplus$widenRenderDistanceBeforeLoad(CallbackInfo ci) {
      NvidiumPlusExtendedRd.widenAtConstruction((Options)this);
   }
}
