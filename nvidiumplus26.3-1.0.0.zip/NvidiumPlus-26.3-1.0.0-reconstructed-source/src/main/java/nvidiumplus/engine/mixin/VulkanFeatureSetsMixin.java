package nvidiumplus.engine.mixin;

import com.mojang.renderpearl.backend.vulkan.VulkanFeatureSets;
import com.mojang.renderpearl.backend.vulkan.init.FeatureSet;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import java.util.Collection;
import java.util.Set;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.vk.MeshShaderFeatureSets;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(VulkanFeatureSets.class)
abstract class VulkanFeatureSetsMixin {
   @Inject(method = "optionalFeatureSets()Ljava/util/Set;", at = @At("RETURN"), cancellable = true)
   private static void nvidiumplus$offerMeshShaderSets(CallbackInfoReturnable<Set<FeatureSet>> cir) {
      try {
         Set<FeatureSet> withOurs = new ObjectOpenHashSet((Collection)cir.getReturnValue());
         withOurs.addAll(MeshShaderFeatureSets.optional());
         cir.setReturnValue(withOurs);
      } catch (Throwable t) {
         NvidiumPlusLog.LOGGER
            .error("NvidiumPlus could not offer its Vulkan feature sets; leaving vanilla device creation untouched (no mesh shaders this session)", t);
      }
   }
}
