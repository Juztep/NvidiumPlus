package nvidiumplus.engine.mixin;

import net.minecraft.client.Minecraft;
import nvidiumplus.engine.NvidiumPlusCpuStages;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
abstract class MinecraftFrameMixin {
   @Unique
   private static long nvidiumplus$frameT0;

   @Inject(method = "renderFrame(Z)V", at = @At("HEAD"))
   private void nvidiumplus$renderFrameHead(boolean tick, CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED) {
         nvidiumplus$frameT0 = System.nanoTime();
      }
   }

   @Inject(method = "renderFrame(Z)V", at = @At("RETURN"))
   private void nvidiumplus$renderFrameReturn(boolean tick, CallbackInfo ci) {
      if (NvidiumPlusCpuStages.ARMED && nvidiumplus$frameT0 != 0L) {
         NvidiumPlusCpuStages.record(10, System.nanoTime() - nvidiumplus$frameT0);
         nvidiumplus$frameT0 = 0L;
      }
   }
}
