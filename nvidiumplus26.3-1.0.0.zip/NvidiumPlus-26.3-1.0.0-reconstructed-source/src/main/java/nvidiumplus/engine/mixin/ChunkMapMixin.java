package nvidiumplus.engine.mixin;

import net.minecraft.server.level.ChunkMap;
import nvidiumplus.engine.NvidiumPlusExtendedRd;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(ChunkMap.class)
public abstract class ChunkMapMixin {
   @ModifyConstant(method = "setServerViewDistance", constant = @Constant(intValue = 32))
   private int nvidiumplus$widenServerViewDistanceClamp(int vanillaCap) {
      return Math.max(vanillaCap, NvidiumPlusExtendedRd.serverViewDistanceCap());
   }
}
