package nvidiumplus.engine.mixin;

import net.caffeinemc.mods.sodium.client.gui.ColorTheme;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "net.caffeinemc.mods.sodium.client.config.builder.ModOptionsBuilderImpl", remap = false)
public abstract class NvidiumPlusWhiteThemeMixin {
   @Shadow
   @Final
   private String configId;
   @Shadow
   private ColorTheme theme;

   @Inject(method = "build", at = @At("HEAD"), remap = false)
   private void nvidiumplus$forceWhiteTheme(CallbackInfoReturnable<?> var1) {
      if ("nvidiumplus".equals(this.configId)) {
         this.theme = new ColorTheme(-1, -1, -1);
      }
   }
}
