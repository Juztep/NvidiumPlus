package nvidiumplus.engine.mixin;

import com.mojang.blaze3d.vertex.UberGpuBuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(targets = "net.minecraft.client.renderer.chunk.SectionRenderDispatcher$SectionUberBuffers")
public interface SectionUberBuffersAccessor {
   @Accessor("vertexBuffer")
   UberGpuBuffer<?> nvidiumplus$vertexBuffer();

   @Accessor("indexBuffer")
   UberGpuBuffer<?> nvidiumplus$indexBuffer();
}
