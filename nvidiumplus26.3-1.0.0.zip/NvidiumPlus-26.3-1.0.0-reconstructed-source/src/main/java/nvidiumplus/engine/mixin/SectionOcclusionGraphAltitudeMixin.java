package nvidiumplus.engine.mixin;

import net.minecraft.client.renderer.SectionOcclusionGraph;
import nvidiumplus.engine.terrain.host.TerrainResidency;
import org.joml.Vector3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(SectionOcclusionGraph.class)
abstract class SectionOcclusionGraphAltitudeMixin {
   @Redirect(
      method = "runUpdates(Lnet/minecraft/client/renderer/SectionOcclusionGraph$GraphStorage;Lnet/minecraft/world/phys/Vec3;Ljava/util/Queue;ZLjava/util/function/Consumer;Lit/unimi/dsi/fastutil/longs/LongOpenHashSet;Lit/unimi/dsi/fastutil/longs/LongOpenHashSet;)V",
      at = @At(value = "INVOKE", target = "Lorg/joml/Vector3d;distanceSquared(DDD)D"),
      require = 0
   )
   private double nvidiumplus$skipRayMarchFromAltitude(Vector3d point, double x, double y, double z) {
      return TerrainResidency.altitudeCullArmed() && TerrainResidency.skipAdvancedRayMarch(y - point.y) ? 0.0 : point.distanceSquared(x, y, z);
   }
}
