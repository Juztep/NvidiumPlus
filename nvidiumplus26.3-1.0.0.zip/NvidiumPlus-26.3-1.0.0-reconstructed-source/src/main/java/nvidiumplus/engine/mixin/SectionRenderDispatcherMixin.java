package nvidiumplus.engine.mixin;

import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.vk.NvidiumPlusTerrainPump;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SectionRenderDispatcher.class)
abstract class SectionRenderDispatcherMixin {
   @Unique
   private static boolean nvidiumplus$disposeHookBroken;

   @Inject(method = "dispose()V", at = @At("HEAD"))
   private void nvidiumplus$onDispose(CallbackInfo ci) {
      if (!nvidiumplus$disposeHookBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         try {
            NvidiumPlusTerrainPump.onDispatcherDispose();
         } catch (Throwable t) {
            nvidiumplus$disposeHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus dispose hook failed outside its own guard; disabling", t);
         }
      }
   }
}
