package nvidiumplus.engine.mixin;

import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.fog.FogData;
import net.minecraft.client.renderer.fog.FogRenderer;
import net.minecraft.util.Mth;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.farfield.FarFieldConfig;
import nvidiumplus.engine.vk.TerrainDrawer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FogRenderer.class)
abstract class FarFieldFogMixin {
   @Unique
   private static final float DELIBERATE_FOG_BLOCKS = 400.0F;
   @Unique
   private static boolean nvidiumplus$farFogHookBroken;
   @Unique
   private static boolean nvidiumplus$farFieldSeenEnabled;

   @Inject(
      method = "setupFog(Lnet/minecraft/client/Camera;ILnet/minecraft/client/DeltaTracker;FLnet/minecraft/client/multiplayer/ClientLevel;)Lnet/minecraft/client/renderer/fog/FogData;",
      at = @At("RETURN")
   )
   private void nvidiumplus$coverFarField(
      Camera camera, int renderDistanceChunks, DeltaTracker deltaTracker, float worldDarkening, ClientLevel level, CallbackInfoReturnable<FogData> cir
   ) {
      if (!nvidiumplus$farFogHookBroken) {
         try {
            nvidiumplus$widenForFarField(renderDistanceChunks, (FogData)cir.getReturnValue());
         } catch (Throwable t) {
            nvidiumplus$farFogHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus far-field fog widening failed; disabling the hook for this session (far terrain will render as fog)", t);
         }
      }
   }

   @Unique
   private static void nvidiumplus$widenForFarField(int renderDistanceChunks, FogData data) {
      if (data != null && renderDistanceChunks > 0) {
         if (FarFieldConfig.enabled()) {
            nvidiumplus$farFieldSeenEnabled = true;
         } else if (!nvidiumplus$farFieldSeenEnabled) {
            return;
         }

         if (NvidiumPlusConfig.terrainRenderingConfigured() && !TerrainDrawer.coveragePassive()) {
            if (FarFieldConfig.enabled()) {
               float vanillaEnd = data.renderDistanceEnd;
               if (vanillaEnd > 0.0F) {
                  float farEnd = Math.min(FarFieldConfig.l1RadiusChunks() * 16.0F, nvidiumplus$projectionFarPlane(renderDistanceChunks));
                  if (farEnd > vanillaEnd) {
                     data.renderDistanceEnd = farEnd;
                     data.renderDistanceStart = farEnd - Mth.clamp(farEnd / 10.0F, 4.0F, 64.0F);
                     float environmentalEnd = data.environmentalEnd;
                     if (environmentalEnd >= 400.0F) {
                        float horizonScale = farEnd / vanillaEnd;
                        data.environmentalStart *= horizonScale;
                        data.environmentalEnd = environmentalEnd * horizonScale;
                     }

                     data.skyEnd = Math.max(data.skyEnd, farEnd);
                     data.cloudEnd = Math.max(data.cloudEnd, Math.min(farEnd, nvidiumplus$cloudRangeBlocks()));
                  }
               }
            }
         }
      }
   }

   @Unique
   private static float nvidiumplus$projectionFarPlane(int renderDistanceChunks) {
      float horizon = renderDistanceChunks * 16.0F;
      return Math.max(horizon * 4.0F, nvidiumplus$cloudRangeBlocks());
   }

   @Unique
   private static float nvidiumplus$cloudRangeBlocks() {
      Minecraft minecraft = Minecraft.getInstance();
      Options options = minecraft != null ? minecraft.options : null;
      if (options == null) {
         return 0.0F;
      }

      Integer chunks = (Integer)options.cloudRange().get();
      return chunks != null ? chunks.intValue() * 16.0F : 0.0F;
   }
}
