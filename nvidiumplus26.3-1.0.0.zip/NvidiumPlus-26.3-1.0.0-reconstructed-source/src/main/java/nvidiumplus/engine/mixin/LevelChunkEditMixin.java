package nvidiumplus.engine.mixin;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.farfield.extract.ExtractDispatch;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LevelChunk.class)
abstract class LevelChunkEditMixin {
   @Unique
   private static boolean nvidiumplus$editHookBroken;

   @Inject(
      method = "setBlockState(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Lnet/minecraft/world/level/block/state/BlockState;",
      at = @At("TAIL")
   )
   private void nvidiumplus$afterSetBlockState(BlockPos pos, BlockState state, int flags, CallbackInfoReturnable<BlockState> cir) {
      if (ExtractDispatch.armed() && !nvidiumplus$editHookBroken) {
         LevelChunk self = (LevelChunk)this;

         try {
            if (!self.getLevel().isClientSide()) {
               return;
            }

            ExtractDispatch.onBlockChanged(self);
         } catch (Throwable t) {
            nvidiumplus$editHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error(
                  "NvidiumPlus far-field block-change bookkeeping failed; disabling the hook for this session (blocks change normally, horizon edits fall back to the drop seam)",
                  t
               );
         }
      }
   }

   @Inject(method = "replaceBiomes(Lnet/minecraft/network/FriendlyByteBuf;)V", at = @At("TAIL"))
   private void nvidiumplus$afterReplaceBiomes(FriendlyByteBuf buffer, CallbackInfo ci) {
      if (ExtractDispatch.armed() && !nvidiumplus$editHookBroken) {
         LevelChunk self = (LevelChunk)this;

         try {
            if (!self.getLevel().isClientSide()) {
               return;
            }

            ExtractDispatch.onBlockChanged(self);
         } catch (Throwable t) {
            nvidiumplus$editHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus far-field biome-change bookkeeping failed; disabling the hook for this session", t);
         }
      }
   }
}
