package nvidiumplus.engine;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class NvidiumPlusLog {
   public static final Logger LOGGER = LoggerFactory.getLogger("nvidiumplus");

   private NvidiumPlusLog() {
   }
}
