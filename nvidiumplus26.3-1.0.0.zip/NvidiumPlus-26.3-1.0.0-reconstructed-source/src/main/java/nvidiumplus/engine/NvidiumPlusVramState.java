package nvidiumplus.engine;

import java.util.Arrays;

public final class NvidiumPlusVramState {
   public static final long RESERVE_DISCRETE_BYTES = 536870912L;
   public static final long RESERVE_INTEGRATED_BYTES = 1073741824L;
   private static volatile long budgetBytes;
   private static volatile long usageBytes;
   private static volatile long lastSampleNanos;
   private static final long[] recent = new long[3];
   private static int recentIndex;
   private static int recentFilled;

   private NvidiumPlusVramState() {
   }

   public static long budgetBytes() {
      return budgetBytes;
   }

   public static long usageBytes() {
      return usageBytes;
   }

   public static boolean known() {
      return budgetBytes > 0L;
   }

   public static long headroomBytes() {
      long budget = budgetBytes;
      if (budget <= 0L) {
         return Long.MAX_VALUE;
      }

      long reserve = NvidiumPlusVulkanState.integratedGpu() ? 1073741824L : 536870912L;
      return Math.max(0L, budget - usageBytes - reserve);
   }

   public static long pressurePct() {
      long budget = budgetBytes;
      return budget <= 0L ? 0L : Math.min(100L, usageBytes * 100L / budget);
   }

   public static void sample(long budget, long usage, long nowNanos) {
      budgetBytes = budget;
      usageBytes = usage;
      lastSampleNanos = nowNanos;
      recent[recentIndex] = headroomBytes();
      recentIndex = (recentIndex + 1) % recent.length;
      if (recentFilled < recent.length) {
         recentFilled++;
      }
   }

   public static long sustainedHeadroomBytes() {
      if (budgetBytes > 0L && recentFilled != 0) {
         long best = 0L;

         for (int i = 0; i < recentFilled; i++) {
            best = Math.max(best, recent[i]);
         }

         return best;
      } else {
         return Long.MAX_VALUE;
      }
   }

   public static long lastSampleNanos() {
      return lastSampleNanos;
   }

   public static void reset() {
      budgetBytes = 0L;
      usageBytes = 0L;
      lastSampleNanos = 0L;
      recentIndex = 0;
      recentFilled = 0;
      Arrays.fill(recent, 0L);
   }
}
