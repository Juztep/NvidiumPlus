package nvidiumplus.engine;

import net.minecraft.client.Minecraft;

public final class NvidiumPlusSmokeRun {
   private static final int TICKS = Integer.getInteger("nvidiumplus.smokeTicks", 0);
   private static int ticks;
   private static boolean stopping;

   private NvidiumPlusSmokeRun() {
   }

   public static void installIfRequested() {
      if (TICKS > 0) {
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus smoke run: this client will SHUT ITSELF DOWN after {} client ticks so that teardown runs and can be read. Set no such property in normal play.",
               TICKS
            );
         NvidiumPlusPlatform.onEndClientTick(NvidiumPlusSmokeRun::onEndTick);
      }
   }

   private static void onEndTick(Minecraft client) {
      if (!stopping && client != null) {
         if (++ticks >= TICKS) {
            stopping = true;
            NvidiumPlusLog.LOGGER.warn("NvidiumPlus smoke run: {} ticks reached, stopping the client. Everything logged after this line is teardown.", TICKS);
            client.schedule(client::stop);
         }
      }
   }
}
