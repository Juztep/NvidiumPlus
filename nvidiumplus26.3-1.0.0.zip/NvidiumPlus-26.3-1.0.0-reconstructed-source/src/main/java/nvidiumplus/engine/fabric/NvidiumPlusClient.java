package nvidiumplus.engine.fabric;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.loader.api.FabricLoader;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusExtendedRd;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusLaunchCheck;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusPlatform;
import nvidiumplus.engine.NvidiumPlusSmokeRun;
import nvidiumplus.engine.gui.NvidiumPlusOptionsScreen;

public final class NvidiumPlusClient implements ClientModInitializer {
   public void onInitializeClient() {
      NvidiumPlusPlatform.install(new FabricPlatformServices());
      NvidiumPlusLog.LOGGER
         .info("NvidiumPlus {} initializing (backend gate armed; the decision runs on the first tick where the GPU device exists)", version());
      NvidiumPlusConfig.get();
      NvidiumPlusGate.init();
      NvidiumPlusLaunchCheck.run();
      NvidiumPlusExtendedRd.init();
      registerOptionsCommand();
      NvidiumPlusSmokeRun.installIfRequested();
   }

   private static void registerOptionsCommand() {
      ClientCommandRegistrationCallback.EVENT
         .register(
            (ClientCommandRegistrationCallback)(dispatcher, buildContext) -> dispatcher.register(
               (LiteralArgumentBuilder)ClientCommands.literal("nvidiumplus").executes(context -> {
                  NvidiumPlusOptionsScreen.openFromCommand();
                  return 1;
               })
            )
         );
   }

   private static String version() {
      return FabricLoader.getInstance().getModContainer("nvidiumplus").map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("?");
   }
}
