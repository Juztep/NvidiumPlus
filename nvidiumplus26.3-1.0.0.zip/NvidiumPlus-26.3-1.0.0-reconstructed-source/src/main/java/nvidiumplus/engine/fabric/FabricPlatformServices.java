package nvidiumplus.engine.fabric;

import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Consumer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import nvidiumplus.engine.NvidiumPlusPlatform;

final class FabricPlatformServices implements NvidiumPlusPlatform.Services {
   @Override
   public Path gameDir() {
      return FabricLoader.getInstance().getGameDir();
   }

   @Override
   public Path configDir() {
      return FabricLoader.getInstance().getConfigDir();
   }

   @Override
   public boolean isDevelopment() {
      return FabricLoader.getInstance().isDevelopmentEnvironment();
   }

   @Override
   public void onEndClientTick(Consumer<Minecraft> callback) {
      ClientTickEvents.END_CLIENT_TICK.register(callback::accept);
   }

   @Override
   public boolean isModLoaded(String modId) {
      return FabricLoader.getInstance().isModLoaded(modId);
   }

   @Override
   public boolean sodiumAdapterAvailable() {
      return true;
   }

   @Override
   public Optional<String> modVersion(String modId) {
      return FabricLoader.getInstance().getModContainer(modId).map(c -> c.getMetadata().getVersion().getFriendlyString());
   }
}
