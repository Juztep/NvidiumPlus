package nvidiumplus.engine;

import java.util.Arrays;
import java.util.concurrent.atomic.LongAdder;

public final class NvidiumPlusCpuStages {
   public static final String PROPERTY = "nvidiumplus.cpustages";
   public static final boolean ARMED = resolveArmed();
   public static final int STAGE_EXTRACT = 0;
   public static final int STAGE_APPLY_FRUSTUM = 1;
   public static final int STAGE_OCCLUSION_UPDATE = 2;
   public static final int STAGE_PREPARE_CHUNKS = 3;
   public static final int STAGE_NVIDIUMPLUS_OPAQUE = 4;
   public static final int STAGE_NVIDIUMPLUS_TRANSLUCENT = 5;
   public static final int STAGE_RESIDENCY_PUMP = 6;
   public static final int STAGE_COMPILE_UPLOAD = 7;
   public static final int STAGE_ENCODER_SUBMIT = 8;
   public static final int STAGE_LEVEL_RENDER = 9;
   public static final int STAGE_RENDER_FRAME = 10;
   public static final int STAGES = 11;
   public static final String[] NAMES = new String[]{
      "extract",
      "applyFrustum",
      "occlusionGraphUpdate",
      "prepareChunkRenders",
      "nvidiumplusOpaque",
      "nvidiumplusTranslucent",
      "residencyPump",
      "compileUpload",
      "encoderSubmit",
      "levelRender",
      "renderFrame"
   };
   private static final LongAdder TAP_COMPILES = new LongAdder();
   private static final long[] current = new long[11];
   private static int currentApplyRuns;
   private static int currentVisibleSections = -1;
   private static boolean frameOpen;
   private static long lastTapCompilesSample;
   private static final long[] accum = new long[11];
   private static final int[] accumCount = new int[11];
   private static int accumFrames;
   private static int accumApplyRuns;
   private static long lastLogNanos;
   private static long[] captureRows = new long[0];
   private static int[] captureApplyRuns = new int[0];
   private static int[] captureVisibleSections = new int[0];
   private static int[] captureSectionCompiles = new int[0];
   private static volatile int captureFilled;
   private static volatile boolean capturing;

   public static void noteTapCompile() {
      TAP_COMPILES.increment();
   }

   public static long tapCompiles() {
      return TAP_COMPILES.sum();
   }

   private NvidiumPlusCpuStages() {
   }

   private static boolean resolveArmed() {
      String p = System.getProperty("nvidiumplus.cpustages");
      return p != null ? Boolean.parseBoolean(p) : System.getProperty("nvidiumplus.bench") != null;
   }

   public static void beginFrame() {
      if (frameOpen) {
         commit();
      }

      Arrays.fill(current, -1L);
      currentApplyRuns = 0;
      currentVisibleSections = -1;
      frameOpen = true;
   }

   public static void record(int stage, long nanos) {
      if (frameOpen) {
         long cur = current[stage];
         current[stage] = cur < 0L ? nanos : cur + nanos;
      }
   }

   public static void noteApplyFrustumRun() {
      if (frameOpen) {
         currentApplyRuns++;
      }
   }

   public static void noteVisibleSections(int size) {
      if (frameOpen) {
         currentVisibleSections = size;
      }
   }

   private static void commit() {
      if (capturing) {
         int filled = captureFilled;
         if ((filled + 1) * 11 <= captureRows.length) {
            System.arraycopy(current, 0, captureRows, filled * 11, 11);
            captureApplyRuns[filled] = currentApplyRuns;
            captureVisibleSections[filled] = currentVisibleSections;
            long taps = TAP_COMPILES.sum();
            captureSectionCompiles[filled] = (int)(taps - lastTapCompilesSample);
            lastTapCompilesSample = taps;
            captureFilled = filled + 1;
         } else {
            capturing = false;
         }
      }

      for (int s = 0; s < 11; s++) {
         if (current[s] >= 0L) {
            accum[s] = accum[s] + current[s];
            accumCount[s]++;
         }
      }

      accumFrames++;
      accumApplyRuns = accumApplyRuns + currentApplyRuns;
      maybeLog();
   }

   private static void maybeLog() {
      long now = System.nanoTime();
      if (lastLogNanos == 0L) {
         lastLogNanos = now;
      } else if (now - lastLogNanos >= 5000000000L) {
         StringBuilder sb = new StringBuilder(224);
         sb.append("NvidiumPlus cpu stages (means us over ").append(accumFrames).append(" frames): ");

         for (int s = 0; s < 11; s++) {
            if (s > 0) {
               sb.append(' ');
            }

            sb.append(NAMES[s]).append('=');
            sb.append(accumCount[s] == 0 ? "absent" : Long.toString(accum[s] / accumCount[s] / 1000L));
         }

         sb.append(" applyFrustumRuns=").append(accumApplyRuns);
         sb.append(" (render-thread nanoTime brackets; applyFrustum NESTS inside extract; ").append("never sum stages with each other or with GPU pass times)");
         String line = sb.toString();
         if (NvidiumPlusConfig.debugStatsEnabled()) {
            NvidiumPlusLog.LOGGER.info(line);
         } else {
            NvidiumPlusLog.LOGGER.debug(line);
         }

         Arrays.fill(accum, 0L);
         Arrays.fill(accumCount, 0);
         accumFrames = 0;
         accumApplyRuns = 0;
         lastLogNanos = now;
      }
   }

   public static void armCapture(int rows) {
      captureRows = new long[rows * 11];
      captureApplyRuns = new int[rows];
      captureVisibleSections = new int[rows];
      captureSectionCompiles = new int[rows];
      lastTapCompilesSample = TAP_COMPILES.sum();
      captureFilled = 0;
      capturing = true;
   }

   public static void disarmCapture() {
      capturing = false;
   }

   public static int captureFilled() {
      return captureFilled;
   }

   public static long[] captureSnapshot() {
      return Arrays.copyOf(captureRows, captureFilled * 11);
   }

   public static int[] captureApplyRunsSnapshot() {
      return Arrays.copyOf(captureApplyRuns, captureFilled);
   }

   public static int[] captureVisibleSectionsSnapshot() {
      return Arrays.copyOf(captureVisibleSections, captureFilled);
   }

   public static int[] captureSectionCompilesSnapshot() {
      return Arrays.copyOf(captureSectionCompiles, captureFilled);
   }

   static {
      Arrays.fill(current, -1L);
   }
}
