package nvidiumplus.engine.vk;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.commands.CommandEncoder;
import com.mojang.renderpearl.api.commands.GpuQueryPool;
import com.mojang.renderpearl.api.device.GpuDevice;
import com.mojang.renderpearl.api.device.GpuDeviceLossException;
import com.mojang.renderpearl.backend.vulkan.VulkanQueryPool;
import java.util.Arrays;
import java.util.OptionalLong;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusLog;

public final class NvidiumPlusGpuTimers {
   public static final String PROPERTY = "nvidiumplus.gpuTimers";
   public static final int PASS_OPAQUE_A = 0;
   public static final int PASS_REGION_RASTER = 1;
   public static final int PASS_SECTION_RASTER = 2;
   public static final int PASS_PHASE_B = 3;
   public static final int PASS_TRANSLUCENT = 4;
   public static final int PASS_1A = 5;
   public static final int PASS_DOWNSAMPLE = 6;
   public static final int PASSES = 7;
   static final int POINT_OPAQUE_BEGIN = 0;
   static final int POINT_AFTER_PHASE_A = 1;
   static final int POINT_AFTER_REGION_RASTER = 2;
   static final int POINT_AFTER_SECTION_RASTER = 3;
   static final int POINT_AFTER_PHASE_B = 4;
   static final int POINT_TRANSLUCENT_BEGIN = 5;
   static final int POINT_AFTER_TRANSLUCENT = 6;
   static final int POINT_AFTER_PASS_1A = 7;
   static final int POINT_AFTER_DOWNSAMPLE = 8;
   private static final int QUERIES_PER_FRAME = 9;
   private static final int RING_FRAMES = 8;
   private static final int READ_LAG = 3;
   private static final long SANE_NANOS = 4000000000L;
   private static GpuQueryPool pool;
   private static double periodNs;
   private static boolean creationAttempted;
   private static long framesTimed;
   private static long armedSerial = -1L;
   private static final int[] ringMask = new int[8];
   private static final long[] ringFrame = new long[8];
   private static volatile String failure;
   private static volatile long framesReadCount;
   private static volatile long framesNotReady;
   private static volatile long framesAnomalous;
   private static volatile long[] lastPassNanos = absentRow();
   private static long[] captureRows = new long[0];
   private static volatile int captureFilled;
   private static volatile boolean capturing;
   private static long lastLogNanos;

   private NvidiumPlusGpuTimers() {
   }

   public static String failure() {
      return failure;
   }

   public static long framesRead() {
      return framesReadCount;
   }

   public static long framesNotReadyCount() {
      return framesNotReady;
   }

   public static long framesAnomalousCount() {
      return framesAnomalous;
   }

   public static boolean live() {
      return pool != null && failure == null;
   }

   public static long[] lastPassNanosSnapshot() {
      return (long[])lastPassNanos.clone();
   }

   public static double timestampPeriodNs() {
      return periodNs;
   }

   public static void armCapture(int rows) {
      captureRows = new long[rows * 7];
      captureFilled = 0;
      capturing = true;
   }

   public static void disarmCapture() {
      capturing = false;
   }

   public static int captureFilled() {
      return captureFilled;
   }

   public static long[] captureSnapshot() {
      int rows = captureFilled;
      return Arrays.copyOf(captureRows, rows * 7);
   }

   public static void beginOpaque(CommandEncoder encoder, long frameSerial) {
      if (armedSerial >= 0L) {
         armedSerial = -1L;
         framesTimed++;
      }

      if (enabled() && failure == null) {
         try {
            if (pool == null && !createPool()) {
               return;
            }

            readLagged(framesTimed - 3L);
            int slot = (int)(framesTimed % 8L);
            ringMask[slot] = 0;
            ringFrame[slot] = framesTimed;
            armedSerial = frameSerial;
            write(encoder, slot, 0);
         } catch (GpuDeviceLossException t) {
            throw t;
         } catch (Throwable t) {
            latch(t);
         }
      }
   }

   public static void mark(CommandEncoder encoder, int point) {
      if (armedSerial >= 0L && failure == null) {
         try {
            write(encoder, (int)(framesTimed % 8L), point);
         } catch (GpuDeviceLossException t) {
            throw t;
         } catch (Throwable t) {
            latch(t);
         }
      }
   }

   public static void beginTranslucent(CommandEncoder encoder, long frameSerial) {
      if (armedSerial == frameSerial && failure == null) {
         try {
            write(encoder, (int)(framesTimed % 8L), 5);
         } catch (GpuDeviceLossException t) {
            throw t;
         } catch (Throwable t) {
            latch(t);
         }
      }
   }

   public static void endTranslucent(CommandEncoder encoder, long frameSerial) {
      if (armedSerial == frameSerial && failure == null) {
         try {
            write(encoder, (int)(framesTimed % 8L), 6);
         } catch (GpuDeviceLossException t) {
            throw t;
         } catch (Throwable t) {
            latch(t);
         }
      }
   }

   public static void endFrame(long frameSerial) {
      if (armedSerial == frameSerial) {
         armedSerial = -1L;
         framesTimed++;
      }
   }

   public static void destroyDeviceObjects() {
      if (pool instanceof VulkanQueryPool vulkanPool) {
         vulkanPool.destroy();
      }

      pool = null;
      creationAttempted = false;
   }

   private static boolean enabled() {
      String p = System.getProperty("nvidiumplus.gpuTimers");
      return p == null || Boolean.parseBoolean(p);
   }

   private static boolean createPool() {
      if (creationAttempted) {
         return false;
      } else {
         creationAttempted = true;
         GpuDevice device = RenderSystem.tryGetDevice();
         if (device == null) {
            creationAttempted = false;
            return false;
         } else {
            float period = device.getDeviceInfo().timestampPeriod();
            if (!(period > 0.0F)) {
               failure = "device reports timestampPeriod=" + period + " (timestamps unusable)";
               NvidiumPlusLog.LOGGER
                  .info("NvidiumPlus GPU timers unavailable: {} — per-pass GPU times stay absent (CPU draw-path micros are unaffected)", failure);
               return false;
            } else {
               pool = device.createTimestampQueryPool(72);
               periodNs = period;
               NvidiumPlusLog.LOGGER
                  .info(
                     "NvidiumPlus GPU timers up: {}-query timestamp pool through vanilla's own plumbing (VulkanQueryPool + CommandEncoder.writeTimestamp = host vkResetQueryPool per write + vkCmdWriteTimestamp2KHR ALL_COMMANDS, sync2), timestampPeriod {} ns/tick, readback lag {} frames",
                     new Object[]{72, period, 3}
                  );
               return true;
            }
         }
      }
   }

   private static void write(CommandEncoder encoder, int slot, int point) {
      encoder.writeTimestamp(pool, slot * 9 + point);
      ringMask[slot] = ringMask[slot] | 1 << point;
   }

   private static void readLagged(long f) {
      if (f >= 0L) {
         int slot = (int)(f % 8L);
         if (ringFrame[slot] == f && (ringMask[slot] & 1) != 0) {
            int mask = ringMask[slot];
            ringFrame[slot] = -1L;
            OptionalLong[] values = pool.getValues(slot * 9, 9);
            long[] row = absentRow();
            boolean anyAbsentReady = false;
            boolean anomalous = false;
            int regionRasterStart = (mask & 256) != 0 ? 8 : 1;
            int[][] pairs = new int[][]{{0, 1}, {regionRasterStart, 2}, {2, 3}, {3, 4}, {5, 6}, {0, 7}, {1, 8}};

            for (int i = 0; i < 7; i++) {
               int a = pairs[i][0];
               int b = pairs[i][1];
               if ((mask & 1 << a) != 0 && (mask & 1 << b) != 0) {
                  if (!values[a].isEmpty() && !values[b].isEmpty()) {
                     long ticks = values[b].getAsLong() - values[a].getAsLong();
                     long nanos = (long)(ticks * periodNs);
                     if (nanos >= 0L && nanos <= 4000000000L) {
                        row[i] = nanos;
                     } else {
                        anomalous = true;
                     }
                  } else {
                     anyAbsentReady = true;
                  }
               }
            }

            if (anyAbsentReady) {
               framesNotReady++;
            }

            if (anomalous) {
               framesAnomalous++;
            }

            if (row[0] >= 0L) {
               framesReadCount++;
               lastPassNanos = row;
               if (capturing) {
                  int filled = captureFilled;
                  if ((filled + 1) * 7 <= captureRows.length) {
                     System.arraycopy(row, 0, captureRows, filled * 7, 7);
                     captureFilled = filled + 1;
                  } else {
                     capturing = false;
                  }
               }

               maybeLog(row);
            }
         }
      }
   }

   private static void maybeLog(long[] row) {
      long now = System.nanoTime();
      if (lastLogNanos == 0L || now - lastLogNanos >= 5000000000L) {
         lastLogNanos = now;
         String line = String.format(
            "NvidiumPlus GPU pass times (frame-%d readback, us): opaqueA=%s downsample=%s regionRaster=%s sectionRaster=%s phaseB=%s translucent=%s (GPU timestamps between vanilla pass-end barriers; CPU draw-path micros are a separate line — never sum the two)",
            3,
            us(row[0]),
            us(row[6]),
            us(row[1]),
            us(row[2]),
            us(row[3]),
            us(row[4])
         );
         if (NvidiumPlusConfig.debugStatsEnabled()) {
            NvidiumPlusLog.LOGGER.info(line);
         } else {
            NvidiumPlusLog.LOGGER.debug(line);
         }
      }
   }

   private static String us(long nanos) {
      return nanos < 0L ? "absent" : Long.toString(nanos / 1000L);
   }

   private static long[] absentRow() {
      long[] row = new long[7];
      Arrays.fill(row, -1L);
      return row;
   }

   private static void latch(Throwable t) {
      failure = t.toString();
      armedSerial = -1L;
      NvidiumPlusLog.LOGGER
         .error("NvidiumPlus GPU timers failed; per-pass GPU timing stays off for this session (terrain drawing is unaffected — first and only report)", t);
   }

   static {
      Arrays.fill(ringFrame, -1L);
   }
}
