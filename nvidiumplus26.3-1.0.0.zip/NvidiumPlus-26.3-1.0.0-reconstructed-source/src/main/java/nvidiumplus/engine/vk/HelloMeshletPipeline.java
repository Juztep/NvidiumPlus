package nvidiumplus.engine.vk;

import java.nio.LongBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkDescriptorSetLayoutBinding;
import org.lwjgl.vulkan.VkDescriptorSetLayoutCreateInfo;
import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkGraphicsPipelineCreateInfo;
import org.lwjgl.vulkan.VkPipelineColorBlendAttachmentState;
import org.lwjgl.vulkan.VkPipelineColorBlendStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineDepthStencilStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineDynamicStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineLayoutCreateInfo;
import org.lwjgl.vulkan.VkPipelineMultisampleStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineRasterizationStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineRenderingCreateInfoKHR;
import org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo;
import org.lwjgl.vulkan.VkPipelineViewportStateCreateInfo;
import org.lwjgl.vulkan.VkDescriptorSetLayoutBinding.Buffer;

public final class HelloMeshletPipeline {
   private static final int COLOR_WRITE_ALL = 15;
   private final long worldSetLayout;
   private final long ndcPipelineLayout;
   private final long worldPipelineLayout;
   private final long ndcPipeline;
   private final long worldPipeline;

   private HelloMeshletPipeline(long worldSetLayout, long ndcPipelineLayout, long worldPipelineLayout, long ndcPipeline, long worldPipeline) {
      this.worldSetLayout = worldSetLayout;
      this.ndcPipelineLayout = ndcPipelineLayout;
      this.worldPipelineLayout = worldPipelineLayout;
      this.ndcPipeline = ndcPipeline;
      this.worldPipeline = worldPipeline;
   }

   public long ndcPipeline() {
      return this.ndcPipeline;
   }

   public long worldPipeline() {
      return this.worldPipeline;
   }

   public long worldPipelineLayout() {
      return this.worldPipelineLayout;
   }

   public long worldSetLayout() {
      return this.worldSetLayout;
   }

   public long ndcPipelineLayout() {
      return this.ndcPipelineLayout;
   }

   public void destroy(VkDevice device) {
      VK10.vkDestroyPipeline(device, this.ndcPipeline, null);
      VK10.vkDestroyPipeline(device, this.worldPipeline, null);
      VK10.vkDestroyPipelineLayout(device, this.ndcPipelineLayout, null);
      VK10.vkDestroyPipelineLayout(device, this.worldPipelineLayout, null);
      VK10.vkDestroyDescriptorSetLayout(device, this.worldSetLayout, null);
   }

   public static HelloMeshletPipeline create(VkDevice device, int vkColorFormat, int vkDepthFormat) {
      long meshModule = NvidiumPlusShaderCompiler.compileResourceToModule(device, "/assets/nvidiumplus/shaders/hello.mesh", 27);
      long worldMeshModule = 0L;
      long fragModule = 0L;

      try {
         worldMeshModule = NvidiumPlusShaderCompiler.compileResourceToModule(device, "/assets/nvidiumplus/shaders/hello_world.mesh", 27);
         fragModule = NvidiumPlusShaderCompiler.compileResourceToModule(device, "/assets/nvidiumplus/shaders/hello.frag", 1);
         return build(device, vkColorFormat, vkDepthFormat, meshModule, worldMeshModule, fragModule);
      } finally {
         VK10.vkDestroyShaderModule(device, meshModule, null);
         if (worldMeshModule != 0L) {
            VK10.vkDestroyShaderModule(device, worldMeshModule, null);
         }

         if (fragModule != 0L) {
            VK10.vkDestroyShaderModule(device, fragModule, null);
         }
      }
   }

   private static HelloMeshletPipeline build(VkDevice device, int vkColorFormat, int vkDepthFormat, long meshModule, long worldMeshModule, long fragModule) {
      MemoryStack stack = MemoryStack.stackPush();

      HelloMeshletPipeline var33;
      try {
         Buffer uboBinding = VkDescriptorSetLayoutBinding.calloc(1, stack);
         ((VkDescriptorSetLayoutBinding)uboBinding.get(0)).binding(0).descriptorType(6).descriptorCount(1).stageFlags(128);
         VkDescriptorSetLayoutCreateInfo setLayoutInfo = VkDescriptorSetLayoutCreateInfo.calloc(stack).sType$Default().flags(1).pBindings(uboBinding);
         LongBuffer handle = stack.mallocLong(1);
         check(VK10.vkCreateDescriptorSetLayout(device, setLayoutInfo, null, handle), "vkCreateDescriptorSetLayout(world UBO)");
         long worldSetLayout = handle.get(0);
         VkPipelineLayoutCreateInfo ndcLayoutInfo = VkPipelineLayoutCreateInfo.calloc(stack).sType$Default();
         check(VK10.vkCreatePipelineLayout(device, ndcLayoutInfo, null, handle), "vkCreatePipelineLayout(ndc)");
         long ndcPipelineLayout = handle.get(0);
         VkPipelineLayoutCreateInfo worldLayoutInfo = VkPipelineLayoutCreateInfo.calloc(stack)
            .sType$Default()
            .pSetLayouts(stack.longs(worldSetLayout))
            .setLayoutCount(1);
         check(VK10.vkCreatePipelineLayout(device, worldLayoutInfo, null, handle), "vkCreatePipelineLayout(world)");
         long worldPipelineLayout = handle.get(0);
         VkPipelineViewportStateCreateInfo viewportState = VkPipelineViewportStateCreateInfo.calloc(stack).sType$Default().viewportCount(1).scissorCount(1);
         VkPipelineRasterizationStateCreateInfo rasterState = VkPipelineRasterizationStateCreateInfo.calloc(stack)
            .sType$Default()
            .depthClampEnable(false)
            .rasterizerDiscardEnable(false)
            .polygonMode(0)
            .cullMode(0)
            .frontFace(1)
            .depthBiasEnable(false)
            .lineWidth(1.0F);
         VkPipelineMultisampleStateCreateInfo multisampleState = VkPipelineMultisampleStateCreateInfo.calloc(stack)
            .sType$Default()
            .rasterizationSamples(1)
            .sampleShadingEnable(false);
         VkPipelineDepthStencilStateCreateInfo depthState = VkPipelineDepthStencilStateCreateInfo.calloc(stack)
            .sType$Default()
            .depthTestEnable(true)
            .depthWriteEnable(false)
            .depthCompareOp(6);
         org.lwjgl.vulkan.VkPipelineColorBlendAttachmentState.Buffer blendAttachment = VkPipelineColorBlendAttachmentState.calloc(1, stack);
         ((VkPipelineColorBlendAttachmentState)blendAttachment.get(0)).blendEnable(false).colorWriteMask(15);
         VkPipelineColorBlendStateCreateInfo blendState = VkPipelineColorBlendStateCreateInfo.calloc(stack)
            .sType$Default()
            .logicOpEnable(false)
            .pAttachments(blendAttachment)
            .attachmentCount(1);
         VkPipelineDynamicStateCreateInfo dynamicState = VkPipelineDynamicStateCreateInfo.calloc(stack).sType$Default().pDynamicStates(stack.ints(1, 0));
         VkPipelineRenderingCreateInfoKHR renderingInfo = VkPipelineRenderingCreateInfoKHR.calloc(stack)
            .sType$Default()
            .colorAttachmentCount(1)
            .pColorAttachmentFormats(stack.ints(vkColorFormat))
            .depthAttachmentFormat(vkDepthFormat);
         org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo.Buffer ndcStages = stages(stack, meshModule, fragModule);
         org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo.Buffer worldStages = stages(stack, worldMeshModule, fragModule);
         org.lwjgl.vulkan.VkGraphicsPipelineCreateInfo.Buffer createInfos = VkGraphicsPipelineCreateInfo.calloc(2, stack);

         for (int i = 0; i < 2; i++) {
            ((VkGraphicsPipelineCreateInfo)createInfos.get(i))
               .sType$Default()
               .pNext(renderingInfo.address())
               .pStages(i == 0 ? ndcStages : worldStages)
               .stageCount(2)
               .pViewportState(viewportState)
               .pRasterizationState(rasterState)
               .pMultisampleState(multisampleState)
               .pDepthStencilState(depthState)
               .pColorBlendState(blendState)
               .pDynamicState(dynamicState)
               .layout(i == 0 ? ndcPipelineLayout : worldPipelineLayout)
               .renderPass(0L);
         }

         LongBuffer pipelines = stack.mallocLong(2);
         check(VK10.vkCreateGraphicsPipelines(device, 0L, createInfos, null, pipelines), "vkCreateGraphicsPipelines(hello ndc+world)");
         var33 = new HelloMeshletPipeline(worldSetLayout, ndcPipelineLayout, worldPipelineLayout, pipelines.get(0), pipelines.get(1));
      } catch (Throwable var35) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var34) {
               var35.addSuppressed(var34);
            }
         }

         throw var35;
      }

      if (stack != null) {
         stack.close();
      }

      return var33;
   }

   private static org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo.Buffer stages(MemoryStack stack, long meshModule, long fragModule) {
      org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo.Buffer stages = VkPipelineShaderStageCreateInfo.calloc(2, stack);
      ((VkPipelineShaderStageCreateInfo)stages.get(0)).sType$Default().stage(128).module(meshModule).pName(stack.UTF8("main"));
      ((VkPipelineShaderStageCreateInfo)stages.get(1)).sType$Default().stage(16).module(fragModule).pName(stack.UTF8("main"));
      return stages;
   }

   private static void check(int vkResult, String what) {
      if (vkResult != 0) {
         throw new IllegalStateException(what + " failed: VkResult " + vkResult);
      }
   }
}
