package nvidiumplus.engine.vk;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;
import nvidiumplus.engine.NvidiumPlusLog;

public final class TranslucentPhaseProbe {
   private static final AtomicLong TARGET_VIEWS = new AtomicLong();
   private static final AtomicLong PROLOGUE_REST = new AtomicLong();
   private static final LongAdder FRAMES = new LongAdder();
   private static final AtomicLong RETAINED_SCAN = new AtomicLong();
   private static final AtomicLong VISIBLE_LOOP = new AtomicLong();
   private static final AtomicLong RECORD = new AtomicLong();
   private static final LongAdder SECTIONS_SCANNED = new LongAdder();
   private static final LongAdder SECTIONS_DRAWN = new LongAdder();
   private static final LongAdder DRAWS = new LongAdder();
   private static final long REPORT_EVERY = 600L;
   public static final boolean ARMED = Boolean.getBoolean("nvidiumplus.probe.translucent");

   private TranslucentPhaseProbe() {
   }

   public static void targetViews(long nanos) {
      TARGET_VIEWS.addAndGet(nanos);
   }

   public static void prologueRest(long nanos) {
      PROLOGUE_REST.addAndGet(nanos);
   }

   public static void retainedScan(long nanos, int scanned) {
      RETAINED_SCAN.addAndGet(nanos);
      SECTIONS_SCANNED.add(scanned);
   }

   public static void visibleLoop(long nanos, int sectionsDrawn, int draws) {
      VISIBLE_LOOP.addAndGet(nanos);
      SECTIONS_DRAWN.add(sectionsDrawn);
      DRAWS.add(draws);
   }

   public static void record(long nanos) {
      RECORD.addAndGet(nanos);
      FRAMES.increment();
      if (FRAMES.sum() % 600L == 0L) {
         NvidiumPlusLog.LOGGER.info(report());
         reset();
      }
   }

   private static void reset() {
      TARGET_VIEWS.set(0L);
      PROLOGUE_REST.set(0L);
      RETAINED_SCAN.set(0L);
      VISIBLE_LOOP.set(0L);
      RECORD.set(0L);
      SECTIONS_SCANNED.reset();
      SECTIONS_DRAWN.reset();
      DRAWS.reset();
      FRAMES.reset();
   }

   public static String report() {
      long frames = Math.max(1L, FRAMES.sum());
      double scan = RETAINED_SCAN.get() / 1000000.0 / frames;
      double loop = VISIBLE_LOOP.get() / 1000000.0 / frames;
      double rec = RECORD.get() / 1000000.0 / frames;
      double views = TARGET_VIEWS.get() / 1000000.0 / frames;
      double rest = PROLOGUE_REST.get() / 1000000.0 / frames;
      return String.format(
         "NvidiumPlus translucent phases over %d frames: target+views %.3f ms, prologue rest %.3f ms, retained scan %.3f ms (%d sections/frame), visible loop %.3f ms (%d drawn, %d draws/frame), upload+record %.3f ms. Total %.3f ms",
         frames,
         views,
         rest,
         scan,
         SECTIONS_SCANNED.sum() / frames,
         loop,
         SECTIONS_DRAWN.sum() / frames,
         DRAWS.sum() / frames,
         rec,
         views + rest + scan + loop + rec
      );
   }
}
