package nvidiumplus.engine.vk;

import java.util.BitSet;

public record VisibleSetSample(long frame, BitSet bits, int forcedRegionWide, int forcedRegionPlain, int forcedSectionWide, int forcedSectionPlain) {
   public int size() {
      return this.bits.cardinality();
   }

   public boolean contains(VisibleSetSample other) {
      BitSet missing = (BitSet)other.bits.clone();
      missing.andNot(this.bits);
      return missing.isEmpty();
   }

   public BitSet minus(VisibleSetSample other) {
      BitSet diff = (BitSet)this.bits.clone();
      diff.andNot(other.bits);
      return diff;
   }

   public String forcedText() {
      return "region " + this.forcedRegionWide + "/" + this.forcedRegionPlain + " section " + this.forcedSectionWide + "/" + this.forcedSectionPlain;
   }

   public boolean forcedAgrees() {
      return this.forcedRegionWide == this.forcedRegionPlain && this.forcedSectionWide == this.forcedSectionPlain;
   }
}
