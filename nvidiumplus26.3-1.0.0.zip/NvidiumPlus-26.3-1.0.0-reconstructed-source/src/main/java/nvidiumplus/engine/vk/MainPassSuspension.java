package nvidiumplus.engine.vk;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.commands.CommandEncoder;
import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.renderpearl.api.commands.RenderPassDescriptor;
import com.mojang.renderpearl.api.commands.RenderPassDescriptor.Attachment;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.api.RenderPassBackend;
import com.mojang.renderpearl.backend.vulkan.VulkanRenderPipeline;
import com.mojang.renderpearl.frontend.FrontendRenderPass;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import net.minecraft.client.Minecraft;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.mixin.RenderPassAccessor;
import org.joml.Vector4fc;

public final class MainPassSuspension implements AutoCloseable {
   private static boolean broken;
   private static long suspensions;
   private final RenderPass wrapper;
   private final RenderPassAccessor access;
   private final CommandEncoder encoder;
   private final RenderPassDescriptor descriptor;
   private final int debugGroups;
   private final VulkanRenderPipeline pipeline;
   private final Object[] uniforms;
   private final ByteBuffer constants;

   private MainPassSuspension(
      RenderPass wrapper,
      RenderPassAccessor access,
      CommandEncoder encoder,
      RenderPassDescriptor descriptor,
      int debugGroups,
      VulkanRenderPipeline pipeline,
      Object[] uniforms,
      ByteBuffer constants
   ) {
      this.wrapper = wrapper;
      this.access = access;
      this.encoder = encoder;
      this.descriptor = descriptor;
      this.debugGroups = debugGroups;
      this.pipeline = pipeline;
      this.uniforms = uniforms;
      this.constants = constants;
   }

   public static long suspensions() {
      return suspensions;
   }

   public static MainPassSuspension suspend(RenderPass pass) {
      if (!broken && pass instanceof FrontendRenderPass) {
         try {
            RenderPassAccessor access = (RenderPassAccessor)pass;
            RenderTarget main = Minecraft.getInstance().gameRenderer.mainRenderTarget();
            GpuTextureView color = main.getColorTextureView();
            GpuTextureView depth = main.getDepthTextureView();
            List<Attachment<Optional<Vector4fc>>> colors = access.nvidiumplus$colorAttachments();
            if (color != null && depth != null && colors.size() == 1 && colors.get(0).textureView() == color && access.nvidiumplus$hasDepthAttachment()) {
               if (!(access.nvidiumplus$backend() instanceof NvidiumPlusPassState state)) {
                  return null;
               } else {
                  VulkanRenderPipeline pipeline = state.nvidiumplus$pipeline();
                  Object[] uniforms = state.nvidiumplus$uniformsSnapshot();
                  ByteBuffer constants = state.nvidiumplus$lastPushConstants();
                  RenderPassDescriptor descriptor = new RenderPassDescriptor(
                     () -> "nvidiumplus: main pass resumed",
                     List.of(new Attachment(color, Optional.empty())),
                     new Attachment(depth, OptionalDouble.empty()),
                     access.nvidiumplus$renderArea()
                  );
                  CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
                  int debugGroups = access.nvidiumplus$pushedDebugGroups();

                  for (int i = 0; i < debugGroups; i++) {
                     pass.popDebugGroup();
                  }

                  pass.close();
                  suspensions++;
                  return new MainPassSuspension(pass, access, encoder, descriptor, debugGroups, pipeline, uniforms, constants);
               }
            } else {
               return null;
            }
         } catch (Throwable t) {
            broken = true;
            NvidiumPlusLog.LOGGER
               .error(
                  "NvidiumPlus could not suspend vanilla's main render pass; the terrain kill switch stays off for this session and vanilla draws the terrain",
                  t
               );
            return null;
         }
      } else {
         return null;
      }
   }

   @Override
   public void close() {
      try {
         RenderPass fresh = this.encoder.createRenderPass(this.descriptor);
         RenderPassBackend backend = ((RenderPassAccessor)fresh).nvidiumplus$backend();
         this.access.nvidiumplus$setBackend(backend);
         this.access.nvidiumplus$setClosed(false);
         if (this.pipeline != null) {
            backend.setPipeline(this.pipeline);

            for (int slot = 0; slot < this.uniforms.length; slot++) {
               if (this.uniforms[slot] != null) {
                  backend.setUniform(slot, this.uniforms[slot]);
               }
            }

            if (this.constants != null) {
               backend.pushConstants(this.constants.duplicate());
            }
         }

         for (int i = 0; i < this.debugGroups; i++) {
            this.wrapper.pushDebugGroup(() -> "nvidiumplus: resumed");
         }
      } catch (Throwable t) {
         broken = true;
         NvidiumPlusLog.LOGGER
            .error(
               "NvidiumPlus could not resume vanilla's main render pass after drawing terrain; the rest of this frame may be wrong and the kill switch stays off for this session",
               t
            );
      }
   }
}
