package nvidiumplus.engine.vk;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.device.GpuDevice;
import com.mojang.renderpearl.backend.vulkan.VulkanCommandEncoder;
import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.mixin.GpuDeviceAccessor;
import org.lwjgl.system.MemoryUtil;

public final class SodiumFrameRing {
   private static final int SLOTS = 8;
   private static int advancesSinceSubmit;
   private static long submitsReturned;
   private static long guardTrips;
   private final VulkanCommandEncoder encoder;
   private final long vma;
   private final NvidiumPlusVkBuffers.MappedBuffer list;
   private final NvidiumPlusVkBuffers.MappedBuffer indirect;
   private final int capacity;
   private final long listSlotBytes;
   private final long indirectSlotBytes;
   private long record;

   private SodiumFrameRing(
      VulkanCommandEncoder encoder, long vma, NvidiumPlusVkBuffers.MappedBuffer list, NvidiumPlusVkBuffers.MappedBuffer indirect, int capacity
   ) {
      this.encoder = encoder;
      this.vma = vma;
      this.list = list;
      this.indirect = indirect;
      this.capacity = capacity;
      this.listSlotBytes = capacity * 128L;
      this.indirectSlotBytes = (capacity + 64) * 12L;
   }

   public static SodiumFrameRing create(int capacity) {
      GpuDevice facade = RenderSystem.tryGetDevice();
      if (facade == null) {
         return null;
      }

      VulkanDevice device = (VulkanDevice)((GpuDeviceAccessor)facade).nvidiumplus$backend();
      VulkanCommandEncoder encoder = device.createCommandEncoder();
      long listBytes = 8L * capacity * 128L;
      long indirectBytes = 8L * (capacity + 64) * 12L;
      NvidiumPlusVkBuffers.MappedBuffer list = NvidiumPlusVkBuffers.createDeviceMapped(
         device.vma(), listBytes, 32, "vmaCreateBuffer(NvidiumPlus sodium frame list)"
      );
      MemoryUtil.memSet(list.mappedAddress(), 0, listBytes);

      NvidiumPlusVkBuffers.MappedBuffer ind;
      try {
         ind = NvidiumPlusVkBuffers.createDeviceMapped(device.vma(), indirectBytes, 256, "vmaCreateBuffer(NvidiumPlus sodium frame indirect)");
      } catch (RuntimeException t) {
         NvidiumPlusVkBuffers.destroy(device.vma(), list.vkBuffer(), list.allocation());
         throw t;
      }

      MemoryUtil.memSet(ind.mappedAddress(), 0, indirectBytes);
      NvidiumPlusLog.LOGGER
         .info(
            "NvidiumPlus Sodium frame ring up: {} regions/slot x {} slots = {} KiB list + {} KiB indirect commands, device-local where the card allows it.",
            new Object[]{capacity, 8, listBytes >> 10, indirectBytes >> 10}
         );
      return new SodiumFrameRing(encoder, device.vma(), list, ind, capacity);
   }

   public int capacity() {
      return this.capacity;
   }

   public static boolean guardTripped() {
      return advancesSinceSubmit >= 4;
   }

   public static long guardTrips() {
      return guardTrips;
   }

   static void countGuardTrip() {
      guardTrips++;
   }

   static void onSubmit() {
      advancesSinceSubmit = 0;
      submitsReturned++;
   }

   public static long submitsReturned() {
      return submitsReturned;
   }

   public void advance() {
      this.record++;
      advancesSinceSubmit++;
   }

   public ByteBuffer listView() {
      long base = this.list.mappedAddress() + this.slotIndex() * this.listSlotBytes;
      return MemoryUtil.memByteBuffer(base, (int)this.listSlotBytes).order(ByteOrder.LITTLE_ENDIAN);
   }

   public ByteBuffer indirectView() {
      long base = this.indirect.mappedAddress() + this.slotIndex() * this.indirectSlotBytes;
      return MemoryUtil.memByteBuffer(base, (int)this.indirectSlotBytes).order(ByteOrder.LITTLE_ENDIAN);
   }

   public long listAddress() {
      return this.list.mappedAddress() + this.slotIndex() * this.listSlotBytes;
   }

   public long indirectAddress() {
      return this.indirect.mappedAddress() + this.slotIndex() * this.indirectSlotBytes;
   }

   public long indirectGroupAddress() {
      return this.indirectAddress() + this.capacity * 12L;
   }

   public long indirectGroupOffset() {
      return this.indirectOffset() + this.capacity * 12L;
   }

   public long listBuffer() {
      return this.list.vkBuffer();
   }

   public long listOffset() {
      return this.slotIndex() * this.listSlotBytes;
   }

   public long listRange() {
      return this.listSlotBytes;
   }

   public long indirectBuffer() {
      return this.indirect.vkBuffer();
   }

   public long indirectOffset() {
      return this.slotIndex() * this.indirectSlotBytes;
   }

   private long slotIndex() {
      return Math.floorMod(this.record, 8L);
   }

   public void destroyNow() {
      NvidiumPlusVkBuffers.destroy(this.vma, this.list.vkBuffer(), this.list.allocation());
      NvidiumPlusVkBuffers.destroy(this.vma, this.indirect.vkBuffer(), this.indirect.allocation());
   }

   public void destroy() {
      long vmaHandle = this.vma;
      NvidiumPlusVkBuffers.MappedBuffer l = this.list;
      NvidiumPlusVkBuffers.MappedBuffer i = this.indirect;
      this.encoder.queueForDestroy(() -> {
         NvidiumPlusVkBuffers.destroy(vmaHandle, l.vkBuffer(), l.allocation());
         NvidiumPlusVkBuffers.destroy(vmaHandle, i.vkBuffer(), i.allocation());
      });
   }
}
