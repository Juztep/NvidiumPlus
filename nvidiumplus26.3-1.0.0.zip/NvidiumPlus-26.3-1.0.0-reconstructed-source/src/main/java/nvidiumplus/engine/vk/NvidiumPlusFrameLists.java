package nvidiumplus.engine.vk;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.device.GpuDevice;
import com.mojang.renderpearl.backend.vulkan.VulkanCommandEncoder;
import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.mixin.GpuDeviceAccessor;
import org.lwjgl.system.MemoryUtil;

final class NvidiumPlusFrameLists {
   static final int SLOTS = 4;
   static final int VIS_ENTRY_BYTES = 32;
   private final VulkanCommandEncoder encoder;
   private final long vma;
   private final int capacity;
   private final long slotVisBytes;
   private final long slotOccBytes;
   private final NvidiumPlusVkBuffers.MappedBuffer vis;
   private final NvidiumPlusVkBuffers.MappedBuffer occ;

   private NvidiumPlusFrameLists(
      VulkanCommandEncoder encoder, long vma, int capacity, NvidiumPlusVkBuffers.MappedBuffer vis, NvidiumPlusVkBuffers.MappedBuffer occ
   ) {
      this.encoder = encoder;
      this.vma = vma;
      this.capacity = capacity;
      this.slotVisBytes = capacity * 32L;
      this.slotOccBytes = capacity * 32L;
      this.vis = vis;
      this.occ = occ;
   }

   static NvidiumPlusFrameLists create(int capacity) {
      GpuDevice facade = RenderSystem.tryGetDevice();
      if (facade == null) {
         return null;
      }

      VulkanDevice device = (VulkanDevice)((GpuDeviceAccessor)facade).nvidiumplus$backend();
      VulkanCommandEncoder encoder = device.createCommandEncoder();
      long vma = device.vma();
      long visBytes = capacity * 32L * 4L;
      long occBytes = capacity * 32L * 4L;
      NvidiumPlusVkBuffers.MappedBuffer vis = NvidiumPlusVkBuffers.createHostMapped(
         vma, visBytes, 32, "vmaCreateBuffer(NvidiumPlus extended visibility list ring)"
      );
      NvidiumPlusVkBuffers.MappedBuffer occ = NvidiumPlusVkBuffers.createHostMapped(
         vma, occBytes, 32, "vmaCreateBuffer(NvidiumPlus extended occlusion list ring)"
      );
      MemoryUtil.memSet(vis.mappedAddress(), 0, visBytes);
      MemoryUtil.memSet(occ.mappedAddress(), 0, occBytes);
      NvidiumPlusLog.LOGGER
         .info(
            "NvidiumPlus extended frame lists up: {} regions/frame — vis ring {} KiB + occlusion list ring {} KiB ({} slots each, host-visible STORAGE; the wave-5/6 16 KiB UBO paths are bypassed this world)",
            new Object[]{capacity, visBytes >> 10, occBytes >> 10, 4}
         );
      return new NvidiumPlusFrameLists(encoder, vma, capacity, vis, occ);
   }

   int capacity() {
      return this.capacity;
   }

   ByteBuffer visWriteView(long frameSerial) {
      long base = this.vis.mappedAddress() + slot(frameSerial) * this.slotVisBytes;
      return MemoryUtil.memByteBuffer(base, (int)this.slotVisBytes).order(ByteOrder.LITTLE_ENDIAN);
   }

   ByteBuffer occWriteView(long frameSerial) {
      long base = this.occ.mappedAddress() + slot(frameSerial) * this.slotOccBytes;
      return MemoryUtil.memByteBuffer(base, (int)this.slotOccBytes).order(ByteOrder.LITTLE_ENDIAN);
   }

   long visBuffer() {
      return this.vis.vkBuffer();
   }

   long visOffset(long frameSerial) {
      return slot(frameSerial) * this.slotVisBytes;
   }

   long visRange() {
      return this.slotVisBytes;
   }

   long occBuffer() {
      return this.occ.vkBuffer();
   }

   long occOffset(long frameSerial) {
      return slot(frameSerial) * this.slotOccBytes;
   }

   long occRange() {
      return this.slotOccBytes;
   }

   private static long slot(long frameSerial) {
      return Math.floorMod(frameSerial, 4L);
   }

   void destroy() {
      long vmaHandle = this.vma;
      NvidiumPlusVkBuffers.MappedBuffer v = this.vis;
      NvidiumPlusVkBuffers.MappedBuffer o = this.occ;
      this.encoder.queueForDestroy(() -> {
         NvidiumPlusVkBuffers.destroy(vmaHandle, v.vkBuffer(), v.allocation());
         NvidiumPlusVkBuffers.destroy(vmaHandle, o.vkBuffer(), o.allocation());
      });
   }

   void destroyNow() {
      NvidiumPlusVkBuffers.destroy(this.vma, this.vis.vkBuffer(), this.vis.allocation());
      NvidiumPlusVkBuffers.destroy(this.vma, this.occ.vkBuffer(), this.occ.allocation());
   }
}
