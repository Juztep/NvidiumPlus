package nvidiumplus.engine.vk;

import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import nvidiumplus.engine.NvidiumPlusLog;
import org.lwjgl.vulkan.VkDevice;

public final class NvidiumPlusDeviceTeardown {
   private NvidiumPlusDeviceTeardown() {
   }

   public static void onDeviceClose(VulkanDevice device) {
      VkDevice vk = device.vkDevice();
      HelloMeshletRenderer.destroyDeviceObjects(vk);
      TerrainDrawer.destroyDeviceObjects(vk);
      NvidiumPlusTerrainPump.onDeviceClose();
      NvidiumPlusLog.LOGGER.info("NvidiumPlus device-lifetime objects destroyed at device close (wave-8 sweep)");
   }
}
