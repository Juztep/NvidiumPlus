package nvidiumplus.engine.vk;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.device.GpuDevice;
import com.mojang.renderpearl.backend.vulkan.VulkanCommandEncoder;
import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusVramState;
import nvidiumplus.engine.NvidiumPlusVulkanState;
import nvidiumplus.engine.mixin.GpuDeviceAccessor;
import nvidiumplus.engine.mixin.VulkanCommandEncoderAccessor;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.vulkan.KHRSynchronization2;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkBufferCopy;
import org.lwjgl.vulkan.VkBufferMemoryBarrier2;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkDependencyInfo;
import org.lwjgl.vulkan.VkBufferCopy.Buffer;

public final class SodiumMirrorGpu {
   static final int STATS_RING = 8;
   public static final int READBACK_LAG = 3;
   private static final int STATS_BYTES = 96;
   private final VulkanDevice device;
   private final VulkanCommandEncoder encoder;
   private final long vma;
   private final int capacity;
   private final NvidiumPlusVkBuffers.DeviceBuffer mirror;
   private VkStagingRing staging;
   private NvidiumPlusVkBuffers.MappedBuffer statsRing;
   private NvidiumPlusVkBuffers.MappedBuffer blockReadback;
   private long blockReadbackFrame = -1L;
   private int blockReadbackMid = -1;
   private int blockReadbackPass = -1;
   private long[] copySrc = new long[256];
   private long[] copyDst = new long[256];
   private long[] copySize = new long[256];
   private int copyCount;
   private long[] fillDst = new long[64];
   private long[] fillSize = new long[64];
   private int fillCount;
   private Buffer copyScratch;
   private long commitSerial;
   private long bytesCommitted;

   private SodiumMirrorGpu(
      VulkanDevice device,
      VulkanCommandEncoder encoder,
      int capacity,
      NvidiumPlusVkBuffers.DeviceBuffer mirror,
      VkStagingRing staging,
      NvidiumPlusVkBuffers.MappedBuffer statsRing
   ) {
      this.device = device;
      this.encoder = encoder;
      this.vma = device.vma();
      this.capacity = capacity;
      this.mirror = mirror;
      this.staging = staging;
      this.statsRing = statsRing;
   }

   public static SodiumMirrorGpu create(int capacity) {
      GpuDevice facade = RenderSystem.tryGetDevice();
      if (facade == null) {
         return null;
      }

      VulkanDevice device = (VulkanDevice)((GpuDeviceAccessor)facade).nvidiumplus$backend();
      VulkanCommandEncoder encoder = device.createCommandEncoder();
      long vma = device.vma();
      long bytes = SodiumGpuVisibilityLayout.mirrorBytes(capacity);
      boolean coherent = SodiumTerrainDrawer.mirrorHostCoherent();
      NvidiumPlusVkBuffers.DeviceBuffer buffer = allocateMirror(vma, bytes, coherent, "vmaCreateBuffer(NvidiumPlus sodium mirror)");
      VkStagingRing staging = null;
      NvidiumPlusVkBuffers.MappedBuffer ring = null;

      try {
         staging = VkStagingRing.create(vma, 33554432, SodiumTerrainDrawer.stagingLag());
         ring = NvidiumPlusVkBuffers.createHostReadback(vma, 768L, 2, "vmaCreateBuffer(NvidiumPlus sodium mirror stats ring)");
      } catch (RuntimeException t) {
         if (staging != null) {
            staging.destroy();
         }

         NvidiumPlusVkBuffers.destroy(vma, buffer.vkBuffer(), buffer.allocation());
         throw t;
      }

      MemoryUtil.memSet(ring.mappedAddress(), 0, 768L);
      SodiumMirrorGpu gpu = new SodiumMirrorGpu(device, encoder, capacity, buffer, staging, ring);
      gpu.zeroInitialize();
      NvidiumPlusLog.LOGGER
         .info(
            "NvidiumPlus Sodium record mirror up: {} region ids, {} MiB {} (rows + two 12 KiB pass blocks per id) + {} MiB staging ring; the task stage now selects Sodium's runs from these records instead of a CPU-built table.",
            new Object[]{
               capacity,
               bytes >> 20,
               !coherent
                  ? "device-local"
                  : (
                     NvidiumPlusVulkanState.integratedGpu()
                        ? "in host-coherent memory (integrated GPU: copies into plain video memory were read stale on one)"
                        : "in host-coherent memory (forced by -Dnvidiumplus.sodium.mirrorHostCoherent)"
                  ),
               32
            }
         );
      return gpu;
   }

   private static NvidiumPlusVkBuffers.DeviceBuffer allocateMirror(long vma, long bytes, boolean coherent, String what) {
      return coherent
         ? NvidiumPlusVkBuffers.createDeviceCoherent(vma, bytes, mirrorUsage(), what)
         : NvidiumPlusVkBuffers.createDeviceLocal(vma, bytes, mirrorUsage(), what);
   }

   private static int mirrorUsage() {
      return 35;
   }

   private void zeroInitialize() {
      MemoryStack stack = MemoryStack.stackPush();

      try {
         VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
         VK10.vkCmdFillBuffer(cb, this.mirror.vkBuffer(), 0L, SodiumGpuVisibilityLayout.mirrorBytes(this.capacity), 0);
         VulkanCommandEncoder.memoryBarrier(cb, stack);
         this.writeLayoutWords(cb, stack);
         VulkanCommandEncoder.memoryBarrier(cb, stack);
         checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(sodium mirror zero-init)");
         this.encoder.execute(cb);
      } catch (Throwable var5) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var4) {
               var5.addSuppressed(var4);
            }
         }

         throw var5;
      }

      if (stack != null) {
         stack.close();
      }
   }

   private void writeLayoutWords(VkCommandBuffer cb, MemoryStack stack) {
      ByteBuffer words = stack.calloc(16).order(ByteOrder.LITTLE_ENDIAN);
      words.putInt(0, this.capacity);
      words.putInt(4, 0);
      words.putInt(8, SodiumGpuVisibilityLayout.recordBaseUvec4(this.capacity, 0));
      words.putInt(12, SodiumGpuVisibilityLayout.recordBaseUvec4(this.capacity, 1));
      VK10.vkCmdUpdateBuffer(cb, this.mirror.vkBuffer(), 96L, words);
   }

   public int capacity() {
      return this.capacity;
   }

   public long vkBuffer() {
      return this.mirror.vkBuffer();
   }

   public long rowsOffset() {
      return SodiumGpuVisibilityLayout.rowsOffset(this.capacity);
   }

   public long rowsRange() {
      return this.capacity * 64L;
   }

   public long statsVkBuffer() {
      return this.mirror.vkBuffer();
   }

   public long statsOffset() {
      return 0L;
   }

   public long commitSerial() {
      return this.commitSerial;
   }

   public long lastCommitBytes() {
      return this.bytesCommitted;
   }

   public boolean beginCommit(long frameSerial) {
      if (this.encoder != null && this.staging != null) {
         this.staging.beginFrame(SodiumFrameRing.submitsReturned());
         this.copyCount = 0;
         this.fillCount = 0;
         this.bytesCommitted = 0L;
         return true;
      } else {
         return false;
      }
   }

   public long stageBlock(int bytes) {
      long off = this.staging.alloc(bytes);
      return off < 0L ? 0L : this.staging.mappedAddress() + off;
   }

   public void copyRow(int mid, long stagedAddress) {
      this.queueCopy(stagedAddress - this.staging.mappedAddress(), SodiumGpuVisibilityLayout.rowsOffset(this.capacity) + mid * 64L, 64L);
   }

   public void copyPassBlock(int mid, int pass, long stagedAddress) {
      this.queueCopy(stagedAddress - this.staging.mappedAddress(), SodiumGpuVisibilityLayout.passOffset(this.capacity, pass) + mid * 12288L, 12288L);
   }

   public void zeroPassBlock(int mid, int pass) {
      this.queueFill(SodiumGpuVisibilityLayout.passOffset(this.capacity, pass) + mid * 12288L, 12288L);
   }

   public void zeroRow(int mid) {
      this.queueFill(SodiumGpuVisibilityLayout.rowsOffset(this.capacity) + mid * 64L, 64L);
   }

   private void queueCopy(long src, long dst, long size) {
      if (this.copyCount == this.copySrc.length) {
         this.copySrc = Arrays.copyOf(this.copySrc, this.copySrc.length * 2);
         this.copyDst = Arrays.copyOf(this.copyDst, this.copyDst.length * 2);
         this.copySize = Arrays.copyOf(this.copySize, this.copySize.length * 2);
      }

      this.copySrc[this.copyCount] = src;
      this.copyDst[this.copyCount] = dst;
      this.copySize[this.copyCount] = size;
      this.copyCount++;
      this.bytesCommitted += size;
   }

   private void queueFill(long dst, long size) {
      if (this.fillCount == this.fillDst.length) {
         this.fillDst = Arrays.copyOf(this.fillDst, this.fillDst.length * 2);
         this.fillSize = Arrays.copyOf(this.fillSize, this.fillSize.length * 2);
      }

      this.fillDst[this.fillCount] = dst;
      this.fillSize[this.fillCount] = size;
      this.fillCount++;
   }

   public void endCommit() {
      if (this.copyCount != 0 || this.fillCount != 0) {
         MemoryStack stack = MemoryStack.stackPush();

         try {
            VulkanCommandEncoderAccessor access = (VulkanCommandEncoderAccessor)this.encoder;
            boolean shared = SodiumTerrainDrawer.commitInDrawBuffer() && access.nvidiumplus$currentRenderPass() == null;
            VkCommandBuffer cb = shared ? access.nvidiumplus$commandBuffer() : this.encoder.allocateAndBeginTransientCommandBuffer();

            for (int i = 0; i < this.fillCount; i++) {
               VK10.vkCmdFillBuffer(cb, this.mirror.vkBuffer(), this.fillDst[i], this.fillSize[i], 0);
            }

            if (this.fillCount > 0 && this.copyCount > 0) {
               VulkanCommandEncoder.memoryBarrier(cb, stack);
            }

            if (this.copyCount > 0) {
               if (SodiumTerrainDrawer.splitRowCopies()) {
                  this.emitCopies(cb, 64, false);
                  this.emitCopies(cb, 64, true);
               } else {
                  this.emitCopies(cb, -1, false);
               }

               this.commitSerial++;
            }

            VulkanCommandEncoder.memoryBarrier(cb, stack);
            if (shared || SodiumTerrainDrawer.commitBarrierExplicit()) {
               this.explicitMirrorBarrier(cb, stack);
            }

            if (!shared) {
               checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(sodium mirror commit)");
               this.encoder.execute(cb);
            }
         } catch (Throwable var7) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (stack != null) {
            stack.close();
         }

         this.copyCount = 0;
         this.fillCount = 0;
      }
   }

   private void explicitMirrorBarrier(VkCommandBuffer cb, MemoryStack stack) {
      long stageAllTransfer = 4096L;
      long stageTask = 524288L;
      long stageMesh = 1048576L;
      long stageFragment = 128L;
      long accessTransferWrite = 4096L;
      long accessShaderRead = 32L;
      long accessShaderStorageRead = 8589934592L;
      org.lwjgl.vulkan.VkBufferMemoryBarrier2.Buffer barrier = VkBufferMemoryBarrier2.calloc(1, stack);
      ((VkBufferMemoryBarrier2)barrier.get(0))
         .sType$Default()
         .srcStageMask(4096L)
         .srcAccessMask(4096L)
         .dstStageMask(1572992L)
         .dstAccessMask(8589934624L)
         .srcQueueFamilyIndex(-1)
         .dstQueueFamilyIndex(-1)
         .buffer(this.mirror.vkBuffer())
         .offset(0L)
         .size(-1L);
      VkDependencyInfo info = VkDependencyInfo.calloc(stack).sType$Default().pBufferMemoryBarriers(barrier);
      KHRSynchronization2.vkCmdPipelineBarrier2KHR(cb, info);
   }

   private void emitCopies(VkCommandBuffer cb, int rowBytes, boolean rowsOnly) {
      int n = 0;

      for (int i = 0; i < this.copyCount; i++) {
         if (rowBytes < 0 || this.copySize[i] == rowBytes == rowsOnly) {
            n++;
         }
      }

      if (n != 0) {
         Buffer regions = this.copyScratch(n);
         int w = 0;

         for (int i = 0; i < this.copyCount; i++) {
            if (rowBytes < 0 || this.copySize[i] == rowBytes == rowsOnly) {
               ((VkBufferCopy)regions.get(w++)).srcOffset(this.copySrc[i]).dstOffset(this.copyDst[i]).size(this.copySize[i]);
            }
         }

         ((Buffer)regions.position(0)).limit(n);
         VK10.vkCmdCopyBuffer(cb, this.staging.vkBuffer(), this.mirror.vkBuffer(), regions);
         regions.clear();
      }
   }

   private Buffer copyScratch(int n) {
      if (this.copyScratch == null || this.copyScratch.capacity() < n) {
         if (this.copyScratch != null) {
            this.copyScratch.free();
         }

         this.copyScratch = VkBufferCopy.calloc(Math.max(n, 256));
      }

      return this.copyScratch;
   }

   public SodiumMirrorGpu grow(int newCapacity) {
      if (newCapacity <= this.capacity) {
         throw new IllegalArgumentException("grow to " + newCapacity + " from " + this.capacity);
      }

      long newBytes = SodiumGpuVisibilityLayout.mirrorBytes(newCapacity);
      long oldBytes = SodiumGpuVisibilityLayout.mirrorBytes(this.capacity);
      MeshShaderDeviceSupport.refreshMemoryBudget(System.nanoTime());
      if (NvidiumPlusVramState.known()) {
         long headroom = NvidiumPlusVramState.headroomBytes();
         if (newBytes > headroom) {
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus Sodium record mirror will not grow {} -> {} ids: {} MiB would exceed the sampled VRAM headroom of {} MiB.",
                  new Object[]{this.capacity, newCapacity, newBytes >> 20, headroom >> 20}
               );
            return null;
         }
      }

      NvidiumPlusVkBuffers.DeviceBuffer larger = allocateMirror(
         this.vma, newBytes, SodiumTerrainDrawer.mirrorHostCoherent(), "vmaCreateBuffer(NvidiumPlus sodium mirror grow)"
      );
      SodiumMirrorGpu next = new SodiumMirrorGpu(this.device, this.encoder, newCapacity, larger, this.staging, this.statsRing);
      next.commitSerial = this.commitSerial + 1L;
      next.blockReadback = this.blockReadback;
      next.blockReadbackFrame = this.blockReadbackFrame;
      next.blockReadbackMid = this.blockReadbackMid;
      next.blockReadbackPass = this.blockReadbackPass;
      this.blockReadback = null;
      this.blockReadbackFrame = -1L;
      this.blockReadbackMid = -1;
      this.blockReadbackPass = -1;
      MemoryStack stack = MemoryStack.stackPush();

      try {
         VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
         long headerAndRows = SodiumGpuVisibilityLayout.rowsOffset(this.capacity) + this.capacity * 64L;
         long passBytes = this.capacity * 12288L;
         Buffer regions = VkBufferCopy.calloc(3, stack);
         ((VkBufferCopy)regions.get(0)).srcOffset(0L).dstOffset(0L).size(headerAndRows);
         ((VkBufferCopy)regions.get(1))
            .srcOffset(SodiumGpuVisibilityLayout.passOffset(this.capacity, 0))
            .dstOffset(SodiumGpuVisibilityLayout.passOffset(newCapacity, 0))
            .size(passBytes);
         ((VkBufferCopy)regions.get(2))
            .srcOffset(SodiumGpuVisibilityLayout.passOffset(this.capacity, 1))
            .dstOffset(SodiumGpuVisibilityLayout.passOffset(newCapacity, 1))
            .size(passBytes);
         VK10.vkCmdCopyBuffer(cb, this.mirror.vkBuffer(), larger.vkBuffer(), regions);
         long newRowsEnd = SodiumGpuVisibilityLayout.rowsOffset(newCapacity) + newCapacity * 64L;
         VK10.vkCmdFillBuffer(cb, larger.vkBuffer(), headerAndRows, newRowsEnd - headerAndRows, 0);

         for (int pass = 0; pass < 2; pass++) {
            long tailStart = SodiumGpuVisibilityLayout.passOffset(newCapacity, pass) + passBytes;
            long tailBytes = (newCapacity - this.capacity) * 12288L;
            VK10.vkCmdFillBuffer(cb, larger.vkBuffer(), tailStart, tailBytes, 0);
         }

         VulkanCommandEncoder.memoryBarrier(cb, stack);
         next.writeLayoutWords(cb, stack);
         VulkanCommandEncoder.memoryBarrier(cb, stack);
         checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(sodium mirror grow)");
         this.encoder.execute(cb);
      } catch (Throwable var23) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var22) {
               var23.addSuppressed(var22);
            }
         }

         throw var23;
      }

      if (stack != null) {
         stack.close();
      }

      long vmaHandle = this.vma;
      NvidiumPlusVkBuffers.DeviceBuffer old = this.mirror;
      this.encoder.queueForDestroy(() -> NvidiumPlusVkBuffers.destroy(vmaHandle, old.vkBuffer(), old.allocation()));
      if (this.copyScratch != null) {
         next.copyScratch = this.copyScratch;
         this.copyScratch = null;
      }

      this.staging = null;
      this.statsRing = null;
      NvidiumPlusLog.LOGGER
         .info(
            "NvidiumPlus Sodium record mirror grew {} -> {} ids ({} -> {} MiB); this frame is drawn by the list path and the mirror resumes next frame.",
            new Object[]{this.capacity, newCapacity, oldBytes >> 20, newBytes >> 20}
         );
      return next;
   }

   public void recordStatsTransfer(long statsFrame) {
      MemoryStack stack = MemoryStack.stackPush();

      try {
         VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
         Buffer copy = VkBufferCopy.calloc(1, stack);
         ((VkBufferCopy)copy.get(0)).srcOffset(0L).dstOffset(statsFrame % 8L * 96L).size(96L);
         VK10.vkCmdCopyBuffer(cb, this.mirror.vkBuffer(), this.statsRing.vkBuffer(), copy);
         if (this.blockReadback != null && this.blockReadbackFrame < 0L && this.blockReadbackMid >= 0) {
            Buffer block = VkBufferCopy.calloc(1, stack);
            ((VkBufferCopy)block.get(0))
               .srcOffset(SodiumGpuVisibilityLayout.passOffset(this.capacity, this.blockReadbackPass) + this.blockReadbackMid * 12288L)
               .dstOffset(0L)
               .size(12288L);
            VK10.vkCmdCopyBuffer(cb, this.mirror.vkBuffer(), this.blockReadback.vkBuffer(), block);
            this.blockReadbackFrame = statsFrame;
         }

         VulkanCommandEncoder.memoryBarrier(cb, stack);
         VK10.vkCmdFillBuffer(cb, this.mirror.vkBuffer(), 0L, 96L, 0);
         VulkanCommandEncoder.memoryBarrier(cb, stack);
         checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(sodium mirror stats)");
         this.encoder.execute(cb);
      } catch (Throwable var8) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var7) {
               var8.addSuppressed(var7);
            }
         }

         throw var8;
      }

      if (stack != null) {
         stack.close();
      }
   }

   public int[] readStats(long statsFrame) {
      if (statsFrame >= 0L && this.statsRing != null) {
         long base = this.statsRing.mappedAddress() + statsFrame % 8L * 96L;
         ByteBuffer slot = MemoryUtil.memByteBuffer(base, 96).order(ByteOrder.LITTLE_ENDIAN);
         int[] words = new int[24];

         for (int i = 0; i < words.length; i++) {
            words[i] = slot.getInt(i * 4);
         }

         return words;
      } else {
         return null;
      }
   }

   public void requestBlockReadback(int mid, int pass) {
      if (this.blockReadbackFrame < 0L) {
         if (this.blockReadback == null) {
            this.blockReadback = NvidiumPlusVkBuffers.createHostReadback(this.vma, 12288L, 2, "vmaCreateBuffer(NvidiumPlus sodium mirror audit readback)");
         }

         this.blockReadbackMid = mid;
         this.blockReadbackPass = pass;
         this.blockReadbackFrame = -1L;
      }
   }

   public int blockReadbackMid() {
      return this.blockReadbackFrame >= 0L ? this.blockReadbackMid : -1;
   }

   public int blockReadbackPass() {
      return this.blockReadbackPass;
   }

   public long takeBlockReadback(long currentStatsFrame) {
      if (this.blockReadback != null && this.blockReadbackFrame >= 0L && currentStatsFrame - this.blockReadbackFrame >= 3L) {
         this.blockReadbackFrame = -1L;
         this.blockReadbackMid = -1;
         return this.blockReadback.mappedAddress();
      } else {
         return 0L;
      }
   }

   public void destroy() {
      long vmaHandle = this.vma;
      NvidiumPlusVkBuffers.DeviceBuffer m = this.mirror;
      VkStagingRing s = this.staging;
      NvidiumPlusVkBuffers.MappedBuffer r = this.statsRing;
      NvidiumPlusVkBuffers.MappedBuffer b = this.blockReadback;
      this.staging = null;
      this.statsRing = null;
      this.blockReadback = null;
      if (this.copyScratch != null) {
         this.copyScratch.free();
         this.copyScratch = null;
      }

      this.encoder.queueForDestroy(() -> {
         NvidiumPlusVkBuffers.destroy(vmaHandle, m.vkBuffer(), m.allocation());
         if (s != null) {
            s.destroy();
         }

         if (r != null) {
            NvidiumPlusVkBuffers.destroy(vmaHandle, r.vkBuffer(), r.allocation());
         }

         if (b != null) {
            NvidiumPlusVkBuffers.destroy(vmaHandle, b.vkBuffer(), b.allocation());
         }
      });
   }

   public void destroyNow() {
      NvidiumPlusVkBuffers.destroy(this.vma, this.mirror.vkBuffer(), this.mirror.allocation());
      if (this.staging != null) {
         this.staging.destroy();
         this.staging = null;
      }

      if (this.statsRing != null) {
         NvidiumPlusVkBuffers.destroy(this.vma, this.statsRing.vkBuffer(), this.statsRing.allocation());
         this.statsRing = null;
      }

      if (this.blockReadback != null) {
         NvidiumPlusVkBuffers.destroy(this.vma, this.blockReadback.vkBuffer(), this.blockReadback.allocation());
         this.blockReadback = null;
      }

      if (this.copyScratch != null) {
         this.copyScratch.free();
         this.copyScratch = null;
      }
   }

   private static void checkVk(int result, String what) {
      if (result != 0) {
         throw new IllegalStateException(what + " failed: VkResult " + result);
      }
   }
}
