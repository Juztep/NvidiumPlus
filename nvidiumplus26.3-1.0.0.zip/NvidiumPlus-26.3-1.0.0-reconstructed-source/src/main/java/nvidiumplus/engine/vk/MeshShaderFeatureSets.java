package nvidiumplus.engine.vk;

import com.mojang.renderpearl.backend.vulkan.VulkanFeatureSets;
import com.mojang.renderpearl.backend.vulkan.VulkanPhysicalDevice;
import com.mojang.renderpearl.backend.vulkan.init.FeatureSet;
import com.mojang.renderpearl.backend.vulkan.init.VulkanFeature;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import nvidiumplus.engine.NvidiumPlusLog;
import org.lwjgl.vulkan.VkPhysicalDevice;

public final class MeshShaderFeatureSets {
   public static final FeatureSet MESH_SHADERS = new FeatureSet(
      "NvidiumPlus mesh shaders",
      Set.of("VK_EXT_mesh_shader"),
      Set.of(MeshShaderDeviceSupport.MESH_SHADER_FEATURE, MeshShaderDeviceSupport.TASK_SHADER_FEATURE)
   );
   public static final FeatureSet FRAGMENT_STORES_AND_ATOMICS = new FeatureSet(
      "NvidiumPlus occlusion culling (fragmentStoresAndAtomics)",
      Set.of(),
      Set.of(new VulkanFeature(VulkanFeatureSets.VK10_FEATURES_STRUCT, "fragmentStoresAndAtomics"))
   );
   public static final FeatureSet CONDITIONAL_RENDERING = new FeatureSet(
      "NvidiumPlus conditional rendering", Set.of("VK_EXT_conditional_rendering"), Set.of(MeshShaderDeviceSupport.CONDITIONAL_RENDERING_FEATURE)
   );
   public static final FeatureSet CONSERVATIVE_RASTERIZATION = new FeatureSet(
      "NvidiumPlus conservative rasterization", Set.of("VK_EXT_conservative_rasterization"), Set.of()
   );
   public static final FeatureSet MEMORY_BUDGET = new FeatureSet("NvidiumPlus memory budget", Set.of("VK_EXT_memory_budget"), Set.of());

   private MeshShaderFeatureSets() {
   }

   public static List<FeatureSet> optional() {
      List<FeatureSet> out = new ArrayList<>(5);
      out.add(MESH_SHADERS);
      out.add(FRAGMENT_STORES_AND_ATOMICS);
      out.add(CONDITIONAL_RENDERING);
      out.add(MEMORY_BUDGET);
      if (Boolean.getBoolean("nvidiumplus.occlusion.conservativeRaster")) {
         out.add(CONSERVATIVE_RASTERIZATION);
      }

      return out;
   }

   public static void onCreateDevice(FeatureSet enabled, VulkanPhysicalDevice physicalDevice) {
      VkPhysicalDevice vk = physicalDevice.vkPhysicalDevice();
      boolean hasExtension = physicalDevice.hasDeviceExtension("VK_EXT_mesh_shader");
      boolean meshShader = false;
      boolean taskShader = false;
      if (hasExtension) {
         Set<VulkanFeature> supported = MESH_SHADERS.supportedFeatures(vk);
         meshShader = supported.contains(MeshShaderDeviceSupport.MESH_SHADER_FEATURE);
         taskShader = supported.contains(MeshShaderDeviceSupport.TASK_SHADER_FEATURE);
      }

      boolean meshEnabled = enabled.contains(MESH_SHADERS);
      if (meshEnabled != (meshShader && taskShader)) {
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus: vanilla {} the mesh-shader feature set but the direct probe says meshShader={}, taskShader={}; going with vanilla",
               new Object[]{meshEnabled ? "enabled" : "did not enable", meshShader, taskShader}
            );
         meshShader = meshEnabled;
         taskShader = meshEnabled;
      }

      MeshShaderDeviceSupport.onDeviceFeaturesDecided(
         physicalDevice,
         hasExtension,
         meshShader,
         taskShader,
         meshEnabled && enabled.contains(FRAGMENT_STORES_AND_ATOMICS),
         meshEnabled && enabled.contains(CONDITIONAL_RENDERING),
         physicalDevice.hasDeviceExtension("VK_EXT_conservative_rasterization"),
         meshEnabled && enabled.contains(CONSERVATIVE_RASTERIZATION),
         enabled.contains(MEMORY_BUDGET)
      );
   }
}
