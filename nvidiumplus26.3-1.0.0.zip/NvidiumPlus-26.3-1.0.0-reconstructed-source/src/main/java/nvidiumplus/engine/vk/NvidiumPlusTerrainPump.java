package nvidiumplus.engine.vk;

import com.mojang.renderpearl.api.device.GpuDeviceLossException;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.terrain.host.TerrainResidency;

public final class NvidiumPlusTerrainPump {
   private static boolean broken;
   private static NvidiumPlusTerrainGpu gpu;
   private static final int DISABLED_RELEASE_FRAMES = 120;
   private static int disabledFramesLeft = 120;

   private NvidiumPlusTerrainPump() {
   }

   public static void afterVanillaTerrainUpload() {
      if (!broken) {
         try {
            if (!NvidiumPlusConfig.terrainRenderingConfigured()) {
               releaseWhileDisabled();
               return;
            }

            if (gpu == null) {
               gpu = NvidiumPlusTerrainGpu.create();
               if (gpu == null) {
                  return;
               }

               disabledFramesLeft = 120;
            }

            TerrainResidency.pump(gpu);
         } catch (GpuDeviceLossException t) {
            broken = true;
            TerrainResidency.recordError("pump: device lost: " + t);
            NvidiumPlusLog.LOGGER
               .error("GPU device lost during NvidiumPlus's terrain pump; residency goes passive (vanilla will report the loss on its own next call)", t);
         } catch (Throwable t) {
            broken = true;
            TerrainResidency.recordError("pump: " + t);
            NvidiumPlusLog.LOGGER.error("NvidiumPlus terrain pump failed; residency disabled for this session", t);
         }
      }
   }

   private static void releaseWhileDisabled() {
      if (gpu != null) {
         TerrainResidency.pump(gpu);
         TerrainResidency.Counters c = TerrainResidency.counters();
         boolean drained = c.sectionsResident() == 0 && c.pendingFreeRanges() == 0 && c.stagingBacklogEntries() == 0;
         if (drained || --disabledFramesLeft <= 0) {
            if (!drained) {
               NvidiumPlusLog.LOGGER
                  .debug(
                     "NvidiumPlus released its arena with {} section(s) still resident; they cannot be drawn while it is switched off and the switch back on rebuilds them",
                     c.sectionsResident()
                  );
            }

            NvidiumPlusTerrainGpu dying = gpu;
            gpu = null;
            TerrainResidency.Counters snapshot = TerrainResidency.disposeAndResetKeepingSeam();
            dying.destroy();
            TerrainDrawer.onDispatcherDispose();
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus terrain rendering was switched off, so its {} MiB arena went back to the graphics card rather than sitting there holding a copy of a world it is not drawing. Switching it back on reloads the terrain",
                  snapshot.arenaCapacityBytes() >> 20
               );
         }
      }
   }

   public static void onDispatcherDispose() {
      try {
         TerrainResidency.Counters snapshot = TerrainResidency.disposeAndReset();
         if (gpu != null) {
            gpu.destroy();
            gpu = null;
         }

         TerrainDrawer.onDispatcherDispose();
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus terrain residency dropped with the dispatcher: {} sections / {} quads were still resident at dispose (releaseAllBuffers should have freed all of them first), {} retained sections / {} quads dropped with the world (wave-11 policy (c): retention is per-world), {} uploads pending, {} frees pending",
               new Object[]{
                  snapshot.sectionsResident(),
                  snapshot.quadsResident(),
                  snapshot.retainedSections(),
                  snapshot.retainedQuads(),
                  snapshot.stagingBacklogEntries(),
                  snapshot.pendingFreeRanges()
               }
            );
      } catch (Throwable t) {
         broken = true;
         TerrainResidency.recordError("dispose: " + t);
         NvidiumPlusLog.LOGGER.error("NvidiumPlus terrain dispose hook failed", t);
      }
   }

   public static void onDeviceClose() {
      if (gpu != null) {
         NvidiumPlusLog.LOGGER
            .warn("NvidiumPlus terrain residency still live at device close (the dispatcher dispose hook never ran); destroying buffers directly");

         try {
            gpu.destroyNow();
         } finally {
            gpu = null;
         }
      }
   }
}
