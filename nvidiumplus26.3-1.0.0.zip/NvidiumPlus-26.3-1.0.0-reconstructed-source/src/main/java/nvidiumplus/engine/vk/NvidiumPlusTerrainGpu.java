package nvidiumplus.engine.vk;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.device.GpuDevice;
import com.mojang.renderpearl.backend.vulkan.VulkanCommandEncoder;
import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import nvidiumplus.engine.NvidiumPlusExtendedRd;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusScaling;
import nvidiumplus.engine.NvidiumPlusVramState;
import nvidiumplus.engine.mixin.GpuDeviceAccessor;
import nvidiumplus.engine.terrain.RegionRecord;
import nvidiumplus.engine.terrain.SectionRecord;
import nvidiumplus.engine.terrain.TerrainArena;
import nvidiumplus.engine.terrain.host.TerrainGpuHost;
import nvidiumplus.engine.terrain.host.TerrainResidency;
import nvidiumplus.engine.terrain.host.VanillaUploadSeam;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkBufferCopy;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkBufferCopy.Buffer;

public final class NvidiumPlusTerrainGpu implements TerrainGpuHost {
   static final int FREE_FRAME_LAG = 3;
   static final long ARENA_INITIAL_BYTES = 268435456L;
   static final int STAGING_BYTES = 33554432;
   private static final long BUDGET_SAMPLE_INTERVAL_NANOS = 1000000000L;
   private final VulkanCommandEncoder encoder;
   private final long vma;
   private final VkArenaBacking arenaBacking;
   private NvidiumPlusVkBuffers.DeviceBuffer regionBuffer;
   private NvidiumPlusVkBuffers.DeviceBuffer sectionBuffer;
   private final VkStagingRing ring;
   private int recordCapacityRegions;
   private final List<long[]> arenaCopies = new ArrayList<>();
   private final List<long[]> arenaLateCopies = new ArrayList<>();
   private final List<long[]> sectionCopies = new ArrayList<>();
   private final List<long[]> regionCopies = new ArrayList<>();
   private final List<long[]> fills = new ArrayList<>();
   private final ArrayDeque<long[]> retiredBackings = new ArrayDeque<>();
   private long currentFrame;
   private static volatile long arenaBuffersRetired;
   private static volatile long recordGrowths;

   static long arenaBytes() {
      long testMiB = Long.getLong("nvidiumplus.test.arenaMiB", 0L);
      if (testMiB > 0L) {
         NvidiumPlusLog.LOGGER
            .warn(
               "nvidiumplus.test.arenaMiB={} — TEST-ONLY tiny terrain arena (initial AND growth ceiling) in use; expect drops and a coverage-guard trip",
               testMiB
            );
      }

      return NvidiumPlusScaling.arenaInitialBytes();
   }

   private NvidiumPlusTerrainGpu(
      VulkanDevice device,
      VulkanCommandEncoder encoder,
      VkArenaBacking arenaBacking,
      NvidiumPlusVkBuffers.DeviceBuffer regionBuffer,
      NvidiumPlusVkBuffers.DeviceBuffer sectionBuffer,
      VkStagingRing ring
   ) {
      this.encoder = encoder;
      this.vma = device.vma();
      this.arenaBacking = arenaBacking;
      this.regionBuffer = regionBuffer;
      this.sectionBuffer = sectionBuffer;
      this.ring = ring;
   }

   static NvidiumPlusTerrainGpu create() {
      GpuDevice facade = RenderSystem.tryGetDevice();
      if (facade == null) {
         return null;
      }

      VulkanDevice device = (VulkanDevice)((GpuDeviceAccessor)facade).nvidiumplus$backend();
      VulkanCommandEncoder encoder = device.createCommandEncoder();
      long vma = device.vma();
      NvidiumPlusScaling.pinForWorld((Integer)Minecraft.getInstance().options.renderDistance().get());
      NvidiumPlusExtendedRd.onWorldPinned();
      VanillaUploadSeam.armForNewWorld();
      VkArenaBacking arenaBacking = new VkArenaBacking(vma);
      NvidiumPlusVkBuffers.DeviceBuffer regionBuffer = null;
      NvidiumPlusVkBuffers.DeviceBuffer sectionBuffer = null;
      VkStagingRing ring = null;
      boolean handedOff = false;

      try {
         long arenaBytes = arenaBytes();
         TerrainArena arena = new TerrainArena(arenaBacking, arenaBytes, 16, NvidiumPlusScaling.arenaBlockBytes(), NvidiumPlusScaling.arenaBlockCount());
         long regionBytes = RegionRecord.regionBufferBytes(TerrainResidency.maxRegions());
         long sectionBytes = SectionRecord.sectionBufferBytes(TerrainResidency.maxRegions());
         int recordUsage = 35;
         regionBuffer = NvidiumPlusVkBuffers.createDeviceLocal(vma, regionBytes, recordUsage, "vmaCreateBuffer(NvidiumPlus region records)");
         sectionBuffer = NvidiumPlusVkBuffers.createDeviceLocal(vma, sectionBytes, recordUsage, "vmaCreateBuffer(NvidiumPlus section records)");
         ring = VkStagingRing.create(vma, 33554432);
         NvidiumPlusTerrainGpu gpu = new NvidiumPlusTerrainGpu(device, encoder, arenaBacking, regionBuffer, sectionBuffer, ring);
         gpu.recordCapacityRegions = TerrainResidency.maxRegions();
         gpu.zeroInitialize(regionBytes, sectionBytes);
         handedOff = true;
         return finishCreate(gpu, arena, arenaBytes, regionBytes, sectionBytes, sectionBuffer, device);
      } finally {
         if (!handedOff) {
            releasePartialStandup(vma, arenaBacking, regionBuffer, sectionBuffer, ring);
         }
      }
   }

   private static void releasePartialStandup(
      long vma,
      VkArenaBacking arenaBacking,
      NvidiumPlusVkBuffers.DeviceBuffer regionBuffer,
      NvidiumPlusVkBuffers.DeviceBuffer sectionBuffer,
      VkStagingRing ring
   ) {
      NvidiumPlusLog.LOGGER
         .warn("NvidiumPlus terrain standup failed part-way - releasing whatever was already allocated so it does not leak for the process lifetime");

      try {
         for (long[] block : arenaBacking.takeAllForDestroy()) {
            if (block[0] != 0L) {
               NvidiumPlusVkBuffers.destroy(vma, block[0], block[1]);
            }
         }
      } catch (Throwable t) {
         NvidiumPlusLog.LOGGER.warn("NvidiumPlus: arena backing release failed during unwind", t);
      }

      for (NvidiumPlusVkBuffers.DeviceBuffer b : new NvidiumPlusVkBuffers.DeviceBuffer[]{regionBuffer, sectionBuffer}) {
         if (b != null) {
            try {
               NvidiumPlusVkBuffers.destroy(vma, b.vkBuffer(), b.allocation());
            } catch (Throwable t) {
               NvidiumPlusLog.LOGGER.warn("NvidiumPlus: record buffer release failed during unwind", t);
            }
         }
      }

      if (ring != null) {
         try {
            ring.destroy();
         } catch (Throwable t) {
            NvidiumPlusLog.LOGGER.warn("NvidiumPlus: staging ring release failed during unwind", t);
         }
      }
   }

   private static NvidiumPlusTerrainGpu finishCreate(
      NvidiumPlusTerrainGpu gpu,
      TerrainArena arena,
      long arenaBytes,
      long regionBytes,
      long sectionBytes,
      NvidiumPlusVkBuffers.DeviceBuffer sectionBuffer,
      VulkanDevice device
   ) {
      TerrainResidency.attachArena(arena, sectionBuffer.vkBuffer());
      NvidiumPlusLog.LOGGER
         .info(
            "NvidiumPlus terrain GPU residency up: arena {} MiB initial (elastic to the {} MiB device ceiling, wave 14) + region {} KiB + section {} MiB records + staging ring {} MiB (device '{}')",
            new Object[]{
               arenaBytes >> 20, NvidiumPlusScaling.arenaCeilingBytes() >> 20, regionBytes >> 10, sectionBytes >> 20, 32, device.getDeviceInfo().name()
            }
         );
      return gpu;
   }

   private void zeroInitialize(long regionBytes, long sectionBytes) {
      MemoryStack stack = MemoryStack.stackPush();

      try {
         VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
         VK10.vkCmdFillBuffer(cb, this.arenaBacking.vkBuffer(), 0L, this.arenaBacking.sizeBytes(), 0);
         VK10.vkCmdFillBuffer(cb, this.regionBuffer.vkBuffer(), 0L, regionBytes, 0);
         VK10.vkCmdFillBuffer(cb, this.sectionBuffer.vkBuffer(), 0L, sectionBytes, 0);
         VulkanCommandEncoder.memoryBarrier(cb, stack);
         checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(zero-init)");
         this.encoder.execute(cb);
      } catch (Throwable var9) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var8) {
               var9.addSuppressed(var8);
            }
         }

         throw var9;
      }

      if (stack != null) {
         stack.close();
      }
   }

   @Override
   public boolean beginFrame(long frame) {
      this.currentFrame = frame;
      long now = System.nanoTime();
      if (now - NvidiumPlusVramState.lastSampleNanos() >= 1000000000L) {
         MeshShaderDeviceSupport.refreshMemoryBudget(now);
      }

      while (!this.retiredBackings.isEmpty() && frame - ((long[])this.retiredBackings.peekFirst())[0] >= 3L) {
         long[] retired = this.retiredBackings.pollFirst();
         if (frame - retired[0] < 3L) {
            throw new IllegalStateException("arena backing retired after " + (frame - retired[0]) + " frames < FREE_FRAME_LAG 3");
         }

         NvidiumPlusVkBuffers.destroy(this.vma, retired[1], retired[2]);
         arenaBuffersRetired++;
      }

      this.ring.beginFrame(frame);
      this.arenaCopies.clear();
      this.arenaLateCopies.clear();
      this.sectionCopies.clear();
      this.regionCopies.clear();
      this.fills.clear();
      return true;
   }

   @Override
   public long maxStageBytes() {
      return this.ring.capacity();
   }

   @Override
   public long stagingUsedBytes() {
      return this.ring.usedBytes();
   }

   @Override
   public boolean stageArenaCopy(ByteBuffer data, int block, long blockByteOffset) {
      return this.stage(data, blockByteOffset, this.arenaCopies, block);
   }

   @Override
   public boolean stageArenaCopyLate(ByteBuffer data, int block, long blockByteOffset) {
      return this.stage(data, blockByteOffset, this.arenaLateCopies, block);
   }

   @Override
   public boolean stageSectionRecords(ByteBuffer data, long byteOffset) {
      return this.stage(data, byteOffset, this.sectionCopies);
   }

   @Override
   public boolean stageRegionRecord(ByteBuffer data, long byteOffset) {
      return this.stage(data, byteOffset, this.regionCopies);
   }

   private boolean stage(ByteBuffer data, long dstOffset, List<long[]> copies) {
      return this.stage(data, dstOffset, copies, 0);
   }

   private boolean stage(ByteBuffer data, long dstOffset, List<long[]> copies, int block) {
      int size = data.remaining();
      if (size <= 0) {
         return true;
      }

      long srcOffset = this.ring.alloc(size);
      if (srcOffset < 0L) {
         return false;
      }

      MemoryUtil.memByteBuffer(this.ring.mappedAddress() + srcOffset, size).put(data.duplicate());
      copies.add(new long[]{srcOffset, dstOffset, size, block});
      return true;
   }

   @Override
   public void onArenaBlockAppended(long blockBytes) {
      MemoryStack stack = MemoryStack.stackPush();

      try {
         VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
         VK10.vkCmdFillBuffer(cb, this.arenaBacking.lastBlockBuffer(), 0L, blockBytes, 0);
         VulkanCommandEncoder.memoryBarrier(cb, stack);
         checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(NvidiumPlus arena append)");
         this.encoder.execute(cb);
      } catch (Throwable var7) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }
         }

         throw var7;
      }

      if (stack != null) {
         stack.close();
      }

      NvidiumPlusLog.LOGGER
         .info(
            "NvidiumPlus terrain arena APPENDED a {} MiB block (no copy, no retirement - every existing address keeps its meaning; total {} MiB across {} blocks, ceiling {} MiB)",
            new Object[]{blockBytes >> 20, this.arenaBacking.sizeBytes() >> 20, this.arenaBacking.blockCount(), NvidiumPlusScaling.arenaCeilingBytes() >> 20}
         );
   }

   @Override
   public long growArena(long newSizeBytes) {
      long oldSize = this.arenaBacking.lastBlockBytes();
      if (newSizeBytes <= oldSize) {
         return 0L;
      }

      NvidiumPlusVkBuffers.DeviceBuffer grown = null;

      try {
         grown = NvidiumPlusVkBuffers.createDeviceLocal(this.vma, newSizeBytes, 35, "vmaCreateBuffer(NvidiumPlus terrain arena growth)");
         MemoryStack stack = MemoryStack.stackPush();

         try {
            VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
            VK10.vkCmdFillBuffer(cb, grown.vkBuffer(), oldSize, newSizeBytes - oldSize, 0);
            Buffer region = VkBufferCopy.calloc(1, stack);
            ((VkBufferCopy)region.get(0)).srcOffset(0L).dstOffset(0L).size(oldSize);
            VK10.vkCmdCopyBuffer(cb, this.arenaBacking.lastBlockBuffer(), grown.vkBuffer(), region);
            VulkanCommandEncoder.memoryBarrier(cb, stack);
            checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(NvidiumPlus arena growth)");
            this.encoder.execute(cb);
         } catch (Throwable var10) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var9) {
                  var10.addSuppressed(var9);
               }
            }

            throw var10;
         }

         if (stack != null) {
            stack.close();
         }
      } catch (Throwable t) {
         if (grown != null) {
            NvidiumPlusVkBuffers.destroy(this.vma, grown.vkBuffer(), grown.allocation());
         }

         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus terrain arena growth to {} MiB failed (treated as growth exhausted; the coverage guard remains the backstop): {}",
               newSizeBytes >> 20,
               t.toString()
            );
         return 0L;
      }

      long[] old = this.arenaBacking.swapForGrowth(grown, newSizeBytes);
      this.retiredBackings.addLast(new long[]{this.currentFrame, old[0], old[1]});
      NvidiumPlusLog.LOGGER
         .info(
            "NvidiumPlus terrain arena grown {} -> {} MiB (grow-and-copy; old buffer retires after {} frames; ceiling {} MiB)",
            new Object[]{oldSize >> 20, newSizeBytes >> 20, 3, NvidiumPlusScaling.arenaCeilingBytes() >> 20}
         );
      return grown.vkBuffer();
   }

   @Override
   public long trimArena(long newSizeBytes, long copyBytes) {
      long oldSize = this.arenaBacking.lastBlockBytes();
      if (newSizeBytes < oldSize && copyBytes <= newSizeBytes && newSizeBytes > 0L) {
         NvidiumPlusVkBuffers.DeviceBuffer shrunk = null;

         try {
            shrunk = NvidiumPlusVkBuffers.createDeviceLocal(this.vma, newSizeBytes, 35, "vmaCreateBuffer(NvidiumPlus terrain arena trim)");
            MemoryStack stack = MemoryStack.stackPush();

            try {
               VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
               if (copyBytes < newSizeBytes) {
                  VK10.vkCmdFillBuffer(cb, shrunk.vkBuffer(), copyBytes, newSizeBytes - copyBytes, 0);
               }

               if (copyBytes > 0L) {
                  Buffer region = VkBufferCopy.calloc(1, stack);
                  ((VkBufferCopy)region.get(0)).srcOffset(0L).dstOffset(0L).size(copyBytes);
                  VK10.vkCmdCopyBuffer(cb, this.arenaBacking.lastBlockBuffer(), shrunk.vkBuffer(), region);
               }

               VulkanCommandEncoder.memoryBarrier(cb, stack);
               checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(NvidiumPlus arena trim)");
               this.encoder.execute(cb);
            } catch (Throwable var12) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var11) {
                     var12.addSuppressed(var11);
                  }
               }

               throw var12;
            }

            if (stack != null) {
               stack.close();
            }
         } catch (Throwable t) {
            if (shrunk != null) {
               NvidiumPlusVkBuffers.destroy(this.vma, shrunk.vkBuffer(), shrunk.allocation());
            }

            NvidiumPlusLog.LOGGER
               .warn("NvidiumPlus terrain arena trim to {} MiB failed (the tail stays committed; nothing else changes): {}", newSizeBytes >> 20, t.toString());
            return 0L;
         }

         long[] old = this.arenaBacking.swapForGrowth(shrunk, newSizeBytes);
         this.retiredBackings.addLast(new long[]{this.currentFrame, old[0], old[1]});
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus terrain arena trimmed {} -> {} MiB ({} MiB returned to the driver; one {} MiB copy; old buffer retires after {} frames; regrowth is the ordinary wave-14 ladder)",
               new Object[]{oldSize >> 20, newSizeBytes >> 20, oldSize - newSizeBytes >> 20, copyBytes >> 20, 3}
            );
         return shrunk.vkBuffer();
      } else {
         return 0L;
      }
   }

   public static long arenaBuffersRetired() {
      return arenaBuffersRetired;
   }

   @Override
   public long growRecords(int newMaxRegions) {
      if (newMaxRegions <= this.recordCapacityRegions) {
         return 0L;
      }

      long oldRegionBytes = RegionRecord.regionBufferBytes(this.recordCapacityRegions);
      long oldSectionBytes = SectionRecord.sectionBufferBytes(this.recordCapacityRegions);
      long newRegionBytes = RegionRecord.regionBufferBytes(newMaxRegions);
      long newSectionBytes = SectionRecord.sectionBufferBytes(newMaxRegions);
      NvidiumPlusVkBuffers.DeviceBuffer grownRegion = null;
      NvidiumPlusVkBuffers.DeviceBuffer grownSection = null;

      try {
         int usage = 35;
         grownRegion = NvidiumPlusVkBuffers.createDeviceLocal(this.vma, newRegionBytes, usage, "vmaCreateBuffer(NvidiumPlus region records growth)");
         grownSection = NvidiumPlusVkBuffers.createDeviceLocal(this.vma, newSectionBytes, usage, "vmaCreateBuffer(NvidiumPlus section records growth)");
         MemoryStack stack = MemoryStack.stackPush();

         try {
            VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
            VK10.vkCmdFillBuffer(cb, grownRegion.vkBuffer(), oldRegionBytes, newRegionBytes - oldRegionBytes, 0);
            VK10.vkCmdFillBuffer(cb, grownSection.vkBuffer(), oldSectionBytes, newSectionBytes - oldSectionBytes, 0);
            Buffer regionCopy = VkBufferCopy.calloc(1, stack);
            ((VkBufferCopy)regionCopy.get(0)).srcOffset(0L).dstOffset(0L).size(oldRegionBytes);
            VK10.vkCmdCopyBuffer(cb, this.regionBuffer.vkBuffer(), grownRegion.vkBuffer(), regionCopy);
            Buffer sectionCopy = VkBufferCopy.calloc(1, stack);
            ((VkBufferCopy)sectionCopy.get(0)).srcOffset(0L).dstOffset(0L).size(oldSectionBytes);
            VK10.vkCmdCopyBuffer(cb, this.sectionBuffer.vkBuffer(), grownSection.vkBuffer(), sectionCopy);
            VulkanCommandEncoder.memoryBarrier(cb, stack);
            checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(NvidiumPlus record growth)");
            this.encoder.execute(cb);
         } catch (Throwable var18) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var17) {
                  var18.addSuppressed(var17);
               }
            }

            throw var18;
         }

         if (stack != null) {
            stack.close();
         }
      } catch (Throwable t) {
         if (grownRegion != null) {
            NvidiumPlusVkBuffers.destroy(this.vma, grownRegion.vkBuffer(), grownRegion.allocation());
         }

         if (grownSection != null) {
            NvidiumPlusVkBuffers.destroy(this.vma, grownSection.vkBuffer(), grownSection.allocation());
         }

         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus record-buffer growth to {} regions failed (the live render-distance raise falls back to the rejoin hint): {}",
               newMaxRegions,
               t.toString()
            );
         return 0L;
      }

      this.retiredBackings.addLast(new long[]{this.currentFrame, this.regionBuffer.vkBuffer(), this.regionBuffer.allocation()});
      this.retiredBackings.addLast(new long[]{this.currentFrame, this.sectionBuffer.vkBuffer(), this.sectionBuffer.allocation()});
      this.regionBuffer = grownRegion;
      this.sectionBuffer = grownSection;
      int oldCapacity = this.recordCapacityRegions;
      this.recordCapacityRegions = newMaxRegions;
      recordGrowths++;
      TerrainDrawer.onPinnedRegrow();
      NvidiumPlusLog.LOGGER
         .info(
            "NvidiumPlus record buffers grown {} -> {} regions (region records {} KiB, section records {} MiB; old pair retires after {} frames; live render-distance raise, wave 15)",
            new Object[]{oldCapacity, newMaxRegions, newRegionBytes >> 10, newSectionBytes >> 20, 3}
         );
      return this.sectionBuffer.vkBuffer();
   }

   public static long recordGrowths() {
      return recordGrowths;
   }

   @Override
   public void dropSnapshotSizedDrawResources() {
      TerrainDrawer.onPinnedRegrow();
   }

   @Override
   public void fillSectionBlockZero(long byteOffset, long bytes) {
      this.fills.add(new long[]{this.sectionBuffer.vkBuffer(), byteOffset, bytes, 0L});
   }

   @Override
   public void fillRegionTombstone(long byteOffset) {
      this.fills.add(new long[]{this.regionBuffer.vkBuffer(), byteOffset, 16L, 4294967295L});
   }

   @Override
   public void endFrame() {
      if (!this.arenaCopies.isEmpty()
         || !this.arenaLateCopies.isEmpty()
         || !this.sectionCopies.isEmpty()
         || !this.regionCopies.isEmpty()
         || !this.fills.isEmpty()) {
         try {
            MemoryStack stack = MemoryStack.stackPush();

            try {
               VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
               if (!this.fills.isEmpty()) {
                  for (long[] fill : this.fills) {
                     VK10.vkCmdFillBuffer(cb, fill[0], fill[1], fill[2], (int)fill[3]);
                  }

                  VulkanCommandEncoder.memoryBarrier(cb, stack);
               }

               this.recordArenaCopies(cb, stack, this.arenaCopies);
               this.recordCopies(cb, stack, this.sectionCopies, this.sectionBuffer.vkBuffer());
               this.recordCopies(cb, stack, this.regionCopies, this.regionBuffer.vkBuffer());
               if (!this.arenaLateCopies.isEmpty()) {
                  VulkanCommandEncoder.memoryBarrier(cb, stack);
                  this.recordArenaCopies(cb, stack, this.arenaLateCopies);
               }

               VulkanCommandEncoder.memoryBarrier(cb, stack);
               checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(NvidiumPlus terrain pump)");
               this.encoder.execute(cb);
            } catch (Throwable var10) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var9) {
                     var10.addSuppressed(var9);
                  }
               }

               throw var10;
            }

            if (stack != null) {
               stack.close();
            }
         } finally {
            this.arenaCopies.clear();
            this.arenaLateCopies.clear();
            this.sectionCopies.clear();
            this.regionCopies.clear();
            this.fills.clear();
         }
      }
   }

   private void recordArenaCopies(VkCommandBuffer cb, MemoryStack stack, List<long[]> copies) {
      if (!copies.isEmpty()) {
         long[] handles = this.arenaBacking.blockHandles();
         int blocks = handles.length;
         if (blocks == 1) {
            this.recordCopies(cb, stack, copies, handles[0]);
         } else {
            List<long[]> perBlock = new ArrayList<>();

            for (int b = 0; b < blocks; b++) {
               perBlock.clear();

               for (long[] copy : copies) {
                  if ((int)copy[3] == b) {
                     perBlock.add(copy);
                  }
               }

               if (!perBlock.isEmpty()) {
                  this.recordCopies(cb, stack, perBlock, handles[b]);
               }
            }
         }
      }
   }

   private void recordCopies(VkCommandBuffer cb, MemoryStack stack, List<long[]> copies, long dst) {
      for (int start = 0; start < copies.size(); start += 256) {
         int n = Math.min(256, copies.size() - start);
         Buffer regions = VkBufferCopy.calloc(n, stack);

         for (int i = 0; i < n; i++) {
            long[] copy = copies.get(start + i);
            ((VkBufferCopy)regions.get(i)).srcOffset(copy[0]).dstOffset(copy[1]).size(copy[2]);
         }

         VK10.vkCmdCopyBuffer(cb, this.ring.vkBuffer(), dst, regions);
      }
   }

   void destroy() {
      long[][] arenaHandles = this.arenaBacking.takeAllForDestroy();
      long[][] parked = this.retiredBackings.toArray(new long[0][]);
      this.retiredBackings.clear();
      long vmaHandle = this.vma;
      this.encoder.queueForDestroy(() -> {
         for (long[] block : arenaHandles) {
            NvidiumPlusVkBuffers.destroy(vmaHandle, block[0], block[1]);
         }

         for (long[] old : parked) {
            NvidiumPlusVkBuffers.destroy(vmaHandle, old[1], old[2]);
         }

         NvidiumPlusVkBuffers.destroy(vmaHandle, this.regionBuffer.vkBuffer(), this.regionBuffer.allocation());
         NvidiumPlusVkBuffers.destroy(vmaHandle, this.sectionBuffer.vkBuffer(), this.sectionBuffer.allocation());
         this.ring.destroy();
      });
   }

   void destroyNow() {
      for (long[] block : this.arenaBacking.takeAllForDestroy()) {
         NvidiumPlusVkBuffers.destroy(this.vma, block[0], block[1]);
      }

      while (!this.retiredBackings.isEmpty()) {
         long[] old = this.retiredBackings.pollFirst();
         NvidiumPlusVkBuffers.destroy(this.vma, old[1], old[2]);
      }

      NvidiumPlusVkBuffers.destroy(this.vma, this.regionBuffer.vkBuffer(), this.regionBuffer.allocation());
      NvidiumPlusVkBuffers.destroy(this.vma, this.sectionBuffer.vkBuffer(), this.sectionBuffer.allocation());
      this.ring.destroy();
   }

   private static void checkVk(int result, String what) {
      if (result != 0) {
         throw new IllegalStateException(what + " failed: VkResult " + result);
      }
   }
}
