package nvidiumplus.engine.vk;

import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

public final class NvidiumPlusProjectionCapture {
   private static final Matrix4f LAST = new Matrix4f();
   private static volatile GpuBufferSlice lastSlice;
   private static volatile long captures;
   private static final Matrix4f PRE_BOB = new Matrix4f();
   private static volatile long preBobSerial;

   private NvidiumPlusProjectionCapture() {
   }

   public static void record(Matrix4f matrix, GpuBufferSlice slice) {
      if (matrix != null) {
         LAST.set(matrix);
         lastSlice = slice;
         captures++;
      }
   }

   public static Matrix4f lastIfBound(GpuBufferSlice bound) {
      GpuBufferSlice slice = lastSlice;
      return slice != null && bound != null && slice == bound ? LAST : null;
   }

   public static long captures() {
      return captures;
   }

   public static void recordPreBob(Matrix4fc matrix) {
      if (matrix != null) {
         PRE_BOB.set(matrix);
         preBobSerial++;
      }
   }

   public static Matrix4fc preBob() {
      return preBobSerial == 0L ? null : PRE_BOB;
   }

   public static long preBobSerial() {
      return preBobSerial;
   }

   public static long preBobFrames() {
      return preBobSerial;
   }
}
