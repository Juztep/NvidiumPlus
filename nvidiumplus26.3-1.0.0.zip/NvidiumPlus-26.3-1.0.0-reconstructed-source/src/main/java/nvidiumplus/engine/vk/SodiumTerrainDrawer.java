package nvidiumplus.engine.vk;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.renderpearl.api.commands.CommandEncoder;
import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.renderpearl.api.device.GpuDeviceLossException;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.vulkan.VulkanConst;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuBuffer;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuSampler;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuTextureView;
import com.mojang.renderpearl.backend.vulkan.VulkanRenderPass;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import net.minecraft.client.Minecraft;
import nvidiumplus.engine.NvidiumPlusBenchRecorder;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusVulkanState;
import nvidiumplus.engine.mixin.RenderPassAccessor;
import nvidiumplus.engine.mixin.VulkanRenderPassAccessor;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.vulkan.EXTMeshShader;
import org.lwjgl.vulkan.KHRPushDescriptor;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkDescriptorBufferInfo;
import org.lwjgl.vulkan.VkDescriptorImageInfo;
import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkWriteDescriptorSet;
import org.lwjgl.vulkan.VkDescriptorBufferInfo.Buffer;

public final class SodiumTerrainDrawer {
   public static final int META_STRIDE = 3;
   public static final String PROPERTY_K_SPLIT = "nvidiumplus.sodium.ksplit";
   public static final String PROPERTY_SOLID_NO_DISCARD = "nvidiumplus.sodium.solidNoDiscard";
   public static final String PROPERTY_FRUSTUM = "nvidiumplus.sodium.frustum";
   public static final int DIAG_EMPTY_PASSES = Integer.getInteger("nvidiumplus.sodium.diag.emptyPasses", 0);
   public static final int FRUSTUM_OFF = 0;
   public static final int FRUSTUM_COUNT = 1;
   public static final int FRUSTUM_CPU = 2;
   public static final int FRUSTUM_GPU = 3;
   public static final int FRUSTUM_MODE = parseFrustumMode(System.getProperty("nvidiumplus.sodium.frustum", "off"));
   public static final boolean FRUSTUM_DIAG_COUNT = Boolean.getBoolean("nvidiumplus.sodium.diag.frustumCount");
   public static final float FRUSTUM_SLACK = 1.125F;
   public static final String PROPERTY_REVERSE_ORDER = "nvidiumplus.sodium.reverseOrder";
   private static final boolean REVERSE_ORDER = Boolean.getBoolean("nvidiumplus.sodium.reverseOrder");
   private static final int K_SPLIT = Math.max(1, Integer.getInteger("nvidiumplus.sodium.ksplit", 1));
   public static final String PROPERTY_BATCH = "nvidiumplus.sodium.batch";
   public static final String PROPERTY_GROUP_MAP = "nvidiumplus.sodium.groupmap";
   private static SodiumTerrainDrawer.Shape shapeResolved;
   private static final int MAX_GROUPS_PER_DRAW = 65535;
   private static TerrainDrawPipeline pipeline;
   private static TerrainDrawPipeline pipelineNoDiscard;
   private static NvidiumPlusSodiumRunTable runTable;
   private static boolean runTableOverflowReported;
   private static boolean groupMapOverflowReported;
   private static volatile boolean broken;
   private static volatile String error;
   private static volatile long framesDrawn;
   private static volatile int lastSectionsDrawn;
   private static volatile int lastRegionsDrawn;
   private static volatile long totalSectionsDrawn;
   private static volatile boolean enabled = true;
   private static volatile int lastDrawCommands;
   private static volatile int lastRunsWritten;
   private static volatile long lastQuadsKept;
   private static volatile long lastQuadsCulled;
   private static volatile long lastTableNanos;
   private static volatile long lastRecordNanos;
   private static volatile long lastBuildNanos;
   private static final long[] buildNanosRing = new long[256];
   private static long buildNanosCount;
   private static volatile long noDiscardPasses;
   private static volatile long discardPasses;
   private static boolean ringGuardReported;
   public static final String PROPERTY_RUN_CACHE = "nvidiumplus.sodium.runCache";
   private static volatile boolean runCacheEnabled = !"false".equalsIgnoreCase(System.getProperty("nvidiumplus.sodium.runCache"));
   private static volatile boolean runCacheArmed;
   private static volatile int lastRegionsHit;
   private static volatile int lastRegionsRebuilt;
   private static volatile long regionsHitTotal;
   private static volatile long regionsRebuiltTotal;
   private static volatile long hookUpload;
   private static volatile long hookRemoveSection;
   private static volatile long hookBufferChange;
   private static volatile long hookSegmentChange;
   private static volatile long hookDelete;
   private static volatile int lastRunsPushed;
   private static volatile int lastRunsFrustumRejected;
   private static volatile long lastQuadsFrustumRejected;
   private static volatile long runsPushedTotal;
   private static volatile long runsFrustumRejectedTotal;
   private static long timerPasses;
   public static final String PROPERTY_GPU_DRAW = "nvidiumplus.sodium.gpuDraw";
   public static final String PROPERTY_OCCLUSION = "nvidiumplus.sodium.occlusion";
   public static final String PROPERTY_GRAPH_REGIONS = "nvidiumplus.sodium.graphRegions";
   public static final String PROPERTY_LIST_MAP = "nvidiumplus.sodium.listMap";
   public static final String LIST_MAP_OFF = "off";
   public static final String LIST_MAP_ON = "on";
   public static final String LIST_MAP_VERIFY = "verify";
   public static final String LIST_MAP_AB = "ab";
   public static final String PROPERTY_DISTANCE_GATE = "nvidiumplus.sodium.distanceGate";
   public static final String PROPERTY_PHASE_B_CPU_SKIP = "nvidiumplus.sodium.phaseBCpuSkip";
   public static final String PROPERTY_COMMIT_BARRIER = "nvidiumplus.sodium.commitBarrier";
   public static final String PROPERTY_SPLIT_ROW_COPIES = "nvidiumplus.sodium.splitRowCopies";
   public static final String PROPERTY_ROWS_FROM_LIST = "nvidiumplus.sodium.rowsFromList";
   public static final String PROPERTY_MIRROR_HOST_COHERENT = "nvidiumplus.sodium.mirrorHostCoherent";
   public static final String PROPERTY_FALLBACK_ON_STALE = "nvidiumplus.sodium.fallbackOnStale";
   public static final String PROPERTY_COMMIT_IN_DRAW_BUFFER = "nvidiumplus.sodium.commitInDrawBuffer";
   private static final long FALLBACK_REFUSING_FRAMES = 2L;
   private static volatile long mirrorStaleTotal;
   private static volatile int mirrorStaleLogged;
   public static final String PROPERTY_STAGING_LAG = "nvidiumplus.sodium.stagingLag";
   public static final String PROPERTY_REMIRROR_ON_REFUSAL = "nvidiumplus.sodium.remirrorOnRefusal";
   public static final String PROPERTY_REGION_HOLD = "nvidiumplus.sodium.regionHold";
   public static final String PROPERTY_STAMP_HOLD = "nvidiumplus.sodium.stampHold";
   public static final String PROPERTY_MERGE_PHASE_A = "nvidiumplus.sodium.mergePhaseA";
   public static final String PROPERTY_OCC_BOXES_PER_WG = "nvidiumplus.sodium.occBoxesPerWG";
   public static final String PROPERTY_DIAG_TASK_SKIP = "nvidiumplus.sodium.diag.taskSkip";
   public static final String PROPERTY_ONE_DRAW = "nvidiumplus.sodium.oneDrawPerGroup";
   private static final boolean ONE_DRAW = !"false".equalsIgnoreCase(System.getProperty("nvidiumplus.sodium.oneDrawPerGroup"));
   private static final int DIAG_TASK_SKIP_FLAGS = diagTaskSkipFlags(System.getProperty("nvidiumplus.sodium.diag.taskSkip", "none"));
   public static final int OCC_BOXES_PER_WG = Math.max(1, Math.min(8, Integer.getInteger("nvidiumplus.sodium.occBoxesPerWG", 4)));
   private static final boolean MERGE_PHASE_A = !"false".equalsIgnoreCase(System.getProperty("nvidiumplus.sodium.mergePhaseA"));
   public static final String PROPERTY_MIRROR_AUDIT = "nvidiumplus.sodium.mirrorAudit";
   private static volatile boolean gpuDrawEnabled = NvidiumPlusConfig.sodiumGpuVisibilityEnabled();
   private static volatile boolean occlusionEnabled = occlusionConfigured(gpuDrawEnabled);
   private static volatile boolean graphRegions = !"false".equalsIgnoreCase(System.getProperty("nvidiumplus.sodium.graphRegions"));
   private static volatile String listMapMode = normaliseListMap(System.getProperty("nvidiumplus.sodium.listMap"));
   private static volatile long listMapDrainNanos;
   private static volatile long listMapMapNanos;
   private static volatile int listMapDrainFrames;
   private static volatile int listMapMapFrames;
   private static volatile long listMapDrainRegions;
   private static volatile long listMapMapRegions;
   private static volatile long listMapCompares;
   private static volatile long listMapMismatches;
   private static volatile String listMapDisarmReason;
   private static final boolean MIRROR_AUDIT = Boolean.getBoolean("nvidiumplus.sodium.mirrorAudit");
   private static volatile String forcedDeclineReason;
   private static volatile int initialCapacityOverride = -1;
   private static volatile boolean gpuDrawBroken;
   private static volatile String gpuDrawError;
   private static volatile boolean occlusionBroken;
   private static volatile String occlusionError;
   private static TerrainDrawPipeline pipelineTask;
   private static TerrainDrawPipeline pipelineTaskNoDiscard;
   private static final List<SodiumTerrainDrawer.InstanceState> liveInstances = new ArrayList<>();
   private static volatile SodiumTerrainDrawer.InstanceState activeState;
   private static long stampSerial = 1L;
   private static final Matrix4f mvpScratch = new Matrix4f();
   private static volatile String rung = "1";
   private static volatile long framesOwned;
   private static volatile long framesAttempted;
   private static volatile long occlusionFrames;
   private static final Map<String, Long> frameDeclines = new LinkedHashMap<>();
   private static volatile long frameDeclinesTotal;
   private static volatile int droppedRegionsPerFrame;
   private static volatile long droppedRegionsTotal;
   private static volatile boolean droppedRegionsLogged;
   private static volatile long oneFrameGapsTotal;
   private static volatile int oneFrameGapRegions;
   private static volatile int oneFrameGapsLogged;
   private static volatile long auditMismatchRegions;
   private static volatile int auditMismatchesLogged;
   private static volatile long unreachableSectionsTotal;
   private static volatile long unreachableRegionsTotal;
   private static volatile int unreachablePerFrame;
   private static volatile int unreachableLogged;
   private static volatile long regionsHeldTotal;
   private static volatile boolean regionsHeldLogged;
   private static volatile long skippedGroupsTotal;
   private static volatile long skippedGroupRegions;
   private static volatile int skippedGroupsLogged;
   private static volatile long regionRejectionsTotal;
   private static volatile int regionRejectionsLogged;
   private static volatile long regionRejectionsFrames;
   private static volatile long rowSamePlaceFrames;
   private static volatile long rowOtherPlaceFrames;
   private static volatile long rowUnknownFrames;
   private static volatile boolean remirrorRequested;
   private static volatile long remirrorsTotal;
   private static int[] rowLedger;
   private static final int LEDGER_STRIDE = 24;
   private static final int LEDGER_GENERATIONS = 4;
   private static final int LEDGER_WRITES = 16;
   private static final int LEDGER_RELEASES = 17;
   private static final int LEDGER_ISSUED = 18;
   private static volatile int commitRegionsPerFrame;
   private static volatile long commitRegionsTotal;
   private static volatile long commitBytesPerFrame;
   private static volatile long commitNanos;
   private static volatile long deadRows;
   private static volatile int midsLive;
   private static volatile int midsCapacity;
   private static volatile long midsReleased;
   private static volatile long growths;
   private static volatile int bufferKeys;
   private static volatile int listedRegions;
   private static volatile int listedSections;
   private static volatile int bufferGroups;
   private static volatile int drawCommandsPerFrame;
   private static volatile long loopNanos;
   private static volatile int gpuSectionsMask;
   private static volatile int gpuSectionsA;
   private static volatile int gpuSectionsB;
   private static volatile long gpuQuads;
   private static volatile long statsFramesRead;
   private static volatile int sectionsEmitted;
   private static final int[] sectionsEmittedByPass = new int[2];
   private static final long[] quadsKeptByPass = new long[2];
   private static volatile long midMissing;
   private static volatile long keyMismatch;
   private static volatile long mirrorAuditMismatches;
   private static volatile long mirrorGpuReadbackMismatches;
   private static volatile long mirrorAuditFrames;
   private static volatile String searchDistanceSource = "none";
   private static volatile float searchDistanceBlocks;
   private static volatile boolean lastFaceAll;
   private static volatile boolean phaseBCpuSkipArmed;
   private static volatile long phaseBCpuSkips;
   private static volatile long instancesRetired;
   private static volatile long occlusionRecreates;
   private static volatile String gpuTimerUnit = "none";
   private static volatile boolean gpuDrawLogged;
   private static final int DIP_MIN_SECTIONS = 64;
   private static final int DIP_TROUGH_NUM = 92;
   private static final int DIP_TROUGH_DEN = 100;
   private static final int DIP_SHOULDER_NUM = 94;
   private static final int DIP_SHOULDER_DEN = 100;
   private static final int DIP_LISTED_NUM = 95;
   private static final int DIP_LISTED_DEN = 100;
   private static final int DIP_LOG_LIMIT = 8;
   private static final int DIP_LOG_EVERY = 64;
   private static volatile long visibilityDips;
   private static volatile long lastVisibilityDipFrame = -1L;
   private static long visibilityDipsLogged;

   private static int parseFrustumMode(String value) {
      return switch (value.trim().toLowerCase(Locale.ROOT)) {
         case "count" -> 1;
         case "cpu" -> 2;
         case "gpu" -> 3;
         default -> 0;
      };
   }

   public static boolean frustumCpuTestWanted() {
      return FRUSTUM_MODE == 1 || FRUSTUM_MODE == 2 || FRUSTUM_DIAG_COUNT;
   }

   public static String frustumModeName() {
      return switch (FRUSTUM_MODE) {
         case 1 -> "count";
         case 2 -> "cpu";
         case 3 -> "gpu";
         default -> "off";
      };
   }

   static SodiumTerrainDrawer.Shape shape() {
      SodiumTerrainDrawer.Shape sh = shapeResolved;
      if (sh == null) {
         if ("false".equalsIgnoreCase(System.getProperty("nvidiumplus.sodium.batch"))) {
            sh = SodiumTerrainDrawer.Shape.PER_SECTION;
         } else if (Boolean.getBoolean("nvidiumplus.sodium.groupmap")) {
            sh = SodiumTerrainDrawer.Shape.GROUP_MAP;
         } else if (NvidiumPlusVulkanState.drawIndirectSupported()) {
            sh = SodiumTerrainDrawer.Shape.DRAW_ID;
         } else {
            sh = SodiumTerrainDrawer.Shape.GROUP_MAP;
         }

         shapeResolved = sh;
      }

      return sh;
   }

   private static boolean batchedEnabled() {
      return shape() != SodiumTerrainDrawer.Shape.PER_SECTION;
   }

   private SodiumTerrainDrawer() {
   }

   public static boolean broken() {
      return broken;
   }

   public static String error() {
      return error;
   }

   public static long framesDrawn() {
      return framesDrawn;
   }

   public static int lastSectionsDrawn() {
      return lastSectionsDrawn;
   }

   public static int lastSectionsDrawnFrame() {
      String r = rung;
      return r != null && r.startsWith("0") ? lastSectionsDrawn : sectionsEmittedFrame();
   }

   public static long totalSectionsDrawn() {
      return totalSectionsDrawn;
   }

   public static int lastRegionsDrawn() {
      return lastRegionsDrawn;
   }

   public static int lastDrawCommands() {
      return lastDrawCommands;
   }

   public static int lastRunsWritten() {
      return lastRunsWritten;
   }

   public static long lastQuadsKept() {
      return lastQuadsKept;
   }

   public static long lastQuadsCulled() {
      return lastQuadsCulled;
   }

   public static void reportFrustum(int pushed, int rejected, long quadsRejected) {
      lastRunsPushed = pushed;
      lastRunsFrustumRejected = rejected;
      lastQuadsFrustumRejected = quadsRejected;
      runsPushedTotal += pushed;
      runsFrustumRejectedTotal += rejected;
      NvidiumPlusBenchRecorder.addRuns(pushed, rejected);
   }

   public static int lastRunsPushed() {
      return lastRunsPushed;
   }

   public static int lastRunsFrustumRejected() {
      return lastRunsFrustumRejected;
   }

   public static long lastQuadsFrustumRejected() {
      return lastQuadsFrustumRejected;
   }

   public static long runsPushedTotal() {
      return runsPushedTotal;
   }

   public static long runsFrustumRejectedTotal() {
      return runsFrustumRejectedTotal;
   }

   public static void reportQuads(long kept, long culled, long buildNanos) {
      lastQuadsKept = kept;
      lastQuadsCulled = culled;
      lastBuildNanos = buildNanos;
      buildNanosRing[(int)(buildNanosCount++ & 255L)] = buildNanos;
   }

   public static double meanBuildNanos() {
      int n = (int)Math.min(buildNanosCount, buildNanosRing.length);
      if (n == 0) {
         return 0.0;
      }

      long sum = 0L;

      for (int i = 0; i < n; i++) {
         sum += buildNanosRing[i];
      }

      return (double)sum / n;
   }

   public static void failEnumeration(Throwable t) {
      broken = true;
      error = t.toString();
      NvidiumPlusLog.LOGGER
         .error(
            "NvidiumPlus could not read Sodium's render lists; Sodium's own renderer keeps the opaque passes for the rest of this session (first and only report). Nothing of Sodium's was consumed or freed.",
            t
         );
   }

   public static long lastTableNanos() {
      return lastTableNanos;
   }

   public static long lastRecordNanos() {
      return lastRecordNanos;
   }

   public static long lastBuildNanos() {
      return lastBuildNanos;
   }

   public static long noDiscardPasses() {
      return noDiscardPasses;
   }

   public static long discardPasses() {
      return discardPasses;
   }

   public static void onEncoderSubmit() {
      NvidiumPlusSodiumRunTable.onSubmit();
      SodiumFrameRing.onSubmit();
   }

   public static int kSplit() {
      return K_SPLIT;
   }

   public static boolean batched() {
      return shapeResolved != null && shapeResolved != SodiumTerrainDrawer.Shape.PER_SECTION;
   }

   public static String shapeName() {
      return shapeResolved == null ? "unresolved" : shapeResolved.name();
   }

   public static boolean enabled() {
      return enabled;
   }

   public static void setEnabled(boolean value) {
      enabled = value;
   }

   public static boolean runCacheEnabled() {
      return runCacheEnabled;
   }

   public static void setRunCacheEnabled(boolean value) {
      runCacheEnabled = value;
   }

   public static void reportRunCache(boolean armed, int regionsHit, int regionsRebuilt) {
      runCacheArmed = armed;
      lastRegionsHit = regionsHit;
      lastRegionsRebuilt = regionsRebuilt;
      regionsHitTotal += regionsHit;
      regionsRebuiltTotal += regionsRebuilt;
   }

   public static boolean runCacheArmed() {
      return runCacheArmed;
   }

   public static int lastRegionsHit() {
      return lastRegionsHit;
   }

   public static int lastRegionsRebuilt() {
      return lastRegionsRebuilt;
   }

   public static long regionsHitTotal() {
      return regionsHitTotal;
   }

   public static long regionsRebuiltTotal() {
      return regionsRebuiltTotal;
   }

   public static void onHookUpload() {
      hookUpload++;
   }

   public static void onHookRemoveSection() {
      hookRemoveSection++;
   }

   public static void onHookBufferChange() {
      hookBufferChange++;
   }

   public static void onHookSegmentChange() {
      hookSegmentChange++;
   }

   public static void onHookDelete() {
      hookDelete++;
   }

   public static long hookUpload() {
      return hookUpload;
   }

   public static long hookRemoveSection() {
      return hookRemoveSection;
   }

   public static long hookBufferChange() {
      return hookBufferChange;
   }

   public static long hookSegmentChange() {
      return hookSegmentChange;
   }

   public static long hookDelete() {
      return hookDelete;
   }

   public static boolean drawOpaque(
      GpuTextureView colorView,
      GpuTextureView depthView,
      GpuTextureView atlasView,
      GpuSampler atlasSampler,
      GpuTextureView lightmapView,
      Matrix4fc modelView,
      Matrix4fc projection,
      GpuBuffer[] geometryBuffers,
      int bufferCount,
      int drawCount,
      int[] drawMeta,
      float[] drawOrigins,
      int regionCount,
      boolean noDiscard
   ) {
      if (broken || !enabled) {
         return false;
      }

      if (colorView == null
         || depthView == null
         || atlasView == null
         || lightmapView == null
         || atlasSampler == null
         || modelView == null
         || projection == null) {
         return false;
      }

      if (drawCount == 0) {
         return false;
      }

      if (shape() != SodiumTerrainDrawer.Shape.PER_SECTION && NvidiumPlusSodiumRunTable.ringGuardTripped()) {
         if (!ringGuardReported) {
            ringGuardReported = true;
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus: more than {} terrain passes were recorded between two queue submits, which is more than the run table's ring can hold safely; the extra passes are drawn by Sodium until the next submit (reported once).",
                  NvidiumPlusSodiumRunTable.safeAdvancesPerSubmit()
               );
         }

         return false;
      } else {
         try {
            record(
               colorView,
               depthView,
               atlasView,
               atlasSampler,
               lightmapView,
               modelView,
               projection,
               geometryBuffers,
               bufferCount,
               drawCount,
               drawMeta,
               drawOrigins,
               noDiscard
            );
            lastSectionsDrawn = drawCount;
            lastRegionsDrawn = regionCount;
            totalSectionsDrawn += drawCount;
            framesDrawn++;
            gpuTimerUnit = "pass";
            return true;
         } catch (GpuDeviceLossException t) {
            throw t;
         } catch (Throwable t) {
            broken = true;
            error = t.toString();
            NvidiumPlusLog.LOGGER
               .error(
                  "NvidiumPlus's mesh-shader draw of Sodium's terrain failed; Sodium's own renderer takes the opaque passes back for the rest of this session (first and only report). Nothing of Sodium's was consumed or freed, so the fallback is complete rather than partial.",
                  t
               );
            return false;
         }
      }
   }

   private static void record(
      GpuTextureView colorView,
      GpuTextureView depthView,
      GpuTextureView atlasView,
      GpuSampler atlasSampler,
      GpuTextureView lightmapView,
      Matrix4fc modelView,
      Matrix4fc projection,
      GpuBuffer[] geometryBuffers,
      int bufferCount,
      int drawCount,
      int[] drawMeta,
      float[] drawOrigins,
      boolean noDiscard
   ) {
      CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
      GpuBufferSlice sceneSlice = uploadScene(encoder, modelView, projection, atlasView.getWidth(0), atlasView.getHeight(0));
      GpuBufferSlice projectionSlice = uploadProjection(encoder, projection);
      long timerSerial = ++timerPasses;
      NvidiumPlusGpuTimers.beginOpaque(encoder, timerSerial);
      RenderPass pass = encoder.createRenderPass(() -> "NvidiumPlus sodium terrain opaque", colorView, Optional.empty(), depthView, OptionalDouble.empty());

      try {
         VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
         VulkanRenderPassAccessor vkPass = (VulkanRenderPassAccessor)backendPass;
         VkCommandBuffer cb = vkPass.nvidiumplus$commandBuffer();
         TerrainDrawPipeline p = pipelineFor(vkPass, colorView, depthView, noDiscard);
         VK10.vkCmdBindPipeline(cb, 0, p.pipeline());
         if (noDiscard) {
            noDiscardPasses++;
         } else {
            discardPasses++;
         }

         if (batchedEnabled() && runTable != null) {
            recordBatched(
               cb, p, sceneSlice, projectionSlice, atlasView, atlasSampler, lightmapView, geometryBuffers, bufferCount, drawCount, drawMeta, drawOrigins
            );
         } else {
            recordPerSection(
               cb, p, sceneSlice, projectionSlice, atlasView, atlasSampler, lightmapView, geometryBuffers, bufferCount, drawCount, drawMeta, drawOrigins
            );
         }
      } catch (Throwable var24) {
         if (pass != null) {
            try {
               pass.close();
            } catch (Throwable var23) {
               var24.addSuppressed(var23);
            }
         }

         throw var24;
      }

      if (pass != null) {
         pass.close();
      }

      NvidiumPlusGpuTimers.mark(encoder, 1);
      NvidiumPlusGpuTimers.endFrame(timerSerial);
   }

   private static void recordPerSection(
      VkCommandBuffer cb,
      TerrainDrawPipeline p,
      GpuBufferSlice sceneSlice,
      GpuBufferSlice projectionSlice,
      GpuTextureView atlasView,
      GpuSampler atlasSampler,
      GpuTextureView lightmapView,
      GpuBuffer[] geometryBuffers,
      int bufferCount,
      int drawCount,
      int[] drawMeta,
      float[] drawOrigins
   ) {
      long recordStart = System.nanoTime();
      MemoryStack stack = MemoryStack.stackPush();

      try {
         ByteBuffer push = stack.calloc(32);
         int wg = p.workgroupQuads();
         int boundBuffer = -1;
         int commands = 0;

         for (int d = 0; d < drawCount; d++) {
            int bufferIndex = drawMeta[d * 3];
            if (bufferIndex >= 0 && bufferIndex < bufferCount) {
               if (bufferIndex != boundBuffer) {
                  pushDescriptors(cb, p, geometryBuffers[bufferIndex], sceneSlice, projectionSlice, atlasView, atlasSampler, lightmapView);
                  boundBuffer = bufferIndex;
               }

               push.putFloat(0, drawOrigins[d * 3]);
               push.putFloat(4, drawOrigins[d * 3 + 1]);
               push.putFloat(8, drawOrigins[d * 3 + 2]);
               int firstVertex = drawMeta[d * 3 + 1];
               int quads = drawMeta[d * 3 + 2];
               int perChunk = K_SPLIT == 1 ? quads : (quads + K_SPLIT - 1) / K_SPLIT;

               for (int first = 0; first < quads; first += perChunk) {
                  int n = Math.min(perChunk, quads - first);
                  push.putInt(12, firstVertex + first * 4);
                  push.putInt(16, n);
                  VK10.vkCmdPushConstants(cb, p.pipelineLayout(), 128, 0, push);
                  EXTMeshShader.vkCmdDrawMeshTasksEXT(cb, (n + wg - 1) / wg, 1, 1);
                  commands++;
               }
            }
         }

         lastDrawCommands = commands;
      } catch (Throwable var27) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var26) {
               var27.addSuppressed(var26);
            }
         }

         throw var27;
      }

      if (stack != null) {
         stack.close();
      }

      lastTableNanos = 0L;
      lastRecordNanos = System.nanoTime() - recordStart;
   }

   private static void recordBatched(
      VkCommandBuffer cb,
      TerrainDrawPipeline p,
      GpuBufferSlice sceneSlice,
      GpuBufferSlice projectionSlice,
      GpuTextureView atlasView,
      GpuSampler atlasSampler,
      GpuTextureView lightmapView,
      GpuBuffer[] geometryBuffers,
      int bufferCount,
      int drawCount,
      int[] drawMeta,
      float[] drawOrigins
   ) {
      long tableStart = System.nanoTime();
      int wg = p.workgroupQuads();
      int capacity = NvidiumPlusSodiumRunTable.capacity();
      int[] start = new int[bufferCount + 1];

      for (int d = 0; d < drawCount; d++) {
         int b = drawMeta[d * 3];
         if (b >= 0 && b < bufferCount) {
            start[b + 1]++;
         }
      }

      for (int b = 0; b < bufferCount; b++) {
         start[b + 1] = start[b + 1] + start[b];
      }

      int totalRuns = start[bufferCount];
      if (totalRuns == 0) {
         lastDrawCommands = 0;
      } else {
         if (totalRuns > capacity && !runTableOverflowReported) {
            runTableOverflowReported = true;
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus's Sodium run table overflowed: {} runs against a capacity of {}. Some terrain will not be drawn this frame and in any frame this busy. Raise RUNS_PER_SLOT.",
                  totalRuns,
                  capacity
               );
         }

         boolean drawId = shape() == SodiumTerrainDrawer.Shape.DRAW_ID;
         ByteBuffer table = runTable.advance();
         ByteBuffer indirect = drawId ? runTable.indirectView() : null;
         ByteBuffer groupMap = drawId ? null : runTable.groupMapView();
         long groupMapAddress = groupMap == null ? 0L : MemoryUtil.memAddress(groupMap);
         int groupCapacity = NvidiumPlusSodiumRunTable.groupCapacity();
         int[] cursor = new int[bufferCount];
         int[] groups = new int[bufferCount];
         System.arraycopy(start, 0, cursor, 0, bufferCount);
         int[] groupStart = new int[bufferCount + 1];
         if (!drawId) {
            for (int d = 0; d < drawCount; d++) {
               int b = drawMeta[d * 3];
               if (b >= 0 && b < bufferCount) {
                  groupStart[b + 1] = groupStart[b + 1] + (drawMeta[d * 3 + 2] + wg - 1) / wg;
               }
            }

            for (int b = 0; b < bufferCount; b++) {
               groupStart[b + 1] = groupStart[b + 1] + groupStart[b];
            }

            if (groupStart[bufferCount] > groupCapacity && !groupMapOverflowReported) {
               groupMapOverflowReported = true;
               NvidiumPlusLog.LOGGER
                  .warn(
                     "NvidiumPlus's Sodium group map overflowed: {} workgroups against a capacity of {}. Dispatches are clipped to the mapped range, so some terrain will not be drawn in frames this busy. Raise GROUPS_PER_SLOT.",
                     groupStart[bufferCount],
                     groupCapacity
                  );
            }
         }

         int written = 0;

         for (int k = 0; k < drawCount; k++) {
            int d = REVERSE_ORDER ? drawCount - 1 - k : k;
            int b = drawMeta[d * 3];
            if (b >= 0 && b < bufferCount) {
               int slot = (int)(cursor[b]++);
               if (slot < capacity) {
                  int firstVertex = drawMeta[d * 3 + 1];
                  int quads = drawMeta[d * 3 + 2];
                  int runGroups = (quads + wg - 1) / wg;
                  if (!drawId) {
                     int local = slot - start[b];
                     int gBase = groupStart[b] + groups[b];
                     int end = Math.min(gBase + runGroups, groupCapacity);
                     int packedBase = local << 12;
                     long addr = groupMapAddress + gBase * 4L;
                     int gi = gBase;

                     for (int i = 0; gi < end; i++) {
                        MemoryUtil.memPutInt(addr, packedBase | i);
                        addr += 4L;
                        gi++;
                     }
                  }

                  groups[b] += runGroups;
                  int o = slot * 32;
                  table.putInt(o, firstVertex);
                  table.putInt(o + 4, quads);
                  table.putInt(o + 8, groups[b]);
                  table.putInt(o + 12, 0);
                  table.putFloat(o + 16, drawOrigins[d * 3]);
                  table.putFloat(o + 20, drawOrigins[d * 3 + 1]);
                  table.putFloat(o + 24, drawOrigins[d * 3 + 2]);
                  table.putFloat(o + 28, 0.0F);
                  if (drawId) {
                     int io = slot * 12;
                     indirect.putInt(io, (quads + wg - 1) / wg);
                     indirect.putInt(io + 4, 1);
                     indirect.putInt(io + 8, 1);
                  }

                  written++;
               }
            }
         }

         lastRunsWritten = written;
         lastTableNanos = System.nanoTime() - tableStart;
         long recordStart = System.nanoTime();
         MemoryStack stack = MemoryStack.stackPush();

         try {
            ByteBuffer push = stack.calloc(32);
            int commands = 0;

            for (int k = 0; k < bufferCount; k++) {
               int b = REVERSE_ORDER ? bufferCount - 1 - k : k;
               int first = start[b];
               int end = Math.min(cursor[b], capacity);
               if (end > first && groups[b] != 0) {
                  pushDescriptors(cb, p, geometryBuffers[b], sceneSlice, projectionSlice, atlasView, atlasSampler, lightmapView);
                  if (drawId) {
                     push.putInt(12, first);
                     push.putInt(16, end - first);
                     push.putInt(20, 0);
                     VK10.vkCmdPushConstants(cb, p.pipelineLayout(), 128, 0, push);
                     EXTMeshShader.vkCmdDrawMeshTasksIndirectEXT(cb, runTable.indirectBuffer(), runTable.indirectOffset() + first * 12L, end - first, 12);
                     commands++;
                  } else {
                     int mapped = Math.max(0, Math.min(groups[b], groupCapacity - groupStart[b]));

                     for (int base = 0; base < mapped; base += 65535) {
                        int n = Math.min(65535, mapped - base);
                        push.putInt(12, first);
                        push.putInt(16, end - first);
                        push.putInt(20, groupStart[b] + base);
                        VK10.vkCmdPushConstants(cb, p.pipelineLayout(), 128, 0, push);
                        EXTMeshShader.vkCmdDrawMeshTasksEXT(cb, n, 1, 1);
                        commands++;
                     }
                  }
               }
            }

            lastDrawCommands = commands;
         } catch (Throwable var45) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var44) {
                  var45.addSuppressed(var44);
               }
            }

            throw var45;
         }

         if (stack != null) {
            stack.close();
         }

         lastRecordNanos = System.nanoTime() - recordStart;
      }
   }

   private static TerrainDrawPipeline pipelineFor(VulkanRenderPassAccessor vkPass, GpuTextureView colorView, GpuTextureView depthView, boolean noDiscard) {
      TerrainDrawPipeline p = noDiscard ? pipelineNoDiscard : pipeline;
      if (p == null) {
         int vkColorFormat = VulkanConst.toVk(colorView.texture().getFormat());
         int vkDepthFormat = VulkanConst.toVk(depthView.texture().getFormat());
         int wg = TerrainDrawer.meshWorkgroupQuads();
         NvidiumPlusVulkanState.MeshShaderCaps caps = NvidiumPlusVulkanState.caps();
         if (caps == null) {
            throw new IllegalStateException(
               "no mesh-shader caps: the Vulkan device was created without VK_EXT_mesh_shader, so this path should never have armed"
            );
         }

         if (caps.maxMeshWorkGroupInvocations() < wg
            || caps.maxMeshOutputVertices() < wg * 4
            || caps.maxMeshOutputPrimitives() < wg * 2
            || caps.maxMeshOutputMemorySize() > 0 && caps.maxMeshOutputMemorySize() < wg * TerrainDrawer.MESH_OUTPUT_BYTES_PER_QUAD) {
            throw new IllegalStateException("device mesh caps below the Sodium draw shape (" + wg + " quads/workgroup): " + caps);
         }

         SodiumTerrainDrawer.Shape sh = shape();
         if (sh != SodiumTerrainDrawer.Shape.PER_SECTION && runTable == null) {
            runTable = NvidiumPlusSodiumRunTable.create();
            if (runTable == null) {
               sh = SodiumTerrainDrawer.Shape.PER_SECTION;
               shapeResolved = sh;
            }
         }

         p = TerrainDrawPipeline.createSodium(
            vkPass.nvidiumplus$device().vkDevice(),
            vkColorFormat,
            vkDepthFormat,
            wg,
            sh != SodiumTerrainDrawer.Shape.PER_SECTION,
            sh == SodiumTerrainDrawer.Shape.DRAW_ID,
            noDiscard
         );
         if (noDiscard) {
            pipelineNoDiscard = p;
         } else {
            pipeline = p;
         }

         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus's Sodium draw pipeline created (color format {}, depth format {}, {} quads/workgroup, shape={}, fragment={}). From here NvidiumPlus's mesh shaders draw the opaque terrain out of Sodium's own region buffers, in Sodium's vertex format, with no copy and no re-encode.",
               new Object[]{vkColorFormat, vkDepthFormat, wg, sh, noDiscard ? "no-discard" : "discard"}
            );
      }

      return p;
   }

   private static void pushDescriptors(
      VkCommandBuffer cb,
      TerrainDrawPipeline p,
      GpuBuffer geometry,
      GpuBufferSlice sceneSlice,
      GpuBufferSlice projectionSlice,
      GpuTextureView atlasView,
      GpuSampler atlasSampler,
      GpuTextureView lightmapView
   ) {
      GpuBufferSlice fog = RenderSystem.getShaderFog();
      GpuBuffer globals = RenderSystem.getGlobalSettingsUniform();
      GpuSampler lightmapSampler = RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR);
      MemoryStack stack = MemoryStack.stackPush();

      try {
         Buffer geometryInfo = bufferInfo(stack, ((VulkanGpuBuffer)geometry).vkBuffer(), 0L, -1L);
         Buffer sceneInfo = bufferInfo(stack, ((VulkanGpuBuffer)sceneSlice.buffer()).vkBuffer(), sceneSlice.offset(), sceneSlice.length());
         Buffer projectionInfo = bufferInfo(stack, ((VulkanGpuBuffer)projectionSlice.buffer()).vkBuffer(), projectionSlice.offset(), projectionSlice.length());
         Buffer fogInfo = bufferInfo(stack, ((VulkanGpuBuffer)fog.buffer()).vkBuffer(), fog.offset(), fog.length());
         Buffer globalsInfo = bufferInfo(stack, ((VulkanGpuBuffer)globals).vkBuffer(), 0L, -1L);
         org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer atlasInfo = imageInfo(stack, atlasView, atlasSampler);
         org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer lightmapInfo = imageInfo(stack, lightmapView, lightmapSampler);
         boolean batched = batchedEnabled() && runTable != null;
         org.lwjgl.vulkan.VkWriteDescriptorSet.Buffer writes = VkWriteDescriptorSet.calloc(batched ? 9 : 7, stack);
         bufferWrite((VkWriteDescriptorSet)writes.get(0), 0, 7, geometryInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(1), 1, 6, sceneInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(2), 2, 6, projectionInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(3), 3, 6, fogInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(4), 4, 6, globalsInfo);
         imageWrite((VkWriteDescriptorSet)writes.get(5), 5, atlasInfo);
         imageWrite((VkWriteDescriptorSet)writes.get(6), 6, lightmapInfo);
         if (batched) {
            bufferWrite((VkWriteDescriptorSet)writes.get(7), 9, 7, bufferInfo(stack, runTable.vkBuffer(), runTable.offset(), runTable.range()));
            bufferWrite(
               (VkWriteDescriptorSet)writes.get(8), 10, 7, bufferInfo(stack, runTable.groupMapBuffer(), runTable.groupMapOffset(), runTable.groupMapRange())
            );
         }

         KHRPushDescriptor.vkCmdPushDescriptorSetKHR(cb, 0, p.pipelineLayout(), 0, writes);
      } catch (Throwable var22) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var21) {
               var22.addSuppressed(var21);
            }
         }

         throw var22;
      }

      if (stack != null) {
         stack.close();
      }
   }

   private static GpuBufferSlice uploadScene(CommandEncoder encoder, Matrix4fc modelView, Matrix4fc projection, int atlasWidth, int atlasHeight) {
      MemoryStack stack = MemoryStack.stackPush();

      GpuBufferSlice var9;
      try {
         ByteBuffer scene = stack.calloc(208);
         modelView.get(scene);
         scene.putFloat(64, atlasWidth);
         scene.putFloat(68, atlasHeight);
         putFrustumPlanes(scene, modelView, projection);
         float subPixelDist = NvidiumPlusConfig.subPixelCullChunks() * 16.0F;
         scene.putFloat(192, 3.4E38F);
         scene.putFloat(196, subPixelDist <= 0.0F ? 3.4E38F : subPixelDist * subPixelDist);
         RenderTarget mainTarget = Minecraft.getInstance().gameRenderer.mainRenderTarget();
         scene.putFloat(200, mainTarget.width);
         scene.putFloat(204, mainTarget.height);
         var9 = encoder.transientMemory().uploadGpu(scene, 256L, 128);
      } catch (Throwable var11) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var10) {
               var11.addSuppressed(var10);
            }
         }

         throw var11;
      }

      if (stack != null) {
         stack.close();
      }

      return var9;
   }

   private static GpuBufferSlice uploadProjection(CommandEncoder encoder, Matrix4fc projection) {
      MemoryStack stack = MemoryStack.stackPush();

      GpuBufferSlice var4;
      try {
         ByteBuffer buf = stack.calloc(64);
         projection.get(buf);
         var4 = encoder.transientMemory().uploadGpu(buf, 256L, 128);
      } catch (Throwable var6) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }
         }

         throw var6;
      }

      if (stack != null) {
         stack.close();
      }

      return var4;
   }

   private static Buffer bufferInfo(MemoryStack stack, long vkBuffer, long offset, long range) {
      Buffer info = VkDescriptorBufferInfo.calloc(1, stack);
      ((VkDescriptorBufferInfo)info.get(0)).buffer(vkBuffer).offset(offset).range(range);
      return info;
   }

   private static org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer imageInfo(MemoryStack stack, GpuTextureView view, GpuSampler sampler) {
      org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer info = VkDescriptorImageInfo.calloc(1, stack);
      ((VkDescriptorImageInfo)info.get(0))
         .sampler(((VulkanGpuSampler)sampler).vkSampler())
         .imageView(((VulkanGpuTextureView)view).vkImageView())
         .imageLayout(1);
      return info;
   }

   private static void bufferWrite(VkWriteDescriptorSet write, int binding, int type, Buffer info) {
      write.sType$Default().dstBinding(binding).descriptorCount(info.remaining()).descriptorType(type).pBufferInfo(info);
   }

   private static void imageWrite(VkWriteDescriptorSet write, int binding, org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer info) {
      write.sType$Default().dstBinding(binding).descriptorCount(1).descriptorType(1).pImageInfo(info);
   }

   public static void destroyDeviceObjects(VkDevice device) {
      if (pipeline != null) {
         pipeline.destroy(device);
         pipeline = null;
      }

      if (pipelineNoDiscard != null) {
         pipelineNoDiscard.destroy(device);
         pipelineNoDiscard = null;
      }

      if (runTable != null) {
         runTable.destroyNow();
         runTable = null;
      }

      if (pipelineTask != null) {
         pipelineTask.destroy(device);
         pipelineTask = null;
      }

      if (pipelineTaskNoDiscard != null) {
         pipelineTaskNoDiscard.destroy(device);
         pipelineTaskNoDiscard = null;
      }

      if (!liveInstances.isEmpty()) {
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus: {} Sodium GPU-visibility instance(s) still live at device close (their chunk renderer was never deleted?); destroying directly",
               liveInstances.size()
            );

         for (SodiumTerrainDrawer.InstanceState s : new ArrayList<>(liveInstances)) {
            s.destroyNow();
         }

         liveInstances.clear();
      }

      activeState = null;
   }

   public static boolean commitInDrawBuffer() {
      String v = System.getProperty("nvidiumplus.sodium.commitInDrawBuffer");
      return v == null || Boolean.parseBoolean(v);
   }

   public static boolean fallbackOnStale() {
      String v = System.getProperty("nvidiumplus.sodium.fallbackOnStale");
      return v == null || Boolean.parseBoolean(v);
   }

   public static boolean mirrorHostCoherent() {
      String v = System.getProperty("nvidiumplus.sodium.mirrorHostCoherent");
      return v != null ? Boolean.parseBoolean(v) : NvidiumPlusVulkanState.integratedGpu();
   }

   public static boolean rowsFromList() {
      String v = System.getProperty("nvidiumplus.sodium.rowsFromList");
      return v == null || Boolean.parseBoolean(v);
   }

   public static long mirrorStaleTotal() {
      return mirrorStaleTotal;
   }

   private static void reportMirrorStale(long frame, int[] st) {
      int n = st[19];
      if (n != 0) {
         mirrorStaleTotal += n;
         if (mirrorStaleLogged < 6) {
            mirrorStaleLogged++;
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus: on stats frame {}, {} task workgroup(s) found the graphics card's own copy of a chunk group record out of date (the first: group id {}, the card's copy holds key {} and popcount {}, the current record has key {} and popcount {}). The record was taken from this frame's fresh copy instead; the section records are checked separately. Total so far {}.",
                  new Object[]{frame, n, st[20], st[21], st[23], st[22] >>> 16, st[22] & 65535, mirrorStaleTotal}
               );
         }
      }
   }

   public static boolean splitRowCopies() {
      String v = System.getProperty("nvidiumplus.sodium.splitRowCopies");
      return v == null || Boolean.parseBoolean(v);
   }

   public static boolean remirrorOnRefusalEnabled() {
      return NvidiumPlusConfig.sodiumRemirrorOnRefusalEnabled();
   }

   public static boolean takeRemirrorRequest() {
      if (!remirrorRequested) {
         return false;
      }

      remirrorRequested = false;
      remirrorsTotal++;
      return true;
   }

   public static long remirrorsTotal() {
      return remirrorsTotal;
   }

   public static int stagingLag() {
      int lag = Integer.getInteger("nvidiumplus.sodium.stagingLag", 3);
      return Math.max(3, Math.min(64, lag));
   }

   public static boolean commitBarrierExplicit() {
      return Boolean.parseBoolean(System.getProperty("nvidiumplus.sodium.commitBarrier"));
   }

   public static boolean oneDrawPerGroup() {
      return ONE_DRAW;
   }

   private static int diagTaskSkipFlags(String value) {
      return switch (value.trim().toLowerCase(Locale.ROOT)) {
         case "all" -> 8;
         case "stamps" -> 16;
         default -> 0;
      };
   }

   public static String diagTaskSkip() {
      return System.getProperty("nvidiumplus.sodium.diag.taskSkip", "none");
   }

   public static boolean mergePhaseA() {
      return MERGE_PHASE_A;
   }

   private static boolean occlusionConfigured(boolean gpuDraw) {
      String v = System.getProperty("nvidiumplus.sodium.occlusion");
      return v != null ? Boolean.parseBoolean(v) : gpuDraw && NvidiumPlusConfig.sodiumOcclusionConfigured();
   }

   public static void applyConfiguredGpuVisibility() {
      boolean gpu = NvidiumPlusConfig.sodiumGpuVisibilityEnabled();
      gpuDrawEnabled = gpu;
      occlusionEnabled = occlusionConfigured(gpu);
   }

   public static boolean gpuDrawEnabled() {
      return gpuDrawEnabled;
   }

   public static void setGpuDrawEnabled(boolean value) {
      gpuDrawEnabled = value;
   }

   public static boolean occlusionEnabled() {
      return occlusionEnabled;
   }

   public static void setOcclusionEnabled(boolean value) {
      occlusionEnabled = value;
   }

   public static boolean graphRegions() {
      return graphRegions;
   }

   private static String normaliseListMap(String raw) {
      if (raw == null) {
         return "on";
      }

      String value = raw.trim().toLowerCase(Locale.ROOT);
      return !"on".equals(value) && !"verify".equals(value) && !"ab".equals(value) && !"off".equals(value) ? "on" : value;
   }

   public static String listMapMode() {
      return listMapMode;
   }

   public static void resetListMapCounters() {
      listMapDrainNanos = 0L;
      listMapMapNanos = 0L;
      listMapDrainFrames = 0;
      listMapMapFrames = 0;
      listMapDrainRegions = 0L;
      listMapMapRegions = 0L;
      listMapCompares = 0L;
      listMapMismatches = 0L;
   }

   public static void setListMapModeForTest(String mode) {
      listMapMode = normaliseListMap(mode);
      listMapDrainNanos = 0L;
      listMapMapNanos = 0L;
      listMapDrainFrames = 0;
      listMapMapFrames = 0;
      listMapDrainRegions = 0L;
      listMapMapRegions = 0L;
      listMapCompares = 0L;
      listMapMismatches = 0L;
   }

   public static void reportListMapFrame(boolean usedMap, long nanos, int listedRegions) {
      if (usedMap) {
         listMapMapNanos += nanos;
         listMapMapFrames++;
         listMapMapRegions += listedRegions;
      } else {
         listMapDrainNanos += nanos;
         listMapDrainFrames++;
         listMapDrainRegions += listedRegions;
      }
   }

   public static void reportListMapCompare(int diff) {
      listMapCompares++;
      if (diff != 0) {
         listMapMismatches++;
      }
   }

   public static void disarmListMap(String reason) {
      if (listMapDisarmReason == null) {
         listMapDisarmReason = reason;
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus is back to draining Sodium's section iterator for the per-region geometry bitmap: {}. Rendering is unaffected; the loop is slightly slower at distance.",
               reason
            );
      }
   }

   public static boolean listMapDisarmed() {
      return listMapDisarmReason != null;
   }

   public static String listMapDisarmReason() {
      return listMapDisarmReason;
   }

   public static long listMapCompares() {
      return listMapCompares;
   }

   public static long listMapMismatches() {
      return listMapMismatches;
   }

   public static int listMapDrainFrames() {
      return listMapDrainFrames;
   }

   public static int listMapMapFrames() {
      return listMapMapFrames;
   }

   public static double listMapDrainMicros() {
      int frames = listMapDrainFrames;
      return frames == 0 ? 0.0 : listMapDrainNanos / (frames * 1000.0);
   }

   public static double listMapMapMicros() {
      int frames = listMapMapFrames;
      return frames == 0 ? 0.0 : listMapMapNanos / (frames * 1000.0);
   }

   public static double listMapDrainRegionsMean() {
      int frames = listMapDrainFrames;
      return frames == 0 ? 0.0 : (double)listMapDrainRegions / frames;
   }

   public static double listMapMapRegionsMean() {
      int frames = listMapMapFrames;
      return frames == 0 ? 0.0 : (double)listMapMapRegions / frames;
   }

   public static void setGraphRegionsForTest(boolean value) {
      graphRegions = value;
   }

   public static void forceDeclineNextFrame(String reason) {
      forcedDeclineReason = reason == null ? "forced" : reason;
   }

   public static String takeForcedDecline() {
      String r = forcedDeclineReason;
      forcedDeclineReason = null;
      return r;
   }

   public static void setMirrorCapacityForTest(int capacity) {
      initialCapacityOverride = capacity <= 0 ? -1 : Math.max(capacity, 16);
   }

   public static int initialCapacity() {
      int o = initialCapacityOverride;
      return o > 0 ? o : 1024;
   }

   public static boolean mirrorAuditEnabled() {
      return MIRROR_AUDIT;
   }

   public static String distanceGateMode() {
      String v = System.getProperty("nvidiumplus.sodium.distanceGate");
      if (v == null || v.isEmpty() || "fog".equalsIgnoreCase(v)) {
         return "fog";
      } else {
         return "off".equalsIgnoreCase(v) ? "off" : "render";
      }
   }

   public static boolean regionHoldEnabled() {
      return Boolean.parseBoolean(System.getProperty("nvidiumplus.sodium.regionHold"));
   }

   public static void recordRowWrite(int mid, int chunkX, int chunkY, int chunkZ, int key, int keysIssued) {
      int[] ledger = ledgerFor(mid);
      if (ledger != null) {
         int b = mid * 24;
         System.arraycopy(ledger, b, ledger, b + 4, 12);
         ledger[b] = chunkX;
         ledger[b + 1] = chunkY;
         ledger[b + 2] = chunkZ;
         ledger[b + 3] = key;
         ledger[b + 16]++;
         ledger[b + 18] = keysIssued;
      }
   }

   public static void recordRowRelease(int mid) {
      int[] ledger = ledgerFor(mid);
      if (ledger != null) {
         ledger[mid * 24 + 17]++;
      }
   }

   public static void resetRowLedger() {
      rowLedger = null;
   }

   private static int[] ledgerFor(int mid) {
      if (mid >= 0 && mid <= 1048576) {
         int[] ledger = rowLedger;
         int need = (mid + 1) * 24;
         if (ledger == null || ledger.length < need) {
            int[] grown = new int[Math.max(need, 24576)];
            if (ledger != null) {
               System.arraycopy(ledger, 0, grown, 0, ledger.length);
            }

            ledger = grown;
            rowLedger = grown;
         }

         return ledger;
      } else {
         return null;
      }
   }

   public static void reportRegionRejections(long frame, int total, int deadRow, int keyMismatch, int[] st) {
      regionRejectionsTotal += total;
      regionRejectionsFrames++;
      if (rowsFromList() && (regionRejectionsLogged < 16 || regionRejectionsLogged < 40 && regionRejectionsFrames % 16L == 0L)) {
         regionRejectionsLogged++;
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus: on stats frame {} the graphics card's copy of the section records of {} task workgroup(s) was out of date, so those chunk groups were left out rather than drawn wrong (the first: group id {}, probe base vertex {} committed, {} on the card, VisMode {}). Total so far {}.",
               new Object[]{frame, total, st[8], st[14], st[15], st.length > 7 ? st[7] : -1, regionRejectionsTotal}
            );
      }

      if (remirrorOnRefusalEnabled()) {
         remirrorRequested = true;
      }

      int verdict = st.length > 18 ? classifyRow(st[8], st) : 0;
      switch (verdict) {
         case 1:
            rowSamePlaceFrames++;
            break;
         case 2:
            rowOtherPlaceFrames++;
            break;
         default:
            rowUnknownFrames++;
      }

      boolean periodic = regionRejectionsLogged >= 16 && regionRejectionsLogged < 40 && regionRejectionsFrames % 16L == 0L;
      if (!rowsFromList() && (regionRejectionsLogged < 16 || periodic)) {
         regionRejectionsLogged++;
         int mid = st[8];
         int rowKey = st[9];
         int groupKey = st[10];
         int slot = st[11];
         int firstSlot = st[12];
         int regionCount = st[13];
         boolean pastEnd = regionCount > 0 && slot >= firstSlot + regionCount;
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus: the graphics card refused to draw {} whole chunk group(s) on stats frame {} - {} because the row said the group was gone and {} because its buffer key was not the one being drawn. The first one: group id {}, the row holds key {}, the draw wanted key {}, read at list entry {} of the run [{}, {}), popcount {} in the entry against {} in the row. {} Total so far {}.",
               new Object[]{
                  total,
                  frame,
                  deadRow,
                  keyMismatch,
                  mid,
                  rowKey,
                  groupKey,
                  slot,
                  firstSlot,
                  firstSlot + regionCount,
                  st[14],
                  st[15],
                  pastEnd
                     ? "THE ENTRY IS PAST THE END OF THE RUN, which the shipped search cannot do: read this as the run bounds themselves being wrong."
                     : "The entry is inside the run, which the shipped search guarantees by arithmetic and is therefore not evidence of anything.",
                  regionRejectionsTotal
               }
            );
         explainRow(mid, st);
      }
   }

   public static long[] rowVerdictCounts() {
      return new long[]{rowSamePlaceFrames, rowOtherPlaceFrames, rowUnknownFrames};
   }

   private static int classifyRow(int mid, int[] st) {
      return matchedGeneration(mid, st) >= 0
         ? 1
         : (rowLedger != null && mid >= 0 && mid * 24 + 24 <= rowLedger.length && rowLedger[mid * 24 + 16] != 0 && st.length > 18 ? 2 : 0);
   }

   private static int matchedGeneration(int mid, int[] st) {
      if (st.length > 18 && mid >= 0) {
         int[] ledger = rowLedger;
         int b = mid * 24;
         if (ledger != null && b + 24 <= ledger.length) {
            int known = Math.min(ledger[b + 16], 4);
            int cx = st[16];
            int cy = st[17];
            int cz = st[18];

            for (int g = 0; g < known; g++) {
               int o = b + g * 4;
               if (ledger[o] == cx && ledger[o + 1] == cy && ledger[o + 2] == cz) {
                  return g;
               }
            }

            return -1;
         } else {
            return -1;
         }
      } else {
         return -1;
      }
   }

   private static void explainRow(int mid, int[] st) {
      if (st.length > 18) {
         int rowX = st[16];
         int rowY = st[17];
         int rowZ = st[18];
         int[] ledger = rowLedger;
         int b = mid * 24;
         if (ledger != null && b >= 0 && b + 24 <= ledger.length && ledger[b + 16] != 0) {
            int gen = matchedGeneration(mid, st);
            NvidiumPlusLog.LOGGER
               .warn(
                  "    ...the row on the card describes chunk ({}, {}, {}); the processor last wrote that id as chunk ({}, {}, {}) with key {} (the write before it, key {}), after {} write(s) and {} release(s), with {} key(s) issued by then. The draw was VisMode {}. {}",
                  new Object[]{
                     rowX,
                     rowY,
                     rowZ,
                     ledger[b],
                     ledger[b + 1],
                     ledger[b + 2],
                     ledger[b + 3],
                     ledger[b + 7],
                     ledger[b + 16],
                     ledger[b + 17],
                     ledger[b + 18],
                     st.length > 7 ? st[7] : -1,
                     gen == 0
                        ? "SAME PLACE, the newest write: the card holds an older copy of the right row, so a row copy did not reach it."
                        : (
                           gen > 0
                              ? "SAME PLACE, " + gen + " write(s) back, which the readback lag makes ordinary: still an older copy of the right row."
                              : "A DIFFERENT PLACE in all four remembered writes: the card is not holding this region's row at all, so the fault is the id or the addressing, not the copy."
                        )
                  }
               );
         } else {
            NvidiumPlusLog.LOGGER
               .warn(
                  "    ...the row on the card describes chunk ({}, {}, {}), and the processor has no record of ever writing that id.",
                  new Object[]{rowX, rowY, rowZ}
               );
         }
      }
   }

   public static long regionRejectionsTotal() {
      return regionRejectionsTotal;
   }

   public static void reportSkippedGroup(int regions, int groups) {
      skippedGroupsTotal++;
      skippedGroupRegions += regions;
      if (skippedGroupsLogged < 8) {
         skippedGroupsLogged++;
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus: a draw group holding {} chunk group(s) had no geometry buffer at draw time and was left out of this frame, out of {} group(s). With one draw per buffer that is a large part of the screen gone at once. Total so far: {} skipped, {} chunk group(s).",
               new Object[]{regions, groups, skippedGroupsTotal, skippedGroupRegions}
            );
      }
   }

   public static long skippedGroupsTotal() {
      return skippedGroupsTotal;
   }

   public static long skippedGroupRegions() {
      return skippedGroupRegions;
   }

   public static long regionsHeldTotal() {
      return regionsHeldTotal;
   }

   public static void reportRegionsHeld(int held) {
      if (held > 0) {
         regionsHeldTotal += held;
         if (!regionsHeldLogged) {
            regionsHeldLogged = true;
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus: {} chunk group(s) left Sodium's draw list this frame and were kept for one more, so nothing blinks out while the list settles (-D{}=false turns this off). Counted from here on.",
                  held,
                  "nvidiumplus.sodium.regionHold"
               );
         }
      }
   }

   public static boolean stampHoldEnabled() {
      String v = System.getProperty("nvidiumplus.sodium.stampHold");
      return v == null || Boolean.parseBoolean(v);
   }

   public static boolean phaseBCpuSkipEnabled() {
      String v = System.getProperty("nvidiumplus.sodium.phaseBCpuSkip");
      return v == null || Boolean.parseBoolean(v);
   }

   public static boolean gpuDrawBroken() {
      return gpuDrawBroken;
   }

   public static String gpuDrawError() {
      return gpuDrawError;
   }

   public static boolean occlusionBroken() {
      return occlusionBroken;
   }

   public static String occlusionError() {
      return occlusionError;
   }

   public static void latchGpuDraw(Throwable t) {
      latchGpuDraw(t.toString(), t);
   }

   public static void latchGpuDraw(String reason) {
      latchGpuDraw(reason, null);
   }

   private static void latchGpuDraw(String reason, Throwable t) {
      if (!gpuDrawBroken) {
         gpuDrawBroken = true;
         gpuDrawError = reason;
         rung = "1";
         NvidiumPlusLog.LOGGER
            .error(
               "NvidiumPlus's GPU-visibility draw of Sodium's terrain is standing down for the rest of this session ({}); the stage-1 list path draws every opaque pass from the next frame (first and only report). Nothing of Sodium's was consumed or freed.",
               reason,
               t
            );
      }
   }

   public static void latchOcclusion(Throwable t) {
      if (!occlusionBroken) {
         occlusionBroken = true;
         occlusionError = t.toString();
         NvidiumPlusLog.LOGGER
            .error(
               "NvidiumPlus's box-raster occlusion on the Sodium host is standing down for the rest of this session; the GPU draw continues in BFS-parity mode (VisMode 0) from the next frame (first and only report).",
               t
            );
      }
   }

   public static String rung() {
      return rung;
   }

   public static void reportRung(String value) {
      rung = value;
   }

   public static long framesOwned() {
      return framesOwned;
   }

   public static long framesAttempted() {
      return framesAttempted;
   }

   public static long occlusionFrames() {
      return occlusionFrames;
   }

   public static void reportAttempt() {
      framesAttempted++;
   }

   public static void reportDecline(String reason) {
      boolean first;
      synchronized (frameDeclines) {
         Long n = frameDeclines.get(reason);
         first = n == null;
         frameDeclines.put(reason, first ? 1L : n + 1L);
      }

      frameDeclinesTotal++;
      rung = "1";
      if ("ringGuard".equals(reason)) {
         SodiumFrameRing.countGuardTrip();
      }

      if (first) {
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus: a Sodium frame declined the GPU-visibility rung ({}); the list path drew it whole. Reported once per reason; the bench carries the counts.",
               reason
            );
      }
   }

   public static Map<String, Long> frameDeclines() {
      synchronized (frameDeclines) {
         return new LinkedHashMap<>(frameDeclines);
      }
   }

   public static long frameDeclinesTotal() {
      return frameDeclinesTotal;
   }

   public static long frameDeclines(String reason) {
      synchronized (frameDeclines) {
         Long n = frameDeclines.get(reason);
         return n == null ? 0L : n;
      }
   }

   public static void reportCommit(int regions, long bytes, long nanos, long deadRowsTotal, int live, int capacity, long released, int keys) {
      commitRegionsPerFrame = regions;
      commitRegionsTotal += regions;
      commitBytesPerFrame = bytes;
      commitNanos = nanos;
      deadRows = deadRowsTotal;
      midsLive = live;
      midsCapacity = capacity;
      midsReleased = released;
      bufferKeys = keys;
   }

   public static void reportFrameLoop(int listed, int sections, int groups, long nanos, boolean faceAll, float searchDistance, String searchSource) {
      listedRegions = listed;
      listedSections = sections;
      bufferGroups = groups;
      loopNanos = nanos;
      lastFaceAll = faceAll;
      searchDistanceBlocks = searchDistance;
      searchDistanceSource = searchSource;
   }

   public static void reportDroppedRegions(int dropped, int gaps, int listedNow) {
      droppedRegionsPerFrame = dropped;
      oneFrameGapRegions = gaps;
      if (gaps > 0) {
         oneFrameGapsTotal += gaps;
         if (oneFrameGapsLogged < 8) {
            oneFrameGapsLogged++;
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus: {} region(s) are in this frame's draw list of {} and were in the list two frames ago, but were missing from the frame between, whose list was not smaller. That list is Sodium's own, and the list path and Sodium's translucent pass draw the same one, so no path drew them on that frame. Total so far {}.",
                  new Object[]{gaps, listedNow, oneFrameGapsTotal}
               );
         }
      }

      if (dropped > 0) {
         droppedRegionsTotal += dropped;
         if (!droppedRegionsLogged) {
            droppedRegionsLogged = true;
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus: {} region(s) NvidiumPlus holds records for had no geometry buffer when this frame's draw list was built, so nothing of them was drawn this frame. Expected to be rare and to recover on the next frame; counted from here on and reported with any visibility dip.",
                  dropped
               );
         }
      }
   }

   public static void reportUnreachable(int sections, int regions, int listedSections) {
      unreachablePerFrame = sections;
      if (sections > 0) {
         unreachableSectionsTotal += sections;
         unreachableRegionsTotal += regions;
         if (unreachableLogged < 8) {
            unreachableLogged++;
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus: {} section(s) in {} chunk group(s) have geometry this frame that the copy on the graphics card cannot reach, out of {} the frame offered. Nothing draws them this frame; the plain list path would have. The group(s) are marked for repair on the next frame. Totals so far: {} section(s), {} group(s).",
                  new Object[]{sections, regions, listedSections, unreachableSectionsTotal, unreachableRegionsTotal}
               );
         }
      }
   }

   public static long unreachableSectionsTotal() {
      return unreachableSectionsTotal;
   }

   public static long unreachableRegionsTotal() {
      return unreachableRegionsTotal;
   }

   public static int unreachablePerFrame() {
      return unreachablePerFrame;
   }

   public static int droppedRegionsPerFrame() {
      return droppedRegionsPerFrame;
   }

   public static long droppedRegionsTotal() {
      return droppedRegionsTotal;
   }

   public static long oneFrameGapsTotal() {
      return oneFrameGapsTotal;
   }

   public static int oneFrameGapRegions() {
      return oneFrameGapRegions;
   }

   public static void reportInvariant(long midMissingTotal, long keyMismatchTotal) {
      midMissing = midMissingTotal;
      keyMismatch = keyMismatchTotal;
   }

   public static void reportGrowth() {
      growths++;
   }

   public static void reportAudit(long frames, long mismatches, long gpuMismatches) {
      mirrorAuditFrames = frames;
      mirrorAuditMismatches = mismatches;
      mirrorGpuReadbackMismatches = gpuMismatches;
   }

   public static void reportAuditMismatch(int mid, int pass, long bytes, int chunkX, int chunkY, int chunkZ) {
      auditMismatchRegions++;
      if (auditMismatchesLogged < 8) {
         auditMismatchesLogged++;
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus mirror audit: region {} at chunk {},{},{} (id {}, {} pass) is not marked dirty, yet {} byte(s) of its records on Sodium's heap differ from what NvidiumPlus last copied to the graphics card. A change reached Sodium without reaching any of NvidiumPlus's five hooks, so the card is drawing that region from records that are out of date. Regions seen so far: {}.",
               new Object[]{mid, chunkX, chunkY, chunkZ, mid, pass == 0 ? "solid" : "cutout", bytes, auditMismatchRegions}
            );
      }
   }

   public static long auditMismatchRegions() {
      return auditMismatchRegions;
   }

   public static void reportSectionsEmitted(int passIndex, int sections, long quads) {
      sectionsEmitted = sections;
      if (passIndex >= 0 && passIndex < 2) {
         sectionsEmittedByPass[passIndex] = sections;
         quadsKeptByPass[passIndex] = quads;
      }
   }

   public static int commitRegionsPerFrame() {
      return commitRegionsPerFrame;
   }

   public static long commitRegionsTotal() {
      return commitRegionsTotal;
   }

   public static long commitBytesPerFrame() {
      return commitBytesPerFrame;
   }

   public static long commitNanos() {
      return commitNanos;
   }

   public static long deadRows() {
      return deadRows;
   }

   public static int midsLive() {
      return midsLive;
   }

   public static int midsCapacity() {
      return midsCapacity;
   }

   public static long midsReleased() {
      return midsReleased;
   }

   public static long growths() {
      return growths;
   }

   public static int bufferKeys() {
      return bufferKeys;
   }

   public static int listedRegions() {
      return listedRegions;
   }

   public static int bufferGroups() {
      return bufferGroups;
   }

   public static int drawCommandsPerFrame() {
      return drawCommandsPerFrame;
   }

   public static long loopNanos() {
      return loopNanos;
   }

   public static int gpuSectionsMask() {
      return gpuSectionsMask;
   }

   public static int gpuSectionsA() {
      return gpuSectionsA;
   }

   public static int gpuSectionsB() {
      return gpuSectionsB;
   }

   public static long gpuQuads() {
      return gpuQuads;
   }

   public static long statsFramesRead() {
      return statsFramesRead;
   }

   public static long statsFrames() {
      SodiumTerrainDrawer.InstanceState s = activeState;
      return s == null ? 0L : s.statsFrames;
   }

   public static int sectionsEmitted() {
      return sectionsEmitted;
   }

   public static int sectionsEmittedFrame() {
      return sectionsEmittedByPass[0] + sectionsEmittedByPass[1];
   }

   public static long quadsKeptFrame() {
      return quadsKeptByPass[0] + quadsKeptByPass[1];
   }

   public static long midMissing() {
      return midMissing;
   }

   public static long keyMismatch() {
      return keyMismatch;
   }

   public static boolean mirrorAuditArmed() {
      return MIRROR_AUDIT;
   }

   public static long mirrorAuditMismatches() {
      return mirrorAuditMismatches;
   }

   public static long mirrorGpuReadbackMismatches() {
      return mirrorGpuReadbackMismatches;
   }

   public static long mirrorAuditFrames() {
      return mirrorAuditFrames;
   }

   public static String searchDistanceSource() {
      return searchDistanceSource;
   }

   public static float searchDistanceBlocks() {
      return searchDistanceBlocks;
   }

   public static boolean faceAll() {
      return lastFaceAll;
   }

   public static boolean phaseBCpuSkipArmed() {
      return phaseBCpuSkipArmed;
   }

   public static long phaseBCpuSkips() {
      return phaseBCpuSkips;
   }

   public static long visibilityDips() {
      return visibilityDips;
   }

   public static long lastVisibilityDipFrame() {
      return lastVisibilityDipFrame;
   }

   public static int instancesLive() {
      return liveInstances.size();
   }

   public static long instancesRetired() {
      return instancesRetired;
   }

   public static long occlusionRecreates() {
      return occlusionRecreates;
   }

   public static String gpuTimerUnit() {
      return gpuTimerUnit;
   }

   public static long ringGuardTrips() {
      return SodiumFrameRing.guardTrips();
   }

   public static int gpuPhaseBAt(long f) {
      SodiumTerrainDrawer.InstanceState s = activeState;
      if (s != null && f >= 0L) {
         int i = (int)(f % 64L);
         return s.phaseBFrames[i] == f ? s.phaseBCounts[i] : -1;
      } else {
         return -1;
      }
   }

   public static long lastReadStatsFrame() {
      SodiumTerrainDrawer.InstanceState s = activeState;
      return s == null ? -1L : s.lastReadStatsFrame;
   }

   public static VisibleSetSample debugVisibleSet() {
      SodiumTerrainDrawer.InstanceState s = activeState;
      return s != null && s.occlusion != null ? s.occlusion.debugVisibleSet() : null;
   }

   public static int gpuSectionsAAt(long f) {
      SodiumTerrainDrawer.InstanceState s = activeState;
      if (s != null && f >= 0L) {
         int i = (int)(f % 64L);
         return s.phaseBFrames[i] == f ? s.phaseACounts[i] : -1;
      } else {
         return -1;
      }
   }

   public static SodiumTerrainDrawer.InstanceState newInstanceState() {
      SodiumTerrainDrawer.InstanceState s = new SodiumTerrainDrawer.InstanceState();
      liveInstances.add(s);
      return s;
   }

   public static void retire(SodiumTerrainDrawer.InstanceState s) {
      if (s != null) {
         liveInstances.remove(s);
         if (activeState == s) {
            activeState = null;
         }

         s.clearFrame();
         if (s.occlusion != null) {
            s.occlusion.destroy();
            s.occlusion = null;
         }

         if (s.ring != null) {
            s.ring.destroy();
            s.ring = null;
         }

         if (s.mirror != null) {
            s.mirror.destroy();
            s.mirror = null;
         }

         instancesRetired++;
      }
   }

   public static boolean ensureResources(SodiumTerrainDrawer.InstanceState s) {
      if (s.mirror == null) {
         s.mirror = SodiumMirrorGpu.create(initialCapacity());
         if (s.mirror == null) {
            return false;
         }
      }

      if (s.ring == null) {
         s.ring = SodiumFrameRing.create(s.mirror.capacity());
         if (s.ring == null) {
            return false;
         }
      }

      return true;
   }

   public static boolean prepareOcclusion(SodiumTerrainDrawer.InstanceState s) {
      if (s.occlusion != null) {
         return true;
      }

      if (s.mirror == null) {
         return false;
      }

      try {
         s.occlusion = TerrainOcclusion.create(s.mirror.capacity(), s.mirror.capacity(), true);
         if (s.occlusion != null) {
            occlusionRecreates++;
         }

         return s.occlusion != null;
      } catch (GpuDeviceLossException t) {
         throw t;
      } catch (Throwable t) {
         latchOcclusion(t);
         return false;
      }
   }

   public static boolean growInstance(SodiumTerrainDrawer.InstanceState s, int newCapacity) {
      SodiumMirrorGpu grown = s.mirror.grow(newCapacity);
      if (grown == null) {
         latchGpuDraw("mirror over budget at " + newCapacity + " ids");
         return false;
      }

      s.mirror = grown;
      if (s.ring != null) {
         s.ring.destroy();
      }

      s.ring = SodiumFrameRing.create(newCapacity);
      if (s.occlusion != null) {
         s.occlusion.destroy();
         s.occlusion = TerrainOcclusion.create(newCapacity, newCapacity, true);
         occlusionRecreates++;
      }

      growths++;
      return true;
   }

   public static boolean drawSolidOwned(
      SodiumTerrainDrawer.InstanceState s,
      GpuTextureView colorView,
      GpuTextureView depthView,
      GpuTextureView atlasView,
      GpuSampler atlasSampler,
      GpuTextureView lightmapView,
      Matrix4fc modelView,
      Matrix4fc projection,
      double camX,
      double camY,
      double camZ,
      float[] sceneTail,
      int[] cameraBlock,
      GpuBuffer[] groupBuffers,
      int[] groupKeys,
      int[] groupStart,
      int groupCount,
      int listedRegions,
      long frameSignature,
      boolean faceAll,
      boolean distanceGate,
      boolean occlusionThisFrame,
      boolean noDiscard
   ) {
      if (colorView != null
         && depthView != null
         && atlasView != null
         && lightmapView != null
         && atlasSampler != null
         && modelView != null
         && projection != null
         && s.mirror != null
         && s.ring != null) {
         boolean occ = occlusionThisFrame && s.occlusion != null && !occlusionBroken;
         s.frameHalfMode = 0;
         if (occ) {
            try {
               s.occlusion.ensureSodiumPipelines(VulkanConst.toVk(colorView.texture().getFormat()), VulkanConst.toVk(depthView.texture().getFormat()));
               long preBobSerial = NvidiumPlusProjectionCapture.preBobSerial();
               s.frameHalfMode = s.occlusion
                  .armHalfRes(
                     colorView,
                     depthView,
                     projection,
                     NvidiumPlusProjectionCapture.preBob(),
                     modelView,
                     preBobSerial,
                     VulkanConst.toVk(colorView.texture().getFormat()),
                     VulkanConst.toVk(depthView.texture().getFormat()),
                     true,
                     true
                  );
            } catch (GpuDeviceLossException t) {
               throw t;
            } catch (Throwable t) {
               latchOcclusion(t);
               occ = false;
               s.frameHalfMode = 0;
            }
         }

         CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
         pullStats(s);
         long stamp = ++stampSerial;
         int frameStamp32 = (int)stamp;
         if (frameStamp32 == 0 || frameStamp32 == 1) {
            stampSerial += 2L;
            frameStamp32 = (int)stampSerial;
         }

         long ownedFrame = s.ownedFrames + 1L;
         GpuBufferSlice sceneSlice = uploadSceneTask(encoder, modelView, projection, atlasView.getWidth(0), atlasView.getHeight(0), sceneTail, cameraBlock);
         GpuBufferSlice projectionSlice = uploadProjection(encoder, projection);
         int flags = 1
            | (faceAll ? 2 : 0)
            | (occ && distanceGate ? 4 : 0)
            | (ONE_DRAW ? 32 : 0)
            | (occ && stampHoldEnabled() ? 64 : 0)
            | (rowsFromList() ? 128 : 0)
            | DIAG_TASK_SKIP_FLAGS;
         int visMode = occ ? 1 : 0;
         long prevStamps = occ ? s.occlusion.prevStampsBuffer(stamp) : s.mirror.vkBuffer();
         long curStamps = occ ? s.occlusion.curStampsBuffer(stamp) : s.mirror.vkBuffer();
         boolean skipPhaseB = occ
            && phaseBSkipDecide(
               s,
               camX,
               camY,
               camZ,
               modelView,
               projection,
               depthView.texture().getWidth(0),
               depthView.texture().getHeight(0),
               s.mirror.commitSerial(),
               frameSignature,
               ownedFrame
            );
         s.sceneSlice = sceneSlice;
         s.projectionSlice = projectionSlice;
         s.listSlice = new TerrainOcclusion.ListSlice(s.ring.listBuffer(), s.ring.listOffset(), s.ring.listRange(), true);
         s.prevStamps = prevStamps;
         s.curStamps = curStamps;
         s.groupBuffers = groupBuffers;
         s.groupKeys = groupKeys;
         s.groupStart = groupStart;
         s.groupCount = groupCount;
         s.listedRegions = listedRegions;
         s.frameStamp32 = frameStamp32;
         s.frameFlags = flags;
         s.frameHasOcclusion = occ;
         s.frameSkipPhaseB = skipPhaseB;
         s.drawCommands = 0;
         int dipSlot = (int)(s.statsFrames % 64L);
         s.dipFrames[dipSlot] = s.statsFrames;
         s.dipListed[dipSlot] = listedSections;
         s.dipRegions[dipSlot] = listedRegions;
         s.dipDropped[dipSlot] = droppedRegionsPerFrame;
         s.dipSkipB[dipSlot] = skipPhaseB;
         s.dipOcc[dipSlot] = occ;
         s.timerSerial = ++timerPasses;
         NvidiumPlusGpuTimers.beginOpaque(encoder, s.timerSerial);
         RenderPass pass = encoder.createRenderPass(() -> "NvidiumPlus sodium terrain 1a", colorView, Optional.empty(), depthView, OptionalDouble.empty());

         try {
            VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
            VulkanRenderPassAccessor vkPass = (VulkanRenderPassAccessor)backendPass;
            VkCommandBuffer cb = vkPass.nvidiumplus$commandBuffer();
            TerrainDrawPipeline p = pipelineTaskFor(vkPass, colorView, depthView, noDiscard);
            VK10.vkCmdBindPipeline(cb, 0, p.pipeline());
            if (noDiscard) {
               noDiscardPasses++;
            } else {
               discardPasses++;
            }

            s.drawCommands = s.drawCommands
               + recordGroups(cb, p, s, visMode, SodiumGpuVisibilityLayout.recordBaseUvec4(s.mirror.capacity(), 0), atlasView, atlasSampler, lightmapView);
            if (MERGE_PHASE_A) {
               TerrainDrawPipeline cutoutPipeline = pipelineTaskFor(vkPass, colorView, depthView, false);
               VK10.vkCmdBindPipeline(cb, 0, cutoutPipeline.pipeline());
               discardPasses++;
               s.drawCommands = s.drawCommands
                  + recordGroups(
                     cb, cutoutPipeline, s, visMode, SodiumGpuVisibilityLayout.recordBaseUvec4(s.mirror.capacity(), 1), atlasView, atlasSampler, lightmapView
                  );
               s.frameCutoutPhaseARecorded = true;
            }
         } catch (Throwable var53) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var50) {
                  var53.addSuppressed(var50);
               }
            }

            throw var53;
         }

         if (pass != null) {
            pass.close();
         }

         NvidiumPlusGpuTimers.mark(encoder, 7);
         s.frameOwned = true;
         s.ownedFrames = ownedFrame;
         framesOwned++;
         framesDrawn++;
         lastSectionsDrawn = listedSections;
         lastRegionsDrawn = listedRegions;
         totalSectionsDrawn = totalSectionsDrawn + listedSections;
         if (occ) {
            occlusionFrames++;
         }

         rung = occ ? "0a" : "0b";
         gpuTimerUnit = "frame";
         lastBuildNanos = 0L;
         activeState = s;
         if (!gpuDrawLogged) {
            gpuDrawLogged = true;
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus is drawing Sodium's opaque terrain from the GPU record mirror: the task stage selects runs per section ({}), one indirect draw per geometry buffer per phase per pass, CPU work O(regions). Region source: {}. Two-frame stamp hold: {}. Staging retirement lag: {} submit(s). Commit barrier: {}. Row copies: {}. Rows read from: {}. Mirror memory: {}. Commit recorded: {}. Fall back if records go stale: {}.",
                  new Object[]{
                     occ ? "box-raster occlusion with temporal history" : "BFS-parity mode",
                     graphRegions() ? "Sodium's own chunk list" : "loaded regions, frustum-tested",
                     stampHoldEnabled() ? "ON" : "OFF",
                     stagingLag(),
                     !commitInDrawBuffer() && !commitBarrierExplicit() ? "vanilla's only" : "explicit",
                     splitRowCopies() ? "their own command" : "batched with the pass blocks",
                     rowsFromList() ? "the per-frame list (fresh)" : "the mirror",
                     mirrorHostCoherent() ? "host-coherent" : "device-local",
                     commitInDrawBuffer() ? "in the draws' command buffer" : "in its own command buffer",
                     fallbackOnStale() ? "ON" : "OFF"
                  }
               );
         }

         return true;
      } else {
         return false;
      }
   }

   public static boolean drawCutoutOwned(
      SodiumTerrainDrawer.InstanceState s,
      GpuTextureView colorView,
      GpuTextureView depthView,
      GpuTextureView atlasView,
      GpuSampler atlasSampler,
      GpuTextureView lightmapView,
      boolean noDiscardSolid
   ) {
      if (s.frameOwned && s.mirror != null && s.ring != null) {
         try {
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            boolean occ = s.frameHasOcclusion;
            int visMode = occ ? 1 : 0;
            int recordBaseSolid = SodiumGpuVisibilityLayout.recordBaseUvec4(s.mirror.capacity(), 0);
            int recordBaseCutout = SodiumGpuVisibilityLayout.recordBaseUvec4(s.mirror.capacity(), 1);

            try {
               if (!s.frameCutoutPhaseARecorded) {
                  RenderPass pass = encoder.createRenderPass(
                     () -> "NvidiumPlus sodium terrain 1b", colorView, Optional.empty(), depthView, OptionalDouble.empty()
                  );

                  try {
                     VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
                     VulkanRenderPassAccessor vkPass = (VulkanRenderPassAccessor)backendPass;
                     VkCommandBuffer cb = vkPass.nvidiumplus$commandBuffer();
                     TerrainDrawPipeline p = pipelineTaskFor(vkPass, colorView, depthView, false);
                     VK10.vkCmdBindPipeline(cb, 0, p.pipeline());
                     discardPasses++;
                     s.drawCommands = s.drawCommands + recordGroups(cb, p, s, visMode, recordBaseCutout, atlasView, atlasSampler, lightmapView);
                  } catch (Throwable var47) {
                     if (pass != null) {
                        try {
                           pass.close();
                        } catch (Throwable var41) {
                           var47.addSuppressed(var41);
                        }
                     }

                     throw var47;
                  }

                  if (pass != null) {
                     pass.close();
                  }
               }
            } catch (GpuDeviceLossException t) {
               throw t;
            } catch (Throwable t) {
               latchGpuDraw(t);
               NvidiumPlusGpuTimers.endFrame(s.timerSerial);
               return false;
            }

            NvidiumPlusGpuTimers.mark(encoder, 1);
            framesDrawn++;
            lastSectionsDrawn = listedSections;
            lastRegionsDrawn = listedRegions;
            totalSectionsDrawn = totalSectionsDrawn + listedSections;
            if (occ) {
               try {
                  int hm = s.frameHalfMode;
                  GpuTextureView rc = colorView;
                  GpuTextureView rd = depthView;
                  if (hm != 0) {
                     rc = s.occlusion.halfColorView();
                     rd = s.occlusion.halfDepthView();
                     GpuTextureView passColor = rc;
                     GpuTextureView passDepth = rd;
                     RenderPass pass = encoder.createRenderPass(
                        () -> "NvidiumPlus occlusion depth downsample", passColor, Optional.empty(), passDepth, OptionalDouble.of(0.0)
                     );

                     try {
                        VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
                        VkCommandBuffer cb = ((VulkanRenderPassAccessor)backendPass).nvidiumplus$commandBuffer();
                        s.occlusion.recordDepthDownsample(cb, depthView);
                     } catch (Throwable var54) {
                        if (pass != null) {
                           try {
                              pass.close();
                           } catch (Throwable var46) {
                              var54.addSuppressed(var46);
                           }
                        }

                        throw var54;
                     }

                     if (pass != null) {
                        pass.close();
                     }

                     NvidiumPlusGpuTimers.mark(encoder, 8);
                  }

                  GpuTextureView rasterColor = rc;
                  GpuTextureView rasterDepth = rd;
                  RenderPass pass = encoder.createRenderPass(
                     () -> "NvidiumPlus sodium occlusion regions", rasterColor, Optional.empty(), rasterDepth, OptionalDouble.empty()
                  );

                  try {
                     VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
                     VkCommandBuffer cb = ((VulkanRenderPassAccessor)backendPass).nvidiumplus$commandBuffer();
                     s.occlusion.recordRegionRasterSodium(cb, s.listSlice, s.sceneSlice, s.projectionSlice, s.listedRegions, s.frameStamp32, hm);
                  } catch (Throwable var53) {
                     if (pass != null) {
                        try {
                           pass.close();
                        } catch (Throwable var45) {
                           var53.addSuppressed(var45);
                        }
                     }

                     throw var53;
                  }

                  if (pass != null) {
                     pass.close();
                  }

                  NvidiumPlusGpuTimers.mark(encoder, 2);
                  pass = encoder.createRenderPass(
                     () -> "NvidiumPlus sodium occlusion sections", rasterColor, Optional.empty(), rasterDepth, OptionalDouble.empty()
                  );

                  try {
                     VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
                     VkCommandBuffer cb = ((VulkanRenderPassAccessor)backendPass).nvidiumplus$commandBuffer();
                     s.occlusion
                        .recordSectionRasterSodium(
                           cb,
                           s.listSlice,
                           s.sceneSlice,
                           s.projectionSlice,
                           s.mirror.vkBuffer(),
                           s.mirror.rowsOffset(),
                           s.mirror.rowsRange(),
                           s.listedRegions,
                           s.frameStamp32,
                           s.curStamps,
                           hm
                        );
                  } catch (Throwable var52) {
                     if (pass != null) {
                        try {
                           pass.close();
                        } catch (Throwable var44) {
                           var52.addSuppressed(var44);
                        }
                     }

                     throw var52;
                  }

                  if (pass != null) {
                     pass.close();
                  }

                  NvidiumPlusGpuTimers.mark(encoder, 3);

                  for (int i = 0; i < DIAG_EMPTY_PASSES; i++) {
                     RenderPass passx = encoder.createRenderPass(
                        () -> "NvidiumPlus diag empty pass", colorView, Optional.empty(), depthView, OptionalDouble.empty()
                     );

                     try {
                        ((RenderPassAccessor)passx).nvidiumplus$backend();
                     } catch (Throwable var51) {
                        if (passx != null) {
                           try {
                              passx.close();
                           } catch (Throwable var43) {
                              var51.addSuppressed(var43);
                           }
                        }

                        throw var51;
                     }

                     if (passx != null) {
                        passx.close();
                     }
                  }

                  if (!s.frameSkipPhaseB) {
                     pass = encoder.createRenderPass(() -> "NvidiumPlus sodium terrain phase B", colorView, Optional.empty(), depthView, OptionalDouble.empty());

                     try {
                        VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
                        VulkanRenderPassAccessor vkPass = (VulkanRenderPassAccessor)backendPass;
                        VkCommandBuffer cb = vkPass.nvidiumplus$commandBuffer();
                        TerrainDrawPipeline solid = pipelineTaskFor(vkPass, colorView, depthView, noDiscardSolid);
                        VK10.vkCmdBindPipeline(cb, 0, solid.pipeline());
                        s.drawCommands = s.drawCommands + recordGroups(cb, solid, s, 2, recordBaseSolid, atlasView, atlasSampler, lightmapView);
                        TerrainDrawPipeline cutout = pipelineTaskFor(vkPass, colorView, depthView, false);
                        VK10.vkCmdBindPipeline(cb, 0, cutout.pipeline());
                        s.drawCommands = s.drawCommands + recordGroups(cb, cutout, s, 2, recordBaseCutout, atlasView, atlasSampler, lightmapView);
                     } catch (Throwable var50) {
                        if (pass != null) {
                           try {
                              pass.close();
                           } catch (Throwable var42) {
                              var50.addSuppressed(var42);
                           }
                        }

                        throw var50;
                     }

                     if (pass != null) {
                        pass.close();
                     }
                  } else {
                     phaseBCpuSkips++;
                  }

                  NvidiumPlusGpuTimers.mark(encoder, 4);
               } catch (GpuDeviceLossException t) {
                  throw t;
               } catch (Throwable t) {
                  latchOcclusion(t);
               }
            }

            s.mirror.recordStatsTransfer(s.statsFrames);
            if (occ) {
               s.occlusion.recordStampsTransfer(s.statsFrames, s.curStamps, s.frameStamp32);
            }

            s.statsFrames++;
            NvidiumPlusGpuTimers.endFrame(s.timerSerial);
            drawCommandsPerFrame = s.drawCommands;
            return true;
         } finally {
            s.clearFrame();
         }
      } else {
         return false;
      }
   }

   private static int recordGroups(
      VkCommandBuffer cb,
      TerrainDrawPipeline p,
      SodiumTerrainDrawer.InstanceState s,
      int visMode,
      int recordBase,
      GpuTextureView atlasView,
      GpuSampler atlasSampler,
      GpuTextureView lightmapView
   ) {
      int commands = 0;
      int stages = 192;
      MemoryStack stack = MemoryStack.stackPush();

      try {
         ByteBuffer push = stack.calloc(32);

         for (int g = 0; g < s.groupCount; g++) {
            int first = s.groupStart[g];
            int count = s.groupStart[g + 1] - first;
            if (count > 0 && s.groupBuffers[g] != null) {
               pushDescriptorsTask(cb, p, s, s.groupBuffers[g], atlasView, atlasSampler, lightmapView);
               push.putInt(0, first);
               push.putInt(4, s.groupKeys[g]);
               push.putInt(8, visMode);
               push.putInt(12, s.frameStamp32);
               push.putInt(16, s.frameFlags);
               push.putInt(20, recordBase);
               push.putInt(24, ONE_DRAW ? count : 0);
               push.putInt(28, recordBase == SodiumGpuVisibilityLayout.recordBaseUvec4(s.mirror.capacity(), 0) ? 0 : 1);
               VK10.vkCmdPushConstants(cb, p.pipelineLayout(), stages, 0, push);
               if (ONE_DRAW) {
                  EXTMeshShader.vkCmdDrawMeshTasksIndirectEXT(cb, s.ring.indirectBuffer(), s.ring.indirectGroupOffset() + g * 12L, 1, 12);
               } else {
                  EXTMeshShader.vkCmdDrawMeshTasksIndirectEXT(cb, s.ring.indirectBuffer(), s.ring.indirectOffset() + first * 12L, count, 12);
               }

               commands++;
            } else if (count > 0) {
               reportSkippedGroup(count, s.groupCount);
            }
         }
      } catch (Throwable var16) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var15) {
               var16.addSuppressed(var15);
            }
         }

         throw var16;
      }

      if (stack != null) {
         stack.close();
      }

      return commands;
   }

   private static void pushDescriptorsTask(
      VkCommandBuffer cb,
      TerrainDrawPipeline p,
      SodiumTerrainDrawer.InstanceState s,
      GpuBuffer geometry,
      GpuTextureView atlasView,
      GpuSampler atlasSampler,
      GpuTextureView lightmapView
   ) {
      GpuBufferSlice fog = RenderSystem.getShaderFog();
      GpuBuffer globals = RenderSystem.getGlobalSettingsUniform();
      GpuSampler lightmapSampler = RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR);
      MemoryStack stack = MemoryStack.stackPush();

      try {
         org.lwjgl.vulkan.VkWriteDescriptorSet.Buffer writes = VkWriteDescriptorSet.calloc(11, stack);
         bufferWrite((VkWriteDescriptorSet)writes.get(0), 0, 7, bufferInfo(stack, ((VulkanGpuBuffer)geometry).vkBuffer(), 0L, -1L));
         bufferWrite(
            (VkWriteDescriptorSet)writes.get(1),
            1,
            6,
            bufferInfo(stack, ((VulkanGpuBuffer)s.sceneSlice.buffer()).vkBuffer(), s.sceneSlice.offset(), s.sceneSlice.length())
         );
         bufferWrite(
            (VkWriteDescriptorSet)writes.get(2),
            2,
            6,
            bufferInfo(stack, ((VulkanGpuBuffer)s.projectionSlice.buffer()).vkBuffer(), s.projectionSlice.offset(), s.projectionSlice.length())
         );
         bufferWrite((VkWriteDescriptorSet)writes.get(3), 3, 6, bufferInfo(stack, ((VulkanGpuBuffer)fog.buffer()).vkBuffer(), fog.offset(), fog.length()));
         bufferWrite((VkWriteDescriptorSet)writes.get(4), 4, 6, bufferInfo(stack, ((VulkanGpuBuffer)globals).vkBuffer(), 0L, -1L));
         imageWrite((VkWriteDescriptorSet)writes.get(5), 5, imageInfo(stack, atlasView, atlasSampler));
         imageWrite((VkWriteDescriptorSet)writes.get(6), 6, imageInfo(stack, lightmapView, lightmapSampler));
         bufferWrite((VkWriteDescriptorSet)writes.get(7), 7, 7, bufferInfo(stack, s.mirror.vkBuffer(), 0L, -1L));
         bufferWrite((VkWriteDescriptorSet)writes.get(8), 8, 7, bufferInfo(stack, s.ring.listBuffer(), s.ring.listOffset(), s.ring.listRange()));
         bufferWrite((VkWriteDescriptorSet)writes.get(9), 9, 7, bufferInfo(stack, s.prevStamps, 0L, -1L));
         bufferWrite((VkWriteDescriptorSet)writes.get(10), 10, 7, bufferInfo(stack, s.curStamps, 0L, -1L));
         KHRPushDescriptor.vkCmdPushDescriptorSetKHR(cb, 0, p.pipelineLayout(), 0, writes);
      } catch (Throwable var14) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var13) {
               var14.addSuppressed(var13);
            }
         }

         throw var14;
      }

      if (stack != null) {
         stack.close();
      }
   }

   private static TerrainDrawPipeline pipelineTaskFor(VulkanRenderPassAccessor vkPass, GpuTextureView colorView, GpuTextureView depthView, boolean noDiscard) {
      TerrainDrawPipeline p = noDiscard ? pipelineTaskNoDiscard : pipelineTask;
      if (p == null) {
         int vkColorFormat = VulkanConst.toVk(colorView.texture().getFormat());
         int vkDepthFormat = VulkanConst.toVk(depthView.texture().getFormat());
         int wg = TerrainDrawer.meshWorkgroupQuads();
         int taskWg = TerrainDrawer.taskWorkgroupSections();
         NvidiumPlusVulkanState.MeshShaderCaps caps = NvidiumPlusVulkanState.caps();
         if (caps == null) {
            throw new IllegalStateException(
               "no mesh-shader caps: the Vulkan device was created without VK_EXT_mesh_shader, so this path should never have armed"
            );
         }

         if (caps.maxMeshWorkGroupInvocations() < wg
            || caps.maxTaskWorkGroupInvocations() < taskWg
            || caps.maxMeshOutputVertices() < wg * 4
            || caps.maxMeshOutputPrimitives() < wg * 2
            || caps.maxMeshOutputMemorySize() > 0 && caps.maxMeshOutputMemorySize() < wg * TerrainDrawer.MESH_OUTPUT_BYTES_PER_QUAD) {
            throw new IllegalStateException(
               "device mesh caps below the Sodium task draw shape (" + wg + " quads/workgroup, " + taskWg + " sections/task workgroup): " + caps
            );
         }

         p = TerrainDrawPipeline.createSodiumTask(vkPass.nvidiumplus$device().vkDevice(), vkColorFormat, vkDepthFormat, wg, taskWg, noDiscard);
         if (noDiscard) {
            pipelineTaskNoDiscard = p;
         } else {
            pipelineTask = p;
         }

         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus's Sodium GPU-visibility pipeline created (color format {}, depth format {}, {} quads/workgroup, {} sections/task workgroup, fragment={}).",
               new Object[]{vkColorFormat, vkDepthFormat, wg, taskWg, noDiscard ? "no-discard" : "discard"}
            );
      }

      return p;
   }

   private static GpuBufferSlice uploadSceneTask(
      CommandEncoder encoder, Matrix4fc modelView, Matrix4fc projection, int atlasWidth, int atlasHeight, float[] tail, int[] block
   ) {
      MemoryStack stack = MemoryStack.stackPush();

      GpuBufferSlice var11;
      try {
         ByteBuffer scene = stack.calloc(240);
         modelView.get(scene);
         scene.putFloat(64, atlasWidth);
         scene.putFloat(68, atlasHeight);
         putFrustumPlanes(scene, modelView, projection);
         scene.putInt(176, block[0] >> 4);
         scene.putInt(180, block[1] >> 4);
         scene.putInt(184, block[2] >> 4);
         float subPixelDist = NvidiumPlusConfig.subPixelCullChunks() * 16.0F;
         scene.putFloat(192, 3.4E38F);
         scene.putFloat(196, subPixelDist <= 0.0F ? 3.4E38F : subPixelDist * subPixelDist);
         RenderTarget mainTarget = Minecraft.getInstance().gameRenderer.mainRenderTarget();
         scene.putFloat(200, mainTarget.width);
         scene.putFloat(204, mainTarget.height);
         scene.putFloat(208, tail[0]);
         scene.putFloat(212, tail[1]);
         scene.putFloat(216, tail[2]);
         scene.putFloat(220, tail[3]);
         scene.putInt(224, block[0]);
         scene.putInt(228, block[1]);
         scene.putInt(232, block[2]);
         scene.putInt(236, 0);
         var11 = encoder.transientMemory().uploadGpu(scene, 256L, 128);
      } catch (Throwable var13) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var12) {
               var13.addSuppressed(var12);
            }
         }

         throw var13;
      }

      if (stack != null) {
         stack.close();
      }

      return var11;
   }

   private static void putFrustumPlanes(ByteBuffer scene, Matrix4fc modelView, Matrix4fc projection) {
      Matrix4f m = mvpScratch.set(projection).mul(modelView);
      putPlane(scene, 80, m.m03() + m.m00(), m.m13() + m.m10(), m.m23() + m.m20(), m.m33() + m.m30());
      putPlane(scene, 96, m.m03() - m.m00(), m.m13() - m.m10(), m.m23() - m.m20(), m.m33() - m.m30());
      putPlane(scene, 112, m.m03() + m.m01(), m.m13() + m.m11(), m.m23() + m.m21(), m.m33() + m.m31());
      putPlane(scene, 128, m.m03() - m.m01(), m.m13() - m.m11(), m.m23() - m.m21(), m.m33() - m.m31());
      putPlane(scene, 144, m.m03() + m.m02(), m.m13() + m.m12(), m.m23() + m.m22(), m.m33() + m.m32());
      putPlane(scene, 160, m.m03() - m.m02(), m.m13() - m.m12(), m.m23() - m.m22(), m.m33() - m.m32());
   }

   private static void putPlane(ByteBuffer dst, int offset, float a, float b, float c, float d) {
      dst.putFloat(offset, a);
      dst.putFloat(offset + 4, b);
      dst.putFloat(offset + 8, c);
      dst.putFloat(offset + 12, d);
   }

   private static void pullStats(SodiumTerrainDrawer.InstanceState s) {
      long readFrame = s.statsFrames - 3L;
      if (readFrame >= 0L && readFrame > s.lastReadStatsFrame) {
         int[] st = s.mirror.readStats(readFrame);
         if (st != null) {
            gpuSectionsMask = st[0];
            gpuSectionsA = st[1];
            gpuSectionsB = st[2];
            gpuQuads = st[3] & 4294967295L;
            if (st.length > 6 && st[4] != 0) {
               reportRegionRejections(readFrame, st[4], st[5], st[6], st);
            }

            if (st.length > 23) {
               reportMirrorStale(readFrame, st);
               int refused = st[4];
               if (fallbackOnStale() && !gpuDrawBroken && refused > 0 && regionRejectionsFrames >= 2L) {
                  latchGpuDraw(
                     "the graphics card left chunk groups off the screen on "
                        + regionRejectionsFrames
                        + " separate frames (the latest, stats frame "
                        + readFrame
                        + ", "
                        + refused
                        + " refused workgroup(s)) because its copy of their records was out of date; the list path - the one GPU Visibility off uses - draws the rest of the session, which stops the flashing. -Dnvidiumplus.sodium.fallbackOnStale=false keeps the GPU path for testing"
                  );
               }
            }

            statsFramesRead++;
            if (st[2] > 0) {
               s.lastPhaseBStatsFrame = readFrame;
            }

            int i = (int)(readFrame % 64L);
            s.phaseBFrames[i] = readFrame;
            s.phaseBCounts[i] = st[2];
            s.phaseACounts[i] = st[1];
            if (s.dipFrames[i] == readFrame) {
               checkVisibilityDip(s, readFrame, st[1], st[2], s.dipListed[i], s.dipRegions[i], s.dipDropped[i], s.dipSkipB[i], s.dipOcc[i]);
            }

            if (s.occlusion != null) {
               s.occlusion.foldVisibleSet(readFrame);
            }

            s.lastReadStatsFrame = readFrame;
         }
      }
   }

   private static boolean phaseBSkipDecide(
      SodiumTerrainDrawer.InstanceState s,
      double camX,
      double camY,
      double camZ,
      Matrix4fc modelView,
      Matrix4fc projection,
      int extentW,
      int extentH,
      long commitSerial,
      long signature,
      long ownedFrame
   ) {
      if (!phaseBCpuSkipEnabled()) {
         s.pbKeyValid = false;
         phaseBCpuSkipArmed = false;
         return false;
      }

      boolean changed = !s.pbKeyValid;
      long px = Double.doubleToRawLongBits(camX);
      long py = Double.doubleToRawLongBits(camY);
      long pz = Double.doubleToRawLongBits(camZ);
      if (px != s.pbPosX || py != s.pbPosY || pz != s.pbPosZ) {
         changed = true;
         s.pbPosX = px;
         s.pbPosY = py;
         s.pbPosZ = pz;
      }

      changed |= matrixChanged(modelView, s.pbModelView, s.pbScratch);
      changed |= matrixChanged(projection, s.pbProjection, s.pbScratch);
      if (extentW != s.pbExtentW || extentH != s.pbExtentH) {
         changed = true;
         s.pbExtentW = extentW;
         s.pbExtentH = extentH;
      }

      if (s.frameHalfMode != s.pbHalfMode) {
         changed = true;
         s.pbHalfMode = s.frameHalfMode;
      }

      int levers = (stampHoldEnabled() ? 1 : 0) | (regionHoldEnabled() ? 2 : 0) | (occlusionEnabled ? 4 : 0);
      if (levers != s.pbLevers) {
         changed = true;
         s.pbLevers = levers;
      }

      if (commitSerial != s.pbCommitSerial) {
         changed = true;
         s.pbCommitSerial = commitSerial;
      }

      if (signature != s.pbSignature) {
         changed = true;
         s.pbSignature = signature;
      }

      if (ownedFrame != s.pbLastOwned + 1L) {
         changed = true;
      }

      s.pbLastOwned = ownedFrame;
      s.pbKeyValid = true;
      if (changed) {
         s.pbInputChangeStatsFrame = s.statsFrames;
      }

      long c = s.pbInputChangeStatsFrame;
      boolean skip = s.lastReadStatsFrame >= c + 2L && s.lastPhaseBStatsFrame <= c;
      phaseBCpuSkipArmed = skip;
      return skip;
   }

   private static void checkVisibilityDip(
      SodiumTerrainDrawer.InstanceState s, long frame, int phaseA, int phaseB, int listed, int regions, int dropped, boolean skipB, boolean occ
   ) {
      int drawn = phaseA + phaseB;
      boolean chained = occ && s.dipTroughFrame == frame - 1L && s.dipLeftFrame == frame - 2L;
      if (chained && dipRule(s.dipLeftA, s.dipLeftB, s.dipLeftListed, s.dipTroughA, s.dipTroughB, s.dipTroughListed, phaseA, phaseB, listed)) {
         visibilityDips++;
         lastVisibilityDipFrame = s.dipTroughFrame;
         long n = visibilityDips;
         if (visibilityDipsLogged < 8L || n % 64L == 0L) {
            visibilityDipsLogged++;
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus: terrain the graphics card was drawing vanished for ONE frame and came back (dip {}). Sections drawn: {} (A {} + B {}) -> {} (A {} + B {}) -> {} (A {} + B {}); the frame's own list held {} -> {} -> {} sections in {} -> {} -> {} regions, and the walk passed over {} -> {} -> {} mirrored regions with no geometry buffer. Phase B pass on the dipped frame: {}. Stats frames {}..{}, rung {}, declines {}, mirror commits {} regions this frame, upload hook {}, one-frame region gaps so far {}.",
                  new Object[]{
                     n,
                     s.dipLeftDrawn,
                     s.dipLeftA,
                     s.dipLeftB,
                     s.dipTroughDrawn,
                     s.dipTroughA,
                     s.dipTroughB,
                     drawn,
                     phaseA,
                     phaseB,
                     s.dipLeftListed,
                     s.dipTroughListed,
                     listed,
                     s.dipLeftRegions,
                     s.dipTroughRegions,
                     regions,
                     s.dipLeftDropped,
                     s.dipTroughDropped,
                     dropped,
                     s.dipTroughSkipB ? "SKIPPED" : "recorded",
                     s.dipLeftFrame,
                     frame,
                     rung,
                     frameDeclinesTotal,
                     commitRegionsPerFrame,
                     hookUpload,
                     oneFrameGapsTotal
                  }
               );
         }
      }

      s.dipLeftFrame = s.dipTroughFrame;
      s.dipLeftDrawn = s.dipTroughDrawn;
      s.dipLeftA = s.dipTroughA;
      s.dipLeftB = s.dipTroughB;
      s.dipLeftListed = s.dipTroughListed;
      s.dipLeftRegions = s.dipTroughRegions;
      s.dipLeftDropped = s.dipTroughDropped;
      s.dipTroughFrame = occ ? frame : -1L;
      s.dipTroughDrawn = drawn;
      s.dipTroughA = phaseA;
      s.dipTroughB = phaseB;
      s.dipTroughListed = listed;
      s.dipTroughRegions = regions;
      s.dipTroughDropped = dropped;
      s.dipTroughSkipB = skipB;
   }

   public static boolean dipRuleForTest(
      int leftA, int leftB, int leftListed, int troughA, int troughB, int troughListed, int rightA, int rightB, int rightListed
   ) {
      return dipRule(leftA, leftB, leftListed, troughA, troughB, troughListed, rightA, rightB, rightListed);
   }

   private static boolean dipRule(int leftA, int leftB, int leftListed, int troughA, int troughB, int troughListed, int rightA, int rightB, int rightListed) {
      int leftDrawn = leftA + leftB;
      int troughDrawn = troughA + troughB;
      int rightDrawn = rightA + rightB;
      if (leftDrawn >= 64 && rightDrawn >= 64) {
         int lowDrawn = Math.min(leftDrawn, rightDrawn);
         int highDrawn = Math.max(leftDrawn, rightDrawn);
         if (lowDrawn * 100L < highDrawn * 94L) {
            return false;
         } else if (troughDrawn * 100L >= lowDrawn * 92L) {
            return false;
         } else {
            return troughA * 100L >= Math.min(leftA, rightA) * 92L
               ? false
               : dipListedStable(leftListed, troughListed) && dipListedStable(leftListed, rightListed);
         }
      } else {
         return false;
      }
   }

   private static boolean dipListedStable(int a, int b) {
      int hi = Math.max(a, b);
      int lo = Math.min(a, b);
      return hi <= 0 || lo * 100L >= hi * 95L;
   }

   private static boolean matrixChanged(Matrix4fc m, float[] prev, float[] scratch) {
      m.get(scratch);
      boolean changed = false;

      for (int i = 0; i < 16; i++) {
         if (Float.floatToRawIntBits(scratch[i]) != Float.floatToRawIntBits(prev[i])) {
            changed = true;
         }

         prev[i] = scratch[i];
      }

      return changed;
   }

   public static final class InstanceState {
      static final int HISTORY = 64;
      SodiumMirrorGpu mirror;
      SodiumFrameRing ring;
      TerrainOcclusion occlusion;
      long ownedFrames;
      long statsFrames;
      int frameStamp32;
      long timerSerial;
      boolean frameOwned;
      boolean frameHasOcclusion;
      boolean frameSkipPhaseB;
      int frameHalfMode;
      int pbHalfMode;
      int pbLevers = -1;
      boolean frameCutoutPhaseARecorded;
      int frameFlags;
      int drawCommands;
      GpuBufferSlice sceneSlice;
      GpuBufferSlice projectionSlice;
      TerrainOcclusion.ListSlice listSlice;
      long prevStamps;
      long curStamps;
      GpuBuffer[] groupBuffers;
      int[] groupKeys;
      int[] groupStart;
      int groupCount;
      int listedRegions;
      boolean pbKeyValid;
      long pbPosX;
      long pbPosY;
      long pbPosZ;
      final float[] pbModelView = new float[16];
      final float[] pbProjection = new float[16];
      final float[] pbScratch = new float[16];
      int pbExtentW;
      int pbExtentH;
      long pbCommitSerial;
      long pbSignature;
      long pbLastOwned;
      long pbInputChangeStatsFrame;
      long lastReadStatsFrame = -1L;
      long lastPhaseBStatsFrame = -1L;
      final long[] phaseBFrames = new long[64];
      final int[] phaseBCounts = new int[64];
      final int[] phaseACounts = new int[64];
      final long[] dipFrames = new long[64];
      final int[] dipListed = new int[64];
      final int[] dipRegions = new int[64];
      final int[] dipDropped = new int[64];
      final boolean[] dipSkipB = new boolean[64];
      final boolean[] dipOcc = new boolean[64];
      long dipLeftFrame = -1L;
      int dipLeftDrawn;
      int dipLeftA;
      int dipLeftB;
      int dipLeftListed;
      int dipLeftRegions;
      int dipLeftDropped;
      long dipTroughFrame = -1L;
      int dipTroughDrawn;
      int dipTroughA;
      int dipTroughB;
      int dipTroughListed;
      int dipTroughRegions;
      int dipTroughDropped;
      boolean dipTroughSkipB;

      InstanceState() {
         Arrays.fill(this.phaseBFrames, -1L);
         Arrays.fill(this.dipFrames, -1L);
      }

      public SodiumMirrorGpu mirror() {
         return this.mirror;
      }

      public SodiumFrameRing ring() {
         return this.ring;
      }

      public long ownedFrames() {
         return this.ownedFrames;
      }

      public long statsFrames() {
         return this.statsFrames;
      }

      public boolean frameOwned() {
         return this.frameOwned;
      }

      public boolean frameHasOcclusion() {
         return this.frameHasOcclusion;
      }

      void clearFrame() {
         this.frameOwned = false;
         this.frameCutoutPhaseARecorded = false;
         this.frameHalfMode = 0;
         this.sceneSlice = null;
         this.projectionSlice = null;
         this.listSlice = null;
         this.groupBuffers = null;
         this.groupKeys = null;
         this.groupStart = null;
         this.groupCount = 0;
      }

      void destroyNow() {
         if (this.occlusion != null) {
            this.occlusion.destroyNow();
            this.occlusion = null;
         }

         if (this.ring != null) {
            this.ring.destroyNow();
            this.ring = null;
         }

         if (this.mirror != null) {
            this.mirror.destroyNow();
            this.mirror = null;
         }
      }
   }

   enum Shape {
      PER_SECTION,
      DRAW_ID,
      GROUP_MAP;
   }
}
