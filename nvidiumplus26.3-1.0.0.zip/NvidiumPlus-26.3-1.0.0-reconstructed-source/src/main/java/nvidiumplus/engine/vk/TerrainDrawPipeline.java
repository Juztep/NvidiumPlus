package nvidiumplus.engine.vk;

import java.nio.LongBuffer;
import java.util.Map;
import nvidiumplus.engine.NvidiumPlusScaling;
import nvidiumplus.engine.NvidiumPlusVulkanState;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkDescriptorSetLayoutBinding;
import org.lwjgl.vulkan.VkDescriptorSetLayoutCreateInfo;
import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkGraphicsPipelineCreateInfo;
import org.lwjgl.vulkan.VkPipelineColorBlendAttachmentState;
import org.lwjgl.vulkan.VkPipelineColorBlendStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineDepthStencilStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineDynamicStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineLayoutCreateInfo;
import org.lwjgl.vulkan.VkPipelineMultisampleStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineRasterizationStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineRenderingCreateInfoKHR;
import org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo;
import org.lwjgl.vulkan.VkPipelineViewportStateCreateInfo;
import org.lwjgl.vulkan.VkPushConstantRange;
import org.lwjgl.vulkan.VkDescriptorSetLayoutBinding.Buffer;

public final class TerrainDrawPipeline {
   private static final int COLOR_WRITE_ALL = 15;
   public static final int PUSH_BYTES = 32;
   static final int PAYLOAD_BYTES_PER_SECTION = 80;
   static final int SODIUM_TASK_PAYLOAD_TAIL_BYTES = 16;
   private final long setLayout;
   private final long pipelineLayout;
   private final long pipeline;
   private final int workgroupQuads;
   private final boolean taskCull;
   private final boolean translucent;
   private final boolean extendedLists;
   private final boolean sodiumTask;
   private final int transQuadCapacity;

   private TerrainDrawPipeline(
      long setLayout,
      long pipelineLayout,
      long pipeline,
      int workgroupQuads,
      boolean taskCull,
      boolean translucent,
      boolean extendedLists,
      boolean sodiumTask,
      int transQuadCapacity
   ) {
      this.setLayout = setLayout;
      this.pipelineLayout = pipelineLayout;
      this.pipeline = pipeline;
      this.workgroupQuads = workgroupQuads;
      this.taskCull = taskCull;
      this.translucent = translucent;
      this.extendedLists = extendedLists;
      this.sodiumTask = sodiumTask;
      this.transQuadCapacity = transQuadCapacity;
   }

   public long pipeline() {
      return this.pipeline;
   }

   public long pipelineLayout() {
      return this.pipelineLayout;
   }

   public long setLayout() {
      return this.setLayout;
   }

   public int workgroupQuads() {
      return this.workgroupQuads;
   }

   public boolean taskCull() {
      return this.taskCull;
   }

   public boolean translucent() {
      return this.translucent;
   }

   public boolean extendedLists() {
      return this.extendedLists;
   }

   public boolean sodiumTask() {
      return this.sodiumTask;
   }

   public int transQuadCapacity() {
      return this.transQuadCapacity;
   }

   public void destroy(VkDevice device) {
      VK10.vkDestroyPipeline(device, this.pipeline, null);
      VK10.vkDestroyPipelineLayout(device, this.pipelineLayout, null);
      VK10.vkDestroyDescriptorSetLayout(device, this.setLayout, null);
   }

   public int pushStageFlags() {
      return this.taskCull ? 192 : 128;
   }

   public static TerrainDrawPipeline create(
      VkDevice device,
      int vkColorFormat,
      int vkDepthFormat,
      int workgroupQuads,
      int taskWgSections,
      int visMaskRegions,
      boolean taskCull,
      boolean extendedLists
   ) {
      return createInternal(device, vkColorFormat, vkDepthFormat, workgroupQuads, taskWgSections, visMaskRegions, taskCull, extendedLists, 0);
   }

   public static TerrainDrawPipeline createTranslucent(VkDevice device, int vkColorFormat, int vkDepthFormat, int workgroupQuads, int transQuads) {
      return createInternal(device, vkColorFormat, vkDepthFormat, workgroupQuads, 1, 1, false, false, transQuads);
   }

   public static TerrainDrawPipeline createSodium(
      VkDevice device, int vkColorFormat, int vkDepthFormat, int workgroupQuads, boolean batched, boolean drawId, boolean noDiscard
   ) {
      return createInternal(device, vkColorFormat, vkDepthFormat, workgroupQuads, 1, 1, false, false, 0, true, batched, drawId, noDiscard, false);
   }

   public static TerrainDrawPipeline createSodiumTask(
      VkDevice device, int vkColorFormat, int vkDepthFormat, int workgroupQuads, int taskWgSections, boolean noDiscard
   ) {
      NvidiumPlusVulkanState.MeshShaderCaps caps = NvidiumPlusVulkanState.caps();
      if (caps == null) {
         throw new IllegalStateException(
            "no mesh-shader caps: the Vulkan device was created without VK_EXT_mesh_shader, so the Sodium GPU-visibility pipeline should never have been requested"
         );
      } else {
         int payloadBytes = 80 * taskWgSections + 16;
         if (caps.maxTaskWorkGroupInvocations() >= taskWgSections && caps.maxTaskPayloadSize() >= payloadBytes) {
            return createInternal(device, vkColorFormat, vkDepthFormat, workgroupQuads, taskWgSections, 1, true, false, 0, true, false, false, noDiscard, true);
         } else {
            throw new IllegalStateException(
               "device task caps below the Sodium GPU-visibility task shape (" + taskWgSections + " lanes, " + payloadBytes + " B payload): " + caps
            );
         }
      }
   }

   private static TerrainDrawPipeline createInternal(
      VkDevice device,
      int vkColorFormat,
      int vkDepthFormat,
      int workgroupQuads,
      int taskWgSections,
      int visMaskRegions,
      boolean taskCull,
      boolean extendedLists,
      int transQuads
   ) {
      return createInternal(
         device,
         vkColorFormat,
         vkDepthFormat,
         workgroupQuads,
         taskWgSections,
         visMaskRegions,
         taskCull,
         extendedLists,
         transQuads,
         false,
         false,
         false,
         false,
         false
      );
   }

   private static TerrainDrawPipeline createInternal(
      VkDevice device,
      int vkColorFormat,
      int vkDepthFormat,
      int workgroupQuads,
      int taskWgSections,
      int visMaskRegions,
      boolean taskCull,
      boolean extendedLists,
      int transQuads,
      boolean sodium,
      boolean sodiumBatched,
      boolean sodiumDrawId,
      boolean noDiscard,
      boolean sodiumTask
   ) {
      boolean translucent = transQuads > 0;
      if (!sodiumTask || sodium && taskCull && !sodiumBatched && !sodiumDrawId && !translucent) {
         int arenaBlocks = sodium ? 1 : NvidiumPlusScaling.arenaBlockCount();
         long arenaBlockBytes = NvidiumPlusScaling.arenaBlockBytes();
         long quadsPerBlock = arenaBlockBytes / 64L;
         int blockShift = Long.numberOfTrailingZeros(quadsPerBlock);
         Map<String, String> macros = Map.ofEntries(
            Map.entry("NVIDIUMPLUS_ARENA_BLOCKS", Integer.toString(arenaBlocks)),
            Map.entry("NVIDIUMPLUS_ARENA_BLOCK_SHIFT", Integer.toString(blockShift)),
            Map.entry("NVIDIUMPLUS_ARENA_BLOCK_MASK", Long.toUnsignedString(quadsPerBlock - 1L) + "u"),
            Map.entry("NVIDIUMPLUS_WG_SIZE", Integer.toString(workgroupQuads)),
            Map.entry("NVIDIUMPLUS_TASK_WG_SIZE", Integer.toString(taskWgSections)),
            Map.entry("NVIDIUMPLUS_VIS_UVEC4S", Integer.toString(visMaskRegions * 2)),
            Map.entry("NVIDIUMPLUS_TASK_CULL", taskCull ? "1" : "0"),
            Map.entry("NVIDIUMPLUS_TRANSLUCENT", translucent ? "1" : "0"),
            Map.entry("NVIDIUMPLUS_SODIUM", sodium ? "1" : "0"),
            Map.entry("NVIDIUMPLUS_PACKED_VARYINGS", TerrainDrawer.PACKED_VARYINGS ? "1" : "0"),
            Map.entry("NVIDIUMPLUS_SODIUM_BATCH", sodiumBatched ? "1" : "0"),
            Map.entry("NVIDIUMPLUS_SODIUM_DRAWID", sodiumBatched && sodiumDrawId ? "1" : "0"),
            Map.entry("NVIDIUMPLUS_SODIUM_MESH_FRUSTUM", sodiumBatched && SodiumTerrainDrawer.FRUSTUM_MODE == 3 ? "1" : "0"),
            Map.entry("NVIDIUMPLUS_SODIUM_FRUSTUM_SLACK", Float.toString(1.125F)),
            Map.entry("NVIDIUMPLUS_SODIUM_TASK", sodiumTask ? "1" : "0"),
            Map.entry("NVIDIUMPLUS_NO_DISCARD", noDiscard ? "1" : "0"),
            Map.entry("NVIDIUMPLUS_TRANS_QUADS", Integer.toString(Math.max(transQuads, 1))),
            Map.entry("NVIDIUMPLUS_LISTS_SSBO", extendedLists ? "1" : "0"),
            Map.entry("NVIDIUMPLUS_LIGHT_STUB", Boolean.getBoolean("nvidiumplus.bench.lightStub") ? "1" : "0"),
            Map.entry("NVIDIUMPLUS_DIAG_NOFOG", Boolean.getBoolean("nvidiumplus.bench.noFog") ? "1" : "0")
         );
         long taskModule = 0L;
         long meshModule = 0L;
         long fragModule = 0L;

         try {
            if (taskCull) {
               taskModule = NvidiumPlusShaderCompiler.compileResourceToModule(device, "/assets/nvidiumplus/shaders/terrain.task", 26, macros);
            }

            meshModule = NvidiumPlusShaderCompiler.compileResourceToModule(device, "/assets/nvidiumplus/shaders/terrain.mesh", 27, macros);
            fragModule = NvidiumPlusShaderCompiler.compileResourceToModule(device, "/assets/nvidiumplus/shaders/terrain.frag", 1, macros);
            return build(
               device,
               vkColorFormat,
               vkDepthFormat,
               taskModule,
               meshModule,
               fragModule,
               workgroupQuads,
               taskCull,
               extendedLists,
               transQuads,
               arenaBlocks,
               sodiumBatched,
               sodiumTask
            );
         } finally {
            if (taskModule != 0L) {
               VK10.vkDestroyShaderModule(device, taskModule, null);
            }

            if (meshModule != 0L) {
               VK10.vkDestroyShaderModule(device, meshModule, null);
            }

            if (fragModule != 0L) {
               VK10.vkDestroyShaderModule(device, fragModule, null);
            }
         }
      } else {
         throw new IllegalArgumentException("sodiumTask requires sodium, taskCull and no batching");
      }
   }

   private static TerrainDrawPipeline build(
      VkDevice device,
      int vkColorFormat,
      int vkDepthFormat,
      long taskModule,
      long meshModule,
      long fragModule,
      int workgroupQuads,
      boolean taskCull,
      boolean extendedLists,
      int transQuads,
      int arenaBlocks,
      boolean sodiumBatched,
      boolean sodiumTask
   ) {
      boolean translucent = transQuads > 0;
      MemoryStack stack = MemoryStack.stackPush();

      TerrainDrawPipeline var45;
      try {
         int taskStage = 64;
         int meshStage = 128;
         int fragStage = 16;
         int bindingCount = sodiumTask ? 11 : (taskCull ? 12 : (translucent ? 9 : (sodiumBatched ? 9 : 7)));
         Buffer bindings = VkDescriptorSetLayoutBinding.calloc(bindingCount, stack);
         int sceneStages = taskCull ? taskStage | meshStage | fragStage : meshStage | fragStage;
         binding((VkDescriptorSetLayoutBinding)bindings.get(0), 0, 7, meshStage, arenaBlocks);
         binding((VkDescriptorSetLayoutBinding)bindings.get(1), 1, 6, sceneStages);
         binding((VkDescriptorSetLayoutBinding)bindings.get(2), 2, 6, meshStage);
         binding((VkDescriptorSetLayoutBinding)bindings.get(3), 3, 6, fragStage);
         binding((VkDescriptorSetLayoutBinding)bindings.get(4), 4, 6, fragStage);
         binding((VkDescriptorSetLayoutBinding)bindings.get(5), 5, 1, fragStage);
         binding((VkDescriptorSetLayoutBinding)bindings.get(6), 6, 1, meshStage);
         if (sodiumTask) {
            binding((VkDescriptorSetLayoutBinding)bindings.get(7), 7, 7, taskStage);
            binding((VkDescriptorSetLayoutBinding)bindings.get(8), 8, 7, taskStage);
            binding((VkDescriptorSetLayoutBinding)bindings.get(9), 9, 7, taskStage);
            binding((VkDescriptorSetLayoutBinding)bindings.get(10), 10, 7, taskStage);
         } else if (taskCull) {
            binding((VkDescriptorSetLayoutBinding)bindings.get(7), 7, 7, taskStage);
            binding((VkDescriptorSetLayoutBinding)bindings.get(8), 8, extendedLists ? 7 : 6, taskStage);
            binding((VkDescriptorSetLayoutBinding)bindings.get(9), 9, 7, taskStage);
            binding((VkDescriptorSetLayoutBinding)bindings.get(10), 10, 7, taskStage);
            binding((VkDescriptorSetLayoutBinding)bindings.get(11), 11, 7, taskStage);
         } else if (translucent) {
            binding((VkDescriptorSetLayoutBinding)bindings.get(7), 7, 7, meshStage);
            binding((VkDescriptorSetLayoutBinding)bindings.get(8), 8, 7, meshStage);
         } else if (sodiumBatched) {
            binding((VkDescriptorSetLayoutBinding)bindings.get(7), 9, 7, meshStage);
            binding((VkDescriptorSetLayoutBinding)bindings.get(8), 10, 7, meshStage);
         }

         VkDescriptorSetLayoutCreateInfo setLayoutInfo = VkDescriptorSetLayoutCreateInfo.calloc(stack).sType$Default().flags(1).pBindings(bindings);
         LongBuffer handle = stack.mallocLong(1);
         check(VK10.vkCreateDescriptorSetLayout(device, setLayoutInfo, null, handle), "vkCreateDescriptorSetLayout(terrain)");
         long setLayout = handle.get(0);
         org.lwjgl.vulkan.VkPushConstantRange.Buffer pushRange = VkPushConstantRange.calloc(1, stack);
         ((VkPushConstantRange)pushRange.get(0)).stageFlags(taskCull ? taskStage | meshStage : meshStage).offset(0).size(32);
         VkPipelineLayoutCreateInfo layoutInfo = VkPipelineLayoutCreateInfo.calloc(stack)
            .sType$Default()
            .pSetLayouts(stack.longs(setLayout))
            .setLayoutCount(1)
            .pPushConstantRanges(pushRange);
         check(VK10.vkCreatePipelineLayout(device, layoutInfo, null, handle), "vkCreatePipelineLayout(terrain)");
         long pipelineLayout = handle.get(0);
         VkPipelineViewportStateCreateInfo viewportState = VkPipelineViewportStateCreateInfo.calloc(stack).sType$Default().viewportCount(1).scissorCount(1);
         VkPipelineRasterizationStateCreateInfo rasterState = VkPipelineRasterizationStateCreateInfo.calloc(stack)
            .sType$Default()
            .depthClampEnable(false)
            .rasterizerDiscardEnable(false)
            .polygonMode(0)
            .cullMode(2)
            .frontFace(1)
            .depthBiasEnable(false)
            .lineWidth(1.0F);
         VkPipelineMultisampleStateCreateInfo multisampleState = VkPipelineMultisampleStateCreateInfo.calloc(stack)
            .sType$Default()
            .rasterizationSamples(1)
            .sampleShadingEnable(false);
         VkPipelineDepthStencilStateCreateInfo depthState = VkPipelineDepthStencilStateCreateInfo.calloc(stack)
            .sType$Default()
            .depthTestEnable(true)
            .depthWriteEnable(true)
            .depthCompareOp(6);
         org.lwjgl.vulkan.VkPipelineColorBlendAttachmentState.Buffer blendAttachment = VkPipelineColorBlendAttachmentState.calloc(1, stack);
         if (translucent) {
            ((VkPipelineColorBlendAttachmentState)blendAttachment.get(0))
               .blendEnable(true)
               .srcColorBlendFactor(6)
               .dstColorBlendFactor(7)
               .colorBlendOp(0)
               .srcAlphaBlendFactor(1)
               .dstAlphaBlendFactor(7)
               .alphaBlendOp(0)
               .colorWriteMask(15);
         } else {
            ((VkPipelineColorBlendAttachmentState)blendAttachment.get(0)).blendEnable(false).colorWriteMask(15);
         }

         VkPipelineColorBlendStateCreateInfo blendState = VkPipelineColorBlendStateCreateInfo.calloc(stack)
            .sType$Default()
            .logicOpEnable(false)
            .pAttachments(blendAttachment)
            .attachmentCount(1);
         VkPipelineDynamicStateCreateInfo dynamicState = VkPipelineDynamicStateCreateInfo.calloc(stack).sType$Default().pDynamicStates(stack.ints(1, 0));
         VkPipelineRenderingCreateInfoKHR renderingInfo = VkPipelineRenderingCreateInfoKHR.calloc(stack)
            .sType$Default()
            .colorAttachmentCount(1)
            .pColorAttachmentFormats(stack.ints(vkColorFormat))
            .depthAttachmentFormat(vkDepthFormat);
         int stageCount = taskCull ? 3 : 2;
         org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo.Buffer stages = VkPipelineShaderStageCreateInfo.calloc(stageCount, stack);
         int si = 0;
         if (taskCull) {
            ((VkPipelineShaderStageCreateInfo)stages.get(si++)).sType$Default().stage(taskStage).module(taskModule).pName(stack.UTF8("main"));
         }

         ((VkPipelineShaderStageCreateInfo)stages.get(si++)).sType$Default().stage(meshStage).module(meshModule).pName(stack.UTF8("main"));
         ((VkPipelineShaderStageCreateInfo)stages.get(si)).sType$Default().stage(fragStage).module(fragModule).pName(stack.UTF8("main"));
         org.lwjgl.vulkan.VkGraphicsPipelineCreateInfo.Buffer createInfo = VkGraphicsPipelineCreateInfo.calloc(1, stack);
         ((VkGraphicsPipelineCreateInfo)createInfo.get(0))
            .sType$Default()
            .pNext(renderingInfo.address())
            .pStages(stages)
            .stageCount(stageCount)
            .pViewportState(viewportState)
            .pRasterizationState(rasterState)
            .pMultisampleState(multisampleState)
            .pDepthStencilState(depthState)
            .pColorBlendState(blendState)
            .pDynamicState(dynamicState)
            .layout(pipelineLayout)
            .renderPass(0L);
         LongBuffer pipelines = stack.mallocLong(1);
         check(
            VK10.vkCreateGraphicsPipelines(device, 0L, createInfo, null, pipelines),
            "vkCreateGraphicsPipelines(NvidiumPlus terrain, taskCull=" + taskCull + ", translucent=" + translucent + ", sodiumTask=" + sodiumTask + ")"
         );
         var45 = new TerrainDrawPipeline(
            setLayout, pipelineLayout, pipelines.get(0), workgroupQuads, taskCull, translucent, extendedLists, sodiumTask, transQuads
         );
      } catch (Throwable var47) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var46) {
               var47.addSuppressed(var46);
            }
         }

         throw var47;
      }

      if (stack != null) {
         stack.close();
      }

      return var45;
   }

   private static void binding(VkDescriptorSetLayoutBinding b, int index, int type, int stages) {
      binding(b, index, type, stages, 1);
   }

   private static void binding(VkDescriptorSetLayoutBinding b, int index, int type, int stages, int count) {
      b.binding(index).descriptorType(type).descriptorCount(count).stageFlags(stages);
   }

   private static void check(int vkResult, String what) {
      if (vkResult != 0) {
         throw new IllegalStateException(what + " failed: VkResult " + vkResult);
      }
   }
}
