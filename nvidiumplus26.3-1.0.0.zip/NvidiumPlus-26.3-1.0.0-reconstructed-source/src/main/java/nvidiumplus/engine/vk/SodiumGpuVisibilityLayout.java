package nvidiumplus.engine.vk;

public final class SodiumGpuVisibilityLayout {
   public static final int MIRROR_HEADER_BYTES = 256;
   public static final int MIRROR_STATS_OFFSET = 0;
   public static final int MIRROR_STATS_BYTES = 96;
   public static final int STAT_REGION_REJECTED = 4;
   public static final int STAT_ROW_DEAD = 5;
   public static final int STAT_KEY_MISMATCH = 6;
   public static final int STAT_FIRST_MID = 8;
   public static final int STAT_FIRST_ROW_KEY = 9;
   public static final int STAT_FIRST_GROUP_KEY = 10;
   public static final int STAT_FIRST_SLOT = 11;
   public static final int STAT_FIRST_GROUP_START = 12;
   public static final int STAT_FIRST_GROUP_COUNT = 13;
   public static final int STAT_FIRST_LIST_POP = 14;
   public static final int STAT_FIRST_ROW_POP = 15;
   public static final int STAT_FIRST_ROW_CX = 16;
   public static final int STAT_FIRST_ROW_CY = 17;
   public static final int STAT_FIRST_ROW_CZ = 18;
   public static final int STAT_FIRST_VISMODE = 7;
   public static final int STAT_MIRROR_STALE = 19;
   public static final int STAT_STALE_MID = 20;
   public static final int STAT_STALE_MIRROR_KEY = 21;
   public static final int STAT_STALE_LIST_KEY = 22;
   public static final int STAT_STALE_MIRROR_POP = 23;
   public static final int MIRROR_LAYOUT_OFFSET = 96;
   public static final int ROW_BYTES = 64;
   public static final int RECORD_BYTES = 48;
   public static final int SLOTS_PER_REGION = 256;
   public static final int PASS_BLOCK_BYTES = 12288;
   public static final int PASS_SOLID = 0;
   public static final int PASS_CUTOUT = 1;
   public static final int PASS_COUNT = 2;
   public static final int CAPACITY_INITIAL = 1024;
   public static final int CAPACITY_ROUND = 64;
   public static final int CAPACITY_TEST_MIN = 16;
   public static final int ROW_CHUNK_X = 0;
   public static final int ROW_CHUNK_Y = 4;
   public static final int ROW_CHUNK_Z = 8;
   public static final int ROW_FLAGS = 12;
   public static final int ROW_OCC_MASK = 16;
   public static final int ROW_BUFFER_KEY = 48;
   public static final int ROW_POPCOUNT = 52;
   public static final int ROW_OCC_MIN = 56;
   public static final int ROW_OCC_MAX = 60;
   public static final int ROW_FLAG_LIVE = 1;
   public static final int ROW_FLAG_FORCE_FULL = 2;
   public static final int LIST_ENTRY_BYTES = 128;
   public static final int LIST_ROW = 64;
   public static final int LIST_ROW_PROBE_SOLID = 120;
   public static final int LIST_ROW_PROBE_CUTOUT = 124;
   public static final int LIST_ORIGIN = 0;
   public static final int LIST_GROUP_END = 12;
   public static final int LIST_META_MID = 16;
   public static final int LIST_META_POPCOUNT = 20;
   public static final int LIST_META_OCC_MIN = 24;
   public static final int LIST_META_OCC_MAX = 28;
   public static final int LIST_BFS_MASK = 32;
   public static final int INDIRECT_BYTES = 12;
   public static final int RING_SLOTS = 8;
   public static final int STAGING_BYTES = 33554432;
   public static final int B_GEOMETRY = 0;
   public static final int B_SCENE = 1;
   public static final int B_PROJECTION = 2;
   public static final int B_FOG = 3;
   public static final int B_GLOBALS = 4;
   public static final int B_ATLAS = 5;
   public static final int B_LIGHTMAP = 6;
   public static final int B_MIRROR = 7;
   public static final int B_LIST = 8;
   public static final int B_PREV_STAMPS = 9;
   public static final int B_CUR_STAMPS = 10;
   public static final int TASK_STAGE_STORAGE_BUFFERS = 4;
   public static final int PUSH_FIRST_SLOT = 0;
   public static final int PUSH_GROUP_KEY = 4;
   public static final int PUSH_VIS_MODE = 8;
   public static final int PUSH_FRAME_STAMP = 12;
   public static final int PUSH_FLAGS = 16;
   public static final int PUSH_RECORD_BASE = 20;
   public static final int PUSH_RESERVED0 = 24;
   public static final int PUSH_RESERVED1 = 28;
   public static final int PUSH_RECORD_PASS = 28;
   public static final int PUSH_REGION_COUNT = 24;
   public static final int FLAG_STATS = 1;
   public static final int FLAG_FACE_ALL = 2;
   public static final int FLAG_DIST_GATE = 4;
   public static final int FLAG_DIAG_SKIP_ALL = 8;
   public static final int FLAG_DIAG_SKIP_STAMPS = 16;
   public static final int FLAG_ONE_DRAW = 32;
   public static final int FLAG_STAMP_HOLD = 64;
   public static final int FLAG_ROWS_FROM_LIST = 128;
   public static final int MAX_GROUP_COMMANDS = 64;
   public static final int VIS_MODE_BFS = 0;
   public static final int VIS_MODE_PHASE_A = 1;
   public static final int VIS_MODE_PHASE_B = 2;
   public static final int SCENE_CAMERA_FRAC = 208;
   public static final int SCENE_CAMERA_BLOCK = 224;
   public static final int SCENE_BYTES_SODIUM = 240;
   public static final String MACRO_SODIUM_TASK = "NVIDIUMPLUS_SODIUM_TASK";
   public static final int FREE_FRAME_LAG = 3;

   public static long rowsOffset(int capacity) {
      return 256L;
   }

   public static long passOffset(int capacity, int pass) {
      return 256L + capacity * 64L + (long)pass * capacity * 12288L;
   }

   public static long mirrorBytes(int capacity) {
      return passOffset(capacity, 2);
   }

   public static int recordBaseUvec4(int capacity, int pass) {
      return (int)((passOffset(capacity, pass) - 256L) / 16L);
   }

   private SodiumGpuVisibilityLayout() {
   }
}
