package nvidiumplus.engine.vk;

import com.mojang.blaze3d.ProjectionType;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.renderpearl.api.commands.CommandEncoder;
import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.renderpearl.api.device.GpuDeviceLossException;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.vulkan.VulkanConst;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuBuffer;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuSampler;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuTextureView;
import com.mojang.renderpearl.backend.vulkan.VulkanRenderPass;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.Optional;
import java.util.OptionalDouble;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher.RenderSection;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.core.SectionPos;
import net.minecraft.world.phys.AABB;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusCpuStages;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusNotify;
import nvidiumplus.engine.NvidiumPlusScaling;
import nvidiumplus.engine.NvidiumPlusVulkanState;
import nvidiumplus.engine.compat.McCompat;
import nvidiumplus.engine.mixin.FrustumAccessor;
import nvidiumplus.engine.mixin.RenderPassAccessor;
import nvidiumplus.engine.mixin.SectionOcclusionGraphAccessor;
import nvidiumplus.engine.mixin.VulkanRenderPassAccessor;
import nvidiumplus.engine.terrain.QuadFacing;
import nvidiumplus.engine.terrain.host.SectionBuildTap;
import nvidiumplus.engine.terrain.host.TerrainResidency;
import nvidiumplus.engine.terrain.host.VanillaUploadSeam;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.EXTConditionalRendering;
import org.lwjgl.vulkan.EXTMeshShader;
import org.lwjgl.vulkan.KHRPushDescriptor;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkConditionalRenderingBeginInfoEXT;
import org.lwjgl.vulkan.VkDescriptorBufferInfo;
import org.lwjgl.vulkan.VkDescriptorImageInfo;
import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkWriteDescriptorSet;
import org.lwjgl.vulkan.VkDescriptorBufferInfo.Buffer;

public final class TerrainDrawer {
   public static final String PROPERTY = "nvidiumplus.terrainDraw";
   public static final String PROPERTY_CPU_CULL = "nvidiumplus.terrainDraw.cpuCull";
   public static final String PROPERTY_BFS_ONLY = "nvidiumplus.terrainDraw.bfsOnly";
   static final int MODE_MASK = 0;
   static final int MODE_PHASE_A = 1;
   static final int MODE_PHASE_B = 2;
   static final int WORKGROUP_QUADS = 32;
   static final int TASK_WG_SECTIONS = 32;
   static final int MAX_MASK_REGIONS = 512;
   static final int VIS_UBO_BYTES = 16384;
   static final int NO_MASK_SLOT = -1;
   static final int SCENE_BYTES = 208;
   static final float CULL_OFF_DIST2 = 3.4E38F;
   static final int TRANS_QUADS_DEFAULT = 64;
   static final int NO_GATE = -1;
   public static final String PROPERTY_MESH_WG = "nvidiumplus.tune.meshWorkgroupQuads";
   public static final String PROPERTY_TASK_WG = "nvidiumplus.tune.taskWorkgroupSections";
   public static final String PROPERTY_FRONT_TO_BACK = "nvidiumplus.tune.frontToBack";
   public static final String PROPERTY_TRANSLUCENT_MULTI_WG = "nvidiumplus.translucentMultiWG";
   public static final String PROPERTY_PHASE_B_CPU_SKIP = "nvidiumplus.occlusion.phaseBCpuSkip";
   private static long prepSkippedSerial = -1L;
   private static volatile long prepSkippedFrames;
   private static volatile long prepSkipHoleFrames;
   private static boolean prepSkipHoleWarned;
   private static boolean ccValid;
   private static long ccEpoch = Long.MIN_VALUE;
   private static long ccPosX;
   private static long ccPosY;
   private static long ccPosZ;
   private static long ccFrusX;
   private static long ccFrusY;
   private static long ccFrusZ;
   private static final float[] ccMatrix = new float[16];
   private static final float[] ccMatrixScratch = new float[16];
   private static int ccDispatched;
   private static long ccSig;
   private static long ccOverflowThisFrame;
   private static int ccRegionCount;
   private static int ccCapacity;
   private static boolean ccExtLists;
   private static boolean ccFrontToBack;
   private static ByteBuffer ccShadow;
   private static volatile long cachedCullHits;
   private static volatile long cachedCullMisses;
   static final int MESH_WG_MAX = 64;
   static final boolean PACKED_VARYINGS = !Boolean.getBoolean("nvidiumplus.unpackedVaryings");
   static final int MESH_OUTPUT_LOCATIONS = PACKED_VARYINGS ? 5 : 7;
   static final int MESH_OUTPUT_BYTES_PER_QUAD = 4 * MESH_OUTPUT_LOCATIONS * 16;
   static final int TASK_WG_MAX = 128;
   private static int resolvedMeshWgQuads = -1;
   private static int resolvedTaskWgSections = -1;
   private static long[] sortKeys = new long[256];
   private static int[] sortMetaScratch = new int[768];
   private static float[] sortOriginScratch = new float[768];
   private static volatile String lastError;
   private static volatile int framesDrawn;
   private static volatile int lastDrawnSections;
   private static volatile long totalDrawnSections;
   private static volatile long cancelledGroups;
   private static volatile int regionsDispatched;
   private static volatile int sectionsVisibleIn;
   private static volatile long dispatchSignature;
   private static volatile long taskCullFrames;
   private static volatile long cpuCullFrames;
   private static volatile long maskOverflowRegions;
   private static volatile int lastRetainedMaskSections;
   private static volatile long retainedMaskSectionsTotal;
   private static volatile int lastUnlistedMaskSections;
   private static volatile int lastRetainedTranslucentSections;
   public static final int COVERAGE_AUDIT_STRIDE = 9;
   public static final int COVERAGE_AUDIT_IN_FRUSTUM = 1;
   public static final int COVERAGE_AUDIT_NO_MASK = 2;
   private static volatile boolean coverageAuditRequested;
   private static volatile boolean coverageAuditCaptured;
   private static volatile int coverageAuditRegions;
   private static volatile long coverageAuditFrame;
   private static long[] coverageAuditKeys = new long[0];
   private static int[] coverageAuditWords = new int[0];
   private static Frustum coverageAuditFrustum;
   private static volatile long translucentFrames;
   private static volatile int lastTranslucentSections;
   private static volatile int lastTranslucentDraws;
   private static volatile long cancelledTranslucentGroups;
   private static volatile long translucentSeparateTargetFrames;
   private static volatile long translucentImprovedTransparencyFrames;
   private static volatile long translucentGatedSections;
   private static volatile long translucentMultiWGFrames;
   private static boolean multiWGLogged;
   private static volatile long translucentGatedFeedFrames;
   private static volatile int lastVisibleSectionsListed;
   private static volatile boolean coveragePassive;
   private static volatile long coverageTrips;
   private static volatile boolean deviceLost;
   private static boolean coverageWarned;
   private static volatile String occlusionError;
   private static volatile long occlusionFrames;
   private static volatile long bfsOnlyFrames;
   private static volatile long statsFrames;
   private static volatile int gpuSectionsDrawn;
   private static volatile int gpuPhaseASections;
   private static volatile int gpuPhaseBSections;
   private static volatile long lastPhaseBStatsFrame = -1L;
   private static volatile long lastDispatchChangeStatsFrame = -1L;
   private static volatile long occOverflowRegions;
   private static volatile long lastReadStatsFrame = -1L;
   private static volatile long pbSkipInputChangeStatsFrame;
   private static volatile long phaseBCpuSkipFrames;
   private static boolean pbSkipKeyValid;
   private static long pbSkipPosX;
   private static long pbSkipPosY;
   private static long pbSkipPosZ;
   private static long pbSkipFrusX;
   private static long pbSkipFrusY;
   private static long pbSkipFrusZ;
   private static final float[] pbSkipFrusMatrix = new float[16];
   private static final float[] pbSkipViewRot = new float[16];
   private static final float[] pbSkipProj = new float[16];
   private static final float[] pbSkipScratch = new float[16];
   private static int pbSkipExtentW = -1;
   private static int pbSkipExtentH = -1;
   private static long pbSkipEpoch = Long.MIN_VALUE;
   private static long pbSkipLastOccSerial = Long.MIN_VALUE;
   private static int pbSkipHalfMode = -1;
   private static volatile boolean phaseBCpuSkipArmed;
   private static volatile long frustumHealNudges;
   private static boolean projHealKeyValid;
   private static final float[] projHealKey = new float[16];
   private static final int HISTORY = 128;
   private static final long[] phaseBFrames = new long[128];
   private static final int[] phaseBCounts = new int[128];
   private static final int[] phaseACounts = new int[128];
   private static final long[] changeFrames = new long[64];
   private static int changeCursor;
   private static boolean broken;
   private static TerrainDrawPipeline taskPipeline;
   private static TerrainDrawPipeline taskPipelineExt;
   private static TerrainDrawPipeline cpuPipeline;
   private static TerrainDrawPipeline translucentPipeline;
   private static NvidiumPlusFrameLists frameLists;
   private static boolean frameListsFailed;
   private static CameraRenderState camera;
   private static long cachedEpoch = Long.MIN_VALUE;
   private static TerrainResidency.DrawSnapshot snapshot;
   private static long frameSerial;
   private static long opaqueOwnedSerial = -1L;
   private static long translucentOwnedSerial = -1L;
   private static long occGateSerial = -1L;
   private static long occCurStampsHandle;
   private static int occGateStamp32;
   private static final IntOpenHashSet occRasteredRegions = new IntOpenHashSet();
   private static final Long2IntOpenHashMap translucentSlotByPos = new Long2IntOpenHashMap();
   private static float[] transOrigins = new float[1536];
   private static int[] transMeta = new int[1536];
   private static long[] retTransKeys = new long[64];
   private static boolean[] transDrawnMark = new boolean[512];
   private static final IntArrayList transDrawnList = new IntArrayList();
   private static TerrainOcclusion occlusion;
   private static boolean occlusionBroken;
   private static long occFrameStamp = 16L;
   private static long prevOcclusionSignature;
   private static final ByteBuffer occUpload = ByteBuffer.allocateDirect(16384).order(ByteOrder.LITTLE_ENDIAN);
   private static float[] runOrigins = new float[768];
   private static int[] runQuads = new int[512];
   private static int[] regionMeta = new int[768];
   private static float[] regionOrigins = new float[768];
   private static final Long2IntOpenHashMap regionSlotByKey = new Long2IntOpenHashMap();
   private static int[] regionMasks = new int[2048];
   private static final ByteBuffer visUpload = ByteBuffer.allocateDirect(16384).order(ByteOrder.LITTLE_ENDIAN);
   private static final Matrix4f mvpScratch = new Matrix4f();
   private static long perfNanosAccum;
   private static long perfNanosMax;
   private static int perfFrames;
   private static long perfTaskGroupsAccum;
   private static long lastPerfLogNanos;
   private static final int EXTENDED_TASK_STAGE_STORAGE = 5;
   private static boolean taskStageWarned;

   public static boolean packedVaryings() {
      return PACKED_VARYINGS;
   }

   private static int maxQuadsByOutputMemory() {
      NvidiumPlusVulkanState.MeshShaderCaps caps = NvidiumPlusVulkanState.caps();
      return caps != null && caps.maxMeshOutputMemorySize() > 0 ? Math.max(1, caps.maxMeshOutputMemorySize() / MESH_OUTPUT_BYTES_PER_QUAD) : Integer.MAX_VALUE;
   }

   public static int meshWorkgroupQuads() {
      int v = resolvedMeshWgQuads;
      if (v < 0) {
         v = resolveKnob("nvidiumplus.tune.meshWorkgroupQuads", 32, 64);
         int memoryCap = maxQuadsByOutputMemory();
         int clamped = Math.min(v, memoryCap);
         if (clamped != v) {
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus mesh workgroup clamped {} -> {} quads: this device's maxMeshOutputMemorySize admits {} at {} output locations",
                  new Object[]{v, clamped, memoryCap, MESH_OUTPUT_LOCATIONS}
               );
         }

         if (NvidiumPlusVulkanState.caps() == null) {
            return clamped;
         }

         resolvedMeshWgQuads = clamped;
         v = clamped;
      }

      return v;
   }

   public static int taskWorkgroupSections() {
      int v = resolvedTaskWgSections;
      if (v < 0) {
         v = resolveKnob("nvidiumplus.tune.taskWorkgroupSections", 32, 128);
         resolvedTaskWgSections = v;
      }

      return v;
   }

   private static int resolveKnob(String property, int def, int max) {
      String raw = System.getProperty(property);
      if (raw == null) {
         return def;
      }

      int parsed;
      try {
         parsed = Integer.parseInt(raw.trim());
      } catch (NumberFormatException e) {
         NvidiumPlusLog.LOGGER.warn("NvidiumPlus: unparseable {}='{}' — using the default {}", new Object[]{property, raw, def});
         return def;
      }

      int clamped = Math.max(1, Math.min(max, parsed));
      if (clamped != parsed) {
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus: {}={} outside [1, {}] — clamped to {} (the ceiling argument is on the property's javadoc; 256-invocation mesh shapes need multi-quad-per-thread emission, which is not implemented)",
               new Object[]{property, parsed, max, clamped}
            );
      }

      if (clamped != def) {
         NvidiumPlusLog.LOGGER.info("NvidiumPlus wave-9 knob: {}={} (default {})", new Object[]{property, clamped, def});
      }

      return clamped;
   }

   private static boolean frontToBackEnabled() {
      String p = System.getProperty("nvidiumplus.tune.frontToBack");
      return p == null || Boolean.parseBoolean(p);
   }

   private static void sortRegionsFrontToBack(int dispatched) {
      if (dispatched > 1 && frontToBackEnabled()) {
         if (sortKeys.length < dispatched) {
            int n = Math.max(dispatched, sortKeys.length * 2);
            sortKeys = new long[n];
            sortMetaScratch = new int[3 * n];
            sortOriginScratch = new float[3 * n];
         }

         for (int r = 0; r < dispatched; r++) {
            float dx = regionOrigins[r * 3] + 64.0F;
            float dy = regionOrigins[r * 3 + 1] + 32.0F;
            float dz = regionOrigins[r * 3 + 2] + 64.0F;
            float d2 = dx * dx + dy * dy + dz * dz;
            sortKeys[r] = (long)Float.floatToIntBits(d2) << 32 | r;
         }

         Arrays.sort(sortKeys, 0, dispatched);

         for (int i = 0; i < dispatched; i++) {
            int src = (int)sortKeys[i];
            sortMetaScratch[i * 3] = regionMeta[src * 3];
            sortMetaScratch[i * 3 + 1] = regionMeta[src * 3 + 1];
            sortMetaScratch[i * 3 + 2] = regionMeta[src * 3 + 2];
            sortOriginScratch[i * 3] = regionOrigins[src * 3];
            sortOriginScratch[i * 3 + 1] = regionOrigins[src * 3 + 1];
            sortOriginScratch[i * 3 + 2] = regionOrigins[src * 3 + 2];
         }

         System.arraycopy(sortMetaScratch, 0, regionMeta, 0, dispatched * 3);
         System.arraycopy(sortOriginScratch, 0, regionOrigins, 0, dispatched * 3);
      }
   }

   private static ByteBuffer ccShadow(long bytes) {
      ByteBuffer b = ccShadow;
      if (b == null || b.capacity() < bytes) {
         b = ByteBuffer.allocateDirect((int)bytes).order(ByteOrder.LITTLE_ENDIAN);
         ccShadow = b;
      }

      return b;
   }

   private static boolean cachedCullFresh(CameraRenderState cam, Frustum frustum, boolean extLists, int occCapacity, int regionCount) {
      if (ccValid
         && ccEpoch == cachedEpoch
         && ccExtLists == extLists
         && ccCapacity == occCapacity
         && ccRegionCount == regionCount
         && ccFrontToBack == frontToBackEnabled()) {
         if (Double.doubleToRawLongBits(cam.pos.x) == ccPosX
            && Double.doubleToRawLongBits(cam.pos.y) == ccPosY
            && Double.doubleToRawLongBits(cam.pos.z) == ccPosZ
            && Double.doubleToRawLongBits(frustum.getCamX()) == ccFrusX
            && Double.doubleToRawLongBits(frustum.getCamY()) == ccFrusY
            && Double.doubleToRawLongBits(frustum.getCamZ()) == ccFrusZ) {
            ccReadMatrix(((FrustumAccessor)frustum).nvidiumplus$matrix(), ccMatrixScratch);

            for (int i = 0; i < 16; i++) {
               if (Float.floatToRawIntBits(ccMatrixScratch[i]) != Float.floatToRawIntBits(ccMatrix[i])) {
                  return false;
               }
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private static void ccStoreKey(CameraRenderState cam, Frustum frustum, boolean extLists, int occCapacity, int regionCount) {
      ccEpoch = cachedEpoch;
      ccPosX = Double.doubleToRawLongBits(cam.pos.x);
      ccPosY = Double.doubleToRawLongBits(cam.pos.y);
      ccPosZ = Double.doubleToRawLongBits(cam.pos.z);
      ccFrusX = Double.doubleToRawLongBits(frustum.getCamX());
      ccFrusY = Double.doubleToRawLongBits(frustum.getCamY());
      ccFrusZ = Double.doubleToRawLongBits(frustum.getCamZ());
      ccReadMatrix(((FrustumAccessor)frustum).nvidiumplus$matrix(), ccMatrix);
      ccExtLists = extLists;
      ccCapacity = occCapacity;
      ccRegionCount = regionCount;
      ccFrontToBack = frontToBackEnabled();
      ccValid = true;
   }

   private static void ccReadMatrix(Matrix4f m, float[] out) {
      out[0] = m.m00();
      out[1] = m.m01();
      out[2] = m.m02();
      out[3] = m.m03();
      out[4] = m.m10();
      out[5] = m.m11();
      out[6] = m.m12();
      out[7] = m.m13();
      out[8] = m.m20();
      out[9] = m.m21();
      out[10] = m.m22();
      out[11] = m.m23();
      out[12] = m.m30();
      out[13] = m.m31();
      out[14] = m.m32();
      out[15] = m.m33();
   }

   private TerrainDrawer() {
   }

   public static String lastError() {
      return lastError;
   }

   public static int framesDrawn() {
      return framesDrawn;
   }

   public static int lastDrawnSections() {
      return lastDrawnSections;
   }

   public static long totalDrawnSections() {
      return totalDrawnSections;
   }

   public static long cancelledGroups() {
      return cancelledGroups;
   }

   public static int regionsDispatched() {
      return regionsDispatched;
   }

   public static int sectionsVisibleIn() {
      return sectionsVisibleIn;
   }

   public static long dispatchSignature() {
      return dispatchSignature;
   }

   public static long taskCullFrames() {
      return taskCullFrames;
   }

   public static long cpuCullFrames() {
      return cpuCullFrames;
   }

   public static long maskOverflowRegions() {
      return maskOverflowRegions;
   }

   public static int lastRetainedMaskSections() {
      return lastRetainedMaskSections;
   }

   public static long retainedMaskSectionsTotal() {
      return retainedMaskSectionsTotal;
   }

   public static int lastUnlistedMaskSections() {
      return lastUnlistedMaskSections;
   }

   public static void armCoverageAudit() {
      coverageAuditCaptured = false;
      coverageAuditRegions = 0;
      coverageAuditRequested = true;
   }

   public static boolean coverageAuditCaptured() {
      return coverageAuditCaptured;
   }

   public static int coverageAuditRegions() {
      return coverageAuditRegions;
   }

   public static long coverageAuditFrame() {
      return coverageAuditFrame;
   }

   public static long[] coverageAuditKeys() {
      return coverageAuditKeys;
   }

   public static int[] coverageAuditWords() {
      return coverageAuditWords;
   }

   public static boolean coverageAuditSectionInFrustum(int sx, int sy, int sz) {
      Frustum f = coverageAuditFrustum;
      if (f == null) {
         return false;
      }

      double x = sx * 16.0;
      double y = sy * 16.0;
      double z = sz * 16.0;
      return f.isVisible(new AABB(x, y, z, x + 16.0, y + 16.0, z + 16.0));
   }

   public static int lastRetainedTranslucentSections() {
      return lastRetainedTranslucentSections;
   }

   public static long translucentGatedFeedFrames() {
      return translucentGatedFeedFrames;
   }

   public static int lastVisibleSectionsListed() {
      return lastVisibleSectionsListed;
   }

   public static int minVisibleSectionsListed() {
      return Math.max(0, SectionBuildTap.visibleSectionsListedMin());
   }

   public static int maxVisibleSectionsListed() {
      return Math.max(0, SectionBuildTap.visibleSectionsListedMax());
   }

   public static long translucentFrames() {
      return translucentFrames;
   }

   public static long translucentSeparateTargetFrames() {
      return translucentSeparateTargetFrames;
   }

   public static long improvedTransparencyFrames() {
      return translucentSeparateTargetFrames + translucentImprovedTransparencyFrames;
   }

   public static void noteTranslucentUnderImprovedTransparency() {
      translucentImprovedTransparencyFrames++;
   }

   public static int lastTranslucentSections() {
      return lastTranslucentSections;
   }

   public static int lastTranslucentDraws() {
      return lastTranslucentDraws;
   }

   public static long cancelledTranslucentGroups() {
      return cancelledTranslucentGroups;
   }

   public static boolean opaqueOwnedThisFrame() {
      return opaqueOwnedSerial == frameSerial;
   }

   public static boolean translucentOwnedThisFrame() {
      return translucentOwnedSerial == frameSerial;
   }

   public static long translucentGatedSections() {
      return translucentGatedSections;
   }

   public static long translucentMultiWGFrames() {
      return translucentMultiWGFrames;
   }

   public static String occlusionError() {
      return occlusionError;
   }

   public static long occlusionFrames() {
      return occlusionFrames;
   }

   public static long bfsOnlyFrames() {
      return bfsOnlyFrames;
   }

   public static long statsFrames() {
      return statsFrames;
   }

   public static int gpuSectionsDrawn() {
      return gpuSectionsDrawn;
   }

   public static int gpuPhaseASections() {
      return gpuPhaseASections;
   }

   public static int gpuPhaseBSections() {
      return gpuPhaseBSections;
   }

   public static long lastPhaseBStatsFrame() {
      return lastPhaseBStatsFrame;
   }

   public static long lastDispatchChangeStatsFrame() {
      return lastDispatchChangeStatsFrame;
   }

   public static long occOverflowRegions() {
      return occOverflowRegions;
   }

   public static long lastReadStatsFrame() {
      return lastReadStatsFrame;
   }

   public static long phaseBCpuSkipFrames() {
      return phaseBCpuSkipFrames;
   }

   public static boolean phaseBCpuSkipArmed() {
      return phaseBCpuSkipArmed;
   }

   public static int gpuSectionsAAt(long f) {
      if (f < 0L) {
         return -1;
      }

      int i = (int)(f % 128L);
      return phaseBFrames[i] == f ? phaseACounts[i] : -1;
   }

   public static VisibleSetSample debugVisibleSet() {
      TerrainOcclusion occ = occlusion;
      return occ == null ? null : occ.debugVisibleSet();
   }

   public static long frustumHealNudges() {
      return frustumHealNudges;
   }

   public static long phaseBSkipInputChangeStatsFrame() {
      return Math.max(pbSkipInputChangeStatsFrame, lastDispatchChangeStatsFrame);
   }

   public static int gpuPhaseBAt(long f) {
      if (f < 0L) {
         return -1;
      }

      int i = (int)(f % 128L);
      return phaseBFrames[i] == f ? phaseBCounts[i] : -1;
   }

   public static long firstDispatchChangeAtOrAfter(long f) {
      long best = -1L;

      for (long c : changeFrames) {
         if (c >= f && (best < 0L || c < best)) {
            best = c;
         }
      }

      return best;
   }

   public static boolean coveragePassive() {
      return coveragePassive;
   }

   public static long coverageTrips() {
      return coverageTrips;
   }

   public static boolean deviceLost() {
      return deviceLost;
   }

   private static void latchError(Throwable t) {
      boolean first = lastError == null;
      lastError = t.toString();
      if (first) {
         NvidiumPlusNotify.chat("nvidiumplus.chat.error.renderer");
      }
   }

   public static long prepSkippedFrames() {
      return prepSkippedFrames;
   }

   public static long prepSkipHoleFrames() {
      return prepSkipHoleFrames;
   }

   public static long cachedCullHitFrames() {
      return cachedCullHits;
   }

   public static long cachedCullMissFrames() {
      return cachedCullMisses;
   }

   public static boolean wouldOwnFrame() {
      if (!broken && !deviceLost) {
         if (TerrainResidency.dropsThisWorld() != 0L) {
            return false;
         } else {
            CameraRenderState cam = camera;
            if (cam != null && cam.initialized && cam.cullFrustum != null) {
               RenderTarget target = McCompat.opaqueTarget();
               return target != null && target.getColorTextureView() != null && target.getDepthTextureView() != null
                  ? Minecraft.getInstance().gameRenderer.lightmap() != null
                  : false;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   public static void notePrepSkipped() {
      prepSkippedSerial = frameSerial;
      prepSkippedFrames++;
   }

   private static void countPrepSkipHole() {
      prepSkipHoleFrames++;
      if (!prepSkipHoleWarned) {
         prepSkipHoleWarned = true;
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus skipVanillaPrep predicted a NvidiumPlus-owned frame but the drawer did not own it — vanilla drew this ONE frame from the skipped (empty) prep. This is the documented first-throw edge; counted in prepSkipHoleFrames (bench legs require it to stay 0; once-only report)"
            );
      }
   }

   private static boolean notePrepOutcome(boolean owned) {
      if (!owned && prepSkippedSerial == frameSerial) {
         countPrepSkipHole();
      }

      return owned;
   }

   private static boolean coverageGuardBlocks() {
      if (TerrainResidency.dropsThisWorld() == 0L) {
         coveragePassive = false;
         return false;
      } else {
         coveragePassive = true;
         reportCoverageTripOnce();
         if (VanillaUploadSeam.suppressedThisWorld() && !VanillaUploadSeam.vanillaHasGeometry()) {
            VanillaUploadSeam.demote("coverage guard tripped");
            return false;
         } else {
            return true;
         }
      }
   }

   private static void reportCoverageTripOnce() {
      if (!coverageWarned) {
         coverageWarned = true;
         NvidiumPlusNotify.chat("nvidiumplus.chat.error.coverage");
         coverageTrips++;
         TerrainResidency.Counters c = TerrainResidency.counters();
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus coverage guard: sections were dropped this world — {} — (arenaFull={}, oversize={}, regionBudget={}, encoding={} — lifetime counts) [latched error: {}] so a NvidiumPlus frame would have holes; vanilla draws everything until a world load with clean counters (once-only report)",
               new Object[]{
                  TerrainResidency.guardTripDescription(),
                  c.droppedArenaFull(),
                  c.droppedOversize(),
                  c.droppedRegionBudget(),
                  c.droppedEncoding(),
                  TerrainResidency.lastError() == null ? "none" : TerrainResidency.lastError()
               }
            );
      }
   }

   public static void onDispatcherDispose() {
      if (occlusion != null) {
         occlusion.destroy();
         occlusion = null;
      }

      if (frameLists != null) {
         frameLists.destroy();
         frameLists = null;
      }

      frameListsFailed = false;
      cachedEpoch = Long.MIN_VALUE;
      snapshot = null;
      ccValid = false;
      ccShadow = null;
      coverageWarned = false;
      occGateSerial = -1L;
      occCurStampsHandle = 0L;
      occRasteredRegions.clear();
      translucentSlotByPos.clear();
      opaqueOwnedSerial = -1L;
      statsFrames = 0L;
      gpuSectionsDrawn = 0;
      gpuPhaseASections = 0;
      gpuPhaseBSections = 0;
      lastPhaseBStatsFrame = -1L;
      lastDispatchChangeStatsFrame = -1L;
      lastReadStatsFrame = -1L;
      prevOcclusionSignature = 0L;
      pbSkipKeyValid = false;
      pbSkipInputChangeStatsFrame = 0L;
      pbSkipEpoch = Long.MIN_VALUE;
      pbSkipLastOccSerial = Long.MIN_VALUE;
      projHealKeyValid = false;
      Arrays.fill(phaseBFrames, -1L);
      Arrays.fill(changeFrames, -1L);
      changeCursor = 0;
   }

   public static void onPinnedRegrow() {
      if (occlusion != null) {
         occlusion.destroy();
         occlusion = null;
      }

      if (frameLists != null) {
         frameLists.destroy();
         frameLists = null;
      }

      frameListsFailed = false;
      cachedEpoch = Long.MIN_VALUE;
      snapshot = null;
      ccValid = false;
      ccShadow = null;
      occGateSerial = -1L;
      occCurStampsHandle = 0L;
      occRasteredRegions.clear();
      translucentSlotByPos.clear();
      opaqueOwnedSerial = -1L;
      statsFrames = 0L;
      gpuSectionsDrawn = 0;
      gpuPhaseASections = 0;
      gpuPhaseBSections = 0;
      lastPhaseBStatsFrame = -1L;
      lastDispatchChangeStatsFrame = -1L;
      lastReadStatsFrame = -1L;
      prevOcclusionSignature = 0L;
      pbSkipKeyValid = false;
      pbSkipInputChangeStatsFrame = 0L;
      pbSkipEpoch = Long.MIN_VALUE;
      pbSkipLastOccSerial = Long.MIN_VALUE;
      projHealKeyValid = false;
      Arrays.fill(phaseBFrames, -1L);
      Arrays.fill(changeFrames, -1L);
      changeCursor = 0;
   }

   public static void destroyDeviceObjects(VkDevice device) {
      if (taskPipeline != null) {
         taskPipeline.destroy(device);
         taskPipeline = null;
      }

      if (taskPipelineExt != null) {
         taskPipelineExt.destroy(device);
         taskPipelineExt = null;
      }

      if (cpuPipeline != null) {
         cpuPipeline.destroy(device);
         cpuPipeline = null;
      }

      if (translucentPipeline != null) {
         translucentPipeline.destroy(device);
         translucentPipeline = null;
      }

      NvidiumPlusGpuTimers.destroyDeviceObjects();
      if (occlusion != null) {
         NvidiumPlusLog.LOGGER.warn("NvidiumPlus occlusion buffers still live at device close (the dispatcher dispose never ran?); destroying directly");
         occlusion.destroyNow();
         occlusion = null;
      }

      if (frameLists != null) {
         NvidiumPlusLog.LOGGER.warn("NvidiumPlus extended frame lists still live at device close (the dispatcher dispose never ran?); destroying directly");
         frameLists.destroyNow();
         frameLists = null;
      }

      TerrainOcclusion.destroyPipelines(device);
      SodiumTerrainDrawer.destroyDeviceObjects(device);
   }

   public static void beginFrame(CameraRenderState cameraRenderState) {
      camera = cameraRenderState;
      frameSerial++;
      if (cameraRenderState != null && cameraRenderState.initialized && cameraRenderState.blockPos != null) {
         SectionBuildTap.publishCameraSection(cameraRenderState.blockPos.getX() >> 4, cameraRenderState.blockPos.getZ() >> 4);
      }

      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft != null && minecraft.levelRenderer != null) {
         int listed = minecraft.levelRenderer.visibleSections().size();
         lastVisibleSectionsListed = listed;
         SectionBuildTap.publishVisibleSections(listed);
      }
   }

   private static void healFrustumOnProjectionChange(CameraRenderState cam) {
      boolean changed = pbSkipMatrixChanged(cam.projectionMatrix, projHealKey);
      if (!projHealKeyValid) {
         projHealKeyValid = true;
      } else if (changed) {
         ((SectionOcclusionGraphAccessor)Minecraft.getInstance().levelRenderer.sectionOcclusionGraph()).nvidiumplus$needsFrustumUpdate().set(true);
         frustumHealNudges++;
      }
   }

   public static boolean drawOpaque(ChunkSectionsToRender sections, GpuSampler atlasSampler, GpuTextureView atlasView) {
      if (broken) {
         return notePrepOutcome(false);
      }

      if (coverageGuardBlocks()) {
         opaqueOwnedSerial = -1L;
         return notePrepOutcome(false);
      }

      try {
         long t0 = System.nanoTime();
         boolean owned = drawOpaqueInner(sections, atlasSampler, atlasView);
         opaqueOwnedSerial = owned ? frameSerial : -1L;
         if (owned) {
            cancelledGroups++;
            long dt = System.nanoTime() - t0;
            if (NvidiumPlusCpuStages.ARMED) {
               NvidiumPlusCpuStages.record(4, dt);
            }

            recordPerf(dt);
         }

         return notePrepOutcome(owned);
      } catch (GpuDeviceLossException t) {
         deviceLost = true;
         broken = true;
         latchError(t);
         NvidiumPlusLog.LOGGER
            .error("GPU device lost during NvidiumPlus's terrain pass; NvidiumPlus goes passive (vanilla will report the loss on its own next call)", t);
         return notePrepOutcome(false);
      } catch (Throwable t) {
         broken = true;
         latchError(t);
         NvidiumPlusLog.LOGGER.error("NvidiumPlus terrain draw failed; vanilla terrain resumes for this session (first and only report)", t);
         return notePrepOutcome(false);
      }
   }

   private static boolean drawOpaqueInner(ChunkSectionsToRender sections, GpuSampler atlasSampler, GpuTextureView atlasView) {
      CameraRenderState cam = camera;
      if (cam != null && cam.initialized && cam.cullFrustum != null) {
         healFrustumOnProjectionChange(cam);
         RenderTarget target = McCompat.opaqueTarget();
         GpuTextureView colorView = target.getColorTextureView();
         GpuTextureView depthView = target.getDepthTextureView();
         GpuTextureView lightmapView = Minecraft.getInstance().gameRenderer.lightmap();
         if (colorView != null && depthView != null && atlasView != null && lightmapView != null) {
            TerrainResidency.DrawSnapshot fresh = TerrainResidency.drawSnapshot(cachedEpoch);
            if (fresh != null) {
               snapshot = fresh;
               cachedEpoch = fresh.epoch();
               rebuildRegionMap(fresh);
            }

            TerrainResidency.DrawSnapshot snap = snapshot;
            if (snap == null || snap.arenaBackingHandle() == 0L) {
               lastDrawnSections = 0;
               return prepSkippedSerial == frameSerial;
            }

            if (snap.sectionCount() == 0) {
               lastDrawnSections = 0;
               return true;
            }

            if (Boolean.getBoolean("nvidiumplus.terrainDraw.cpuCull") || snap.sectionRecordsHandle() == 0L) {
               return drawCpuCulled(snap, cam, atlasSampler, colorView, depthView, atlasView, lightmapView);
            }

            if (NvidiumPlusConfig.occlusionCullingEnabled(effectiveRenderDistance()) && !occlusionBroken) {
               try {
                  Boolean occluded = drawOcclusionCulled(snap, cam, atlasSampler, colorView, depthView, atlasView, lightmapView);
                  if (occluded != null) {
                     return occluded;
                  }
               } catch (GpuDeviceLossException t) {
                  throw t;
               } catch (Throwable t) {
                  occlusionBroken = true;
                  occlusionError = t.toString();
                  NvidiumPlusLog.LOGGER
                     .error("NvidiumPlus occlusion culling failed; reverting to the BFS visibility feed for this session (first and only report)", t);
               }
            }

            return drawTaskCulled(snap, cam, atlasSampler, colorView, depthView, atlasView, lightmapView);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private static Boolean drawOcclusionCulled(
      TerrainResidency.DrawSnapshot snap,
      CameraRenderState cam,
      GpuSampler atlasSampler,
      GpuTextureView colorView,
      GpuTextureView depthView,
      GpuTextureView atlasView,
      GpuTextureView lightmapView
   ) {
      if (occlusion == null) {
         occlusion = TerrainOcclusion.create();
         if (occlusion == null) {
            return null;
         }
      }

      boolean extLists = ensureFrameLists();
      int occCapacity = extLists ? frameLists.capacity() : 512;
      int regionCount = snap.regionCount();
      int[] rd = snap.regionData();
      Frustum frustum = cam.cullFrustum;
      double camX = cam.pos.x;
      double camY = cam.pos.y;
      double camZ = cam.pos.z;
      long stamp = ++occFrameStamp;
      int frameStamp32 = (int)stamp;
      boolean cacheOn = NvidiumPlusConfig.cachedCullEnabled();
      ByteBuffer occDst;
      if (!cacheOn) {
         ccValid = false;
         occDst = extLists ? frameLists.occWriteView(frameSerial) : occUpload;
      } else {
         occDst = extLists ? ccShadow(frameLists.occRange()) : occUpload;
      }

      boolean cacheHit = cacheOn && cachedCullFresh(cam, frustum, extLists, occCapacity, regionCount);
      int dispatched;
      long sig;
      if (cacheHit) {
         dispatched = ccDispatched;
         sig = ccSig;
         occOverflowRegions = occOverflowRegions + ccOverflowThisFrame;
         cachedCullHits++;
      } else {
         int built = 0;
         long builtSig = 0L;
         long overflowThisFrame = 0L;
         occRasteredRegions.clear();

         for (int r = 0; r < regionCount; r++) {
            int ro = r * 7;
            int id = rd[ro];
            int count = rd[ro + 4];
            if (count > 0) {
               double bx = rd[ro + 1] * 128.0;
               double by = rd[ro + 2] * 64.0;
               double bz = rd[ro + 3] * 128.0;
               if (frustum.isVisible(new AABB(bx, by, bz, bx + 128.0, by + 64.0, bz + 128.0))) {
                  if ((built + 1) * 3 > regionMeta.length) {
                     regionMeta = Arrays.copyOf(regionMeta, regionMeta.length * 2);
                     regionOrigins = Arrays.copyOf(regionOrigins, regionOrigins.length * 2);
                  }

                  float ox = (float)(bx - camX);
                  float oy = (float)(by - camY);
                  float oz = (float)(bz - camZ);
                  regionOrigins[built * 3] = ox;
                  regionOrigins[built * 3 + 1] = oy;
                  regionOrigins[built * 3 + 2] = oz;
                  int slot;
                  if (built < occCapacity) {
                     slot = built;
                     occRasteredRegions.add(id);
                     int dst = slot * 32;
                     occDst.putFloat(dst, ox);
                     occDst.putFloat(dst + 4, oy);
                     occDst.putFloat(dst + 8, oz);
                     occDst.putFloat(dst + 12, 0.0F);
                     occDst.putInt(dst + 16, id);
                     occDst.putInt(dst + 20, count);
                     occDst.putInt(dst + 24, rd[ro + 5]);
                     occDst.putInt(dst + 28, rd[ro + 6]);
                  } else {
                     slot = -1;
                     overflowThisFrame++;
                  }

                  regionMeta[built * 3] = id;
                  regionMeta[built * 3 + 1] = slot;
                  regionMeta[built * 3 + 2] = (count + taskWorkgroupSections() - 1) / taskWorkgroupSections();
                  builtSig += (id + 1L) * (2L * id + 31L);
                  built++;
               }
            }
         }

         dispatched = built;
         sig = builtSig;
         occOverflowRegions += overflowThisFrame;
         if (cacheOn) {
            cachedCullMisses++;
            ccDispatched = dispatched;
            ccSig = sig;
            ccOverflowThisFrame = overflowThisFrame;
            ccStoreKey(cam, frustum, extLists, occCapacity, regionCount);
         }
      }

      regionsDispatched = dispatched;
      dispatchSignature = sig;
      if (sig != prevOcclusionSignature) {
         prevOcclusionSignature = sig;
         lastDispatchChangeStatsFrame = statsFrames;
         changeFrames[changeCursor] = statsFrames;
         changeCursor = (changeCursor + 1) % changeFrames.length;
      }

      if (dispatched == 0) {
         lastDrawnSections = 0;
         return true;
      }

      if (!cacheHit) {
         sortRegionsFrontToBack(dispatched);
      }

      pullGpuStats(true);
      int halfMode = 0;
      if (occlusion != null) {
         Matrix4f bound = NvidiumPlusProjectionCapture.lastIfBound(RenderSystem.getProjectionMatrixBuffer());
         if (bound != null && RenderSystem.getProjectionType() == ProjectionType.PERSPECTIVE) {
            if (!bound.equals(cam.projectionMatrix)) {
               TerrainOcclusion.halfResArmProjectionMismatches++;
            }

            long preBobSerial = NvidiumPlusProjectionCapture.preBobSerial();
            halfMode = occlusion.armHalfRes(
               colorView,
               depthView,
               bound,
               NvidiumPlusProjectionCapture.preBob(),
               cam.viewRotationMatrix,
               preBobSerial,
               VulkanConst.toVk(colorView.texture().getFormat()),
               VulkanConst.toVk(depthView.texture().getFormat()),
               false,
               extLists
            );
         }
      }

      boolean phaseBCpuSkip = phaseBCpuSkipDecide(cam, frustum, depthView, halfMode);
      CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
      GpuBufferSlice sceneSlice = uploadScene(encoder, cam, atlasView.getWidth(0), atlasView.getHeight(0));
      int rasterCount = Math.min(dispatched, occCapacity);
      TerrainOcclusion.ListSlice occListSlice;
      if (extLists) {
         if (cacheOn) {
            ByteBuffer ring = frameLists.occWriteView(frameSerial);
            ByteBuffer src = occDst.duplicate();
            src.position(0).limit(rasterCount * 32);
            ring.put(src);
         }

         occListSlice = new TerrainOcclusion.ListSlice(frameLists.occBuffer(), frameLists.occOffset(frameSerial), frameLists.occRange(), true);
      } else {
         occUpload.clear();
         occListSlice = TerrainOcclusion.ListSlice.ofUniformSlice(encoder.transientMemory().uploadGpu(occUpload, 256L, 128));
      }

      long prevStamps = occlusion.prevStampsBuffer(stamp);
      long curStamps = occlusion.curStampsBuffer(stamp);
      long taskGroupsThisFrame = 0L;
      NvidiumPlusGpuTimers.beginOpaque(encoder, frameSerial);
      RenderPass pass = encoder.createRenderPass(() -> "NvidiumPlus terrain phase A", colorView, Optional.empty(), depthView, OptionalDouble.empty());

      try {
         VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
         VulkanRenderPassAccessor vkPass = (VulkanRenderPassAccessor)backendPass;
         VkCommandBuffer cb = vkPass.nvidiumplus$commandBuffer();
         TerrainDrawPipeline p = pipelineFor(vkPass, colorView, depthView, true, extLists);
         occlusion.ensurePipelines(VulkanConst.toVk(colorView.texture().getFormat()), VulkanConst.toVk(depthView.texture().getFormat()), extLists);
         VK10.vkCmdBindPipeline(cb, 0, p.pipeline());
         pushDescriptors(
            cb,
            p,
            snap.arenaBlockHandles(),
            sceneSlice,
            atlasView,
            atlasSampler,
            lightmapView,
            snap.sectionRecordsHandle(),
            occListSlice,
            prevStamps,
            curStamps,
            occlusion.statsBuffer()
         );
         taskGroupsThisFrame += recordPhaseDraws(cb, p, dispatched, frameStamp32, 1);
      } catch (Throwable var63) {
         if (pass != null) {
            try {
               pass.close();
            } catch (Throwable var58) {
               var63.addSuppressed(var58);
            }
         }

         throw var63;
      }

      if (pass != null) {
         pass.close();
      }

      NvidiumPlusGpuTimers.mark(encoder, 1);
      GpuTextureView rasterColorView = colorView;
      GpuTextureView rasterDepthView = depthView;
      if (halfMode != 0) {
         rasterColorView = occlusion.halfColorView();
         rasterDepthView = occlusion.halfDepthView();
         GpuTextureView passColor = rasterColorView;
         GpuTextureView passDepth = rasterDepthView;
         RenderPass passx = encoder.createRenderPass(
            () -> "NvidiumPlus occlusion depth downsample", passColor, Optional.empty(), passDepth, OptionalDouble.of(0.0)
         );

         try {
            VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)passx).nvidiumplus$backend();
            VkCommandBuffer cb = ((VulkanRenderPassAccessor)backendPass).nvidiumplus$commandBuffer();
            occlusion.recordDepthDownsample(cb, depthView);
         } catch (Throwable var62) {
            if (passx != null) {
               try {
                  passx.close();
               } catch (Throwable var57) {
                  var62.addSuppressed(var57);
               }
            }

            throw var62;
         }

         if (passx != null) {
            passx.close();
         }

         NvidiumPlusGpuTimers.mark(encoder, 8);
      }

      GpuTextureView rasterColor = rasterColorView;
      GpuTextureView rasterDepth = rasterDepthView;
      RenderPass passx = encoder.createRenderPass(() -> "NvidiumPlus occlusion regions", rasterColor, Optional.empty(), rasterDepth, OptionalDouble.empty());

      try {
         VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)passx).nvidiumplus$backend();
         VkCommandBuffer cb = ((VulkanRenderPassAccessor)backendPass).nvidiumplus$commandBuffer();
         occlusion.recordRegionRaster(cb, occListSlice, sceneSlice, rasterCount, frameStamp32, halfMode);
      } catch (Throwable var61) {
         if (passx != null) {
            try {
               passx.close();
            } catch (Throwable var56) {
               var61.addSuppressed(var56);
            }
         }

         throw var61;
      }

      if (passx != null) {
         passx.close();
      }

      NvidiumPlusGpuTimers.mark(encoder, 2);
      passx = encoder.createRenderPass(() -> "NvidiumPlus occlusion sections", rasterColor, Optional.empty(), rasterDepth, OptionalDouble.empty());

      try {
         VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)passx).nvidiumplus$backend();
         VkCommandBuffer cb = ((VulkanRenderPassAccessor)backendPass).nvidiumplus$commandBuffer();
         occlusion.recordSectionRaster(cb, occListSlice, sceneSlice, snap.sectionRecordsHandle(), rasterCount, frameStamp32, curStamps, halfMode);
      } catch (Throwable var60) {
         if (passx != null) {
            try {
               passx.close();
            } catch (Throwable var55) {
               var60.addSuppressed(var55);
            }
         }

         throw var60;
      }

      if (passx != null) {
         passx.close();
      }

      NvidiumPlusGpuTimers.mark(encoder, 3);
      boolean phaseBSkipUnsafe = Boolean.getBoolean("nvidiumplus.occlusion.phaseBSkipUnsafe");
      if (!phaseBSkipUnsafe && !phaseBCpuSkip) {
         RenderPass passxx = encoder.createRenderPass(() -> "NvidiumPlus terrain phase B", colorView, Optional.empty(), depthView, OptionalDouble.empty());

         try {
            VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)passxx).nvidiumplus$backend();
            VulkanRenderPassAccessor vkPass = (VulkanRenderPassAccessor)backendPass;
            VkCommandBuffer cb = vkPass.nvidiumplus$commandBuffer();
            TerrainDrawPipeline p = pipelineFor(vkPass, colorView, depthView, true, extLists);
            VK10.vkCmdBindPipeline(cb, 0, p.pipeline());
            pushDescriptors(
               cb,
               p,
               snap.arenaBlockHandles(),
               sceneSlice,
               atlasView,
               atlasSampler,
               lightmapView,
               snap.sectionRecordsHandle(),
               occListSlice,
               prevStamps,
               curStamps,
               occlusion.statsBuffer()
            );
            boolean phaseBPredicated = occlusion.phaseBPredicateActive();
            if (phaseBPredicated) {
               MemoryStack stack = MemoryStack.stackPush();

               try {
                  VkConditionalRenderingBeginInfoEXT begin = VkConditionalRenderingBeginInfoEXT.calloc(stack)
                     .sType(1000081002)
                     .buffer(occlusion.predicateVkBuffer())
                     .offset(0L)
                     .flags(0);
                  EXTConditionalRendering.vkCmdBeginConditionalRenderingEXT(cb, begin);
               } catch (Throwable var59) {
                  if (stack != null) {
                     try {
                        stack.close();
                     } catch (Throwable var54) {
                        var59.addSuppressed(var54);
                     }
                  }

                  throw var59;
               }

               if (stack != null) {
                  stack.close();
               }
            }

            taskGroupsThisFrame += recordPhaseDraws(cb, p, dispatched, frameStamp32, 2);
            if (phaseBPredicated) {
               EXTConditionalRendering.vkCmdEndConditionalRenderingEXT(cb);
            }
         } catch (Throwable var64) {
            if (passxx != null) {
               try {
                  passxx.close();
               } catch (Throwable var53) {
                  var64.addSuppressed(var53);
               }
            }

            throw var64;
         }

         if (passxx != null) {
            passxx.close();
         }
      }

      NvidiumPlusGpuTimers.mark(encoder, 4);
      occlusion.recordStatsTransfer(statsFrames);
      occlusion.recordStampsTransfer(statsFrames, curStamps, frameStamp32);
      statsFrames++;
      occGateSerial = frameSerial;
      occCurStampsHandle = curStamps;
      occGateStamp32 = frameStamp32;
      perfTaskGroupsAccum += taskGroupsThisFrame;
      framesDrawn++;
      taskCullFrames++;
      occlusionFrames++;
      totalDrawnSections = totalDrawnSections + Math.max(gpuSectionsDrawn, 0);
      return true;
   }

   private static int effectiveRenderDistance() {
      Minecraft client = Minecraft.getInstance();
      return client != null && client.options != null ? client.options.getEffectiveRenderDistance() : 0;
   }

   private static long recordPhaseDraws(VkCommandBuffer cb, TerrainDrawPipeline p, int dispatched, int frameStamp32, int mode) {
      long taskGroups = 0L;
      MemoryStack stack = MemoryStack.stackPush();

      try {
         ByteBuffer push = stack.calloc(32);
         int pushStages = p.pushStageFlags();

         for (int r = 0; r < dispatched; r++) {
            int slot = regionMeta[r * 3 + 1];
            int visMode;
            int maskSlot;
            if (slot >= 0) {
               visMode = mode;
               maskSlot = -1;
            } else {
               if (mode != 1) {
                  continue;
               }

               visMode = 0;
               maskSlot = -1;
            }

            push.putFloat(0, regionOrigins[r * 3]);
            push.putFloat(4, regionOrigins[r * 3 + 1]);
            push.putFloat(8, regionOrigins[r * 3 + 2]);
            push.putInt(12, regionMeta[r * 3]);
            push.putInt(16, maskSlot);
            push.putInt(20, visMode);
            push.putInt(24, frameStamp32);
            push.putInt(28, 1);
            VK10.vkCmdPushConstants(cb, p.pipelineLayout(), pushStages, 0, push);
            int groups = regionMeta[r * 3 + 2];
            EXTMeshShader.vkCmdDrawMeshTasksEXT(cb, groups, 1, 1);
            taskGroups += groups;
         }
      } catch (Throwable var16) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var15) {
               var16.addSuppressed(var15);
            }
         }

         throw var16;
      }

      if (stack != null) {
         stack.close();
      }

      return taskGroups;
   }

   private static void pullGpuStats(boolean adoptAsPrimary) {
      if (occlusion != null) {
         long readFrame = statsFrames - 3L;
         int[] s = occlusion.readStats(readFrame);
         if (s != null) {
            int total = s[0] + s[1] + s[2];
            gpuSectionsDrawn = total;
            gpuPhaseASections = s[1];
            gpuPhaseBSections = s[2];
            if (adoptAsPrimary) {
               lastDrawnSections = total;
               sectionsVisibleIn = total;
            }

            if (s[2] > 0) {
               lastPhaseBStatsFrame = readFrame;
            }

            int i = (int)(readFrame % 128L);
            phaseBFrames[i] = readFrame;
            phaseBCounts[i] = s[2];
            phaseACounts[i] = s[1];
            occlusion.foldVisibleSet(readFrame);
            lastReadStatsFrame = readFrame;
         }
      }
   }

   private static boolean phaseBCpuSkipDecide(CameraRenderState cam, Frustum frustum, GpuTextureView depthView, int halfMode) {
      String cpuSkipProp = System.getProperty("nvidiumplus.occlusion.phaseBCpuSkip");
      if (cpuSkipProp != null && !Boolean.parseBoolean(cpuSkipProp)) {
         pbSkipKeyValid = false;
         phaseBCpuSkipArmed = false;
         return false;
      }

      if (occlusion.phaseBPredicateActive()) {
         phaseBCpuSkipArmed = false;
         return false;
      }

      boolean changed = !pbSkipKeyValid;
      long posX = Double.doubleToRawLongBits(cam.pos.x);
      long posY = Double.doubleToRawLongBits(cam.pos.y);
      long posZ = Double.doubleToRawLongBits(cam.pos.z);
      long frusX = Double.doubleToRawLongBits(frustum.getCamX());
      long frusY = Double.doubleToRawLongBits(frustum.getCamY());
      long frusZ = Double.doubleToRawLongBits(frustum.getCamZ());
      if (posX != pbSkipPosX || posY != pbSkipPosY || posZ != pbSkipPosZ || frusX != pbSkipFrusX || frusY != pbSkipFrusY || frusZ != pbSkipFrusZ) {
         changed = true;
         pbSkipPosX = posX;
         pbSkipPosY = posY;
         pbSkipPosZ = posZ;
         pbSkipFrusX = frusX;
         pbSkipFrusY = frusY;
         pbSkipFrusZ = frusZ;
      }

      changed |= pbSkipMatrixChanged(((FrustumAccessor)frustum).nvidiumplus$matrix(), pbSkipFrusMatrix);
      changed |= pbSkipMatrixChanged(cam.viewRotationMatrix, pbSkipViewRot);
      changed |= pbSkipMatrixChanged(cam.projectionMatrix, pbSkipProj);
      int extentW = depthView.texture().getWidth(0);
      int extentH = depthView.texture().getHeight(0);
      if (extentW != pbSkipExtentW || extentH != pbSkipExtentH) {
         changed = true;
         pbSkipExtentW = extentW;
         pbSkipExtentH = extentH;
      }

      if (halfMode != pbSkipHalfMode) {
         changed = true;
         pbSkipHalfMode = halfMode;
      }

      if (cachedEpoch != pbSkipEpoch) {
         changed = true;
         pbSkipEpoch = cachedEpoch;
      }

      if (!TerrainResidency.gpuCommitBacklogEmpty()) {
         changed = true;
      }

      if (frameSerial != pbSkipLastOccSerial + 1L) {
         changed = true;
      }

      pbSkipLastOccSerial = frameSerial;
      pbSkipKeyValid = true;
      if (changed) {
         pbSkipInputChangeStatsFrame = statsFrames;
      }

      long c = Math.max(pbSkipInputChangeStatsFrame, lastDispatchChangeStatsFrame);
      boolean skip = lastReadStatsFrame >= c + 2L && lastPhaseBStatsFrame <= c;
      phaseBCpuSkipArmed = skip;
      if (skip) {
         phaseBCpuSkipFrames++;
      }

      return skip;
   }

   private static boolean pbSkipMatrixChanged(Matrix4f m, float[] prev) {
      ccReadMatrix(m, pbSkipScratch);
      boolean changed = false;

      for (int i = 0; i < 16; i++) {
         if (Float.floatToRawIntBits(pbSkipScratch[i]) != Float.floatToRawIntBits(prev[i])) {
            changed = true;
         }

         prev[i] = pbSkipScratch[i];
      }

      return changed;
   }

   private static boolean drawTaskCulled(
      TerrainResidency.DrawSnapshot snap,
      CameraRenderState cam,
      GpuSampler atlasSampler,
      GpuTextureView colorView,
      GpuTextureView depthView,
      GpuTextureView atlasView,
      GpuTextureView lightmapView
   ) {
      ccValid = false;
      boolean extLists = ensureFrameLists();
      int maskCapacity = extLists ? frameLists.capacity() : 512;
      ByteBuffer visDst = extLists ? frameLists.visWriteView(frameSerial) : visUpload;
      int regionCount = snap.regionCount();
      int[] rd = snap.regionData();
      Frustum frustum = cam.cullFrustum;
      double camX = cam.pos.x;
      double camY = cam.pos.y;
      double camZ = cam.pos.z;
      Arrays.fill(regionMasks, 0, regionCount * 8, 0);
      ObjectArrayList<RenderSection> visible = Minecraft.getInstance().levelRenderer.visibleSections();
      int i = 0;

      for (int n = visible.size(); i < n; i++) {
         long node = ((RenderSection)visible.get(i)).getSectionNode();
         int sx = SectionPos.x(node);
         int sy = SectionPos.y(node);
         int sz = SectionPos.z(node);
         int idx = regionSlotByKey.get(regionKey(sx >> 3, sy >> 2, sz >> 3));
         if (idx >= 0) {
            int posKey = (sy & 3) << 6 | (sz & 7) << 3 | sx & 7;
            regionMasks[idx * 8 + (posKey >>> 5)] = regionMasks[idx * 8 + (posKey >>> 5)] | 1 << (posKey & 31);
         }
      }

      int[] retainedMasks = snap.retainedMasks();
      int[] unlistedMasks = snap.unlistedMasks();
      boolean audit = coverageAuditRequested;
      int auditRegions = 0;
      if (audit && coverageAuditKeys.length < regionCount) {
         coverageAuditKeys = new long[regionCount];
         coverageAuditWords = new int[regionCount * 9];
      }

      if (audit) {
         coverageAuditFrustum = new Frustum(frustum);
      }

      int dispatched = 0;
      int visIn = 0;
      int retainedIn = 0;
      int unlistedIn = 0;
      long sig = 0L;
      long overflowThisFrame = 0L;

      for (int r = 0; r < regionCount; r++) {
         int ro = r * 7;
         int id = rd[ro];
         int count = rd[ro + 4];
         if (count > 0) {
            double bx = rd[ro + 1] * 128.0;
            double by = rd[ro + 2] * 64.0;
            double bz = rd[ro + 3] * 128.0;
            boolean inFrustum = frustum.isVisible(new AABB(bx, by, bz, bx + 128.0, by + 64.0, bz + 128.0));
            int auditOffset = -1;
            if (audit) {
               auditOffset = auditRegions * 9;
               coverageAuditKeys[auditRegions] = regionKey(rd[ro + 1], rd[ro + 2], rd[ro + 3]);
               auditRegions++;
               coverageAuditWords[auditOffset] = inFrustum ? 1 : 0;

               for (int w = 0; w < 8; w++) {
                  coverageAuditWords[auditOffset + 1 + w] = 0;
               }
            }

            if (inFrustum) {
               int pop = 0;
               int maskSlot;
               if (dispatched < maskCapacity) {
                  maskSlot = dispatched;
                  int dst = maskSlot * 32;

                  for (int w = 0; w < 8; w++) {
                     int word = regionMasks[r * 8 + w];
                     int retainedWord = retainedMasks[r * 8 + w];
                     int unlistedWord = unlistedMasks[r * 8 + w];
                     int merged = word | retainedWord;
                     visDst.putInt(dst + w * 4, merged);
                     pop += Integer.bitCount(merged);
                     if (audit) {
                        coverageAuditWords[auditOffset + 1 + w] = merged;
                     }

                     retainedIn += Integer.bitCount(retainedWord & ~word & ~unlistedWord);
                     unlistedIn += Integer.bitCount(unlistedWord & ~word);
                  }

                  if (pop == 0) {
                     continue;
                  }
               } else {
                  maskSlot = -1;
                  overflowThisFrame++;
                  pop = count;
                  if (audit) {
                     coverageAuditWords[auditOffset] = coverageAuditWords[auditOffset] | 2;
                  }
               }

               if ((dispatched + 1) * 3 > regionMeta.length) {
                  regionMeta = Arrays.copyOf(regionMeta, regionMeta.length * 2);
                  regionOrigins = Arrays.copyOf(regionOrigins, regionOrigins.length * 2);
               }

               regionOrigins[dispatched * 3] = (float)(bx - camX);
               regionOrigins[dispatched * 3 + 1] = (float)(by - camY);
               regionOrigins[dispatched * 3 + 2] = (float)(bz - camZ);
               regionMeta[dispatched * 3] = id;
               regionMeta[dispatched * 3 + 1] = maskSlot;
               regionMeta[dispatched * 3 + 2] = (count + taskWorkgroupSections() - 1) / taskWorkgroupSections();
               sig += (id + 1L) * (2L * id + 31L);
               visIn += pop;
               dispatched++;
            }
         }
      }

      regionsDispatched = dispatched;
      sectionsVisibleIn = visIn;
      dispatchSignature = sig;
      lastDrawnSections = visIn;
      maskOverflowRegions += overflowThisFrame;
      lastRetainedMaskSections = retainedIn;
      retainedMaskSectionsTotal += retainedIn;
      lastUnlistedMaskSections = unlistedIn;
      if (audit) {
         coverageAuditRegions = auditRegions;
         coverageAuditFrame = frameSerial;
         coverageAuditRequested = false;
         coverageAuditCaptured = true;
      }

      if (dispatched == 0) {
         return true;
      }

      sortRegionsFrontToBack(dispatched);
      CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
      GpuBufferSlice sceneSlice = uploadScene(encoder, cam, atlasView.getWidth(0), atlasView.getHeight(0));
      TerrainOcclusion.ListSlice visList;
      if (extLists) {
         visList = new TerrainOcclusion.ListSlice(frameLists.visBuffer(), frameLists.visOffset(frameSerial), frameLists.visRange(), true);
      } else {
         visUpload.clear();
         visList = TerrainOcclusion.ListSlice.ofUniformSlice(encoder.transientMemory().uploadGpu(visUpload, 256L, 128));
      }

      boolean stats = occlusion != null && !occlusionBroken;
      if (stats) {
         pullGpuStats(false);
      }

      long taskGroupsThisFrame = 0L;
      NvidiumPlusGpuTimers.beginOpaque(encoder, frameSerial);
      RenderPass pass = encoder.createRenderPass(() -> "NvidiumPlus terrain opaque", colorView, Optional.empty(), depthView, OptionalDouble.empty());

      try {
         VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
         VulkanRenderPassAccessor vkPass = (VulkanRenderPassAccessor)backendPass;
         VkCommandBuffer cb = vkPass.nvidiumplus$commandBuffer();
         TerrainDrawPipeline p = pipelineFor(vkPass, colorView, depthView, true, extLists);
         VK10.vkCmdBindPipeline(cb, 0, p.pipeline());
         pushDescriptors(
            cb,
            p,
            snap.arenaBlockHandles(),
            sceneSlice,
            atlasView,
            atlasSampler,
            lightmapView,
            snap.sectionRecordsHandle(),
            visList,
            stats ? occlusion.prevStampsBuffer(occFrameStamp) : 0L,
            stats ? occlusion.curStampsBuffer(occFrameStamp) : 0L,
            stats ? occlusion.statsBuffer() : 0L
         );
         MemoryStack stack = MemoryStack.stackPush();

         try {
            ByteBuffer push = stack.calloc(32);
            int pushStages = p.pushStageFlags();

            for (int r = 0; r < dispatched; r++) {
               push.putFloat(0, regionOrigins[r * 3]);
               push.putFloat(4, regionOrigins[r * 3 + 1]);
               push.putFloat(8, regionOrigins[r * 3 + 2]);
               push.putInt(12, regionMeta[r * 3]);
               push.putInt(16, regionMeta[r * 3 + 1]);
               push.putInt(20, 0);
               push.putInt(24, 0);
               push.putInt(28, stats ? 1 : 0);
               VK10.vkCmdPushConstants(cb, p.pipelineLayout(), pushStages, 0, push);
               int groups = regionMeta[r * 3 + 2];
               EXTMeshShader.vkCmdDrawMeshTasksEXT(cb, groups, 1, 1);
               taskGroupsThisFrame += groups;
            }
         } catch (Throwable var54) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var53) {
                  var54.addSuppressed(var53);
               }
            }

            throw var54;
         }

         if (stack != null) {
            stack.close();
         }
      } catch (Throwable var55) {
         if (pass != null) {
            try {
               pass.close();
            } catch (Throwable var52) {
               var55.addSuppressed(var52);
            }
         }

         throw var55;
      }

      if (pass != null) {
         pass.close();
      }

      NvidiumPlusGpuTimers.mark(encoder, 1);
      if (stats) {
         occlusion.recordStatsTransfer(statsFrames);
         statsFrames++;
      }

      perfTaskGroupsAccum += taskGroupsThisFrame;
      framesDrawn++;
      totalDrawnSections += visIn;
      taskCullFrames++;
      bfsOnlyFrames++;
      return true;
   }

   private static long regionKey(int rx, int ry, int rz) {
      return (rx & 2097151L) << 42 | (ry & 2097151L) << 21 | rz & 2097151L;
   }

   private static long sectionKey(int sx, int sy, int sz) {
      return (sx & 2097151L) << 42 | (sy & 2097151L) << 21 | sz & 2097151L;
   }

   private static void rebuildRegionMap(TerrainResidency.DrawSnapshot snap) {
      regionSlotByKey.clear();
      int[] rd = snap.regionData();
      int regionCount = snap.regionCount();

      for (int r = 0; r < regionCount; r++) {
         int ro = r * 7;
         regionSlotByKey.put(regionKey(rd[ro + 1], rd[ro + 2], rd[ro + 3]), r);
      }

      if (regionMasks.length < regionCount * 8) {
         regionMasks = new int[Math.max(regionCount * 8, regionMasks.length * 2)];
      }

      translucentSlotByPos.clear();
      int[] d = snap.data();
      int n = snap.maxSlot() + 1;

      for (int s = 0; s < n; s++) {
         int o = s * 20;
         if (d[o + 4] > 0 && d[o + 18] >= 0) {
            translucentSlotByPos.put(sectionKey(d[o], d[o + 1], d[o + 2]), s);
         }
      }
   }

   private static boolean drawCpuCulled(
      TerrainResidency.DrawSnapshot snap,
      CameraRenderState cam,
      GpuSampler atlasSampler,
      GpuTextureView colorView,
      GpuTextureView depthView,
      GpuTextureView atlasView,
      GpuTextureView lightmapView
   ) {
      ccValid = false;
      Frustum frustum = cam.cullFrustum;
      int camSx = cam.blockPos.getX() >> 4;
      int camSy = cam.blockPos.getY() >> 4;
      int camSz = cam.blockPos.getZ() >> 4;
      double camX = cam.pos.x;
      double camY = cam.pos.y;
      double camZ = cam.pos.z;
      int[] d = snap.data();
      int n = snap.maxSlot() + 1;
      int runCountTotal = 0;
      int visibleSections = 0;

      for (int s = 0; s < n; s++) {
         int o = s * 20;
         if (d[o + 18] != -2) {
            int sx = d[o];
            int sy = d[o + 1];
            int sz = d[o + 2];
            double bx = sx << 4;
            double by = sy << 4;
            double bz = sz << 4;
            if (frustum.isVisible(new AABB(bx, by, bz, bx + 16.0, by + 16.0, bz + 16.0))) {
               int relX = sx - camSx;
               int relY = sy - camSy;
               int relZ = sz - camSz;
               int addr = d[o + 3];
               float ox = (float)(bx - camX);
               float oy = (float)(by - camY);
               float oz = (float)(bz - camZ);
               int runFirst = -1;
               int runLen = 0;
               boolean any = false;

               for (int b = 0; b < 7; b++) {
                  int count = d[o + 11 + b];
                  if (count != 0) {
                     if (QuadFacing.byIndex(b).visibleFrom(relX, relY, relZ)) {
                        int start = d[o + 4 + b];
                        if (runLen > 0 && runFirst + runLen == start) {
                           runLen += count;
                        } else {
                           if (runLen > 0) {
                              runCountTotal = pushRun(runCountTotal, ox, oy, oz, addr + runFirst, runLen);
                              any = true;
                           }

                           runFirst = start;
                           runLen = count;
                        }
                     } else if (runLen > 0) {
                        runCountTotal = pushRun(runCountTotal, ox, oy, oz, addr + runFirst, runLen);
                        any = true;
                        runLen = 0;
                     }
                  }
               }

               if (runLen > 0) {
                  runCountTotal = pushRun(runCountTotal, ox, oy, oz, addr + runFirst, runLen);
                  any = true;
               }

               if (any) {
                  visibleSections++;
               }
            }
         }
      }

      lastDrawnSections = visibleSections;
      if (runCountTotal == 0) {
         cpuCullFrames++;
         return true;
      }

      CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
      GpuBufferSlice sceneSlice = uploadScene(encoder, cam, atlasView.getWidth(0), atlasView.getHeight(0));
      NvidiumPlusGpuTimers.beginOpaque(encoder, frameSerial);
      RenderPass pass = encoder.createRenderPass(() -> "NvidiumPlus terrain opaque", colorView, Optional.empty(), depthView, OptionalDouble.empty());

      try {
         VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
         VulkanRenderPassAccessor vkPass = (VulkanRenderPassAccessor)backendPass;
         VkCommandBuffer cb = vkPass.nvidiumplus$commandBuffer();
         TerrainDrawPipeline p = pipelineFor(vkPass, colorView, depthView, false);
         VK10.vkCmdBindPipeline(cb, 0, p.pipeline());
         pushDescriptors(cb, p, snap.arenaBlockHandles(), sceneSlice, atlasView, atlasSampler, lightmapView, 0L, null, 0L, 0L, 0L);
         MemoryStack stack = MemoryStack.stackPush();

         try {
            ByteBuffer push = stack.calloc(32);
            int wg = p.workgroupQuads();

            for (int r = 0; r < runCountTotal; r++) {
               push.putFloat(0, runOrigins[r * 3]);
               push.putFloat(4, runOrigins[r * 3 + 1]);
               push.putFloat(8, runOrigins[r * 3 + 2]);
               push.putInt(12, runQuads[r * 2]);
               push.putInt(16, runQuads[r * 2 + 1]);
               VK10.vkCmdPushConstants(cb, p.pipelineLayout(), 128, 0, push);
               int groups = (runQuads[r * 2 + 1] + wg - 1) / wg;
               EXTMeshShader.vkCmdDrawMeshTasksEXT(cb, groups, 1, 1);
            }
         } catch (Throwable var47) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var46) {
                  var47.addSuppressed(var46);
               }
            }

            throw var47;
         }

         if (stack != null) {
            stack.close();
         }
      } catch (Throwable var48) {
         if (pass != null) {
            try {
               pass.close();
            } catch (Throwable var45) {
               var48.addSuppressed(var45);
            }
         }

         throw var48;
      }

      if (pass != null) {
         pass.close();
      }

      NvidiumPlusGpuTimers.mark(encoder, 1);
      framesDrawn++;
      totalDrawnSections += visibleSections;
      cpuCullFrames++;
      return true;
   }

   private static int pushRun(int runCount, float ox, float oy, float oz, int firstQuad, int quads) {
      if ((runCount + 1) * 3 > runOrigins.length) {
         runOrigins = Arrays.copyOf(runOrigins, runOrigins.length * 2);
         runQuads = Arrays.copyOf(runQuads, runQuads.length * 2);
      }

      runOrigins[runCount * 3] = ox;
      runOrigins[runCount * 3 + 1] = oy;
      runOrigins[runCount * 3 + 2] = oz;
      runQuads[runCount * 2] = firstQuad;
      runQuads[runCount * 2 + 1] = quads;
      return runCount + 1;
   }

   public static boolean drawTranslucent(ChunkSectionsToRender sections, GpuSampler atlasSampler, GpuTextureView atlasView) {
      if (broken) {
         return false;
      }

      try {
         long t0 = System.nanoTime();
         boolean owned = drawTranslucentInner(sections, atlasSampler, atlasView);
         if (owned) {
            translucentOwnedSerial = frameSerial;
            cancelledTranslucentGroups++;
            if (NvidiumPlusCpuStages.ARMED) {
               NvidiumPlusCpuStages.record(5, System.nanoTime() - t0);
            }

            NvidiumPlusGpuTimers.endFrame(frameSerial);
         } else if (prepSkippedSerial == frameSerial && opaqueOwnedSerial == frameSerial) {
            countPrepSkipHole();
         }

         return owned;
      } catch (GpuDeviceLossException t) {
         deviceLost = true;
         broken = true;
         latchError(t);
         NvidiumPlusLog.LOGGER
            .error("GPU device lost during NvidiumPlus's translucent pass; NvidiumPlus goes passive (vanilla will report the loss on its own next call)", t);
         if (prepSkippedSerial == frameSerial && opaqueOwnedSerial == frameSerial) {
            countPrepSkipHole();
         }

         return false;
      } catch (Throwable t) {
         broken = true;
         latchError(t);
         NvidiumPlusLog.LOGGER.error("NvidiumPlus translucent draw failed; vanilla terrain resumes for this session (first and only report)", t);
         if (prepSkippedSerial == frameSerial && opaqueOwnedSerial == frameSerial) {
            countPrepSkipHole();
         }

         return false;
      }
   }

   private static boolean drawTranslucentInner(ChunkSectionsToRender sections, GpuSampler atlasSampler, GpuTextureView atlasView) {
      CameraRenderState cam = camera;
      if (cam == null || !cam.initialized || cam.cullFrustum == null) {
         return false;
      }

      if (opaqueOwnedSerial != frameSerial) {
         return false;
      }

      long probeEntry = TranslucentPhaseProbe.ARMED ? System.nanoTime() : 0L;
      RenderTarget target = McCompat.translucentTarget();
      if (target != Minecraft.getInstance().gameRenderer.mainRenderTarget()) {
         translucentSeparateTargetFrames++;
      }

      GpuTextureView colorView = target.getColorTextureView();
      GpuTextureView depthView = target.getDepthTextureView();
      GpuTextureView lightmapView = Minecraft.getInstance().gameRenderer.lightmap();
      if (colorView != null && depthView != null && atlasView != null && lightmapView != null) {
         long probeViews = 0L;
         if (TranslucentPhaseProbe.ARMED) {
            probeViews = System.nanoTime();
            TranslucentPhaseProbe.targetViews(probeViews - probeEntry);
         }

         TerrainResidency.DrawSnapshot snap = snapshot;
         if (snap != null && snap.sectionCount() != 0 && snap.arenaBackingHandle() != 0L) {
            Frustum frustum = cam.cullFrustum;
            double camX = cam.pos.x;
            double camY = cam.pos.y;
            double camZ = cam.pos.z;
            int[] d = snap.data();
            int cap = transQuadCapacity();
            boolean occGate = occGateSerial == frameSerial && occCurStampsHandle != 0L && snap.sectionRecordsHandle() != 0L;
            String multiWGProp = System.getProperty("nvidiumplus.translucentMultiWG");
            boolean multiWG = multiWGProp == null || Boolean.parseBoolean(multiWGProp);
            if (multiWG && !multiWGLogged) {
               multiWGLogged = true;
               NvidiumPlusLog.LOGGER
                  .info(
                     "NvidiumPlus translucent multi-WG batching active: one draw per section instead of one per 64 quads (worth 1.3 ms/frame at rd 64, measured on RDNA4). The workgroup ordering it relies on is guaranteed by VK_EXT_mesh_shader for directly launched workgroups; -D{}=false forces the split-draw path",
                     "nvidiumplus.translucentMultiWG"
                  );
            }

            int drawCount = 0;
            int sectionsDrawn = 0;
            long gated = 0L;
            long probeT0 = 0L;
            if (TranslucentPhaseProbe.ARMED) {
               probeT0 = System.nanoTime();
               TranslucentPhaseProbe.prologueRest(probeT0 - probeViews);
            }

            int retainedTransDrawn = 0;
            int snapCount = snap.maxSlot() + 1;
            if (transDrawnMark.length < snapCount) {
               transDrawnMark = new boolean[Math.max(snapCount, transDrawnMark.length * 2)];
            }

            boolean gatedFeed = occGate;
            int retTransCount = 0;

            for (int s = 0; s < snapCount; s++) {
               int o = s * 20;
               if ((gatedFeed || d[o + 19] != 0) && d[o + 4] > 0 && d[o + 18] >= 0) {
                  double bx = d[o] << 4;
                  double by = d[o + 1] << 4;
                  double bz = d[o + 2] << 4;
                  if (frustum.isVisible(new AABB(bx, by, bz, bx + 16.0, by + 16.0, bz + 16.0))) {
                     float ddx = (float)(bx + 8.0 - camX);
                     float ddy = (float)(by + 8.0 - camY);
                     float ddz = (float)(bz + 8.0 - camZ);
                     float d2 = ddx * ddx + ddy * ddy + ddz * ddz;
                     if (retTransCount == retTransKeys.length) {
                        retTransKeys = Arrays.copyOf(retTransKeys, retTransKeys.length * 2);
                     }

                     retTransKeys[retTransCount++] = (long)Float.floatToIntBits(d2) << 32 | s;
                  }
               }
            }

            Arrays.sort(retTransKeys, 0, retTransCount);

            for (int i = retTransCount - 1; i >= 0; i--) {
               int s = (int)retTransKeys[i];
               int o = s * 20;
               int sx = d[o];
               int sy = d[o + 1];
               int sz = d[o + 2];
               int count = d[o + 4];
               int addr = d[o + 3];
               int gate = -1;
               if (occGate) {
                  int gidx = d[o + 18];
                  if (gidx >= 0 && occRasteredRegions.contains(gidx >>> 8)) {
                     int posKey = (sy & 3) << 6 | (sz & 7) << 3 | sx & 7;
                     gate = posKey << 20 | gidx;
                     gated++;
                  }
               }

               float ox = (float)((sx << 4) - camX);
               float oy = (float)((sy << 4) - camY);
               float oz = (float)((sz << 4) - camZ);
               int sliceStep = multiWG ? count : cap;

               for (int first = 0; first < count; first += sliceStep) {
                  if ((drawCount + 1) * 3 > transMeta.length) {
                     transOrigins = Arrays.copyOf(transOrigins, transOrigins.length * 2);
                     transMeta = Arrays.copyOf(transMeta, transMeta.length * 2);
                  }

                  transOrigins[drawCount * 3] = ox;
                  transOrigins[drawCount * 3 + 1] = oy;
                  transOrigins[drawCount * 3 + 2] = oz;
                  transMeta[drawCount * 3] = addr + first;
                  transMeta[drawCount * 3 + 1] = Math.min(sliceStep, count - first);
                  transMeta[drawCount * 3 + 2] = gate;
                  drawCount++;
               }

               if (!gatedFeed) {
                  transDrawnMark[s] = true;
                  transDrawnList.add(s);
               }

               sectionsDrawn++;
               retainedTransDrawn++;
            }

            long probeT1 = 0L;
            if (TranslucentPhaseProbe.ARMED) {
               probeT1 = System.nanoTime();
               TranslucentPhaseProbe.retainedScan(probeT1 - probeT0, snapCount);
            }

            ObjectArrayList<RenderSection> visible = gatedFeed ? null : Minecraft.getInstance().levelRenderer.visibleSections();

            for (int i = visible == null ? -1 : visible.size() - 1; i >= 0; i--) {
               long node = ((RenderSection)visible.get(i)).getSectionNode();
               int sx = SectionPos.x(node);
               int sy = SectionPos.y(node);
               int sz = SectionPos.z(node);
               int idx = translucentSlotByPos.get(sectionKey(sx, sy, sz));
               if (idx >= 0 && (idx >= transDrawnMark.length || !transDrawnMark[idx])) {
                  int o = idx * 20;
                  double bx = sx << 4;
                  double by = sy << 4;
                  double bz = sz << 4;
                  if (frustum.isVisible(new AABB(bx, by, bz, bx + 16.0, by + 16.0, bz + 16.0))) {
                     int count = d[o + 4];
                     int addr = d[o + 3];
                     int gate = -1;
                     if (occGate) {
                        int gidx = d[o + 18];
                        if (gidx >= 0 && occRasteredRegions.contains(gidx >>> 8)) {
                           int posKey = (sy & 3) << 6 | (sz & 7) << 3 | sx & 7;
                           gate = posKey << 20 | gidx;
                           gated++;
                        }
                     }

                     float ox = (float)(bx - camX);
                     float oy = (float)(by - camY);
                     float oz = (float)(bz - camZ);
                     int sliceStep = multiWG ? count : cap;

                     for (int first = 0; first < count; first += sliceStep) {
                        if ((drawCount + 1) * 3 > transMeta.length) {
                           transOrigins = Arrays.copyOf(transOrigins, transOrigins.length * 2);
                           transMeta = Arrays.copyOf(transMeta, transMeta.length * 2);
                        }

                        transOrigins[drawCount * 3] = ox;
                        transOrigins[drawCount * 3 + 1] = oy;
                        transOrigins[drawCount * 3 + 2] = oz;
                        transMeta[drawCount * 3] = addr + first;
                        transMeta[drawCount * 3 + 1] = Math.min(sliceStep, count - first);
                        transMeta[drawCount * 3 + 2] = gate;
                        drawCount++;
                     }

                     sectionsDrawn++;
                  }
               }
            }

            for (int i = 0; i < transDrawnList.size(); i++) {
               transDrawnMark[transDrawnList.getInt(i)] = false;
            }

            transDrawnList.clear();
            long probeT2 = 0L;
            if (TranslucentPhaseProbe.ARMED) {
               probeT2 = System.nanoTime();
               TranslucentPhaseProbe.visibleLoop(probeT2 - probeT1, sectionsDrawn, drawCount);
            }

            lastTranslucentSections = sectionsDrawn;
            lastTranslucentDraws = drawCount;
            lastRetainedTranslucentSections = retainedTransDrawn;
            translucentGatedSections += gated;
            if (gatedFeed) {
               translucentGatedFeedFrames++;
            }

            if (drawCount == 0) {
               translucentFrames++;
               return true;
            }

            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            GpuBufferSlice sceneSlice = uploadScene(encoder, cam, atlasView.getWidth(0), atlasView.getHeight(0));
            NvidiumPlusGpuTimers.beginTranslucent(encoder, frameSerial);
            RenderPass pass = encoder.createRenderPass(() -> "NvidiumPlus terrain translucent", colorView, Optional.empty(), depthView, OptionalDouble.empty());

            try {
               VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
               VulkanRenderPassAccessor vkPass = (VulkanRenderPassAccessor)backendPass;
               VkCommandBuffer cb = vkPass.nvidiumplus$commandBuffer();
               TerrainDrawPipeline p = translucentPipelineFor(vkPass, colorView, depthView);
               VK10.vkCmdBindPipeline(cb, 0, p.pipeline());
               pushTranslucentDescriptors(
                  cb,
                  p,
                  snap.arenaBlockHandles(),
                  sceneSlice,
                  atlasView,
                  atlasSampler,
                  lightmapView,
                  snap.sectionRecordsHandle(),
                  occGate ? occCurStampsHandle : 0L
               );
               MemoryStack stack = MemoryStack.stackPush();

               try {
                  ByteBuffer push = stack.calloc(32);

                  for (int r = 0; r < drawCount; r++) {
                     push.putFloat(0, transOrigins[r * 3]);
                     push.putFloat(4, transOrigins[r * 3 + 1]);
                     push.putFloat(8, transOrigins[r * 3 + 2]);
                     push.putInt(12, transMeta[r * 3]);
                     push.putInt(16, transMeta[r * 3 + 1]);
                     push.putInt(20, transMeta[r * 3 + 2]);
                     push.putInt(24, occGateStamp32);
                     VK10.vkCmdPushConstants(cb, p.pipelineLayout(), 128, 0, push);
                     int groups = (transMeta[r * 3 + 1] + cap - 1) / cap;
                     EXTMeshShader.vkCmdDrawMeshTasksEXT(cb, groups, 1, 1);
                  }
               } catch (Throwable var62) {
                  if (stack != null) {
                     try {
                        stack.close();
                     } catch (Throwable var61) {
                        var62.addSuppressed(var61);
                     }
                  }

                  throw var62;
               }

               if (stack != null) {
                  stack.close();
               }
            } catch (Throwable var63) {
               if (pass != null) {
                  try {
                     pass.close();
                  } catch (Throwable var60) {
                     var63.addSuppressed(var60);
                  }
               }

               throw var63;
            }

            if (pass != null) {
               pass.close();
            }

            NvidiumPlusGpuTimers.endTranslucent(encoder, frameSerial);
            if (multiWG) {
               translucentMultiWGFrames++;
            }

            if (TranslucentPhaseProbe.ARMED) {
               TranslucentPhaseProbe.record(System.nanoTime() - probeT2);
            }

            translucentFrames++;
            return true;
         } else {
            lastTranslucentSections = 0;
            lastTranslucentDraws = 0;
            translucentFrames++;
            return true;
         }
      } else {
         return false;
      }
   }

   private static int transQuadCapacity() {
      NvidiumPlusVulkanState.MeshShaderCaps caps = NvidiumPlusVulkanState.caps();
      int cap = 64;
      if (caps != null) {
         cap = Math.min(cap, Math.min(caps.maxMeshOutputVertices() / 4, caps.maxMeshOutputPrimitives() / 2));
         cap = Math.min(cap, maxQuadsByOutputMemory());
      }

      return Math.max(cap, 1);
   }

   private static TerrainDrawPipeline translucentPipelineFor(VulkanRenderPassAccessor vkPass, GpuTextureView colorView, GpuTextureView depthView) {
      TerrainDrawPipeline p = translucentPipeline;
      if (p == null) {
         int vkColorFormat = VulkanConst.toVk(colorView.texture().getFormat());
         int vkDepthFormat = VulkanConst.toVk(depthView.texture().getFormat());
         int transQuads = transQuadCapacity();
         NvidiumPlusVulkanState.MeshShaderCaps caps = NvidiumPlusVulkanState.caps();
         if (caps != null
            && (
               caps.maxMeshWorkGroupInvocations() < meshWorkgroupQuads()
                  || caps.maxMeshOutputVertices() < transQuads * 4
                  || caps.maxMeshOutputPrimitives() < transQuads * 2
                  || caps.maxMeshOutputMemorySize() > 0 && caps.maxMeshOutputMemorySize() < transQuads * MESH_OUTPUT_BYTES_PER_QUAD
            )) {
            throw new IllegalStateException(
               "device mesh caps below the translucent shape ("
                  + transQuads
                  + " quads/draw, "
                  + transQuads * MESH_OUTPUT_BYTES_PER_QUAD
                  + " B output): "
                  + caps
            );
         }

         p = TerrainDrawPipeline.createTranslucent(vkPass.nvidiumplus$device().vkDevice(), vkColorFormat, vkDepthFormat, meshWorkgroupQuads(), transQuads);
         translucentPipeline = p;
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus translucent pipeline created (color format {}, depth format {}, {} quads/draw in one workgroup — blend SRC_ALPHA/ONE_MINUS_SRC_ALPHA + ONE/ONE_MINUS_SRC_ALPHA, depth GEQUAL write ON, vanilla TRANSLUCENT_TERRAIN verbatim)",
               new Object[]{vkColorFormat, vkDepthFormat, transQuads}
            );
      }

      return p;
   }

   private static void pushTranslucentDescriptors(
      VkCommandBuffer cb,
      TerrainDrawPipeline p,
      long[] arenaBlocks,
      GpuBufferSlice sceneSlice,
      GpuTextureView atlasView,
      GpuSampler atlasSampler,
      GpuTextureView lightmapView,
      long sectionRecordsBuffer,
      long curStamps
   ) {
      GpuBufferSlice projection = RenderSystem.getProjectionMatrixBuffer();
      GpuBufferSlice fog = RenderSystem.getShaderFog();
      GpuBuffer globals = RenderSystem.getGlobalSettingsUniform();
      GpuSampler lightmapSampler = RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR);
      MemoryStack stack = MemoryStack.stackPush();

      try {
         Buffer arenaInfo = arenaBlockInfos(stack, arenaBlocks, NvidiumPlusScaling.arenaBlockCount());
         Buffer sceneInfo = bufferInfo(stack, ((VulkanGpuBuffer)sceneSlice.buffer()).vkBuffer(), sceneSlice.offset(), sceneSlice.length());
         Buffer projectionInfo = bufferInfo(stack, ((VulkanGpuBuffer)projection.buffer()).vkBuffer(), projection.offset(), projection.length());
         Buffer fogInfo = bufferInfo(stack, ((VulkanGpuBuffer)fog.buffer()).vkBuffer(), fog.offset(), fog.length());
         Buffer globalsInfo = bufferInfo(stack, ((VulkanGpuBuffer)globals).vkBuffer(), 0L, -1L);
         org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer atlasInfo = imageInfo(stack, atlasView, atlasSampler);
         org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer lightmapInfo = imageInfo(stack, lightmapView, lightmapSampler);
         org.lwjgl.vulkan.VkWriteDescriptorSet.Buffer writes = VkWriteDescriptorSet.calloc(9, stack);
         bufferWrite((VkWriteDescriptorSet)writes.get(0), 0, 7, arenaInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(1), 1, 6, sceneInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(2), 2, 6, projectionInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(3), 3, 6, fogInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(4), 4, 6, globalsInfo);
         imageWrite((VkWriteDescriptorSet)writes.get(5), 5, atlasInfo);
         imageWrite((VkWriteDescriptorSet)writes.get(6), 6, lightmapInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(7), 7, 7, bufferInfo(stack, sectionRecordsBuffer != 0L ? sectionRecordsBuffer : arenaBlocks[0], 0L, -1L));
         bufferWrite((VkWriteDescriptorSet)writes.get(8), 8, 7, bufferInfo(stack, curStamps != 0L ? curStamps : arenaBlocks[0], 0L, -1L));
         KHRPushDescriptor.vkCmdPushDescriptorSetKHR(cb, 0, p.pipelineLayout(), 0, writes);
      } catch (Throwable var25) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var24) {
               var25.addSuppressed(var24);
            }
         }

         throw var25;
      }

      if (stack != null) {
         stack.close();
      }
   }

   private static GpuBufferSlice uploadScene(CommandEncoder encoder, CameraRenderState cam, int atlasWidth, int atlasHeight) {
      MemoryStack stack = MemoryStack.stackPush();

      GpuBufferSlice var10;
      try {
         ByteBuffer scene = stack.calloc(208);
         cam.viewRotationMatrix.get(scene);
         scene.putFloat(64, atlasWidth);
         scene.putFloat(68, atlasHeight);
         Matrix4f m = mvpScratch.set(cam.projectionMatrix).mul(cam.viewRotationMatrix);
         putPlane(scene, 80, m.m03() + m.m00(), m.m13() + m.m10(), m.m23() + m.m20(), m.m33() + m.m30());
         putPlane(scene, 96, m.m03() - m.m00(), m.m13() - m.m10(), m.m23() - m.m20(), m.m33() - m.m30());
         putPlane(scene, 112, m.m03() + m.m01(), m.m13() + m.m11(), m.m23() + m.m21(), m.m33() + m.m31());
         putPlane(scene, 128, m.m03() - m.m01(), m.m13() - m.m11(), m.m23() - m.m21(), m.m33() - m.m31());
         putPlane(scene, 144, m.m03() + m.m02(), m.m13() + m.m12(), m.m23() + m.m22(), m.m33() + m.m32());
         putPlane(scene, 160, m.m03() - m.m02(), m.m13() - m.m12(), m.m23() - m.m22(), m.m33() - m.m32());
         scene.putInt(176, cam.blockPos.getX() >> 4);
         scene.putInt(180, cam.blockPos.getY() >> 4);
         scene.putInt(184, cam.blockPos.getZ() >> 4);
         float plantDist = NvidiumPlusConfig.plantCullChunks() * 16.0F;
         float subPixelDist = NvidiumPlusConfig.subPixelCullChunks() * 16.0F;
         scene.putFloat(192, plantDist <= 0.0F ? 3.4E38F : plantDist * plantDist);
         scene.putFloat(196, subPixelDist <= 0.0F ? 3.4E38F : subPixelDist * subPixelDist);
         RenderTarget mainTarget = Minecraft.getInstance().gameRenderer.mainRenderTarget();
         scene.putFloat(200, mainTarget.width);
         scene.putFloat(204, mainTarget.height);
         var10 = encoder.transientMemory().uploadGpu(scene, 256L, 128);
      } catch (Throwable var12) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var11) {
               var12.addSuppressed(var11);
            }
         }

         throw var12;
      }

      if (stack != null) {
         stack.close();
      }

      return var10;
   }

   private static void putPlane(ByteBuffer dst, int offset, float a, float b, float c, float d) {
      dst.putFloat(offset, a);
      dst.putFloat(offset + 4, b);
      dst.putFloat(offset + 8, c);
      dst.putFloat(offset + 12, d);
   }

   private static boolean taskStageHasRoom() {
      long limit = NvidiumPlusVulkanState.arenaLimits().maxPerStageDescriptorStorageBuffers();
      if (limit > 0L && limit < 5L) {
         if (!taskStageWarned) {
            taskStageWarned = true;
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus: this device reports {} per-stage storage buffers and the extended render distance path needs {}, so the standard per-frame list path is used instead. Culling degrades at long render distance; rendering does not change",
                  limit,
                  5
               );
         }

         return false;
      } else {
         return true;
      }
   }

   private static boolean ensureFrameLists() {
      if (!NvidiumPlusScaling.current().extended() || frameListsFailed) {
         return false;
      }

      if (!taskStageHasRoom()) {
         return false;
      }

      if (frameLists != null) {
         return true;
      }

      try {
         frameLists = NvidiumPlusFrameLists.create(NvidiumPlusScaling.current().dispatchCapacity());
      } catch (Throwable t) {
         frameListsFailed = true;
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus extended frame lists failed to create — falling back to the standard 512-region per-frame lists (overflow fails open; culling degrades, parity never)",
               t
            );
         return false;
      }

      return frameLists != null;
   }

   private static TerrainDrawPipeline pipelineFor(VulkanRenderPassAccessor vkPass, GpuTextureView colorView, GpuTextureView depthView, boolean taskCull) {
      return pipelineFor(vkPass, colorView, depthView, taskCull, false);
   }

   private static TerrainDrawPipeline pipelineFor(
      VulkanRenderPassAccessor vkPass, GpuTextureView colorView, GpuTextureView depthView, boolean taskCull, boolean extLists
   ) {
      TerrainDrawPipeline p = taskCull ? (extLists ? taskPipelineExt : taskPipeline) : cpuPipeline;
      if (p == null) {
         int vkColorFormat = VulkanConst.toVk(colorView.texture().getFormat());
         int vkDepthFormat = VulkanConst.toVk(depthView.texture().getFormat());
         int wg = meshWorkgroupQuads();
         int tws = taskWorkgroupSections();
         NvidiumPlusVulkanState.MeshShaderCaps caps = NvidiumPlusVulkanState.caps();
         if (caps != null) {
            if (caps.maxMeshWorkGroupInvocations() < wg
               || caps.maxMeshOutputVertices() < wg * 4
               || caps.maxMeshOutputPrimitives() < wg * 2
               || caps.maxMeshOutputMemorySize() > 0 && caps.maxMeshOutputMemorySize() < wg * MESH_OUTPUT_BYTES_PER_QUAD) {
               throw new IllegalStateException(
                  "device mesh caps below the terrain workgroup shape (" + wg + " quads, " + wg * MESH_OUTPUT_BYTES_PER_QUAD + " B output): " + caps
               );
            }

            if (taskCull) {
               int payloadBytes = tws * 80;
               if (caps.maxTaskWorkGroupInvocations() < tws || caps.maxTaskPayloadSize() < payloadBytes) {
                  throw new IllegalStateException(
                     "device task caps below the terrain task shape ("
                        + tws
                        + " sections, "
                        + payloadBytes
                        + " B payload — check the nvidiumplus.tune.taskWorkgroupSections sweep value): "
                        + caps
                  );
               }

               NvidiumPlusLog.LOGGER
                  .info(
                     "NvidiumPlus terrain task stage: {} sections/workgroup, ≤{} B payload vs device caps maxTaskInvocations={}, maxTaskPayloadSize={}, preferredTaskInvocations={} (NVIDIUMPLUS_TASK_WG_SIZE via nvidiumplus.tune.taskWorkgroupSections)",
                     new Object[]{
                        tws, payloadBytes, caps.maxTaskWorkGroupInvocations(), caps.maxTaskPayloadSize(), caps.maxPreferredTaskWorkGroupInvocations()
                     }
                  );
            }

            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus terrain pipeline ({}): workgroup {} quads = {} verts/{} prims vs device caps maxInvocations={}, maxOutVerts={}, maxOutPrims={}, preferredInvocations={} (NVIDIUMPLUS_WG_SIZE via nvidiumplus.tune.meshWorkgroupQuads)",
                  new Object[]{
                     taskCull ? "task-cull" : "cpu-cull",
                     wg,
                     wg * 4,
                     wg * 2,
                     caps.maxMeshWorkGroupInvocations(),
                     caps.maxMeshOutputVertices(),
                     caps.maxMeshOutputPrimitives(),
                     caps.maxPreferredMeshWorkGroupInvocations()
                  }
               );
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus mesh-output budget: {} B/workgroup of maxMeshOutputMemorySize={} ({} locations/vertex, {} components of maxMeshOutputComponents={}) - the translucent shape is clamped by the same budget",
                  new Object[]{
                     wg * MESH_OUTPUT_BYTES_PER_QUAD,
                     caps.maxMeshOutputMemorySize(),
                     MESH_OUTPUT_LOCATIONS,
                     MESH_OUTPUT_LOCATIONS * 4,
                     caps.maxMeshOutputComponents()
                  }
               );
         }

         p = TerrainDrawPipeline.create(vkPass.nvidiumplus$device().vkDevice(), vkColorFormat, vkDepthFormat, wg, tws, 512, taskCull, extLists);
         if (taskCull) {
            if (extLists) {
               taskPipelineExt = p;
            } else {
               taskPipeline = p;
            }
         } else {
            cpuPipeline = p;
         }

         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus terrain pipeline created (color format {}, depth format {}, {} quads/workgroup, taskCull={}, extendedLists={})",
               new Object[]{vkColorFormat, vkDepthFormat, wg, taskCull, extLists}
            );
      }

      return p;
   }

   private static void pushDescriptors(
      VkCommandBuffer cb,
      TerrainDrawPipeline p,
      long[] arenaBlocks,
      GpuBufferSlice sceneSlice,
      GpuTextureView atlasView,
      GpuSampler atlasSampler,
      GpuTextureView lightmapView,
      long sectionRecordsBuffer,
      TerrainOcclusion.ListSlice visList,
      long prevStamps,
      long curStamps,
      long statsBuf
   ) {
      GpuBufferSlice projection = RenderSystem.getProjectionMatrixBuffer();
      GpuBufferSlice fog = RenderSystem.getShaderFog();
      GpuBuffer globals = RenderSystem.getGlobalSettingsUniform();
      GpuSampler lightmapSampler = RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR);
      boolean taskMode = p.taskCull();
      MemoryStack stack = MemoryStack.stackPush();

      try {
         Buffer arenaInfo = arenaBlockInfos(stack, arenaBlocks, NvidiumPlusScaling.arenaBlockCount());
         Buffer sceneInfo = bufferInfo(stack, ((VulkanGpuBuffer)sceneSlice.buffer()).vkBuffer(), sceneSlice.offset(), sceneSlice.length());
         Buffer projectionInfo = bufferInfo(stack, ((VulkanGpuBuffer)projection.buffer()).vkBuffer(), projection.offset(), projection.length());
         Buffer fogInfo = bufferInfo(stack, ((VulkanGpuBuffer)fog.buffer()).vkBuffer(), fog.offset(), fog.length());
         Buffer globalsInfo = bufferInfo(stack, ((VulkanGpuBuffer)globals).vkBuffer(), 0L, -1L);
         org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer atlasInfo = imageInfo(stack, atlasView, atlasSampler);
         org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer lightmapInfo = imageInfo(stack, lightmapView, lightmapSampler);
         org.lwjgl.vulkan.VkWriteDescriptorSet.Buffer writes = VkWriteDescriptorSet.calloc(taskMode ? 12 : 7, stack);
         bufferWrite((VkWriteDescriptorSet)writes.get(0), 0, 7, arenaInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(1), 1, 6, sceneInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(2), 2, 6, projectionInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(3), 3, 6, fogInfo);
         bufferWrite((VkWriteDescriptorSet)writes.get(4), 4, 6, globalsInfo);
         imageWrite((VkWriteDescriptorSet)writes.get(5), 5, atlasInfo);
         imageWrite((VkWriteDescriptorSet)writes.get(6), 6, lightmapInfo);
         if (taskMode) {
            Buffer recordsInfo = bufferInfo(stack, sectionRecordsBuffer, 0L, -1L);
            TerrainOcclusion.ListSlice list8 = visList;
            if (list8 == null) {
               list8 = p.extendedLists()
                  ? new TerrainOcclusion.ListSlice(sectionRecordsBuffer, 0L, -1L, true)
                  : TerrainOcclusion.ListSlice.ofUniformSlice(sceneSlice);
            }

            Buffer visInfo = bufferInfo(stack, list8.vkBuffer(), list8.offset(), list8.range());
            bufferWrite((VkWriteDescriptorSet)writes.get(7), 7, 7, recordsInfo);
            bufferWrite((VkWriteDescriptorSet)writes.get(8), 8, list8.ssbo() ? 7 : 6, visInfo);
            bufferWrite((VkWriteDescriptorSet)writes.get(9), 9, 7, bufferInfo(stack, prevStamps != 0L ? prevStamps : sectionRecordsBuffer, 0L, -1L));
            bufferWrite((VkWriteDescriptorSet)writes.get(10), 10, 7, bufferInfo(stack, curStamps != 0L ? curStamps : sectionRecordsBuffer, 0L, -1L));
            bufferWrite((VkWriteDescriptorSet)writes.get(11), 11, 7, bufferInfo(stack, statsBuf != 0L ? statsBuf : sectionRecordsBuffer, 0L, -1L));
         }

         KHRPushDescriptor.vkCmdPushDescriptorSetKHR(cb, 0, p.pipelineLayout(), 0, writes);
      } catch (Throwable var34) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var33) {
               var34.addSuppressed(var33);
            }
         }

         throw var34;
      }

      if (stack != null) {
         stack.close();
      }
   }

   private static Buffer bufferInfo(MemoryStack stack, long vkBuffer, long offset, long range) {
      Buffer info = VkDescriptorBufferInfo.calloc(1, stack);
      ((VkDescriptorBufferInfo)info.get(0)).buffer(vkBuffer).offset(offset).range(range);
      return info;
   }

   private static org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer imageInfo(MemoryStack stack, GpuTextureView view, GpuSampler sampler) {
      org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer info = VkDescriptorImageInfo.calloc(1, stack);
      ((VkDescriptorImageInfo)info.get(0))
         .sampler(((VulkanGpuSampler)sampler).vkSampler())
         .imageView(((VulkanGpuTextureView)view).vkImageView())
         .imageLayout(1);
      return info;
   }

   private static void bufferWrite(VkWriteDescriptorSet write, int binding, int type, Buffer info) {
      write.sType$Default().dstBinding(binding).descriptorCount(info.remaining()).descriptorType(type).pBufferInfo(info);
   }

   private static Buffer arenaBlockInfos(MemoryStack stack, long[] handles, int declaredBlocks) {
      Buffer info = VkDescriptorBufferInfo.calloc(declaredBlocks, stack);
      long fallback = handles.length > 0 ? handles[0] : 0L;

      for (int i = 0; i < declaredBlocks; i++) {
         long h = i < handles.length && handles[i] != 0L ? handles[i] : fallback;
         ((VkDescriptorBufferInfo)info.get(i)).buffer(h).offset(0L).range(-1L);
      }

      return info;
   }

   private static void imageWrite(VkWriteDescriptorSet write, int binding, org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer info) {
      write.sType$Default().dstBinding(binding).descriptorCount(1).descriptorType(1).pImageInfo(info);
   }

   private static void recordPerf(long nanos) {
      perfNanosAccum += nanos;
      perfNanosMax = Math.max(perfNanosMax, nanos);
      perfFrames++;
      long now = System.nanoTime();
      if (lastPerfLogNanos == 0L) {
         lastPerfLogNanos = now;
      } else if (now - lastPerfLogNanos >= 5000000000L) {
         String line = String.format(
            "NvidiumPlus draw-path: avg %dus max %dus over %d frames; last frame regions=%d sectionsVisibleIn=%d taskGroups~%d maskOverflows=%d retainedMask=%d unlistedMask=%d retainedTrans=%d cachedCull=%d/%d prepSkipped=%d/%d (CPU-side recording micros ONLY — the wave-9 GPU pass times are NvidiumPlusGpuTimers' separate line; never sum the two; cachedCull=hits/misses is the wave-12 REAL-PLAY hit-rate evidence, prepSkipped=skips/holes must show holes 0)",
            perfFrames == 0 ? 0L : perfNanosAccum / perfFrames / 1000L,
            perfNanosMax / 1000L,
            perfFrames,
            regionsDispatched,
            sectionsVisibleIn,
            perfFrames == 0 ? 0L : perfTaskGroupsAccum / perfFrames,
            maskOverflowRegions,
            lastRetainedMaskSections,
            lastUnlistedMaskSections,
            lastRetainedTranslucentSections,
            cachedCullHits,
            cachedCullMisses,
            prepSkippedFrames,
            prepSkipHoleFrames
         );
         if (NvidiumPlusConfig.debugStatsEnabled()) {
            NvidiumPlusLog.LOGGER.info(line);
         } else {
            NvidiumPlusLog.LOGGER.debug(line);
         }

         perfNanosAccum = 0L;
         perfNanosMax = 0L;
         perfFrames = 0;
         perfTaskGroupsAccum = 0L;
         lastPerfLogNanos = now;
      }
   }

   static {
      Arrays.fill(phaseBFrames, -1L);
      Arrays.fill(changeFrames, -1L);
      translucentSlotByPos.defaultReturnValue(-1);
      regionSlotByKey.defaultReturnValue(-1);
   }
}
