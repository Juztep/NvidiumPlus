package nvidiumplus.engine.vk;

import java.nio.LongBuffer;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.vma.Vma;
import org.lwjgl.util.vma.VmaAllocationCreateInfo;
import org.lwjgl.util.vma.VmaAllocationInfo;
import org.lwjgl.vulkan.VkBufferCreateInfo;

final class NvidiumPlusVkBuffers {
   private NvidiumPlusVkBuffers() {
   }

   static NvidiumPlusVkBuffers.DeviceBuffer createDeviceLocal(long vma, long sizeBytes, int vkUsage, String what) {
      MemoryStack stack = MemoryStack.stackPush();

      NvidiumPlusVkBuffers.DeviceBuffer var11;
      try {
         VkBufferCreateInfo bufferInfo = VkBufferCreateInfo.calloc(stack).sType$Default().size(sizeBytes).usage(vkUsage).sharingMode(0);
         VmaAllocationCreateInfo allocInfo = VmaAllocationCreateInfo.calloc(stack).usage(8);
         LongBuffer pBuffer = stack.callocLong(1);
         PointerBuffer pAllocation = stack.callocPointer(1);
         check(Vma.vmaCreateBuffer(vma, bufferInfo, allocInfo, pBuffer, pAllocation, null), what);
         var11 = new NvidiumPlusVkBuffers.DeviceBuffer(pBuffer.get(0), pAllocation.get(0));
      } catch (Throwable var13) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var12) {
               var13.addSuppressed(var12);
            }
         }

         throw var13;
      }

      if (stack != null) {
         stack.close();
      }

      return var11;
   }

   static NvidiumPlusVkBuffers.MappedBuffer createHostMapped(long vma, long sizeBytes, int vkUsage, String what) {
      MemoryStack stack = MemoryStack.stackPush();

      NvidiumPlusVkBuffers.MappedBuffer var14;
      try {
         VkBufferCreateInfo bufferInfo = VkBufferCreateInfo.calloc(stack).sType$Default().size(sizeBytes).usage(vkUsage).sharingMode(0);
         VmaAllocationCreateInfo allocInfo = VmaAllocationCreateInfo.calloc(stack).usage(9).requiredFlags(6).flags(1028);
         LongBuffer pBuffer = stack.callocLong(1);
         PointerBuffer pAllocation = stack.callocPointer(1);
         VmaAllocationInfo allocationInfo = VmaAllocationInfo.calloc(stack);
         check(Vma.vmaCreateBuffer(vma, bufferInfo, allocInfo, pBuffer, pAllocation, allocationInfo), what);
         long mapped = allocationInfo.pMappedData();
         if (mapped == 0L) {
            Vma.vmaDestroyBuffer(vma, pBuffer.get(0), pAllocation.get(0));
            throw new IllegalStateException(what + ": VMA returned no persistent mapping");
         }

         var14 = new NvidiumPlusVkBuffers.MappedBuffer(pBuffer.get(0), pAllocation.get(0), mapped);
      } catch (Throwable var16) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var15) {
               var16.addSuppressed(var15);
            }
         }

         throw var16;
      }

      if (stack != null) {
         stack.close();
      }

      return var14;
   }

   static NvidiumPlusVkBuffers.DeviceBuffer createDeviceCoherent(long vma, long sizeBytes, int vkUsage, String what) {
      NvidiumPlusVkBuffers.MappedBuffer mapped = createDeviceMapped(vma, sizeBytes, vkUsage, what);
      return new NvidiumPlusVkBuffers.DeviceBuffer(mapped.vkBuffer(), mapped.allocation());
   }

   static NvidiumPlusVkBuffers.MappedBuffer createDeviceMapped(long vma, long sizeBytes, int vkUsage, String what) {
      MemoryStack stack = MemoryStack.stackPush();

      NvidiumPlusVkBuffers.MappedBuffer var14;
      try {
         VkBufferCreateInfo bufferInfo = VkBufferCreateInfo.calloc(stack).sType$Default().size(sizeBytes).usage(vkUsage).sharingMode(0);
         VmaAllocationCreateInfo allocInfo = VmaAllocationCreateInfo.calloc(stack).usage(8).requiredFlags(6).preferredFlags(1).flags(1028);
         LongBuffer pBuffer = stack.callocLong(1);
         PointerBuffer pAllocation = stack.callocPointer(1);
         VmaAllocationInfo allocationInfo = VmaAllocationInfo.calloc(stack);
         check(Vma.vmaCreateBuffer(vma, bufferInfo, allocInfo, pBuffer, pAllocation, allocationInfo), what);
         long mapped = allocationInfo.pMappedData();
         if (mapped == 0L) {
            Vma.vmaDestroyBuffer(vma, pBuffer.get(0), pAllocation.get(0));
            throw new IllegalStateException(what + ": VMA returned no persistent mapping");
         }

         var14 = new NvidiumPlusVkBuffers.MappedBuffer(pBuffer.get(0), pAllocation.get(0), mapped);
      } catch (Throwable var16) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var15) {
               var16.addSuppressed(var15);
            }
         }

         throw var16;
      }

      if (stack != null) {
         stack.close();
      }

      return var14;
   }

   static NvidiumPlusVkBuffers.MappedBuffer createHostReadback(long vma, long sizeBytes, int vkUsage, String what) {
      MemoryStack stack = MemoryStack.stackPush();

      NvidiumPlusVkBuffers.MappedBuffer var14;
      try {
         VkBufferCreateInfo bufferInfo = VkBufferCreateInfo.calloc(stack).sType$Default().size(sizeBytes).usage(vkUsage).sharingMode(0);
         VmaAllocationCreateInfo allocInfo = VmaAllocationCreateInfo.calloc(stack).usage(9).requiredFlags(6).flags(2052);
         LongBuffer pBuffer = stack.callocLong(1);
         PointerBuffer pAllocation = stack.callocPointer(1);
         VmaAllocationInfo allocationInfo = VmaAllocationInfo.calloc(stack);
         check(Vma.vmaCreateBuffer(vma, bufferInfo, allocInfo, pBuffer, pAllocation, allocationInfo), what);
         long mapped = allocationInfo.pMappedData();
         if (mapped == 0L) {
            Vma.vmaDestroyBuffer(vma, pBuffer.get(0), pAllocation.get(0));
            throw new IllegalStateException(what + ": VMA returned no persistent mapping");
         }

         var14 = new NvidiumPlusVkBuffers.MappedBuffer(pBuffer.get(0), pAllocation.get(0), mapped);
      } catch (Throwable var16) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var15) {
               var16.addSuppressed(var15);
            }
         }

         throw var16;
      }

      if (stack != null) {
         stack.close();
      }

      return var14;
   }

   static void destroy(long vma, long vkBuffer, long allocation) {
      if (vkBuffer != 0L) {
         Vma.vmaDestroyBuffer(vma, vkBuffer, allocation);
      }
   }

   public static boolean isOutOfMemory(int vkResult) {
      return vkResult == -2 || vkResult == -1;
   }

   private static void check(int vkResult, String what) {
      if (vkResult != 0) {
         String message = what + " failed: VkResult " + vkResult;
         if (isOutOfMemory(vkResult)) {
            throw new NvidiumPlusVkBuffers.OutOfDeviceMemoryException(message + " (out of memory - the graphics card could not fit this allocation)", vkResult);
         } else {
            throw new IllegalStateException(message);
         }
      }
   }

   record DeviceBuffer(long vkBuffer, long allocation) {
   }

   record MappedBuffer(long vkBuffer, long allocation, long mappedAddress) {
   }

   public static final class OutOfDeviceMemoryException extends IllegalStateException {
      private static final long serialVersionUID = 1L;
      private final int vkResult;

      OutOfDeviceMemoryException(String message, int vkResult) {
         super(message);
         this.vkResult = vkResult;
      }

      public int vkResult() {
         return this.vkResult;
      }
   }
}
