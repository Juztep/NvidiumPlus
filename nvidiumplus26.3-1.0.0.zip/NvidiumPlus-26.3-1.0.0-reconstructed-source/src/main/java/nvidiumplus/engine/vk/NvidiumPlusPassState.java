package nvidiumplus.engine.vk;

import com.mojang.renderpearl.backend.vulkan.VulkanRenderPipeline;
import java.nio.ByteBuffer;

public interface NvidiumPlusPassState {
   VulkanRenderPipeline nvidiumplus$pipeline();

   Object[] nvidiumplus$uniformsSnapshot();

   ByteBuffer nvidiumplus$lastPushConstants();
}
