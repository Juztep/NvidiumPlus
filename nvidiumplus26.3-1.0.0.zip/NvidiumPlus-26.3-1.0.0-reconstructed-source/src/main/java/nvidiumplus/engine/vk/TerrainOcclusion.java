package nvidiumplus.engine.vk;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.renderpearl.api.device.GpuDevice;
import com.mojang.renderpearl.api.device.GpuDeviceLossException;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.vulkan.VulkanCommandEncoder;
import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuBuffer;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuSampler;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuTextureView;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.LongBuffer;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusScaling;
import nvidiumplus.engine.NvidiumPlusVulkanState;
import nvidiumplus.engine.mixin.GpuDeviceAccessor;
import nvidiumplus.engine.terrain.host.TerrainResidency;
import org.joml.Matrix4fc;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.vulkan.EXTMeshShader;
import org.lwjgl.vulkan.KHRPushDescriptor;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkBufferCopy;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkDescriptorBufferInfo;
import org.lwjgl.vulkan.VkDescriptorImageInfo;
import org.lwjgl.vulkan.VkDescriptorSetLayoutBinding;
import org.lwjgl.vulkan.VkDescriptorSetLayoutCreateInfo;
import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkGraphicsPipelineCreateInfo;
import org.lwjgl.vulkan.VkPipelineColorBlendAttachmentState;
import org.lwjgl.vulkan.VkPipelineColorBlendStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineDepthStencilStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineDynamicStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineLayoutCreateInfo;
import org.lwjgl.vulkan.VkPipelineMultisampleStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineRasterizationConservativeStateCreateInfoEXT;
import org.lwjgl.vulkan.VkPipelineRasterizationStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineRenderingCreateInfoKHR;
import org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo;
import org.lwjgl.vulkan.VkPipelineViewportStateCreateInfo;
import org.lwjgl.vulkan.VkPushConstantRange;
import org.lwjgl.vulkan.VkWriteDescriptorSet;
import org.lwjgl.vulkan.VkDescriptorSetLayoutBinding.Buffer;

public final class TerrainOcclusion {
   static final int MAX_OCC_REGIONS = 512;
   static final int OCC_ENTRY_BYTES = 32;
   static final int OCC_LIST_BYTES = 16384;
   static final int READBACK_LAG = 3;
   static final int STATS_RING = 8;
   static final int STATS_BYTES = 16;
   private static long regionSetLayout;
   private static long regionPipelineLayout;
   private static long regionPipeline;
   private static long sectionSetLayout;
   private static long sectionPipelineLayout;
   private static long sectionPipeline;
   private static long regionSetLayoutExt;
   private static long regionPipelineLayoutExt;
   private static long regionPipelineExt;
   private static long sectionSetLayoutExt;
   private static long sectionPipelineLayoutExt;
   private static long sectionPipelineExt;
   private static long regionSetLayoutSodium;
   private static long regionPipelineLayoutSodium;
   private static long regionPipelineSodium;
   private static long sectionSetLayoutSodium;
   private static long sectionPipelineLayoutSodium;
   private static long sectionPipelineSodium;
   private static long regionPipelineFlat;
   private static long sectionPipelineFlat;
   private static long regionPipelineExtFlat;
   private static long sectionPipelineExtFlat;
   private static long regionPipelineSodiumFlat;
   private static long sectionPipelineSodiumFlat;
   private static long regionPipelineHalf;
   private static long sectionPipelineHalf;
   private static long regionPipelineExtHalf;
   private static long sectionPipelineExtHalf;
   private static long regionPipelineSodiumHalf;
   private static long sectionPipelineSodiumHalf;
   private static long downsampleSetLayout;
   private static long downsamplePipelineLayout;
   private static long downsamplePipeline;
   private final VulkanDevice device;
   private final VulkanCommandEncoder encoder;
   private final long vma;
   private final int regionStampSlots;
   private final boolean sodium;
   private final NvidiumPlusVkBuffers.DeviceBuffer sectionStampsA;
   private final NvidiumPlusVkBuffers.DeviceBuffer sectionStampsB;
   private final NvidiumPlusVkBuffers.DeviceBuffer regionStamps;
   private final NvidiumPlusVkBuffers.DeviceBuffer stats;
   private final NvidiumPlusVkBuffers.MappedBuffer statsRing;
   private final NvidiumPlusVkBuffers.DeviceBuffer predicate;
   private final int stampRows;
   private OcclusionHalfResTarget halfTarget;
   private final NvidiumPlusVkBuffers.MappedBuffer stampsRing;
   private final long copyBytes;
   private final long slotBytes;
   private final int copyRows;
   private final int[] ringStamp;
   private final long[] ringFrame;
   private final int[] ringForcedRegionWide;
   private final int[] ringForcedRegionPlain;
   private final int[] ringForcedSectionWide;
   private final int[] ringForcedSectionPlain;
   private volatile VisibleSetSample lastVisibleSet;
   private boolean stampsSizeLogged;
   private boolean captureOpen = true;
   static final String PROPERTY_PHASE_B_PREDICATE = "nvidiumplus.occlusion.phaseBPredicate";
   public static final String PROPERTY_HALF_RES = "nvidiumplus.occlusion.halfRes";
   public static final String PROPERTY_HALF_RES_ARM = "nvidiumplus.occlusion.halfResArm";
   public static final String PROPERTY_CONSERVATIVE_RASTER = "nvidiumplus.occlusion.conservativeRaster";
   static final String PROPERTY_HALF_RES_INFLATE = "nvidiumplus.occlusion.diag.halfResInflate";
   public static final String PROPERTY_STAMPS_READBACK = "nvidiumplus.occlusion.diag.stampsReadback";
   public static final String PROPERTY_STAMPS_ROWS = "nvidiumplus.occlusion.diag.stampsRows";
   public static final int HALF_RES_ARM_BIAS = 1;
   public static final int HALF_RES_ARM_FLAT = 2;
   private static volatile boolean halfResArmValueWarned;
   private static volatile boolean halfResEnabled = Boolean.getBoolean("nvidiumplus.occlusion.halfRes");
   private static volatile int halfResArm = configuredArm();
   private static volatile boolean halfResBroken;
   private static volatile String halfResError;
   static volatile long halfResFrames;
   static volatile long halfResRasterFrames;
   static volatile long halfResFlatFrames;
   static volatile long halfResAllocations;
   static volatile long halfResAllocationFailures;
   static volatile long halfResArmSkips;
   static volatile long halfResArmProjectionMismatches;
   static volatile long halfResArmSkipsNonFinite;
   static volatile long halfResArmSkipsNoPreBob;
   static volatile long halfResArmSkipsStale;
   static volatile long halfResArmSkipsShape;
   static volatile long halfResArmSkipsNonRigid;
   static volatile long halfResArmSkipsTranslation;
   static volatile long halfResArmSkipsView;
   static volatile float halfResMaxArmedTranslation;
   static volatile float halfResMaxArmedOrtho;
   static volatile long halfResArmedTransformedFrames;
   static volatile int halfResWidth;
   static volatile int halfResHeight;
   static volatile float halfResInflateK;
   static volatile float halfResNearR;

   static int listCapacity() {
      return Math.max(512, NvidiumPlusScaling.current().dispatchCapacity());
   }

   public static int configuredArm() {
      String v = System.getProperty("nvidiumplus.occlusion.halfResArm", "flat");
      if ("bias".equalsIgnoreCase(v)) {
         return 1;
      }

      if (!"flat".equalsIgnoreCase(v) && !halfResArmValueWarned) {
         halfResArmValueWarned = true;
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus: {}='{}' is not 'flat' or 'bias'; reading it as flat (the only arm whose superset holds by construction)",
               "nvidiumplus.occlusion.halfResArm",
               v
            );
      }

      return 2;
   }

   public static boolean halfResEnabled() {
      return halfResEnabled;
   }

   public static void setHalfResEnabled(boolean enabled) {
      halfResEnabled = enabled;
   }

   public static int halfResArm() {
      return halfResArm;
   }

   public static void setHalfResArm(int arm) {
      halfResArm = arm == 1 ? 1 : 2;
   }

   public static long halfResFrames() {
      return halfResFrames;
   }

   public static long halfResRasterFrames() {
      return halfResRasterFrames;
   }

   public static long halfResFlatFrames() {
      return halfResFlatFrames;
   }

   public static long halfResAllocations() {
      return halfResAllocations;
   }

   public static long halfResAllocationFailures() {
      return halfResAllocationFailures;
   }

   public static long halfResArmSkips() {
      return halfResArmSkips;
   }

   public static long halfResArmProjectionMismatches() {
      return halfResArmProjectionMismatches;
   }

   public static long halfResArmSkipsNonFinite() {
      return halfResArmSkipsNonFinite;
   }

   public static long halfResArmSkipsNoPreBob() {
      return halfResArmSkipsNoPreBob;
   }

   public static long halfResArmSkipsStale() {
      return halfResArmSkipsStale;
   }

   public static long halfResArmSkipsShape() {
      return halfResArmSkipsShape;
   }

   public static long halfResArmSkipsNonRigid() {
      return halfResArmSkipsNonRigid;
   }

   public static long halfResArmSkipsTranslation() {
      return halfResArmSkipsTranslation;
   }

   public static long halfResArmSkipsView() {
      return halfResArmSkipsView;
   }

   public static float halfResMaxArmedTranslation() {
      return halfResMaxArmedTranslation;
   }

   public static void resetHalfResMaxArmedForTest() {
      halfResMaxArmedTranslation = 0.0F;
      halfResMaxArmedOrtho = 0.0F;
   }

   public static float halfResMaxArmedOrtho() {
      return halfResMaxArmedOrtho;
   }

   public static long halfResArmedTransformedFrames() {
      return halfResArmedTransformedFrames;
   }

   public static String halfResArmSkipReasons() {
      return "total="
         + halfResArmSkips
         + " nonFinite="
         + halfResArmSkipsNonFinite
         + " noPreBob="
         + halfResArmSkipsNoPreBob
         + " stale="
         + halfResArmSkipsStale
         + " shape="
         + halfResArmSkipsShape
         + " nonRigid="
         + halfResArmSkipsNonRigid
         + " translation="
         + halfResArmSkipsTranslation
         + " view="
         + halfResArmSkipsView;
   }

   public static int halfResWidth() {
      return halfResWidth;
   }

   public static int halfResHeight() {
      return halfResHeight;
   }

   public static float halfResInflateK() {
      return halfResInflateK;
   }

   public static float halfResNearR() {
      return halfResNearR;
   }

   public static boolean halfResBroken() {
      return halfResBroken;
   }

   public static String halfResError() {
      return halfResError;
   }

   public static boolean conservativeRasterActive() {
      return NvidiumPlusVulkanState.conservativeRasterizationEnabled();
   }

   private static boolean halfResInflateEnabled() {
      String v = System.getProperty("nvidiumplus.occlusion.diag.halfResInflate");
      return v == null || Boolean.parseBoolean(v);
   }

   private static void latchHalfRes(Throwable t) {
      if (!halfResBroken) {
         halfResBroken = true;
         halfResError = String.valueOf(t);
         NvidiumPlusLog.LOGGER
            .error(
               "NvidiumPlus's half-resolution occlusion depth is standing down for the rest of this session; the rasters run at full resolution from this frame (first and only report)",
               t
            );
      }
   }

   private TerrainOcclusion(
      VulkanDevice device,
      VulkanCommandEncoder encoder,
      int regionStampSlots,
      boolean sodium,
      NvidiumPlusVkBuffers.DeviceBuffer sectionStampsA,
      NvidiumPlusVkBuffers.DeviceBuffer sectionStampsB,
      NvidiumPlusVkBuffers.DeviceBuffer regionStamps,
      NvidiumPlusVkBuffers.DeviceBuffer stats,
      NvidiumPlusVkBuffers.MappedBuffer statsRing,
      NvidiumPlusVkBuffers.DeviceBuffer predicate,
      int stampRows,
      NvidiumPlusVkBuffers.MappedBuffer stampsRing,
      int copyRows
   ) {
      this.device = device;
      this.encoder = encoder;
      this.vma = device.vma();
      this.regionStampSlots = regionStampSlots;
      this.sodium = sodium;
      this.sectionStampsA = sectionStampsA;
      this.sectionStampsB = sectionStampsB;
      this.regionStamps = regionStamps;
      this.stats = stats;
      this.statsRing = statsRing;
      this.predicate = predicate;
      this.stampRows = stampRows;
      this.stampsRing = stampsRing;
      this.copyRows = copyRows;
      this.copyBytes = copyRows * 256L * 4L;
      this.slotBytes = this.copyBytes + 16L;
      if (stampsRing == null) {
         this.ringStamp = null;
         this.ringFrame = null;
         this.ringForcedRegionWide = null;
         this.ringForcedRegionPlain = null;
         this.ringForcedSectionWide = null;
         this.ringForcedSectionPlain = null;
      } else {
         this.ringStamp = new int[8];
         this.ringFrame = new long[8];
         Arrays.fill(this.ringFrame, -1L);
         this.ringForcedRegionWide = new int[8];
         this.ringForcedRegionPlain = new int[8];
         this.ringForcedSectionWide = new int[8];
         this.ringForcedSectionPlain = new int[8];
      }
   }

   static TerrainOcclusion create() {
      return create(TerrainResidency.maxRegions(), listCapacity(), false);
   }

   static TerrainOcclusion create(int maxRegions, int listCapacity, boolean sodium) {
      GpuDevice facade = RenderSystem.tryGetDevice();
      if (facade == null) {
         return null;
      }

      VulkanDevice device = (VulkanDevice)((GpuDeviceAccessor)facade).nvidiumplus$backend();
      VulkanCommandEncoder encoder = device.createCommandEncoder();
      long vma = device.vma();
      long stampBytes = maxRegions * 256L * 4L;
      int regionStampSlots = listCapacity;
      int stampUsage = 34;
      boolean stampsReadback = Boolean.getBoolean("nvidiumplus.occlusion.diag.stampsReadback");
      int diagBytes = stampsReadback ? 8 : 0;
      if (stampsReadback) {
         stampUsage |= 1;
      }

      NvidiumPlusVkBuffers.DeviceBuffer a = NvidiumPlusVkBuffers.createDeviceLocal(
         vma, stampBytes + diagBytes, stampUsage, "vmaCreateBuffer(NvidiumPlus occlusion section stamps A)"
      );
      NvidiumPlusVkBuffers.DeviceBuffer b = NvidiumPlusVkBuffers.createDeviceLocal(
         vma, stampBytes + diagBytes, stampUsage, "vmaCreateBuffer(NvidiumPlus occlusion section stamps B)"
      );
      NvidiumPlusVkBuffers.DeviceBuffer region = NvidiumPlusVkBuffers.createDeviceLocal(
         vma, regionStampSlots * 4L + diagBytes, stampUsage, "vmaCreateBuffer(NvidiumPlus occlusion region stamps)"
      );
      NvidiumPlusVkBuffers.DeviceBuffer stats = null;
      NvidiumPlusVkBuffers.MappedBuffer ring = null;
      NvidiumPlusVkBuffers.DeviceBuffer predicate = null;
      if (!sodium) {
         stats = NvidiumPlusVkBuffers.createDeviceLocal(vma, 16L, stampUsage | 1, "vmaCreateBuffer(NvidiumPlus occlusion stats)");
         ring = NvidiumPlusVkBuffers.createHostReadback(vma, 128L, 2, "vmaCreateBuffer(NvidiumPlus occlusion stats ring)");
         String predProp = System.getProperty("nvidiumplus.occlusion.phaseBPredicate");
         boolean wantPredicate = predProp != null && Boolean.parseBoolean(predProp);
         if (wantPredicate && NvidiumPlusVulkanState.conditionalRenderingSupported()) {
            predicate = NvidiumPlusVkBuffers.createDeviceLocal(vma, 4L, 546, "vmaCreateBuffer(NvidiumPlus phase-B predicate)");
         } else if (wantPredicate && predProp != null) {
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus: {}=true but the device did not offer VK_EXT_conditional_rendering; phase B records directly",
                  "nvidiumplus.occlusion.phaseBPredicate"
               );
         }
      }

      NvidiumPlusVkBuffers.MappedBuffer stampsRing = null;
      int copyRows = maxRegions;
      if (stampsReadback) {
         int wanted = Integer.getInteger("nvidiumplus.occlusion.diag.stampsRows", 0);
         if (wanted > 0) {
            copyRows = Math.min(maxRegions, wanted);
         }

         long slot = copyRows * 256L * 4L + 16L;
         stampsRing = NvidiumPlusVkBuffers.createHostReadback(vma, 8L * slot, 2, "vmaCreateBuffer(NvidiumPlus occlusion stamps readback)");
      }

      TerrainOcclusion occ = new TerrainOcclusion(
         device, encoder, regionStampSlots, sodium, a, b, region, stats, ring, predicate, maxRegions, stampsRing, copyRows
      );
      occ.zeroInitialize(stampBytes + diagBytes, regionStampSlots * 4L + diagBytes);
      if (sodium) {
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus occlusion GPU state up for the Sodium host: 2×{} KiB section stamps ({} region ids × 256 slots) + {} B region stamps ({} slots), device '{}'; stats in the record mirror's header, phase-B predicate off.",
               new Object[]{stampBytes >> 10, maxRegions, regionStampSlots * 4, regionStampSlots, device.getDeviceInfo().name()}
            );
      } else {
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus occlusion GPU state up: 2×{} KiB section stamps + {} B region stamps ({} slots) + {} B stats (+{} B host ring), device '{}'; phase-B predicate {} (VK_EXT_conditional_rendering: the GPU skips the phase-B dispatches on frames where no section became newly visible)",
               new Object[]{stampBytes >> 10, regionStampSlots * 4, regionStampSlots, 16, 128, device.getDeviceInfo().name(), predicate != null ? "ON" : "off"}
            );
      }

      return occ;
   }

   boolean sodiumHost() {
      return this.sodium;
   }

   private void zeroInitialize(long stampBytes, long regionBytes) {
      MemoryStack stack = MemoryStack.stackPush();

      try {
         VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
         VK10.vkCmdFillBuffer(cb, this.sectionStampsA.vkBuffer(), 0L, stampBytes, 0);
         VK10.vkCmdFillBuffer(cb, this.sectionStampsB.vkBuffer(), 0L, stampBytes, 0);
         VK10.vkCmdFillBuffer(cb, this.regionStamps.vkBuffer(), 0L, regionBytes, 0);
         if (this.stats != null) {
            VK10.vkCmdFillBuffer(cb, this.stats.vkBuffer(), 0L, 16L, 0);
         }

         if (this.predicate != null) {
            VK10.vkCmdFillBuffer(cb, this.predicate.vkBuffer(), 0L, 4L, 1);
         }

         VulkanCommandEncoder.memoryBarrier(cb, stack);
         checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(occlusion zero-init)");
         this.encoder.execute(cb);
      } catch (Throwable var9) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var8) {
               var9.addSuppressed(var8);
            }
         }

         throw var9;
      }

      if (stack != null) {
         stack.close();
      }

      if (this.statsRing != null) {
         MemoryUtil.memSet(this.statsRing.mappedAddress(), 0, 128L);
      }

      if (this.stampsRing != null) {
         MemoryUtil.memSet(this.stampsRing.mappedAddress(), 0, 8L * this.slotBytes);
      }
   }

   boolean phaseBPredicateActive() {
      return this.predicate != null;
   }

   long predicateVkBuffer() {
      return this.predicate.vkBuffer();
   }

   long curStampsBuffer(long frameStamp) {
      return ((frameStamp & 1L) == 0L ? this.sectionStampsA : this.sectionStampsB).vkBuffer();
   }

   long otherStampsBuffer(long curBuffer) {
      return curBuffer == this.sectionStampsA.vkBuffer() ? this.sectionStampsB.vkBuffer() : this.sectionStampsA.vkBuffer();
   }

   long prevStampsBuffer(long frameStamp) {
      return ((frameStamp & 1L) == 0L ? this.sectionStampsB : this.sectionStampsA).vkBuffer();
   }

   long statsBuffer() {
      if (this.stats == null) {
         throw new IllegalStateException("no occlusion stats buffer on the Sodium host: read the mirror header through SodiumMirrorGpu");
      } else {
         return this.stats.vkBuffer();
      }
   }

   void ensurePipelines(int vkColorFormat, int vkDepthFormat, boolean extendedLists) {
      if ((extendedLists ? regionPipelineExt : regionPipeline) == 0L) {
         VkDevice vk = this.device.vkDevice();
         Map<String, String> macros = Map.of(
            "NVIDIUMPLUS_OCC_REGIONS", Integer.toString(512), "NVIDIUMPLUS_LISTS_SSBO", extendedLists ? "1" : "0", "NVIDIUMPLUS_SODIUM", "0"
         );
         Map<String, String> sectionMacros = Map.of(
            "NVIDIUMPLUS_OCC_REGIONS",
            Integer.toString(512),
            "NVIDIUMPLUS_LISTS_SSBO",
            extendedLists ? "1" : "0",
            "NVIDIUMPLUS_SODIUM",
            "0",
            "NVIDIUMPLUS_MARK_NEW",
            this.phaseBPredicateActive() ? "1" : "0"
         );
         long regionMesh = 0L;
         long sectionTask = 0L;
         long sectionMesh = 0L;
         long boxFrag = 0L;
         long boxFragSection = 0L;

         try {
            regionMesh = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/region_raster.mesh", 27, macros);
            sectionTask = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/section_raster.task", 26, sectionMacros);
            sectionMesh = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/section_raster.mesh", 27, sectionMacros);
            boxFrag = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/box.frag", 1, macros);
            boxFragSection = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/box.frag", 1, sectionMacros);
            MemoryStack stack = MemoryStack.stackPush();

            try {
               int taskStage = 64;
               int meshStage = 128;
               int fragStage = 16;
               int listType = extendedLists ? 7 : 6;
               String tag = extendedLists ? " (extended lists)" : "";
               Buffer rb = VkDescriptorSetLayoutBinding.calloc(4, stack);
               binding((VkDescriptorSetLayoutBinding)rb.get(0), 0, listType, meshStage);
               binding((VkDescriptorSetLayoutBinding)rb.get(1), 1, 6, meshStage);
               binding((VkDescriptorSetLayoutBinding)rb.get(2), 2, 6, meshStage);
               binding((VkDescriptorSetLayoutBinding)rb.get(3), 3, 7, meshStage | fragStage);
               long rSet = createSetLayout(vk, stack, rb, "region raster" + tag);
               long rLayout = createPipelineLayout(vk, stack, rSet, meshStage | fragStage, "region raster" + tag);
               long rPipe = buildBoxPipeline(vk, stack, vkColorFormat, vkDepthFormat, rLayout, 0L, regionMesh, boxFrag, "region raster" + tag, false, false);
               boolean mark = this.phaseBPredicateActive();
               Buffer sb = VkDescriptorSetLayoutBinding.calloc(mark ? 8 : 6, stack);
               binding((VkDescriptorSetLayoutBinding)sb.get(0), 0, listType, taskStage);
               binding((VkDescriptorSetLayoutBinding)sb.get(1), 1, 6, meshStage);
               binding((VkDescriptorSetLayoutBinding)sb.get(2), 2, 6, meshStage);
               binding((VkDescriptorSetLayoutBinding)sb.get(3), 3, 7, meshStage | fragStage);
               binding((VkDescriptorSetLayoutBinding)sb.get(4), 4, 7, taskStage);
               binding((VkDescriptorSetLayoutBinding)sb.get(5), 5, 7, meshStage);
               if (mark) {
                  binding((VkDescriptorSetLayoutBinding)sb.get(6), 6, 7, meshStage | fragStage);
                  binding((VkDescriptorSetLayoutBinding)sb.get(7), 7, 7, meshStage | fragStage);
               }

               long sSet = createSetLayout(vk, stack, sb, "section raster" + tag);
               long sLayout = createPipelineLayout(vk, stack, sSet, taskStage | meshStage | fragStage, "section raster" + tag);
               long sPipe = buildBoxPipeline(
                  vk,
                  stack,
                  vkColorFormat,
                  vkDepthFormat,
                  sLayout,
                  sectionTask,
                  sectionMesh,
                  mark ? boxFragSection : boxFrag,
                  "section raster" + tag,
                  false,
                  false
               );
               if (extendedLists) {
                  regionSetLayoutExt = rSet;
                  regionPipelineLayoutExt = rLayout;
                  regionPipelineExt = rPipe;
                  sectionSetLayoutExt = sSet;
                  sectionPipelineLayoutExt = sLayout;
                  sectionPipelineExt = sPipe;
               } else {
                  regionSetLayout = rSet;
                  regionPipelineLayout = rLayout;
                  regionPipeline = rPipe;
                  sectionSetLayout = sSet;
                  sectionPipelineLayout = sLayout;
                  sectionPipeline = sPipe;
               }
            } catch (Throwable var44) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var43) {
                     var44.addSuppressed(var43);
                  }
               }

               throw var44;
            }

            if (stack != null) {
               stack.close();
            }

            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus occlusion pipelines created (color format {}, depth format {}, {} regions/frame list cap{}, GEQUAL write-off, colorWriteMask 0, cull NONE)",
                  new Object[]{vkColorFormat, vkDepthFormat, extendedLists ? listCapacity() : 512, extendedLists ? " via SSBO frame lists (wave 10)" : ""}
               );
         } finally {
            VkDevice dev = vk;
            if (regionMesh != 0L) {
               VK10.vkDestroyShaderModule(dev, regionMesh, null);
            }

            if (sectionTask != 0L) {
               VK10.vkDestroyShaderModule(dev, sectionTask, null);
            }

            if (sectionMesh != 0L) {
               VK10.vkDestroyShaderModule(dev, sectionMesh, null);
            }

            if (boxFrag != 0L) {
               VK10.vkDestroyShaderModule(dev, boxFrag, null);
            }

            if (boxFragSection != 0L) {
               VK10.vkDestroyShaderModule(dev, boxFragSection, null);
            }
         }
      }
   }

   void ensureSodiumPipelines(int vkColorFormat, int vkDepthFormat) {
      if (regionPipelineSodium == 0L) {
         VkDevice vk = this.device.vkDevice();
         Map<String, String> macros = Map.of(
            "NVIDIUMPLUS_OCC_REGIONS",
            Integer.toString(512),
            "NVIDIUMPLUS_LISTS_SSBO",
            "1",
            "NVIDIUMPLUS_SODIUM",
            "1",
            "NVIDIUMPLUS_MARK_NEW",
            "0",
            "NVIDIUMPLUS_OCC_BOXES_PER_WG",
            Integer.toString(SodiumTerrainDrawer.OCC_BOXES_PER_WG)
         );
         long regionMesh = 0L;
         long sectionTask = 0L;
         long sectionMesh = 0L;
         long boxFrag = 0L;

         try {
            regionMesh = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/region_raster.mesh", 27, macros);
            sectionTask = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/section_raster.task", 26, macros);
            sectionMesh = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/section_raster.mesh", 27, macros);
            boxFrag = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/box.frag", 1, macros);
            MemoryStack stack = MemoryStack.stackPush();

            try {
               int taskStage = 64;
               int meshStage = 128;
               int fragStage = 16;
               String tag = " (Sodium host)";
               Buffer rb = VkDescriptorSetLayoutBinding.calloc(4, stack);
               binding((VkDescriptorSetLayoutBinding)rb.get(0), 0, 7, meshStage);
               binding((VkDescriptorSetLayoutBinding)rb.get(1), 1, 6, meshStage);
               binding((VkDescriptorSetLayoutBinding)rb.get(2), 2, 6, meshStage);
               binding((VkDescriptorSetLayoutBinding)rb.get(3), 3, 7, meshStage | fragStage);
               long rSet = createSetLayout(vk, stack, rb, "region raster" + tag);
               long rLayout = createPipelineLayout(vk, stack, rSet, meshStage | fragStage, "region raster" + tag);
               long rPipe = buildBoxPipeline(vk, stack, vkColorFormat, vkDepthFormat, rLayout, 0L, regionMesh, boxFrag, "region raster" + tag, false, false);
               Buffer sb = VkDescriptorSetLayoutBinding.calloc(6, stack);
               binding((VkDescriptorSetLayoutBinding)sb.get(0), 0, 7, taskStage);
               binding((VkDescriptorSetLayoutBinding)sb.get(1), 1, 6, meshStage);
               binding((VkDescriptorSetLayoutBinding)sb.get(2), 2, 6, meshStage);
               binding((VkDescriptorSetLayoutBinding)sb.get(3), 3, 7, meshStage | fragStage);
               binding((VkDescriptorSetLayoutBinding)sb.get(4), 4, 7, taskStage);
               binding((VkDescriptorSetLayoutBinding)sb.get(5), 5, 7, meshStage);
               long sSet = createSetLayout(vk, stack, sb, "section raster" + tag);
               long sLayout = createPipelineLayout(vk, stack, sSet, taskStage | meshStage | fragStage, "section raster" + tag);
               long sPipe = buildBoxPipeline(
                  vk, stack, vkColorFormat, vkDepthFormat, sLayout, sectionTask, sectionMesh, boxFrag, "section raster" + tag, false, false
               );
               regionSetLayoutSodium = rSet;
               regionPipelineLayoutSodium = rLayout;
               regionPipelineSodium = rPipe;
               sectionSetLayoutSodium = sSet;
               sectionPipelineLayoutSodium = sLayout;
               sectionPipelineSodium = sPipe;
            } catch (Throwable var37) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var36) {
                     var37.addSuppressed(var36);
                  }
               }

               throw var37;
            }

            if (stack != null) {
               stack.close();
            }

            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus occlusion pipelines created for the Sodium host (color format {}, depth format {}; 64-B list entries via the frame ring, section boxes from the record mirror's rows; GEQUAL write-off, colorWriteMask 0, cull NONE)",
                  vkColorFormat,
                  vkDepthFormat
               );
         } finally {
            if (regionMesh != 0L) {
               VK10.vkDestroyShaderModule(vk, regionMesh, null);
            }

            if (sectionTask != 0L) {
               VK10.vkDestroyShaderModule(vk, sectionTask, null);
            }

            if (sectionMesh != 0L) {
               VK10.vkDestroyShaderModule(vk, sectionMesh, null);
            }

            if (boxFrag != 0L) {
               VK10.vkDestroyShaderModule(vk, boxFrag, null);
            }
         }
      }
   }

   void ensureHalfResPipelines(int vkColorFormat, int vkDepthFormat, boolean extendedLists, boolean flat) {
      this.ensurePipelines(vkColorFormat, vkDepthFormat, extendedLists);
      long built = extendedLists ? (flat ? regionPipelineExtFlat : regionPipelineExtHalf) : (flat ? regionPipelineFlat : regionPipelineHalf);
      if (built == 0L) {
         this.buildHalfVariant(vkColorFormat, vkDepthFormat, false, extendedLists, flat);
      }
   }

   void ensureSodiumHalfResPipelines(int vkColorFormat, int vkDepthFormat, boolean flat) {
      this.ensureSodiumPipelines(vkColorFormat, vkDepthFormat);
      if ((flat ? regionPipelineSodiumFlat : regionPipelineSodiumHalf) == 0L) {
         this.buildHalfVariant(vkColorFormat, vkDepthFormat, true, true, flat);
      }
   }

   private void buildHalfVariant(int vkColorFormat, int vkDepthFormat, boolean sodiumHost, boolean extendedLists, boolean flat) {
      VkDevice vk = this.device.vkDevice();
      boolean mark = !sodiumHost && this.phaseBPredicateActive();
      Map<String, String> macros = new HashMap<>();
      macros.put("NVIDIUMPLUS_OCC_REGIONS", Integer.toString(512));
      macros.put("NVIDIUMPLUS_LISTS_SSBO", extendedLists ? "1" : "0");
      macros.put("NVIDIUMPLUS_SODIUM", sodiumHost ? "1" : "0");
      macros.put("NVIDIUMPLUS_MARK_NEW", mark ? "1" : "0");
      macros.put("NVIDIUMPLUS_OCC_HALFRES", "1");
      if (flat) {
         macros.put("NVIDIUMPLUS_OCC_HALFRES_FLAT", "1");
      }

      if (sodiumHost) {
         macros.put("NVIDIUMPLUS_OCC_BOXES_PER_WG", Integer.toString(SodiumTerrainDrawer.OCC_BOXES_PER_WG));
      }

      Map<String, String> regionMacros = new HashMap<>(macros);
      regionMacros.put("NVIDIUMPLUS_MARK_NEW", "0");
      String arm = flat ? "FLAT" : "bias (comparator; sound only where z+o<=1)";
      String tag = " (half-res " + arm + (sodiumHost ? ", Sodium host" : (extendedLists ? ", extended lists" : "")) + ")";
      long regionMesh = 0L;
      long sectionTask = 0L;
      long sectionMesh = 0L;
      long boxFrag = 0L;
      long boxFragSection = 0L;

      try {
         regionMesh = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/region_raster.mesh", 27, regionMacros);
         sectionTask = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/section_raster.task", 26, macros);
         sectionMesh = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/section_raster.mesh", 27, macros);
         boxFrag = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/box.frag", 1, regionMacros);
         boxFragSection = mark ? NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/box.frag", 1, macros) : 0L;
         MemoryStack stack = MemoryStack.stackPush();

         try {
            long rLayout;
            long sLayout;
            if (sodiumHost) {
               rLayout = regionPipelineLayoutSodium;
               sLayout = sectionPipelineLayoutSodium;
            } else if (extendedLists) {
               rLayout = regionPipelineLayoutExt;
               sLayout = sectionPipelineLayoutExt;
            } else {
               rLayout = regionPipelineLayout;
               sLayout = sectionPipelineLayout;
            }

            if (rLayout == 0L || sLayout == 0L) {
               throw new IllegalStateException(
                  "half-res occlusion pipelines were asked for before the full-res layouts existed (region " + rLayout + ", section " + sLayout + ")"
               );
            }

            long rPipe = buildBoxPipeline(vk, stack, vkColorFormat, vkDepthFormat, rLayout, 0L, regionMesh, boxFrag, "region raster" + tag, true, flat);
            long sPipe = buildBoxPipeline(
               vk, stack, vkColorFormat, vkDepthFormat, sLayout, sectionTask, sectionMesh, mark ? boxFragSection : boxFrag, "section raster" + tag, true, flat
            );
            if (sodiumHost) {
               if (flat) {
                  regionPipelineSodiumFlat = rPipe;
                  sectionPipelineSodiumFlat = sPipe;
               } else {
                  regionPipelineSodiumHalf = rPipe;
                  sectionPipelineSodiumHalf = sPipe;
               }
            } else if (extendedLists) {
               if (flat) {
                  regionPipelineExtFlat = rPipe;
                  sectionPipelineExtFlat = sPipe;
               } else {
                  regionPipelineExtHalf = rPipe;
                  sectionPipelineExtHalf = sPipe;
               }
            } else if (flat) {
               regionPipelineFlat = rPipe;
               sectionPipelineFlat = sPipe;
            } else {
               regionPipelineHalf = rPipe;
               sectionPipelineHalf = sPipe;
            }
         } catch (Throwable var36) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var35) {
                  var36.addSuppressed(var35);
               }
            }

            throw var36;
         }

         if (stack != null) {
            stack.close();
         }

         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus half-resolution occlusion pipelines created{} (color format {}, depth format {}; arm {}, conservative raster {}; the full-res set's layouts, GEQUAL write-off, colorWriteMask 0, cull NONE)",
               new Object[]{tag, vkColorFormat, vkDepthFormat, arm, conservativeRasterActive() ? "on" : "off"}
            );
      } finally {
         if (regionMesh != 0L) {
            VK10.vkDestroyShaderModule(vk, regionMesh, null);
         }

         if (sectionTask != 0L) {
            VK10.vkDestroyShaderModule(vk, sectionTask, null);
         }

         if (sectionMesh != 0L) {
            VK10.vkDestroyShaderModule(vk, sectionMesh, null);
         }

         if (boxFrag != 0L) {
            VK10.vkDestroyShaderModule(vk, boxFrag, null);
         }

         if (boxFragSection != 0L) {
            VK10.vkDestroyShaderModule(vk, boxFragSection, null);
         }
      }
   }

   void ensureDownsamplePipeline(int vkColorFormat, int vkDepthFormat) {
      if (downsamplePipeline == 0L) {
         VkDevice vk = this.device.vkDevice();
         long meshModule = 0L;
         long fragModule = 0L;

         try {
            meshModule = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/depth_downsample.mesh", 27, Map.of());
            fragModule = NvidiumPlusShaderCompiler.compileResourceToModule(vk, "/assets/nvidiumplus/shaders/occlusion/depth_downsample.frag", 1, Map.of());
            MemoryStack stack = MemoryStack.stackPush();

            try {
               int fragStage = 16;
               Buffer b = VkDescriptorSetLayoutBinding.calloc(1, stack);
               binding((VkDescriptorSetLayoutBinding)b.get(0), 0, 1, fragStage);
               long set = createSetLayout(vk, stack, b, "depth downsample");
               long layout = createPipelineLayout(vk, stack, set, fragStage, "depth downsample");
               long pipe = buildDownsamplePipeline(vk, stack, vkColorFormat, vkDepthFormat, layout, meshModule, fragModule);
               downsampleSetLayout = set;
               downsamplePipelineLayout = layout;
               downsamplePipeline = pipe;
            } catch (Throwable var22) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var21) {
                     var22.addSuppressed(var21);
                  }
               }

               throw var22;
            }

            if (stack != null) {
               stack.close();
            }

            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus occlusion depth downsample pipeline created (color format {}, depth format {}; full-screen mesh triangle at z=0.5, depth compare ALWAYS + write ON, MIN over the 2x2 (3-wide on an odd axis) window - reversed-Z, so the min is the FARTHEST sample and a max here would delete terrain)",
                  vkColorFormat,
                  vkDepthFormat
               );
         } finally {
            if (meshModule != 0L) {
               VK10.vkDestroyShaderModule(vk, meshModule, null);
            }

            if (fragModule != 0L) {
               VK10.vkDestroyShaderModule(vk, fragModule, null);
            }
         }
      }
   }

   void recordDepthDownsample(VkCommandBuffer cb, GpuTextureView mainDepth) {
      if (downsamplePipeline == 0L) {
         throw new IllegalStateException("the occlusion depth downsample pipeline was not created");
      }

      MemoryStack stack = MemoryStack.stackPush();

      try {
         VK10.vkCmdBindPipeline(cb, 0, downsamplePipeline);
         org.lwjgl.vulkan.VkDescriptorImageInfo.Buffer image = VkDescriptorImageInfo.calloc(1, stack);
         ((VkDescriptorImageInfo)image.get(0))
            .sampler(((VulkanGpuSampler)RenderSystem.getSamplerCache().getClampToEdge(FilterMode.NEAREST)).vkSampler())
            .imageView(((VulkanGpuTextureView)mainDepth).vkImageView())
            .imageLayout(1);
         org.lwjgl.vulkan.VkWriteDescriptorSet.Buffer writes = VkWriteDescriptorSet.calloc(1, stack);
         ((VkWriteDescriptorSet)writes.get(0)).sType$Default().dstBinding(0).descriptorCount(1).descriptorType(1).pImageInfo(image);
         KHRPushDescriptor.vkCmdPushDescriptorSetKHR(cb, 0, downsamplePipelineLayout, 0, writes);
         ByteBuffer push = stack.calloc(16);
         push.putInt(0, mainDepth.texture().getWidth(0));
         push.putInt(4, mainDepth.texture().getHeight(0));
         VK10.vkCmdPushConstants(cb, downsamplePipelineLayout, 16, 0, push);
         EXTMeshShader.vkCmdDrawMeshTasksEXT(cb, 1, 1, 1);
      } catch (Throwable var8) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var7) {
               var8.addSuppressed(var7);
            }
         }

         throw var8;
      }

      if (stack != null) {
         stack.close();
      }
   }

   int armHalfRes(
      GpuTextureView mainColor,
      GpuTextureView mainDepth,
      Matrix4fc projection,
      Matrix4fc preBob,
      Matrix4fc modelView,
      long preBobSerial,
      int vkColorFormat,
      int vkDepthFormat,
      boolean sodiumHost,
      boolean extendedLists
   ) {
      if (halfResEnabled && !halfResBroken) {
         int mode = halfResArm();
         boolean flat = mode == 2;

         try {
            if (this.halfTarget == null) {
               this.halfTarget = new OcclusionHalfResTarget(this.encoder);
            }

            if (!this.halfTarget.ensure(mainColor, mainDepth)) {
               return 0;
            }

            if (!this.halfTarget.arm(projection, preBob, modelView, preBobSerial)) {
               return 0;
            }

            this.ensureDownsamplePipeline(vkColorFormat, vkDepthFormat);
            if (sodiumHost) {
               this.ensureSodiumHalfResPipelines(vkColorFormat, vkDepthFormat, flat);
            } else {
               this.ensureHalfResPipelines(vkColorFormat, vkDepthFormat, extendedLists, flat);
            }
         } catch (GpuDeviceLossException t) {
            throw t;
         } catch (Throwable t) {
            latchHalfRes(t);
            return 0;
         }

         halfResFrames++;
         if (flat) {
            halfResFlatFrames++;
         }

         return mode;
      } else {
         return 0;
      }
   }

   GpuTextureView halfColorView() {
      return this.halfTarget == null ? null : this.halfTarget.colorView();
   }

   GpuTextureView halfDepthView() {
      return this.halfTarget == null ? null : this.halfTarget.depthView();
   }

   private float frameInflateK() {
      return this.halfTarget != null && halfResInflateEnabled() ? this.halfTarget.inflateK() : 0.0F;
   }

   private float frameNearR() {
      return this.halfTarget == null ? 0.0F : this.halfTarget.nearR();
   }

   void recordRegionRaster(VkCommandBuffer cb, TerrainOcclusion.ListSlice occList, GpuBufferSlice scene, int drawCount, int frameStamp, int halfMode) {
      GpuBufferSlice projection = RenderSystem.getProjectionMatrixBuffer();
      boolean ext = occList.ssbo();
      long pipeline = ext
         ? (halfMode == 2 ? regionPipelineExtFlat : (halfMode == 1 ? regionPipelineExtHalf : regionPipelineExt))
         : (halfMode == 2 ? regionPipelineFlat : (halfMode == 1 ? regionPipelineHalf : regionPipeline));
      long layout = ext ? regionPipelineLayoutExt : regionPipelineLayout;
      int listType = ext ? 7 : 6;
      MemoryStack stack = MemoryStack.stackPush();

      try {
         VK10.vkCmdBindPipeline(cb, 0, pipeline);
         org.lwjgl.vulkan.VkWriteDescriptorSet.Buffer writes = VkWriteDescriptorSet.calloc(4, stack);
         bufferWrite((VkWriteDescriptorSet)writes.get(0), 0, listType, bufferInfo(stack, occList.vkBuffer(), occList.offset(), occList.range()));
         bufferWrite((VkWriteDescriptorSet)writes.get(1), 1, 6, sliceInfo(stack, scene));
         bufferWrite((VkWriteDescriptorSet)writes.get(2), 2, 6, sliceInfo(stack, projection));
         bufferWrite((VkWriteDescriptorSet)writes.get(3), 3, 7, bufferInfo(stack, this.regionStamps.vkBuffer(), 0L, -1L));
         KHRPushDescriptor.vkCmdPushDescriptorSetKHR(cb, 0, layout, 0, writes);
         pushStamp(
            cb,
            stack,
            layout,
            144,
            frameStamp,
            halfMode != 0 ? this.frameInflateK() : 0.0F,
            halfMode != 0 ? this.frameNearR() : 0.0F,
            halfMode != 0 ? this.regionDiagBase() : 0
         );
         EXTMeshShader.vkCmdDrawMeshTasksEXT(cb, drawCount, 1, 1);
      } catch (Throwable var18) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var17) {
               var18.addSuppressed(var17);
            }
         }

         throw var18;
      }

      if (stack != null) {
         stack.close();
      }
   }

   void recordSectionRaster(
      VkCommandBuffer cb,
      TerrainOcclusion.ListSlice occList,
      GpuBufferSlice scene,
      long sectionRecordsBuffer,
      int drawCount,
      int frameStamp,
      long curStampsBuffer,
      int halfMode
   ) {
      GpuBufferSlice projection = RenderSystem.getProjectionMatrixBuffer();
      boolean ext = occList.ssbo();
      long pipeline = ext
         ? (halfMode == 2 ? sectionPipelineExtFlat : (halfMode == 1 ? sectionPipelineExtHalf : sectionPipelineExt))
         : (halfMode == 2 ? sectionPipelineFlat : (halfMode == 1 ? sectionPipelineHalf : sectionPipeline));
      long layout = ext ? sectionPipelineLayoutExt : sectionPipelineLayout;
      if (halfMode != 0) {
         halfResRasterFrames++;
      }

      int listType = ext ? 7 : 6;
      MemoryStack stack = MemoryStack.stackPush();

      try {
         VK10.vkCmdBindPipeline(cb, 0, pipeline);
         boolean mark = this.phaseBPredicateActive();
         org.lwjgl.vulkan.VkWriteDescriptorSet.Buffer writes = VkWriteDescriptorSet.calloc(mark ? 8 : 6, stack);
         bufferWrite((VkWriteDescriptorSet)writes.get(0), 0, listType, bufferInfo(stack, occList.vkBuffer(), occList.offset(), occList.range()));
         bufferWrite((VkWriteDescriptorSet)writes.get(1), 1, 6, sliceInfo(stack, scene));
         bufferWrite((VkWriteDescriptorSet)writes.get(2), 2, 6, sliceInfo(stack, projection));
         bufferWrite((VkWriteDescriptorSet)writes.get(3), 3, 7, bufferInfo(stack, curStampsBuffer, 0L, -1L));
         bufferWrite((VkWriteDescriptorSet)writes.get(4), 4, 7, bufferInfo(stack, this.regionStamps.vkBuffer(), 0L, -1L));
         bufferWrite((VkWriteDescriptorSet)writes.get(5), 5, 7, bufferInfo(stack, sectionRecordsBuffer, 0L, -1L));
         if (mark) {
            bufferWrite((VkWriteDescriptorSet)writes.get(6), 6, 7, bufferInfo(stack, this.otherStampsBuffer(curStampsBuffer), 0L, -1L));
            bufferWrite((VkWriteDescriptorSet)writes.get(7), 7, 7, bufferInfo(stack, this.predicate.vkBuffer(), 0L, -1L));
         }

         KHRPushDescriptor.vkCmdPushDescriptorSetKHR(cb, 0, layout, 0, writes);
         pushStamp(
            cb,
            stack,
            layout,
            208,
            frameStamp,
            halfMode != 0 ? this.frameInflateK() : 0.0F,
            halfMode != 0 ? this.frameNearR() : 0.0F,
            halfMode != 0 ? this.sectionDiagBase() : 0
         );
         EXTMeshShader.vkCmdDrawMeshTasksEXT(cb, drawCount, 1, 1);
      } catch (Throwable var22) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var21) {
               var22.addSuppressed(var21);
            }
         }

         throw var22;
      }

      if (stack != null) {
         stack.close();
      }
   }

   private int regionDiagBase() {
      return this.stampsRing == null ? 0 : this.regionStampSlots;
   }

   private int sectionDiagBase() {
      return this.stampsRing == null ? 0 : this.stampRows * 256;
   }

   void recordRegionRasterSodium(
      VkCommandBuffer cb, TerrainOcclusion.ListSlice occList, GpuBufferSlice scene, GpuBufferSlice projection, int drawCount, int frameStamp, int halfMode
   ) {
      if (drawCount > 0) {
         long pipeline = halfMode == 2 ? regionPipelineSodiumFlat : (halfMode == 1 ? regionPipelineSodiumHalf : regionPipelineSodium);
         if (pipeline == 0L) {
            throw new IllegalStateException("Sodium-host occlusion pipelines were not created");
         }

         MemoryStack stack = MemoryStack.stackPush();

         try {
            VK10.vkCmdBindPipeline(cb, 0, pipeline);
            org.lwjgl.vulkan.VkWriteDescriptorSet.Buffer writes = VkWriteDescriptorSet.calloc(4, stack);
            bufferWrite((VkWriteDescriptorSet)writes.get(0), 0, 7, bufferInfo(stack, occList.vkBuffer(), occList.offset(), occList.range()));
            bufferWrite((VkWriteDescriptorSet)writes.get(1), 1, 6, sliceInfo(stack, scene));
            bufferWrite((VkWriteDescriptorSet)writes.get(2), 2, 6, sliceInfo(stack, projection));
            bufferWrite((VkWriteDescriptorSet)writes.get(3), 3, 7, bufferInfo(stack, this.regionStamps.vkBuffer(), 0L, -1L));
            KHRPushDescriptor.vkCmdPushDescriptorSetKHR(cb, 0, regionPipelineLayoutSodium, 0, writes);
            pushStamp(
               cb,
               stack,
               regionPipelineLayoutSodium,
               144,
               frameStamp,
               halfMode != 0 ? this.frameInflateK() : 0.0F,
               halfMode != 0 ? this.frameNearR() : 0.0F,
               halfMode != 0 ? this.regionDiagBase() : 0
            );
            EXTMeshShader.vkCmdDrawMeshTasksEXT(cb, drawCount, 1, 1);
         } catch (Throwable var14) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var13) {
                  var14.addSuppressed(var13);
               }
            }

            throw var14;
         }

         if (stack != null) {
            stack.close();
         }
      }
   }

   void recordSectionRasterSodium(
      VkCommandBuffer cb,
      TerrainOcclusion.ListSlice occList,
      GpuBufferSlice scene,
      GpuBufferSlice projection,
      long rowsVkBuffer,
      long rowsOffset,
      long rowsRange,
      int drawCount,
      int frameStamp,
      long curStampsBuffer,
      int halfMode
   ) {
      if (drawCount > 0) {
         long pipeline = halfMode == 2 ? sectionPipelineSodiumFlat : (halfMode == 1 ? sectionPipelineSodiumHalf : sectionPipelineSodium);
         if (pipeline == 0L) {
            throw new IllegalStateException("Sodium-host occlusion pipelines were not created");
         }

         if (halfMode != 0) {
            halfResRasterFrames++;
         }

         MemoryStack stack = MemoryStack.stackPush();

         try {
            VK10.vkCmdBindPipeline(cb, 0, pipeline);
            org.lwjgl.vulkan.VkWriteDescriptorSet.Buffer writes = VkWriteDescriptorSet.calloc(6, stack);
            bufferWrite((VkWriteDescriptorSet)writes.get(0), 0, 7, bufferInfo(stack, occList.vkBuffer(), occList.offset(), occList.range()));
            bufferWrite((VkWriteDescriptorSet)writes.get(1), 1, 6, sliceInfo(stack, scene));
            bufferWrite((VkWriteDescriptorSet)writes.get(2), 2, 6, sliceInfo(stack, projection));
            bufferWrite((VkWriteDescriptorSet)writes.get(3), 3, 7, bufferInfo(stack, curStampsBuffer, 0L, -1L));
            bufferWrite((VkWriteDescriptorSet)writes.get(4), 4, 7, bufferInfo(stack, this.regionStamps.vkBuffer(), 0L, -1L));
            bufferWrite((VkWriteDescriptorSet)writes.get(5), 5, 7, bufferInfo(stack, rowsVkBuffer, rowsOffset, rowsRange));
            KHRPushDescriptor.vkCmdPushDescriptorSetKHR(cb, 0, sectionPipelineLayoutSodium, 0, writes);
            pushStamp(
               cb,
               stack,
               sectionPipelineLayoutSodium,
               208,
               frameStamp,
               halfMode != 0 ? this.frameInflateK() : 0.0F,
               halfMode != 0 ? this.frameNearR() : 0.0F,
               halfMode != 0 ? this.sectionDiagBase() : 0
            );
            EXTMeshShader.vkCmdDrawMeshTasksEXT(cb, drawCount, 1, 1);
         } catch (Throwable var22) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var21) {
                  var22.addSuppressed(var21);
               }
            }

            throw var22;
         }

         if (stack != null) {
            stack.close();
         }
      }
   }

   void recordStatsTransfer(long statsFrame) {
      if (this.stats == null) {
         throw new IllegalStateException("no occlusion stats buffer on the Sodium host: SodiumMirrorGpu.recordStatsTransfer reads the mirror header");
      }

      MemoryStack stack = MemoryStack.stackPush();

      try {
         VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
         org.lwjgl.vulkan.VkBufferCopy.Buffer copy = VkBufferCopy.calloc(1, stack);
         ((VkBufferCopy)copy.get(0)).srcOffset(0L).dstOffset(statsFrame % 8L * 16L).size(16L);
         VK10.vkCmdCopyBuffer(cb, this.stats.vkBuffer(), this.statsRing.vkBuffer(), copy);
         VulkanCommandEncoder.memoryBarrier(cb, stack);
         VK10.vkCmdFillBuffer(cb, this.stats.vkBuffer(), 0L, 16L, 0);
         if (this.predicate != null) {
            VK10.vkCmdFillBuffer(cb, this.predicate.vkBuffer(), 0L, 4L, 0);
         }

         VulkanCommandEncoder.memoryBarrier(cb, stack);
         checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(occlusion stats)");
         this.encoder.execute(cb);
      } catch (Throwable var7) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }
         }

         throw var7;
      }

      if (stack != null) {
         stack.close();
      }
   }

   int[] readStats(long statsFrame) {
      if (statsFrame >= 0L && this.statsRing != null) {
         long base = this.statsRing.mappedAddress() + statsFrame % 8L * 16L;
         ByteBuffer slot = MemoryUtil.memByteBuffer(base, 16).order(ByteOrder.LITTLE_ENDIAN);
         return new int[]{slot.getInt(0), slot.getInt(4), slot.getInt(8), slot.getInt(12)};
      } else {
         return null;
      }
   }

   boolean visibleSetCaptureAvailable() {
      return this.stampsRing != null;
   }

   void beginVisibleSetCapture() {
      this.captureOpen = true;
   }

   void endVisibleSetCapture() {
      this.captureOpen = false;
   }

   void recordStampsTransfer(long statsFrame, long curStampsBuffer, int frameStamp) {
      if (this.stampsRing != null && this.captureOpen && statsFrame >= 0L) {
         int slot = (int)(statsFrame % 8L);
         long dst = slot * this.slotBytes;
         long sectionDiagBytes = this.stampRows * 256L * 4L;
         long regionDiagBytes = this.regionStampSlots * 4L;
         MemoryStack stack = MemoryStack.stackPush();

         try {
            VkCommandBuffer cb = this.encoder.allocateAndBeginTransientCommandBuffer();
            org.lwjgl.vulkan.VkBufferCopy.Buffer copy = VkBufferCopy.calloc(2, stack);
            ((VkBufferCopy)copy.get(0)).srcOffset(0L).dstOffset(dst).size(this.copyBytes);
            ((VkBufferCopy)copy.get(1)).srcOffset(sectionDiagBytes).dstOffset(dst + this.copyBytes).size(8L);
            VK10.vkCmdCopyBuffer(cb, curStampsBuffer, this.stampsRing.vkBuffer(), copy);
            org.lwjgl.vulkan.VkBufferCopy.Buffer regionCopy = VkBufferCopy.calloc(1, stack);
            ((VkBufferCopy)regionCopy.get(0)).srcOffset(regionDiagBytes).dstOffset(dst + this.copyBytes + 8L).size(8L);
            VK10.vkCmdCopyBuffer(cb, this.regionStamps.vkBuffer(), this.stampsRing.vkBuffer(), regionCopy);
            VulkanCommandEncoder.memoryBarrier(cb, stack);
            VK10.vkCmdFillBuffer(cb, curStampsBuffer, sectionDiagBytes, 8L, 0);
            VK10.vkCmdFillBuffer(cb, this.regionStamps.vkBuffer(), regionDiagBytes, 8L, 0);
            VulkanCommandEncoder.memoryBarrier(cb, stack);
            checkVk(VK10.vkEndCommandBuffer(cb), "vkEndCommandBuffer(occlusion stamps)");
            this.encoder.execute(cb);
         } catch (Throwable var18) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var17) {
                  var18.addSuppressed(var17);
               }
            }

            throw var18;
         }

         if (stack != null) {
            stack.close();
         }

         this.ringStamp[slot] = frameStamp;
         this.ringFrame[slot] = statsFrame;
         if (!this.stampsSizeLogged) {
            this.stampsSizeLogged = true;
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus occlusion stamps readback ARMED (test-only): {} of {} stamp rows copied per owned frame = {} KiB a slot, {} KiB ring, and a render-thread fold over {} ints EVERY owned frame. Never set this in a bench or a latency leg.",
                  new Object[]{this.copyRows, this.stampRows, this.copyBytes >> 10, 8L * this.slotBytes >> 10, this.copyBytes / 4L}
               );
         }
      }
   }

   void foldVisibleSet(long readFrame) {
      if (this.stampsRing != null && readFrame >= 0L) {
         int slot = (int)(readFrame % 8L);
         if (this.ringFrame[slot] == readFrame) {
            long base = this.stampsRing.mappedAddress() + slot * this.slotBytes;
            ByteBuffer buf = MemoryUtil.memByteBuffer(base, (int)this.slotBytes).order(ByteOrder.LITTLE_ENDIAN);
            int words = this.copyRows * 256;
            int stamp = this.ringStamp[slot];
            BitSet bits = new BitSet(words);

            for (int i = 0; i < words; i++) {
               if (buf.getInt(i * 4) == stamp) {
                  bits.set(i);
               }
            }

            int tail = (int)this.copyBytes;
            int sectionWide = buf.getInt(tail);
            int sectionPlain = buf.getInt(tail + 4);
            int regionWide = buf.getInt(tail + 8);
            int regionPlain = buf.getInt(tail + 12);
            this.lastVisibleSet = new VisibleSetSample(readFrame, bits, regionWide, regionPlain, sectionWide, sectionPlain);
         }
      }
   }

   VisibleSetSample debugVisibleSet() {
      return this.lastVisibleSet;
   }

   static void destroyPipelines(VkDevice vk) {
      if (regionPipeline != 0L) {
         VK10.vkDestroyPipeline(vk, regionPipeline, null);
         regionPipeline = 0L;
      }

      if (regionPipelineLayout != 0L) {
         VK10.vkDestroyPipelineLayout(vk, regionPipelineLayout, null);
         regionPipelineLayout = 0L;
      }

      if (regionSetLayout != 0L) {
         VK10.vkDestroyDescriptorSetLayout(vk, regionSetLayout, null);
         regionSetLayout = 0L;
      }

      if (sectionPipeline != 0L) {
         VK10.vkDestroyPipeline(vk, sectionPipeline, null);
         sectionPipeline = 0L;
      }

      if (sectionPipelineLayout != 0L) {
         VK10.vkDestroyPipelineLayout(vk, sectionPipelineLayout, null);
         sectionPipelineLayout = 0L;
      }

      if (sectionSetLayout != 0L) {
         VK10.vkDestroyDescriptorSetLayout(vk, sectionSetLayout, null);
         sectionSetLayout = 0L;
      }

      if (regionPipelineExt != 0L) {
         VK10.vkDestroyPipeline(vk, regionPipelineExt, null);
         regionPipelineExt = 0L;
      }

      if (regionPipelineLayoutExt != 0L) {
         VK10.vkDestroyPipelineLayout(vk, regionPipelineLayoutExt, null);
         regionPipelineLayoutExt = 0L;
      }

      if (regionSetLayoutExt != 0L) {
         VK10.vkDestroyDescriptorSetLayout(vk, regionSetLayoutExt, null);
         regionSetLayoutExt = 0L;
      }

      if (sectionPipelineExt != 0L) {
         VK10.vkDestroyPipeline(vk, sectionPipelineExt, null);
         sectionPipelineExt = 0L;
      }

      if (sectionPipelineLayoutExt != 0L) {
         VK10.vkDestroyPipelineLayout(vk, sectionPipelineLayoutExt, null);
         sectionPipelineLayoutExt = 0L;
      }

      if (sectionSetLayoutExt != 0L) {
         VK10.vkDestroyDescriptorSetLayout(vk, sectionSetLayoutExt, null);
         sectionSetLayoutExt = 0L;
      }

      if (regionPipelineSodium != 0L) {
         VK10.vkDestroyPipeline(vk, regionPipelineSodium, null);
         regionPipelineSodium = 0L;
      }

      if (regionPipelineLayoutSodium != 0L) {
         VK10.vkDestroyPipelineLayout(vk, regionPipelineLayoutSodium, null);
         regionPipelineLayoutSodium = 0L;
      }

      if (regionSetLayoutSodium != 0L) {
         VK10.vkDestroyDescriptorSetLayout(vk, regionSetLayoutSodium, null);
         regionSetLayoutSodium = 0L;
      }

      if (sectionPipelineSodium != 0L) {
         VK10.vkDestroyPipeline(vk, sectionPipelineSodium, null);
         sectionPipelineSodium = 0L;
      }

      if (sectionPipelineLayoutSodium != 0L) {
         VK10.vkDestroyPipelineLayout(vk, sectionPipelineLayoutSodium, null);
         sectionPipelineLayoutSodium = 0L;
      }

      if (sectionSetLayoutSodium != 0L) {
         VK10.vkDestroyDescriptorSetLayout(vk, sectionSetLayoutSodium, null);
         sectionSetLayoutSodium = 0L;
      }

      long[] halfPipelines = new long[]{
         regionPipelineFlat,
         sectionPipelineFlat,
         regionPipelineExtFlat,
         sectionPipelineExtFlat,
         regionPipelineSodiumFlat,
         sectionPipelineSodiumFlat,
         regionPipelineHalf,
         sectionPipelineHalf,
         regionPipelineExtHalf,
         sectionPipelineExtHalf,
         regionPipelineSodiumHalf,
         sectionPipelineSodiumHalf
      };

      for (long p : halfPipelines) {
         if (p != 0L) {
            VK10.vkDestroyPipeline(vk, p, null);
         }
      }

      regionPipelineFlat = 0L;
      sectionPipelineFlat = 0L;
      regionPipelineExtFlat = 0L;
      sectionPipelineExtFlat = 0L;
      regionPipelineSodiumFlat = 0L;
      sectionPipelineSodiumFlat = 0L;
      regionPipelineHalf = 0L;
      sectionPipelineHalf = 0L;
      regionPipelineExtHalf = 0L;
      sectionPipelineExtHalf = 0L;
      regionPipelineSodiumHalf = 0L;
      sectionPipelineSodiumHalf = 0L;
      if (downsamplePipeline != 0L) {
         VK10.vkDestroyPipeline(vk, downsamplePipeline, null);
         downsamplePipeline = 0L;
      }

      if (downsamplePipelineLayout != 0L) {
         VK10.vkDestroyPipelineLayout(vk, downsamplePipelineLayout, null);
         downsamplePipelineLayout = 0L;
      }

      if (downsampleSetLayout != 0L) {
         VK10.vkDestroyDescriptorSetLayout(vk, downsampleSetLayout, null);
         downsampleSetLayout = 0L;
      }
   }

   void destroyNow() {
      if (this.halfTarget != null) {
         this.halfTarget.destroyNow();
         this.halfTarget = null;
      }

      if (this.stampsRing != null) {
         NvidiumPlusVkBuffers.destroy(this.vma, this.stampsRing.vkBuffer(), this.stampsRing.allocation());
      }

      NvidiumPlusVkBuffers.destroy(this.vma, this.sectionStampsA.vkBuffer(), this.sectionStampsA.allocation());
      NvidiumPlusVkBuffers.destroy(this.vma, this.sectionStampsB.vkBuffer(), this.sectionStampsB.allocation());
      NvidiumPlusVkBuffers.destroy(this.vma, this.regionStamps.vkBuffer(), this.regionStamps.allocation());
      if (this.stats != null) {
         NvidiumPlusVkBuffers.destroy(this.vma, this.stats.vkBuffer(), this.stats.allocation());
      }

      if (this.statsRing != null) {
         NvidiumPlusVkBuffers.destroy(this.vma, this.statsRing.vkBuffer(), this.statsRing.allocation());
      }

      if (this.predicate != null) {
         NvidiumPlusVkBuffers.destroy(this.vma, this.predicate.vkBuffer(), this.predicate.allocation());
      }
   }

   void destroy() {
      if (this.halfTarget != null) {
         this.halfTarget.destroy();
         this.halfTarget = null;
      }

      long vmaHandle = this.vma;
      NvidiumPlusVkBuffers.MappedBuffer stampRing = this.stampsRing;
      NvidiumPlusVkBuffers.DeviceBuffer a = this.sectionStampsA;
      NvidiumPlusVkBuffers.DeviceBuffer b = this.sectionStampsB;
      NvidiumPlusVkBuffers.DeviceBuffer region = this.regionStamps;
      NvidiumPlusVkBuffers.DeviceBuffer st = this.stats;
      NvidiumPlusVkBuffers.MappedBuffer ring = this.statsRing;
      NvidiumPlusVkBuffers.DeviceBuffer pred = this.predicate;
      this.encoder.queueForDestroy(() -> {
         NvidiumPlusVkBuffers.destroy(vmaHandle, a.vkBuffer(), a.allocation());
         NvidiumPlusVkBuffers.destroy(vmaHandle, b.vkBuffer(), b.allocation());
         NvidiumPlusVkBuffers.destroy(vmaHandle, region.vkBuffer(), region.allocation());
         if (st != null) {
            NvidiumPlusVkBuffers.destroy(vmaHandle, st.vkBuffer(), st.allocation());
         }

         if (ring != null) {
            NvidiumPlusVkBuffers.destroy(vmaHandle, ring.vkBuffer(), ring.allocation());
         }

         if (pred != null) {
            NvidiumPlusVkBuffers.destroy(vmaHandle, pred.vkBuffer(), pred.allocation());
         }

         if (stampRing != null) {
            NvidiumPlusVkBuffers.destroy(vmaHandle, stampRing.vkBuffer(), stampRing.allocation());
         }
      });
   }

   private static long createSetLayout(VkDevice vk, MemoryStack stack, Buffer bindings, String what) {
      VkDescriptorSetLayoutCreateInfo info = VkDescriptorSetLayoutCreateInfo.calloc(stack).sType$Default().flags(1).pBindings(bindings);
      LongBuffer handle = stack.mallocLong(1);
      checkVk(VK10.vkCreateDescriptorSetLayout(vk, info, null, handle), "vkCreateDescriptorSetLayout(occlusion " + what + ")");
      return handle.get(0);
   }

   private static long createPipelineLayout(VkDevice vk, MemoryStack stack, long setLayout, int pushStages, String what) {
      org.lwjgl.vulkan.VkPushConstantRange.Buffer range = VkPushConstantRange.calloc(1, stack);
      ((VkPushConstantRange)range.get(0)).stageFlags(pushStages).offset(0).size(16);
      VkPipelineLayoutCreateInfo info = VkPipelineLayoutCreateInfo.calloc(stack)
         .sType$Default()
         .pSetLayouts(stack.longs(setLayout))
         .setLayoutCount(1)
         .pPushConstantRanges(range);
      LongBuffer handle = stack.mallocLong(1);
      checkVk(VK10.vkCreatePipelineLayout(vk, info, null, handle), "vkCreatePipelineLayout(occlusion " + what + ")");
      return handle.get(0);
   }

   private static long buildBoxPipeline(
      VkDevice vk,
      MemoryStack stack,
      int vkColorFormat,
      int vkDepthFormat,
      long pipelineLayout,
      long taskModule,
      long meshModule,
      long fragModule,
      String what,
      boolean half,
      boolean flat
   ) {
      VkPipelineViewportStateCreateInfo viewportState = VkPipelineViewportStateCreateInfo.calloc(stack).sType$Default().viewportCount(1).scissorCount(1);
      VkPipelineRasterizationStateCreateInfo rasterState = VkPipelineRasterizationStateCreateInfo.calloc(stack)
         .sType$Default()
         .depthClampEnable(false)
         .rasterizerDiscardEnable(false)
         .polygonMode(0)
         .cullMode(0)
         .frontFace(1)
         .depthBiasEnable(false)
         .lineWidth(1.0F);
      if (half && !flat) {
         rasterState.depthBiasEnable(true).depthBiasConstantFactor(2.0F).depthBiasClamp(0.0F).depthBiasSlopeFactor(2.0F);
      }

      if (conservativeRasterActive()) {
         rasterState.pNext(
            VkPipelineRasterizationConservativeStateCreateInfoEXT.calloc(stack)
               .sType$Default()
               .flags(0)
               .conservativeRasterizationMode(1)
               .extraPrimitiveOverestimationSize(0.0F)
         );
      }

      VkPipelineMultisampleStateCreateInfo multisampleState = VkPipelineMultisampleStateCreateInfo.calloc(stack)
         .sType$Default()
         .rasterizationSamples(1)
         .sampleShadingEnable(false);
      VkPipelineDepthStencilStateCreateInfo depthState = VkPipelineDepthStencilStateCreateInfo.calloc(stack)
         .sType$Default()
         .depthTestEnable(true)
         .depthWriteEnable(false)
         .depthCompareOp(6);
      org.lwjgl.vulkan.VkPipelineColorBlendAttachmentState.Buffer blendAttachment = VkPipelineColorBlendAttachmentState.calloc(1, stack);
      ((VkPipelineColorBlendAttachmentState)blendAttachment.get(0)).blendEnable(false).colorWriteMask(0);
      VkPipelineColorBlendStateCreateInfo blendState = VkPipelineColorBlendStateCreateInfo.calloc(stack)
         .sType$Default()
         .logicOpEnable(false)
         .pAttachments(blendAttachment)
         .attachmentCount(1);
      VkPipelineDynamicStateCreateInfo dynamicState = VkPipelineDynamicStateCreateInfo.calloc(stack).sType$Default().pDynamicStates(stack.ints(1, 0));
      VkPipelineRenderingCreateInfoKHR renderingInfo = VkPipelineRenderingCreateInfoKHR.calloc(stack)
         .sType$Default()
         .colorAttachmentCount(1)
         .pColorAttachmentFormats(stack.ints(vkColorFormat))
         .depthAttachmentFormat(vkDepthFormat);
      int stageCount = taskModule != 0L ? 3 : 2;
      org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo.Buffer stages = VkPipelineShaderStageCreateInfo.calloc(stageCount, stack);
      int si = 0;
      if (taskModule != 0L) {
         ((VkPipelineShaderStageCreateInfo)stages.get(si++)).sType$Default().stage(64).module(taskModule).pName(stack.UTF8("main"));
      }

      ((VkPipelineShaderStageCreateInfo)stages.get(si++)).sType$Default().stage(128).module(meshModule).pName(stack.UTF8("main"));
      ((VkPipelineShaderStageCreateInfo)stages.get(si)).sType$Default().stage(16).module(fragModule).pName(stack.UTF8("main"));
      org.lwjgl.vulkan.VkGraphicsPipelineCreateInfo.Buffer createInfo = VkGraphicsPipelineCreateInfo.calloc(1, stack);
      ((VkGraphicsPipelineCreateInfo)createInfo.get(0))
         .sType$Default()
         .pNext(renderingInfo.address())
         .pStages(stages)
         .stageCount(stageCount)
         .pViewportState(viewportState)
         .pRasterizationState(rasterState)
         .pMultisampleState(multisampleState)
         .pDepthStencilState(depthState)
         .pColorBlendState(blendState)
         .pDynamicState(dynamicState)
         .layout(pipelineLayout)
         .renderPass(0L);
      LongBuffer pipelines = stack.mallocLong(1);
      checkVk(VK10.vkCreateGraphicsPipelines(vk, 0L, createInfo, null, pipelines), "vkCreateGraphicsPipelines(NvidiumPlus occlusion " + what + ")");
      return pipelines.get(0);
   }

   private static long buildDownsamplePipeline(
      VkDevice vk, MemoryStack stack, int vkColorFormat, int vkDepthFormat, long pipelineLayout, long meshModule, long fragModule
   ) {
      VkPipelineViewportStateCreateInfo viewportState = VkPipelineViewportStateCreateInfo.calloc(stack).sType$Default().viewportCount(1).scissorCount(1);
      VkPipelineRasterizationStateCreateInfo rasterState = VkPipelineRasterizationStateCreateInfo.calloc(stack)
         .sType$Default()
         .depthClampEnable(false)
         .rasterizerDiscardEnable(false)
         .polygonMode(0)
         .cullMode(0)
         .frontFace(1)
         .depthBiasEnable(false)
         .lineWidth(1.0F);
      VkPipelineMultisampleStateCreateInfo multisampleState = VkPipelineMultisampleStateCreateInfo.calloc(stack)
         .sType$Default()
         .rasterizationSamples(1)
         .sampleShadingEnable(false);
      VkPipelineDepthStencilStateCreateInfo depthState = VkPipelineDepthStencilStateCreateInfo.calloc(stack)
         .sType$Default()
         .depthTestEnable(true)
         .depthWriteEnable(true)
         .depthCompareOp(7);
      org.lwjgl.vulkan.VkPipelineColorBlendAttachmentState.Buffer blendAttachment = VkPipelineColorBlendAttachmentState.calloc(1, stack);
      ((VkPipelineColorBlendAttachmentState)blendAttachment.get(0)).blendEnable(false).colorWriteMask(0);
      VkPipelineColorBlendStateCreateInfo blendState = VkPipelineColorBlendStateCreateInfo.calloc(stack)
         .sType$Default()
         .logicOpEnable(false)
         .pAttachments(blendAttachment)
         .attachmentCount(1);
      VkPipelineDynamicStateCreateInfo dynamicState = VkPipelineDynamicStateCreateInfo.calloc(stack).sType$Default().pDynamicStates(stack.ints(1, 0));
      VkPipelineRenderingCreateInfoKHR renderingInfo = VkPipelineRenderingCreateInfoKHR.calloc(stack)
         .sType$Default()
         .colorAttachmentCount(1)
         .pColorAttachmentFormats(stack.ints(vkColorFormat))
         .depthAttachmentFormat(vkDepthFormat);
      org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo.Buffer stages = VkPipelineShaderStageCreateInfo.calloc(2, stack);
      ((VkPipelineShaderStageCreateInfo)stages.get(0)).sType$Default().stage(128).module(meshModule).pName(stack.UTF8("main"));
      ((VkPipelineShaderStageCreateInfo)stages.get(1)).sType$Default().stage(16).module(fragModule).pName(stack.UTF8("main"));
      org.lwjgl.vulkan.VkGraphicsPipelineCreateInfo.Buffer createInfo = VkGraphicsPipelineCreateInfo.calloc(1, stack);
      ((VkGraphicsPipelineCreateInfo)createInfo.get(0))
         .sType$Default()
         .pNext(renderingInfo.address())
         .pStages(stages)
         .stageCount(2)
         .pViewportState(viewportState)
         .pRasterizationState(rasterState)
         .pMultisampleState(multisampleState)
         .pDepthStencilState(depthState)
         .pColorBlendState(blendState)
         .pDynamicState(dynamicState)
         .layout(pipelineLayout)
         .renderPass(0L);
      LongBuffer pipelines = stack.mallocLong(1);
      checkVk(VK10.vkCreateGraphicsPipelines(vk, 0L, createInfo, null, pipelines), "vkCreateGraphicsPipelines(NvidiumPlus occlusion depth downsample)");
      return pipelines.get(0);
   }

   private static void pushStamp(VkCommandBuffer cb, MemoryStack stack, long layout, int stages, int frameStamp, float inflateK, float nearR, int diagBase) {
      ByteBuffer push = stack.calloc(16);
      push.putInt(0, frameStamp);
      push.putFloat(4, inflateK);
      push.putFloat(8, nearR);
      push.putInt(12, diagBase);
      VK10.vkCmdPushConstants(cb, layout, stages, 0, push);
   }

   private static org.lwjgl.vulkan.VkDescriptorBufferInfo.Buffer sliceInfo(MemoryStack stack, GpuBufferSlice slice) {
      return bufferInfo(stack, ((VulkanGpuBuffer)slice.buffer()).vkBuffer(), slice.offset(), slice.length());
   }

   private static org.lwjgl.vulkan.VkDescriptorBufferInfo.Buffer bufferInfo(MemoryStack stack, long vkBuffer, long offset, long range) {
      org.lwjgl.vulkan.VkDescriptorBufferInfo.Buffer info = VkDescriptorBufferInfo.calloc(1, stack);
      ((VkDescriptorBufferInfo)info.get(0)).buffer(vkBuffer).offset(offset).range(range);
      return info;
   }

   private static void bufferWrite(VkWriteDescriptorSet write, int binding, int type, org.lwjgl.vulkan.VkDescriptorBufferInfo.Buffer info) {
      write.sType$Default().dstBinding(binding).descriptorCount(1).descriptorType(type).pBufferInfo(info);
   }

   private static void binding(VkDescriptorSetLayoutBinding b, int index, int type, int stages) {
      b.binding(index).descriptorType(type).descriptorCount(1).stageFlags(stages);
   }

   private static void checkVk(int result, String what) {
      if (result != 0) {
         throw new IllegalStateException(what + " failed: VkResult " + result);
      }
   }

   record ListSlice(long vkBuffer, long offset, long range, boolean ssbo) {
      static TerrainOcclusion.ListSlice ofUniformSlice(GpuBufferSlice slice) {
         return new TerrainOcclusion.ListSlice(((VulkanGpuBuffer)slice.buffer()).vkBuffer(), slice.offset(), slice.length(), false);
      }
   }
}
