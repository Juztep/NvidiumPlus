package nvidiumplus.engine.vk;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.renderpearl.api.commands.CommandEncoder;
import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.vulkan.VulkanConst;
import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuBuffer;
import com.mojang.renderpearl.backend.vulkan.VulkanRenderPass;
import java.nio.ByteBuffer;
import java.util.Optional;
import java.util.OptionalDouble;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.mixin.RenderPassAccessor;
import nvidiumplus.engine.mixin.VulkanRenderPassAccessor;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.EXTMeshShader;
import org.lwjgl.vulkan.KHRPushDescriptor;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkDescriptorBufferInfo;
import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkWriteDescriptorSet;
import org.lwjgl.vulkan.VkDescriptorBufferInfo.Buffer;

public final class HelloMeshletRenderer {
   private static final boolean ENABLED = Boolean.getBoolean("nvidiumplus.helloMeshlet");
   private static final int MVP_BYTES = 64;
   private static final long UBO_ALIGNMENT = 256L;
   private static volatile String lastError;
   private static volatile int framesDrawn;
   private static boolean broken;
   private static HelloMeshletPipeline pipeline;
   private static boolean anchorLatched;
   private static double anchorX;
   private static double anchorY;
   private static double anchorZ;

   private HelloMeshletRenderer() {
   }

   public static String lastError() {
      return lastError;
   }

   public static int frameCount() {
      return framesDrawn;
   }

   public static void destroyDeviceObjects(VkDevice device) {
      HelloMeshletPipeline p = pipeline;
      if (p != null) {
         pipeline = null;
         p.destroy(device);
      }
   }

   public static void afterOpaqueTerrain(LevelRenderState levelRenderState) {
      if (ENABLED && !broken) {
         if (NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
            try {
               draw(levelRenderState);
               framesDrawn++;
            } catch (Throwable t) {
               broken = true;
               lastError = t.toString();
               NvidiumPlusLog.LOGGER.error("Hello-meshlet draw failed; disabled for this session (first and only report)", t);
            }
         }
      }
   }

   private static void draw(LevelRenderState levelRenderState) {
      RenderTarget mainTarget = Minecraft.getInstance().gameRenderer.mainRenderTarget();
      GpuTextureView colorView = mainTarget.getColorTextureView();
      GpuTextureView depthView = mainTarget.getDepthTextureView();
      if (colorView != null && depthView != null) {
         CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
         GpuBufferSlice mvpSlice = levelRenderState != null ? uploadMvp(encoder, levelRenderState.cameraRenderState) : null;
         RenderPass pass = encoder.createRenderPass(() -> "NvidiumPlus hello meshlet", colorView, Optional.empty(), depthView, OptionalDouble.empty());

         try {
            VulkanRenderPass backendPass = (VulkanRenderPass)((RenderPassAccessor)pass).nvidiumplus$backend();
            VulkanRenderPassAccessor vkPass = (VulkanRenderPassAccessor)backendPass;
            VkCommandBuffer commandBuffer = vkPass.nvidiumplus$commandBuffer();
            HelloMeshletPipeline p = pipelineFor(vkPass.nvidiumplus$device(), colorView, depthView);
            VK10.vkCmdBindPipeline(commandBuffer, 0, p.ndcPipeline());
            EXTMeshShader.vkCmdDrawMeshTasksEXT(commandBuffer, 1, 1, 1);
            if (mvpSlice != null) {
               VK10.vkCmdBindPipeline(commandBuffer, 0, p.worldPipeline());
               pushMvpDescriptor(commandBuffer, p.worldPipelineLayout(), mvpSlice);
               EXTMeshShader.vkCmdDrawMeshTasksEXT(commandBuffer, 1, 1, 1);
            }
         } catch (Throwable var12) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var11) {
                  var12.addSuppressed(var11);
               }
            }

            throw var12;
         }

         if (pass != null) {
            pass.close();
         }
      }
   }

   private static HelloMeshletPipeline pipelineFor(VulkanDevice device, GpuTextureView colorView, GpuTextureView depthView) {
      HelloMeshletPipeline p = pipeline;
      if (p == null) {
         int vkColorFormat = VulkanConst.toVk(colorView.texture().getFormat());
         int vkDepthFormat = VulkanConst.toVk(depthView.texture().getFormat());
         p = HelloMeshletPipeline.create(device.vkDevice(), vkColorFormat, vkDepthFormat);
         pipeline = p;
         NvidiumPlusLog.LOGGER
            .info(
               "Hello-meshlet pipelines created (color format {} [{}], depth format {} [{}])",
               new Object[]{colorView.texture().getFormat(), vkColorFormat, depthView.texture().getFormat(), vkDepthFormat}
            );
      }

      return p;
   }

   private static GpuBufferSlice uploadMvp(CommandEncoder encoder, CameraRenderState camera) {
      if (camera != null && camera.initialized) {
         if (!anchorLatched) {
            Matrix4f view = camera.viewRotationMatrix;
            double forwardX = -view.m02();
            double forwardY = -view.m12();
            double forwardZ = -view.m22();
            anchorX = camera.pos.x + forwardX * 4.0;
            anchorY = camera.pos.y + forwardY * 4.0 - 0.5;
            anchorZ = camera.pos.z + forwardZ * 4.0;
            anchorLatched = true;
            NvidiumPlusLog.LOGGER.info("Hello-meshlet world anchor latched at ({}, {}, {})", new Object[]{anchorX, anchorY, anchorZ});
         }

         Matrix4f mvp = new Matrix4f(camera.projectionMatrix)
            .mul(camera.viewRotationMatrix)
            .translate((float)(anchorX - camera.pos.x), (float)(anchorY - camera.pos.y), (float)(anchorZ - camera.pos.z));
         MemoryStack stack = MemoryStack.stackPush();

         GpuBufferSlice var13;
         try {
            ByteBuffer bytes = stack.malloc(64);
            mvp.get(bytes);
            var13 = encoder.transientMemory().uploadGpu(bytes, 256L, 128);
         } catch (Throwable var10) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var9) {
                  var10.addSuppressed(var9);
               }
            }

            throw var10;
         }

         if (stack != null) {
            stack.close();
         }

         return var13;
      } else {
         return null;
      }
   }

   private static void pushMvpDescriptor(VkCommandBuffer commandBuffer, long pipelineLayout, GpuBufferSlice slice) {
      MemoryStack stack = MemoryStack.stackPush();

      try {
         Buffer bufferInfo = VkDescriptorBufferInfo.calloc(1, stack);
         ((VkDescriptorBufferInfo)bufferInfo.get(0)).buffer(((VulkanGpuBuffer)slice.buffer()).vkBuffer()).offset(slice.offset()).range(64L);
         org.lwjgl.vulkan.VkWriteDescriptorSet.Buffer write = VkWriteDescriptorSet.calloc(1, stack);
         ((VkWriteDescriptorSet)write.get(0)).sType$Default().dstBinding(0).descriptorCount(1).descriptorType(6).pBufferInfo(bufferInfo);
         KHRPushDescriptor.vkCmdPushDescriptorSetKHR(commandBuffer, 0, pipelineLayout, 0, write);
      } catch (Throwable var8) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var7) {
               var8.addSuppressed(var7);
            }
         }

         throw var8;
      }

      if (stack != null) {
         stack.close();
      }
   }
}
