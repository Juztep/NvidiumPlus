package nvidiumplus.engine.vk;

import java.util.ArrayDeque;

final class VkStagingRing {
   private final long vma;
   private final long vkBuffer;
   private final long allocation;
   private final long mappedAddress;
   private final int capacity;
   private final int freeFrameLag;
   private int head;
   private long used;
   private long currentFrame = Long.MIN_VALUE;
   private long currentFrameBytes;
   private final ArrayDeque<long[]> spans = new ArrayDeque<>();

   private VkStagingRing(long vma, NvidiumPlusVkBuffers.MappedBuffer buffer, int capacity, int freeFrameLag) {
      this.vma = vma;
      this.vkBuffer = buffer.vkBuffer();
      this.allocation = buffer.allocation();
      this.mappedAddress = buffer.mappedAddress();
      this.capacity = capacity;
      this.freeFrameLag = freeFrameLag;
   }

   static VkStagingRing create(long vma, int capacity) {
      return create(vma, capacity, 3);
   }

   static VkStagingRing create(long vma, int capacity, int freeFrameLag) {
      NvidiumPlusVkBuffers.MappedBuffer buffer = NvidiumPlusVkBuffers.createHostMapped(vma, capacity, 1, "vmaCreateBuffer(NvidiumPlus staging ring)");
      return new VkStagingRing(vma, buffer, capacity, freeFrameLag);
   }

   int freeFrameLag() {
      return this.freeFrameLag;
   }

   long vkBuffer() {
      return this.vkBuffer;
   }

   long mappedAddress() {
      return this.mappedAddress;
   }

   int capacity() {
      return this.capacity;
   }

   long usedBytes() {
      return this.used;
   }

   void beginFrame(long frame) {
      if (this.currentFrameBytes > 0L) {
         this.spans.addLast(new long[]{this.currentFrame, this.currentFrameBytes});
         this.currentFrameBytes = 0L;
      }

      this.currentFrame = frame;

      while (!this.spans.isEmpty() && frame - ((long[])this.spans.peekFirst())[0] >= this.freeFrameLag) {
         this.used = this.used - this.spans.pollFirst()[1];
      }
   }

   long alloc(int size) {
      int aligned = size + 3 & -4;
      if (aligned > 0 && aligned <= this.capacity) {
         if (this.head + aligned > this.capacity) {
            long pad = this.capacity - this.head;
            if (this.used + pad + aligned > this.capacity) {
               return -1L;
            }

            this.used += pad;
            this.currentFrameBytes += pad;
            this.head = 0;
         } else if (this.used + aligned > this.capacity) {
            return -1L;
         }

         long offset = this.head;
         this.head += aligned;
         this.used += aligned;
         this.currentFrameBytes += aligned;
         return offset;
      } else {
         return -1L;
      }
   }

   void destroy() {
      NvidiumPlusVkBuffers.destroy(this.vma, this.vkBuffer, this.allocation);
   }
}
