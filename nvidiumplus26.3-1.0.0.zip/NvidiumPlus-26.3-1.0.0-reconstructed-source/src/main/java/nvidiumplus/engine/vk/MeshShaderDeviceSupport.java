package nvidiumplus.engine.vk;

import com.mojang.renderpearl.backend.vulkan.VulkanPhysicalDevice;
import com.mojang.renderpearl.backend.vulkan.init.VulkanFeature;
import com.mojang.renderpearl.backend.vulkan.init.VulkanPNextStruct;
import java.util.Collection;
import java.util.Set;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusScaling;
import nvidiumplus.engine.NvidiumPlusVramState;
import nvidiumplus.engine.NvidiumPlusVulkanState;
import nvidiumplus.engine.compat.McCompat;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VK11;
import org.lwjgl.vulkan.VK12;
import org.lwjgl.vulkan.VkMemoryHeap;
import org.lwjgl.vulkan.VkPhysicalDevice;
import org.lwjgl.vulkan.VkPhysicalDeviceConditionalRenderingFeaturesEXT;
import org.lwjgl.vulkan.VkPhysicalDeviceConservativeRasterizationPropertiesEXT;
import org.lwjgl.vulkan.VkPhysicalDeviceFeatures;
import org.lwjgl.vulkan.VkPhysicalDeviceFeatures2;
import org.lwjgl.vulkan.VkPhysicalDeviceMaintenance3Properties;
import org.lwjgl.vulkan.VkPhysicalDeviceMemoryBudgetPropertiesEXT;
import org.lwjgl.vulkan.VkPhysicalDeviceMemoryProperties;
import org.lwjgl.vulkan.VkPhysicalDeviceMemoryProperties2;
import org.lwjgl.vulkan.VkPhysicalDeviceMeshShaderFeaturesEXT;
import org.lwjgl.vulkan.VkPhysicalDeviceMeshShaderPropertiesEXT;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties2;
import org.lwjgl.vulkan.VkPhysicalDevicePushDescriptorPropertiesKHR;

public final class MeshShaderDeviceSupport {
   public static final String EXTENSION_NAME = "VK_EXT_mesh_shader";
   public static final VulkanPNextStruct MESH_SHADER_FEATURES_STRUCT = McCompat.pnextStruct(
      VkPhysicalDeviceMeshShaderFeaturesEXT.class, 1000328000, VkPhysicalDeviceMeshShaderFeaturesEXT.SIZEOF
   );
   public static final VulkanFeature MESH_SHADER_FEATURE = new VulkanFeature(
      MESH_SHADER_FEATURES_STRUCT, "meshShader", VkPhysicalDeviceMeshShaderFeaturesEXT.MESHSHADER
   );
   public static final VulkanFeature TASK_SHADER_FEATURE = new VulkanFeature(
      MESH_SHADER_FEATURES_STRUCT, "taskShader", VkPhysicalDeviceMeshShaderFeaturesEXT.TASKSHADER
   );
   private static final VulkanPNextStruct BASE_FEATURES_STRUCT = McCompat.pnextStruct(
      VkPhysicalDeviceFeatures2.class, 1000059000, VkPhysicalDeviceProperties2.SIZEOF
   );
   public static final VulkanFeature FRAGMENT_STORES_AND_ATOMICS = new VulkanFeature(
      BASE_FEATURES_STRUCT, "fragmentStoresAndAtomics", VkPhysicalDeviceFeatures.FRAGMENTSTORESANDATOMICS
   );
   private static final VulkanPNextStruct MESH_SHADER_PROPERTIES_STRUCT = McCompat.pnextStruct(
      VkPhysicalDeviceMeshShaderPropertiesEXT.class, 1000328001, VkPhysicalDeviceMeshShaderPropertiesEXT.SIZEOF
   );
   public static final String MEMORY_BUDGET_EXTENSION = "VK_EXT_memory_budget";
   public static final String CONDITIONAL_RENDERING_EXTENSION = "VK_EXT_conditional_rendering";
   public static final VulkanPNextStruct CONDITIONAL_RENDERING_FEATURES_STRUCT = McCompat.pnextStruct(
      VkPhysicalDeviceConditionalRenderingFeaturesEXT.class, 1000081001, VkPhysicalDeviceConditionalRenderingFeaturesEXT.SIZEOF
   );
   public static final VulkanFeature CONDITIONAL_RENDERING_FEATURE = new VulkanFeature(
      CONDITIONAL_RENDERING_FEATURES_STRUCT, "conditionalRendering", VkPhysicalDeviceConditionalRenderingFeaturesEXT.CONDITIONALRENDERING
   );
   public static final String CONSERVATIVE_RASTERIZATION_EXTENSION = "VK_EXT_conservative_rasterization";
   private static final VulkanPNextStruct CONSERVATIVE_RASTERIZATION_PROPERTIES_STRUCT = McCompat.pnextStruct(
      VkPhysicalDeviceConservativeRasterizationPropertiesEXT.class, 1000101000, VkPhysicalDeviceConservativeRasterizationPropertiesEXT.SIZEOF
   );
   private static final VulkanPNextStruct MAINTENANCE_3_PROPERTIES_STRUCT = McCompat.pnextStruct(
      VkPhysicalDeviceMaintenance3Properties.class, 1000168000, VkPhysicalDeviceMaintenance3Properties.SIZEOF
   );
   private static final VulkanPNextStruct PUSH_DESCRIPTOR_PROPERTIES_STRUCT = McCompat.pnextStruct(
      VkPhysicalDevicePushDescriptorPropertiesKHR.class, 1000080000, VkPhysicalDevicePushDescriptorPropertiesKHR.SIZEOF
   );
   private static volatile VkPhysicalDevice budgetProbeDevice;

   public static void refreshMemoryBudget(long nowNanos) {
      VkPhysicalDevice device = budgetProbeDevice;
      if (device != null && NvidiumPlusVulkanState.memoryBudgetSupported()) {
         long[] sample = queryMemoryBudget(device);
         if (sample != null) {
            NvidiumPlusVramState.sample(sample[0], sample[1], nowNanos);
         }
      }
   }

   private MeshShaderDeviceSupport() {
   }

   public static void onCreateDevice(Collection<String> extensions, VulkanPhysicalDevice physicalDevice, Set<VulkanFeature> features) {
      VkPhysicalDevice vk = physicalDevice.vkPhysicalDevice();
      boolean hasExtension = physicalDevice.hasDeviceExtension("VK_EXT_mesh_shader");
      boolean meshShader = hasExtension && isFeatureSupported(vk, MESH_SHADER_FEATURE);
      boolean taskShader = hasExtension && isFeatureSupported(vk, TASK_SHADER_FEATURE);
      boolean hasMemoryBudget = physicalDevice.hasDeviceExtension("VK_EXT_memory_budget");
      if (hasMemoryBudget) {
         extensions.add("VK_EXT_memory_budget");
      }

      boolean fragmentStoresAndAtomics = false;
      boolean conditionalRendering = false;
      boolean consRasterPresent = physicalDevice.hasDeviceExtension("VK_EXT_conservative_rasterization");
      boolean consRasterEnabled = false;
      if (meshShader && taskShader) {
         extensions.add("VK_EXT_mesh_shader");
         features.add(MESH_SHADER_FEATURE);
         features.add(TASK_SHADER_FEATURE);
         fragmentStoresAndAtomics = isFeatureSupported(vk, FRAGMENT_STORES_AND_ATOMICS);
         if (fragmentStoresAndAtomics) {
            features.add(FRAGMENT_STORES_AND_ATOMICS);
         }

         conditionalRendering = physicalDevice.hasDeviceExtension("VK_EXT_conditional_rendering") && isFeatureSupported(vk, CONDITIONAL_RENDERING_FEATURE);
         if (conditionalRendering) {
            extensions.add("VK_EXT_conditional_rendering");
            features.add(CONDITIONAL_RENDERING_FEATURE);
         }

         consRasterEnabled = consRasterPresent && Boolean.getBoolean("nvidiumplus.occlusion.conservativeRaster");
         if (consRasterEnabled) {
            extensions.add("VK_EXT_conservative_rasterization");
         }
      }

      onDeviceFeaturesDecided(
         physicalDevice,
         hasExtension,
         meshShader,
         taskShader,
         fragmentStoresAndAtomics,
         conditionalRendering,
         consRasterPresent,
         consRasterEnabled,
         hasMemoryBudget
      );
   }

   public static void onDeviceFeaturesDecided(
      VulkanPhysicalDevice physicalDevice,
      boolean hasExtension,
      boolean meshShader,
      boolean taskShader,
      boolean fragmentStoresAndAtomics,
      boolean conditionalRendering,
      boolean conservativeRasterPresent,
      boolean conservativeRasterEnabled,
      boolean memoryBudget
   ) {
      String name = physicalDevice.deviceName();
      String driver = physicalDevice.driverInfo();
      VkPhysicalDevice vk = physicalDevice.vkPhysicalDevice();
      long localHeapBytes = queryDeviceLocalHeapBytes(vk);
      long storageRange = queryMaxStorageBufferRange(vk);
      boolean hasMemoryBudget = memoryBudget;
      NvidiumPlusVulkanState.setMemoryBudgetSupported(hasMemoryBudget);
      NvidiumPlusVulkanState.setIntegratedGpu(isIntegrated(vk));
      budgetProbeDevice = vk;
      NvidiumPlusVramState.reset();
      if (meshShader && taskShader) {
         NvidiumPlusVulkanState.setDrawIndirectSupported(true);
         if (!fragmentStoresAndAtomics) {
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus: this device reports no fragmentStoresAndAtomics, so occlusion culling cannot run (mesh-shader terrain is unaffected). Device '{}', driver '{}'",
                  name,
                  driver
               );
         }

         boolean condRender = conditionalRendering;
         NvidiumPlusVulkanState.setConditionalRenderingSupported(condRender);
         boolean consRasterWanted = Boolean.getBoolean("nvidiumplus.occlusion.conservativeRaster");
         boolean consRasterPresent = conservativeRasterPresent;
         boolean consRaster = conservativeRasterEnabled;
         NvidiumPlusVulkanState.setConservativeRasterizationSupported(consRasterPresent);
         NvidiumPlusVulkanState.setConservativeRasterizationEnabled(consRaster);
         NvidiumPlusVulkanState.ConservativeRasterCaps consCaps = consRasterPresent ? queryConservativeRasterCaps(vk) : null;
         NvidiumPlusVulkanState.setConservativeRasterCaps(consCaps);
         if (consRasterWanted && !consRasterPresent) {
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus: -D{}=true but this device did not offer {}; the box rasters keep the mesh-stage coverage inflation alone (which is the load-bearing ingredient - part B was always additive)",
                  "nvidiumplus.occlusion.conservativeRaster",
                  "VK_EXT_conservative_rasterization"
               );
         }

         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus conservative rasterization: {} {}, {}; overestimation size {} (max extra {}, granularity {}), degenerate triangles rasterized {}, post-depth coverage {}",
               new Object[]{
                  "VK_EXT_conservative_rasterization",
                  consRasterPresent ? "present" : "ABSENT",
                  consRaster ? "enabled by property" : "not requested",
                  consCaps == null ? "n/a" : consCaps.primitiveOverestimationSize(),
                  consCaps == null ? "n/a" : consCaps.maxExtraPrimitiveOverestimationSize(),
                  consCaps == null ? "n/a" : consCaps.extraPrimitiveOverestimationSizeGranularity(),
                  consCaps == null ? "n/a" : consCaps.degenerateTrianglesRasterized(),
                  consCaps == null ? "n/a" : consCaps.conservativeRasterizationPostDepthCoverage()
               }
            );
         NvidiumPlusVulkanState.MeshShaderCaps caps = queryCaps(vk);
         NvidiumPlusVulkanState.recordDeviceCreation(name, driver, true, caps, localHeapBytes, storageRange, queryArenaLimits(vk));
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus java heap: max {} MiB (the launcher's default is 2048; a raw JVM takes a quarter of system RAM, so benchmark runs and real sessions can differ here)",
               Runtime.getRuntime().maxMemory() >> 20
            );
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus memory probe on '{}': device-local heap {} MiB, maxStorageBufferRange {} MiB -> terrain arena ceiling {} MiB ({}% of the largest DEVICE_LOCAL heap, floor {} MiB, CLAMPED to what a shader can address; -Dnvidiumplus.tune.arenaCeilingMiB overrides; integrated GPUs report their shared heap here — the fraction then bounds NvidiumPlus's share of SYSTEM memory)",
               new Object[]{name, localHeapBytes >> 20, storageRange >> 20, NvidiumPlusScaling.arenaCeilingBytes() >> 20, 50, 256L}
            );
         NvidiumPlusVulkanState.ArenaLimits limits = NvidiumPlusVulkanState.arenaLimits();
         long blockBytes = NvidiumPlusScaling.arenaBlockBytes();
         int blocks = NvidiumPlusScaling.arenaBlockCount();
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus arena geometry: block {} MiB x {} = {} MiB addressable (limits: maxStorageBufferRange {} MiB, maxMemoryAllocationSize {} MiB, maxPushDescriptors {}, maxPerStageDescriptorStorageBuffers {}, maxDescriptorSetStorageBuffers {} — a 0 means the driver did not report it and it was treated as no-information, never as no-capacity)",
               new Object[]{
                  blockBytes >> 20,
                  blocks,
                  blockBytes * blocks >> 20,
                  limits.maxStorageBufferRange() >> 20,
                  limits.maxMemoryAllocationSize() >> 20,
                  limits.maxPushDescriptors(),
                  limits.maxPerStageDescriptorStorageBuffers(),
                  limits.maxDescriptorSetStorageBuffers()
               }
            );
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus memory budget: VK_EXT_memory_budget {}, device type {} (reserve kept clear for vanilla and everything else: {} MiB). A heap SIZE is a hardware fact; a heap BUDGET is what is free after vanilla's textures and every other process, and only the budget can stop NvidiumPlus taking the last of the card and crashing something else",
               new Object[]{
                  NvidiumPlusVulkanState.memoryBudgetSupported() ? "supported" : "ABSENT",
                  NvidiumPlusVulkanState.integratedGpu() ? "INTEGRATED (heap is shared system memory)" : "discrete",
                  (NvidiumPlusVulkanState.integratedGpu() ? 1073741824L : 536870912L) >> 20
               }
            );
         if (blockBytes < 536870912L) {
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus: arena blocks clamped to {} MiB, below the preferred {} MiB, because this device's limits round down to a power of two. More blocks are used to compensate",
                  blockBytes >> 20,
                  512L
               );
         }

         long ceilingNow = NvidiumPlusScaling.arenaCeilingBytes();
         long blockTotal = blockBytes * blocks;
         if (storageRange > 0L && blockTotal > storageRange) {
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus: terrain memory can now exceed maxStorageBufferRange ({} MiB). That limit bounds ONE binding, and the arena is {} separately bound blocks of {} MiB, so {} MiB is reachable and the ceiling is {} MiB. Before the split this card stopped at {} MiB",
                  new Object[]{storageRange >> 20, blocks, blockBytes >> 20, blockTotal >> 20, ceilingNow >> 20, storageRange >> 20}
               );
         }

         NvidiumPlusLog.LOGGER
            .info(
               "Requesting {} on '{}' (driver {}, vendor {}): meshShader+taskShader supported. Caps: maxTaskWorkGroupInvocations={}, maxTaskPayloadSize={}, maxMeshWorkGroupInvocations={}, maxMeshOutputVertices={}, maxMeshOutputPrimitives={}, maxPreferredTaskWorkGroupInvocations={}, maxPreferredMeshWorkGroupInvocations={}, prefersLocalInvocationVertexOutput={}, prefersLocalInvocationPrimitiveOutput={}, prefersCompactVertexOutput={}, prefersCompactPrimitiveOutput={}",
               new Object[]{
                  "VK_EXT_mesh_shader",
                  name,
                  driver,
                  physicalDevice.vendorName(),
                  caps.maxTaskWorkGroupInvocations(),
                  caps.maxTaskPayloadSize(),
                  caps.maxMeshWorkGroupInvocations(),
                  caps.maxMeshOutputVertices(),
                  caps.maxMeshOutputPrimitives(),
                  caps.maxPreferredTaskWorkGroupInvocations(),
                  caps.maxPreferredMeshWorkGroupInvocations(),
                  caps.prefersLocalInvocationVertexOutput(),
                  caps.prefersLocalInvocationPrimitiveOutput(),
                  caps.prefersCompactVertexOutput(),
                  caps.prefersCompactPrimitiveOutput()
               }
            );
      } else {
         NvidiumPlusVulkanState.recordDeviceCreation(name, driver, false, null, localHeapBytes, storageRange, queryArenaLimits(vk));
         NvidiumPlusLog.LOGGER
            .info(
               "'{}' (driver {}) has no usable {} (extension present: {}, meshShader: {}, taskShader: {}); NvidiumPlus will stay off on this device",
               new Object[]{name, driver, "VK_EXT_mesh_shader", hasExtension, meshShader, taskShader}
            );
      }

      NvidiumPlusLog.LOGGER.debug("Vulkan validation layers can be enabled for debugging with the --vulkanValidation launch argument (vanilla 26.2 flag)");
   }

   private static boolean isFeatureSupported(VkPhysicalDevice device, VulkanFeature feature) {
      MemoryStack stack = MemoryStack.stackPush();

      boolean var4;
      try {
         VkPhysicalDeviceFeatures2 features2 = VkPhysicalDeviceFeatures2.calloc(stack).sType$Default();
         feature.struct().findOrCreateStructInPNextChain(features2, stack);
         VK12.vkGetPhysicalDeviceFeatures2(device, features2);
         var4 = feature.get(features2);
      } catch (Throwable var6) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }
         }

         throw var6;
      }

      if (stack != null) {
         stack.close();
      }

      return var4;
   }

   private static long queryDeviceLocalHeapBytes(VkPhysicalDevice device) {
      MemoryStack stack = MemoryStack.stackPush();

      long var9;
      try {
         VkPhysicalDeviceMemoryProperties memory = VkPhysicalDeviceMemoryProperties.calloc(stack);
         VK10.vkGetPhysicalDeviceMemoryProperties(device, memory);
         long largest = 0L;

         for (int i = 0; i < memory.memoryHeapCount(); i++) {
            VkMemoryHeap heap = memory.memoryHeaps(i);
            if ((heap.flags() & 1) != 0) {
               largest = Math.max(largest, heap.size());
            }
         }

         var9 = largest;
      } catch (Throwable var8) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var7) {
               var8.addSuppressed(var7);
            }
         }

         throw var8;
      }

      if (stack != null) {
         stack.close();
      }

      return var9;
   }

   private static long queryMaxStorageBufferRange(VkPhysicalDevice device) {
      MemoryStack stack = MemoryStack.stackPush();

      long var3;
      try {
         VkPhysicalDeviceProperties properties = VkPhysicalDeviceProperties.calloc(stack);
         VK10.vkGetPhysicalDeviceProperties(device, properties);
         var3 = Integer.toUnsignedLong(properties.limits().maxStorageBufferRange());
      } catch (Throwable var6) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }
         }

         throw var6;
      }

      if (stack != null) {
         stack.close();
      }

      return var3;
   }

   private static boolean isIntegrated(VkPhysicalDevice device) {
      MemoryStack stack = MemoryStack.stackPush();

      boolean var3;
      try {
         VkPhysicalDeviceProperties properties = VkPhysicalDeviceProperties.calloc(stack);
         VK10.vkGetPhysicalDeviceProperties(device, properties);
         var3 = properties.deviceType() == 1;
      } catch (Throwable var5) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var4) {
               var5.addSuppressed(var4);
            }
         }

         throw var5;
      }

      if (stack != null) {
         stack.close();
      }

      return var3;
   }

   public static long[] queryMemoryBudget(VkPhysicalDevice device) {
      MemoryStack stack = MemoryStack.stackPush();

      J var13;
      label58: {
         try {
            VkPhysicalDeviceMemoryBudgetPropertiesEXT budget = VkPhysicalDeviceMemoryBudgetPropertiesEXT.calloc(stack).sType$Default();
            VkPhysicalDeviceMemoryProperties2 props2 = VkPhysicalDeviceMemoryProperties2.calloc(stack).sType$Default().pNext(budget.address());
            VK11.vkGetPhysicalDeviceMemoryProperties2(device, props2);
            VkPhysicalDeviceMemoryProperties memory = props2.memoryProperties();
            long best = 0L;
            int bestHeap = -1;

            for (int i = 0; i < memory.memoryHeapCount(); i++) {
               VkMemoryHeap heap = memory.memoryHeaps(i);
               if ((heap.flags() & 1) != 0 && heap.size() > best) {
                  best = heap.size();
                  bestHeap = i;
               }
            }

            if (bestHeap < 0) {
               var13 = null;
               break label58;
            }

            var13 = new long[]{budget.heapBudget(bestHeap), budget.heapUsage(bestHeap)};
         } catch (Throwable var11) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var10) {
                  var11.addSuppressed(var10);
               }
            }

            throw var11;
         }

         if (stack != null) {
            stack.close();
         }

         return (long[])var13;
      }

      if (stack != null) {
         stack.close();
      }

      return (long[])var13;
   }

   private static NvidiumPlusVulkanState.ArenaLimits queryArenaLimits(VkPhysicalDevice device) {
      MemoryStack stack = MemoryStack.stackPush();

      NvidiumPlusVulkanState.ArenaLimits var18;
      try {
         VkPhysicalDeviceProperties properties = VkPhysicalDeviceProperties.calloc(stack);
         VK10.vkGetPhysicalDeviceProperties(device, properties);
         long range = Integer.toUnsignedLong(properties.limits().maxStorageBufferRange());
         long perStage = Integer.toUnsignedLong(properties.limits().maxPerStageDescriptorStorageBuffers());
         long perSet = Integer.toUnsignedLong(properties.limits().maxDescriptorSetStorageBuffers());
         VkPhysicalDeviceProperties2 properties2 = VkPhysicalDeviceProperties2.calloc(stack).sType$Default();
         long maintenance3 = MAINTENANCE_3_PROPERTIES_STRUCT.findOrCreateStructInPNextChain(properties2, stack);
         long pushDescriptor = PUSH_DESCRIPTOR_PROPERTIES_STRUCT.findOrCreateStructInPNextChain(properties2, stack);
         VK11.vkGetPhysicalDeviceProperties2(device, properties2);
         long maxAllocation = VkPhysicalDeviceMaintenance3Properties.create(maintenance3).maxMemoryAllocationSize();
         long maxPush = Integer.toUnsignedLong(VkPhysicalDevicePushDescriptorPropertiesKHR.create(pushDescriptor).maxPushDescriptors());
         var18 = new NvidiumPlusVulkanState.ArenaLimits(range, perStage, perSet, maxAllocation, maxPush);
      } catch (Throwable var20) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var19) {
               var20.addSuppressed(var19);
            }
         }

         throw var20;
      }

      if (stack != null) {
         stack.close();
      }

      return var18;
   }

   private static NvidiumPlusVulkanState.ConservativeRasterCaps queryConservativeRasterCaps(VkPhysicalDevice device) {
      MemoryStack stack = MemoryStack.stackPush();

      NvidiumPlusVulkanState.ConservativeRasterCaps var6;
      try {
         VkPhysicalDeviceProperties2 properties2 = VkPhysicalDeviceProperties2.calloc(stack).sType$Default();
         long address = CONSERVATIVE_RASTERIZATION_PROPERTIES_STRUCT.findOrCreateStructInPNextChain(properties2, stack);
         VK11.vkGetPhysicalDeviceProperties2(device, properties2);
         VkPhysicalDeviceConservativeRasterizationPropertiesEXT props = VkPhysicalDeviceConservativeRasterizationPropertiesEXT.create(address);
         var6 = new NvidiumPlusVulkanState.ConservativeRasterCaps(
            props.primitiveOverestimationSize(),
            props.maxExtraPrimitiveOverestimationSize(),
            props.extraPrimitiveOverestimationSizeGranularity(),
            props.degenerateTrianglesRasterized(),
            props.fullyCoveredFragmentShaderInputVariable(),
            props.conservativeRasterizationPostDepthCoverage()
         );
      } catch (Throwable var8) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var7) {
               var8.addSuppressed(var7);
            }
         }

         throw var8;
      }

      if (stack != null) {
         stack.close();
      }

      return var6;
   }

   private static NvidiumPlusVulkanState.MeshShaderCaps queryCaps(VkPhysicalDevice device) {
      MemoryStack stack = MemoryStack.stackPush();

      NvidiumPlusVulkanState.MeshShaderCaps var6;
      try {
         VkPhysicalDeviceProperties2 properties2 = VkPhysicalDeviceProperties2.calloc(stack).sType$Default();
         long address = MESH_SHADER_PROPERTIES_STRUCT.findOrCreateStructInPNextChain(properties2, stack);
         VK11.vkGetPhysicalDeviceProperties2(device, properties2);
         VkPhysicalDeviceMeshShaderPropertiesEXT props = VkPhysicalDeviceMeshShaderPropertiesEXT.create(address);
         var6 = new NvidiumPlusVulkanState.MeshShaderCaps(
            props.maxTaskWorkGroupInvocations(),
            props.maxTaskPayloadSize(),
            props.maxMeshWorkGroupInvocations(),
            props.maxMeshOutputVertices(),
            props.maxMeshOutputPrimitives(),
            props.maxMeshOutputComponents(),
            props.maxMeshOutputMemorySize(),
            props.maxPreferredTaskWorkGroupInvocations(),
            props.maxPreferredMeshWorkGroupInvocations(),
            props.prefersLocalInvocationVertexOutput(),
            props.prefersLocalInvocationPrimitiveOutput(),
            props.prefersCompactVertexOutput(),
            props.prefersCompactPrimitiveOutput()
         );
      } catch (Throwable var8) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var7) {
               var8.addSuppressed(var7);
            }
         }

         throw var8;
      }

      if (stack != null) {
         stack.close();
      }

      return var6;
   }
}
