package nvidiumplus.engine.vk;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Map.Entry;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.shaderc.Shaderc;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkShaderModuleCreateInfo;

public final class NvidiumPlusShaderCompiler {
   public static final int KIND_MESH = 27;
   public static final int KIND_TASK = 26;
   public static final int KIND_FRAGMENT = 1;

   private NvidiumPlusShaderCompiler() {
   }

   public static long compileResourceToModule(VkDevice device, String resourcePath, int shadercKind) {
      return compileResourceToModule(device, resourcePath, shadercKind, Map.of());
   }

   public static long compileResourceToModule(VkDevice device, String resourcePath, int shadercKind, Map<String, String> macros) {
      String source = loadResource(resourcePath);
      long compiler = Shaderc.shaderc_compiler_initialize();
      if (compiler == 0L) {
         throw new NvidiumPlusShaderCompiler.ShaderCompileException(resourcePath, "shaderc_compiler_initialize returned NULL");
      }

      long options = 0L;
      long result = 0L;

      try {
         options = Shaderc.shaderc_compile_options_initialize();
         if (options == 0L) {
            throw new NvidiumPlusShaderCompiler.ShaderCompileException(resourcePath, "shaderc_compile_options_initialize returned NULL");
         }

         Shaderc.shaderc_compile_options_set_target_env(options, 0, 4202496);

         for (Entry<String, String> macro : macros.entrySet()) {
            Shaderc.shaderc_compile_options_add_macro_definition(options, macro.getKey(), macro.getValue());
         }

         result = Shaderc.shaderc_compile_into_spv(compiler, source, shadercKind, resourcePath, "main", options);
         if (result == 0L) {
            throw new NvidiumPlusShaderCompiler.ShaderCompileException(resourcePath, "shaderc_compile_into_spv returned NULL");
         } else {
            int status = Shaderc.shaderc_result_get_compilation_status(result);
            if (status != 0) {
               throw new NvidiumPlusShaderCompiler.ShaderCompileException(
                  resourcePath, "shaderc status " + status + ":\n" + Shaderc.shaderc_result_get_error_message(result)
               );
            } else {
               ByteBuffer spirv = Shaderc.shaderc_result_get_bytes(result);
               if (spirv == null) {
                  throw new NvidiumPlusShaderCompiler.ShaderCompileException(resourcePath, "successful result carried no SPIR-V bytes");
               } else {
                  return createModule(device, resourcePath, spirv);
               }
            }
         }
      } finally {
         if (result != 0L) {
            Shaderc.shaderc_result_release(result);
         }

         if (options != 0L) {
            Shaderc.shaderc_compile_options_release(options);
         }

         Shaderc.shaderc_compiler_release(compiler);
      }
   }

   private static long createModule(VkDevice device, String resourcePath, ByteBuffer spirv) {
      MemoryStack stack = MemoryStack.stackPush();

      long var7;
      try {
         VkShaderModuleCreateInfo createInfo = VkShaderModuleCreateInfo.calloc(stack).sType$Default().pCode(spirv);
         LongBuffer module = stack.mallocLong(1);
         int vkResult = VK10.vkCreateShaderModule(device, createInfo, null, module);
         if (vkResult != 0) {
            throw new NvidiumPlusShaderCompiler.ShaderCompileException(resourcePath, "vkCreateShaderModule failed: " + vkResult);
         }

         var7 = module.get(0);
      } catch (Throwable var10) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var9) {
               var10.addSuppressed(var9);
            }
         }

         throw var10;
      }

      if (stack != null) {
         stack.close();
      }

      return var7;
   }

   private static String loadResource(String resourcePath) {
      try (InputStream in = NvidiumPlusShaderCompiler.class.getResourceAsStream(resourcePath)) {
         if (in == null) {
            throw new NvidiumPlusShaderCompiler.ShaderCompileException(resourcePath, "resource not found on the classpath");
         } else {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
         }
      } catch (IOException e) {
         throw new NvidiumPlusShaderCompiler.ShaderCompileException(resourcePath, "I/O error reading resource", e);
      }
   }

   public static final class ShaderCompileException extends RuntimeException {
      public ShaderCompileException(String resourcePath, String detail) {
         super("Failed to compile '" + resourcePath + "': " + detail);
      }

      public ShaderCompileException(String resourcePath, String detail, Throwable cause) {
         super("Failed to compile '" + resourcePath + "': " + detail, cause);
      }
   }
}
