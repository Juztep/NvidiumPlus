package nvidiumplus.engine.vk;

import java.util.ArrayList;
import java.util.List;
import nvidiumplus.engine.terrain.ArenaBacking;

public final class VkArenaBacking implements ArenaBacking {
   private static final int USAGE = 35;
   private final long vma;
   private final List<long[]> blocks = new ArrayList<>();

   public VkArenaBacking(long vma) {
      this.vma = vma;
   }

   @Override
   public long allocate(long sizeBytes) {
      if (!this.blocks.isEmpty()) {
         throw new IllegalStateException("arena backing allocated twice");
      }

      NvidiumPlusVkBuffers.DeviceBuffer buffer = NvidiumPlusVkBuffers.createDeviceLocal(this.vma, sizeBytes, 35, "vmaCreateBuffer(NvidiumPlus terrain arena)");
      this.blocks.add(new long[]{buffer.vkBuffer(), buffer.allocation(), sizeBytes});
      return buffer.vkBuffer();
   }

   @Override
   public long appendBlock(long sizeBytes) {
      try {
         NvidiumPlusVkBuffers.DeviceBuffer buffer = NvidiumPlusVkBuffers.createDeviceLocal(
            this.vma, sizeBytes, 35, "vmaCreateBuffer(NvidiumPlus terrain arena block " + this.blocks.size() + ")"
         );
         this.blocks.add(new long[]{buffer.vkBuffer(), buffer.allocation(), sizeBytes});
         return buffer.vkBuffer();
      } catch (NvidiumPlusVkBuffers.OutOfDeviceMemoryException e) {
         return 0L;
      }
   }

   long vkBuffer() {
      return this.blocks.isEmpty() ? 0L : this.blocks.get(0)[0];
   }

   long[] blockHandles() {
      long[] out = new long[this.blocks.size()];

      for (int i = 0; i < out.length; i++) {
         out[i] = this.blocks.get(i)[0];
      }

      return out;
   }

   int blockCount() {
      return this.blocks.size();
   }

   long sizeBytes() {
      long total = 0L;

      for (long[] b : this.blocks) {
         total += b[2];
      }

      return total;
   }

   long lastBlockBytes() {
      return this.blocks.isEmpty() ? 0L : this.blocks.get(this.blocks.size() - 1)[2];
   }

   long lastBlockBuffer() {
      return this.blocks.isEmpty() ? 0L : this.blocks.get(this.blocks.size() - 1)[0];
   }

   long[] swapForGrowth(NvidiumPlusVkBuffers.DeviceBuffer grown, long grownSizeBytes) {
      int last = this.blocks.size() - 1;
      long[] old = (long[])this.blocks.get(last).clone();
      this.blocks.set(last, new long[]{grown.vkBuffer(), grown.allocation(), grownSizeBytes});
      return old;
   }

   long[][] takeAllForDestroy() {
      long[][] out = new long[this.blocks.size()][];

      for (int i = 0; i < out.length; i++) {
         out[i] = new long[]{this.blocks.get(i)[0], this.blocks.get(i)[1]};
      }

      this.blocks.clear();
      return out;
   }
}
