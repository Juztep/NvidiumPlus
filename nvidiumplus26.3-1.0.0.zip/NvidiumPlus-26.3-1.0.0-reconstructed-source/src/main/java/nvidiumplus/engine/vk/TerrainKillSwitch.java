package nvidiumplus.engine.vk;

import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import net.minecraft.client.renderer.chunk.ChunkSectionLayerGroup;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusLog;

public final class TerrainKillSwitch {
   private static boolean drawHookBroken;
   private static boolean helloHookBroken;

   private TerrainKillSwitch() {
   }

   public static boolean beforeRenderGroup(ChunkSectionsToRender sections, ChunkSectionLayerGroup group, GpuSampler sampler, GpuTextureView atlasView) {
      if (!drawHookBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS && NvidiumPlusConfig.terrainRenderingEnabled()) {
         try {
            if (group == ChunkSectionLayerGroup.OPAQUE) {
               if (TerrainDrawer.drawOpaque(sections, sampler, atlasView)) {
                  helloProbe();
                  return true;
               }
            } else if (group == ChunkSectionLayerGroup.TRANSLUCENT) {
               return TerrainDrawer.drawTranslucent(sections, sampler, atlasView);
            }
         } catch (Throwable t) {
            drawHookBroken = true;
            NvidiumPlusLog.LOGGER
               .error("NvidiumPlus terrain kill switch failed outside the drawer's own guard; disabling for this session (vanilla terrain resumes)", t);
         }

         return false;
      } else {
         return false;
      }
   }

   public static void afterRenderGroup(ChunkSectionLayerGroup group) {
      if (group == ChunkSectionLayerGroup.OPAQUE) {
         helloProbe();
      }
   }

   public static boolean armed() {
      return !drawHookBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS && NvidiumPlusConfig.terrainRenderingEnabled();
   }

   public static boolean translucentWanted() {
      return armed() && TerrainDrawer.opaqueOwnedThisFrame();
   }

   public static void noteTranslucentUnderImprovedTransparency() {
      if (!drawHookBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         TerrainDrawer.noteTranslucentUnderImprovedTransparency();
      }
   }

   public static boolean translucentOwnedThisFrame() {
      return !drawHookBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS ? TerrainDrawer.translucentOwnedThisFrame() : false;
   }

   private static void helloProbe() {
      if (!helloHookBroken && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         try {
            HelloMeshletRenderer.afterOpaqueTerrain(null);
         } catch (Throwable t) {
            helloHookBroken = true;
            NvidiumPlusLog.LOGGER.error("NvidiumPlus hello-meshlet hook failed outside the renderer's own guard; disabling the hook for this session", t);
         }
      }
   }
}
