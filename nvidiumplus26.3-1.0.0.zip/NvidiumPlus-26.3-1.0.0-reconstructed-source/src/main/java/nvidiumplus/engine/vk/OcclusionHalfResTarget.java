package nvidiumplus.engine.vk;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.device.GpuDevice;
import com.mojang.renderpearl.api.device.GpuDeviceLossException;
import com.mojang.renderpearl.api.textures.GpuTexture;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.vulkan.VulkanCommandEncoder;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuTexture;
import com.mojang.renderpearl.backend.vulkan.VulkanGpuTextureView;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.mixin.VulkanCommandEncoderAccessor;
import org.joml.Matrix4fc;

final class OcclusionHalfResTarget {
   static final float OCC_NEAR = 0.05F;
   static final float OCC_NEAR_SLACK = 0.05F;
   private static final float INFLATE_PIXELS = 2.8284F;
   private final VulkanCommandEncoder encoder;
   private GpuTexture color;
   private GpuTexture depth;
   private GpuTextureView colorView;
   private GpuTextureView depthView;
   private int halfW;
   private int halfH;
   private int srcW;
   private int srcH;
   private float inflateK;
   private float nearR;
   private static volatile boolean armWarned;
   private static volatile boolean createLogged;
   private static final float CANONICAL_EPSILON = 1.0E-5F;
   private static final float RIGID_EPS = 1.0E-4F;
   private static final float ORTHO_EPS = 1.0E-4F;
   private static final float TRANSLATE_MAX = 0.25F;
   private static final float TRANSFORMED_ORTHO_EPS = 1.0E-6F;
   private static final float TRANSFORMED_TRANSLATION_EPS = 1.0E-6F;
   private long lastArmedPreBobSerial;

   OcclusionHalfResTarget(VulkanCommandEncoder encoder) {
      this.encoder = encoder;
   }

   int halfWidth() {
      return this.halfW;
   }

   int halfHeight() {
      return this.halfH;
   }

   GpuTextureView colorView() {
      return this.colorView;
   }

   GpuTextureView depthView() {
      return this.depthView;
   }

   float inflateK() {
      return this.inflateK;
   }

   float nearR() {
      return this.nearR;
   }

   boolean ensure(GpuTextureView mainColor, GpuTextureView mainDepth) {
      if (((VulkanCommandEncoderAccessor)this.encoder).nvidiumplus$currentRenderPass() != null) {
         throw new IllegalStateException("half-res target created inside an open render pass");
      }

      GpuDevice device = RenderSystem.tryGetDevice();
      if (device == null) {
         return false;
      }

      int w = mainDepth.texture().getWidth(0);
      int h = mainDepth.texture().getHeight(0);
      if (w == this.srcW
         && h == this.srcH
         && this.color != null
         && this.depth != null
         && this.colorView != null
         && this.depthView != null
         && !this.color.isClosed()
         && !this.depth.isClosed()
         && !this.colorView.isClosed()
         && !this.depthView.isClosed()) {
         return true;
      }

      this.closeAll();
      int nw = (w + 1) / 2;
      int nh = (h + 1) / 2;
      GpuTexture c = null;
      GpuTexture d = null;
      GpuTextureView cv = null;
      GpuTextureView dv = null;

      try {
         c = device.createTexture(() -> "NvidiumPlus occlusion half colour", 8, mainColor.texture().getFormat(), nw, nh, 1, 1);
         d = device.createTexture(() -> "NvidiumPlus occlusion half depth", 8, mainDepth.texture().getFormat(), nw, nh, 1, 1);
         cv = device.createTextureView(c);
         dv = device.createTextureView(d);
      } catch (GpuDeviceLossException t) {
         throw t;
      } catch (Throwable t) {
         TerrainOcclusion.halfResAllocationFailures++;
         closeQuietly(cv);
         closeQuietly(c);
         closeQuietly(dv);
         closeQuietly(d);
         throw t;
      }

      this.color = c;
      this.depth = d;
      this.colorView = cv;
      this.depthView = dv;
      this.srcW = w;
      this.srcH = h;
      this.halfW = nw;
      this.halfH = nh;
      TerrainOcclusion.halfResAllocations++;
      TerrainOcclusion.halfResWidth = nw;
      TerrainOcclusion.halfResHeight = nh;
      String line = "NvidiumPlus occlusion half-res target {}x{} for a {}x{} main target (colour {}, depth {})";
      if (createLogged) {
         NvidiumPlusLog.LOGGER.debug(line, new Object[]{nw, nh, w, h, mainColor.texture().getFormat(), mainDepth.texture().getFormat()});
      } else {
         createLogged = true;
         NvidiumPlusLog.LOGGER.info(line, new Object[]{nw, nh, w, h, mainColor.texture().getFormat(), mainDepth.texture().getFormat()});
      }

      return true;
   }

   boolean arm(Matrix4fc drawn, Matrix4fc preBob, Matrix4fc modelView, long preBobSerial) {
      if (drawn == null || !allFinite(drawn)) {
         TerrainOcclusion.halfResArmSkips++;
         TerrainOcclusion.halfResArmSkipsNonFinite++;
         this.warnRefused(
            "G-1 (the drawn matrix is null or has a non-finite entry)",
            drawn == null ? "null" : "m00=" + drawn.m00() + " m11=" + drawn.m11() + " m23=" + drawn.m23() + " m33=" + drawn.m33()
         );
         return false;
      }

      if (preBob == null) {
         TerrainOcclusion.halfResArmSkips++;
         TerrainOcclusion.halfResArmSkipsNoPreBob++;
         this.warnRefused("G0 (no pre-bob stash)", "NvidiumPlusProjectionCapture.preBob() is null: the LevelRenderer.render HEAD hook never ran on this host");
         return false;
      }

      if (preBobSerial <= this.lastArmedPreBobSerial) {
         TerrainOcclusion.halfResArmSkips++;
         TerrainOcclusion.halfResArmSkipsStale++;
         this.warnRefused(
            "G0 (stale stash)",
            "preBobSerial "
               + preBobSerial
               + " has not advanced since the previous arm at "
               + this.lastArmedPreBobSerial
               + ": this arm was reached outside LevelRenderer.render, or the stash has latched"
         );
         return false;
      }

      float off = Math.max(
         Math.max(Math.max(Math.abs(preBob.m01()), Math.abs(preBob.m02())), Math.max(Math.abs(preBob.m03()), Math.abs(preBob.m10()))),
         Math.max(
            Math.max(Math.abs(preBob.m12()), Math.abs(preBob.m13())),
            Math.max(Math.max(Math.abs(preBob.m20()), Math.abs(preBob.m21())), Math.max(Math.abs(preBob.m30()), Math.abs(preBob.m31())))
         )
      );
      float w = Math.abs(preBob.m33());
      float persp = Math.abs(preBob.m23() + 1.0F);
      if (off <= 1.0E-5F
         && w <= 1.0E-5F
         && persp <= 1.0E-5F
         && preBob.m00() > 0.0F
         && preBob.m11() > 0.0F
         && preBob.m22() > 0.0F
         && Math.abs(preBob.m32()) > 0.0F) {
         float p00 = preBob.m00();
         float p11 = preBob.m11();
         float p22 = preBob.m22();
         float p32 = preBob.m32();
         double l00 = (double)drawn.m00() / p00;
         double l01 = (double)drawn.m10() / p00;
         double l02 = (double)drawn.m20() / p00;
         double l10 = (double)drawn.m01() / p11;
         double l11 = (double)drawn.m11() / p11;
         double l12 = (double)drawn.m21() / p11;
         double l20 = -drawn.m03();
         double l21 = -drawn.m13();
         double l22 = -drawn.m23();
         float tx = drawn.m30() / p00;
         float ty = drawn.m31() / p11;
         float tz = -drawn.m33();
         double b0 = (drawn.m02() + (double)p22 * drawn.m03()) / p32;
         double b1 = (drawn.m12() + (double)p22 * drawn.m13()) / p32;
         double b2 = (drawn.m22() + (double)p22 * drawn.m23()) / p32;
         double b3 = (drawn.m32() + (double)p22 * drawn.m33()) / p32;
         double bottom = Math.max(Math.max(Math.abs(b0), Math.abs(b1)), Math.max(Math.abs(b2), Math.abs(b3 - 1.0)));
         if (!(bottom <= 1.0E-4F)) {
            TerrainOcclusion.halfResArmSkips++;
            TerrainOcclusion.halfResArmSkipsNonRigid++;
            this.warnRefused(
               "G2 (the recovered transform is projective, not affine)",
               "bottom row (" + b0 + ", " + b1 + ", " + b2 + ", " + b3 + ") deviates by " + bottom + " (tolerance 1.0E-4)"
            );
            return false;
         }

         double ortho = orthoResidual(l00, l01, l02, l10, l11, l12, l20, l21, l22);
         if (!(ortho <= 1.0E-4F)) {
            TerrainOcclusion.halfResArmSkips++;
            TerrainOcclusion.halfResArmSkipsNonRigid++;
            this.warnRefused(
               "G3 (the recovered transform is not an isometry)",
               "||L^T L - I||_inf " + ortho + " (tolerance 1.0E-4); the portal/nausea rotate-scale-rotate does exactly this"
            );
            return false;
         }

         double tNorm = Math.sqrt((double)tx * tx + (double)ty * ty + (double)tz * tz);
         if (!(tNorm <= 0.25)) {
            TerrainOcclusion.halfResArmSkips++;
            TerrainOcclusion.halfResArmSkipsTranslation++;
            this.warnRefused(
               "G4 (the recovered eye displacement is out of bounds)",
               "||t|| " + tNorm + " blocks from t=(" + tx + ", " + ty + ", " + tz + ") (bound 0.25; vanilla's bob is <= 0.1)"
            );
            return false;
         }

         if (modelView != null && allFinite(modelView)) {
            double viewOrigin = Math.max(
               Math.max(Math.abs(modelView.m30()), Math.abs(modelView.m31())),
               Math.max(
                  Math.abs(modelView.m32()),
                  Math.max(
                     Math.max(Math.abs(modelView.m03()), Math.abs(modelView.m13())), Math.max(Math.abs(modelView.m23()), Math.abs(modelView.m33() - 1.0F))
                  )
               )
            );
            double viewOrtho = orthoResidual(
               modelView.m00(),
               modelView.m10(),
               modelView.m20(),
               modelView.m01(),
               modelView.m11(),
               modelView.m21(),
               modelView.m02(),
               modelView.m12(),
               modelView.m22()
            );
            if (viewOrigin <= 1.0E-4F && viewOrtho <= 1.0E-4F) {
               float a00 = Math.abs(p00);
               float a11 = Math.abs(p11);
               float scale = Math.min(this.halfW * a00, this.halfH * a11);
               if (!(scale > 0.0F)) {
                  TerrainOcclusion.halfResArmSkips++;
                  TerrainOcclusion.halfResArmSkipsShape++;
                  this.warnRefused("G1 (no half target to scale against)", "halfW " + this.halfW + " halfH " + this.halfH + " m00 " + a00 + " m11 " + a11);
                  return false;
               }

               this.inflateK = 2.8284F / scale;
               this.nearR = (float)(0.05F * Math.sqrt(1.0 + 1.0 / ((double)a00 * a00) + 1.0 / ((double)a11 * a11)) + tNorm) + 0.05F;
               TerrainOcclusion.halfResInflateK = this.inflateK;
               TerrainOcclusion.halfResNearR = this.nearR;
               this.lastArmedPreBobSerial = preBobSerial;
               float tf = (float)tNorm;
               float of = (float)ortho;
               if (tf > TerrainOcclusion.halfResMaxArmedTranslation) {
                  TerrainOcclusion.halfResMaxArmedTranslation = tf;
               }

               if (of > TerrainOcclusion.halfResMaxArmedOrtho) {
                  TerrainOcclusion.halfResMaxArmedOrtho = of;
               }

               if (tf > 1.0E-6F || of > 1.0E-6F) {
                  TerrainOcclusion.halfResArmedTransformedFrames++;
               }

               return true;
            } else {
               TerrainOcclusion.halfResArmSkips++;
               TerrainOcclusion.halfResArmSkipsView++;
               this.warnRefused(
                  "G5 (ModelViewMat is not a rotation about the origin)",
                  "origin/bottom-row deviation "
                     + viewOrigin
                     + " (tolerance 1.0E-4), ||Q^T Q - I||_inf "
                     + viewOrtho
                     + " (tolerance 1.0E-4); the shader origin is assumed to BE the eye"
               );
               return false;
            }
         } else {
            TerrainOcclusion.halfResArmSkips++;
            TerrainOcclusion.halfResArmSkipsView++;
            this.warnRefused("G5 (no usable ModelViewMat)", modelView == null ? "null" : "a non-finite entry");
            return false;
         }
      } else {
         TerrainOcclusion.halfResArmSkips++;
         TerrainOcclusion.halfResArmSkipsShape++;
         this.warnRefused(
            "G1 (the pre-bob stash is not a canonical perspective)",
            "worst off-diagonal "
               + off
               + ", |m33| "
               + w
               + ", |m23+1| "
               + persp
               + ", m00 "
               + preBob.m00()
               + ", m11 "
               + preBob.m11()
               + ", m22 "
               + preBob.m22()
               + ", m32 "
               + preBob.m32()
               + " (tolerance 1.0E-5)"
         );
         return false;
      }
   }

   private static boolean allFinite(Matrix4fc m) {
      return Float.isFinite(m.m00())
         && Float.isFinite(m.m01())
         && Float.isFinite(m.m02())
         && Float.isFinite(m.m03())
         && Float.isFinite(m.m10())
         && Float.isFinite(m.m11())
         && Float.isFinite(m.m12())
         && Float.isFinite(m.m13())
         && Float.isFinite(m.m20())
         && Float.isFinite(m.m21())
         && Float.isFinite(m.m22())
         && Float.isFinite(m.m23())
         && Float.isFinite(m.m30())
         && Float.isFinite(m.m31())
         && Float.isFinite(m.m32())
         && Float.isFinite(m.m33());
   }

   private static double orthoResidual(double r00, double r01, double r02, double r10, double r11, double r12, double r20, double r21, double r22) {
      double e00 = r00 * r00 + r10 * r10 + r20 * r20 - 1.0;
      double e11 = r01 * r01 + r11 * r11 + r21 * r21 - 1.0;
      double e22 = r02 * r02 + r12 * r12 + r22 * r22 - 1.0;
      double e01 = r00 * r01 + r10 * r11 + r20 * r21;
      double e02 = r00 * r02 + r10 * r12 + r20 * r22;
      double e12 = r01 * r02 + r11 * r12 + r21 * r22;
      double diag = Math.max(Math.abs(e00), Math.max(Math.abs(e11), Math.abs(e22)));
      return Math.max(diag, Math.max(Math.abs(e01), Math.max(Math.abs(e02), Math.abs(e12))));
   }

   private void warnRefused(String check, String detail) {
      if (!armWarned) {
         armWarned = true;
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus half-res occlusion depth: the arm refused a frame at {}: {}. Running full-res this frame and counting the skip (first and only report; the per-reason counters keep counting).",
               check,
               detail
            );
      }
   }

   void destroy() {
      this.closeAll();
   }

   void destroyNow() {
      if (this.colorView instanceof VulkanGpuTextureView v) {
         v.destroy();
      }

      if (this.depthView instanceof VulkanGpuTextureView v) {
         v.destroy();
      }

      if (this.color instanceof VulkanGpuTexture t) {
         t.destroy();
      }

      if (this.depth instanceof VulkanGpuTexture t) {
         t.destroy();
      }

      this.forget();
   }

   private void closeAll() {
      closeQuietly(this.colorView);
      closeQuietly(this.color);
      closeQuietly(this.depthView);
      closeQuietly(this.depth);
      this.forget();
   }

   private void forget() {
      this.color = null;
      this.depth = null;
      this.colorView = null;
      this.depthView = null;
      this.srcW = 0;
      this.srcH = 0;
      this.halfW = 0;
      this.halfH = 0;
      TerrainOcclusion.halfResWidth = 0;
      TerrainOcclusion.halfResHeight = 0;
   }

   private static void closeQuietly(AutoCloseable o) {
      if (o != null) {
         try {
            o.close();
         } catch (Throwable var2) {
         }
      }
   }
}
