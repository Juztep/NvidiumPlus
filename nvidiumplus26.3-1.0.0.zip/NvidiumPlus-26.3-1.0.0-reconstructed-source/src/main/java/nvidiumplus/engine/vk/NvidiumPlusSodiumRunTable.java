package nvidiumplus.engine.vk;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.device.GpuDevice;
import com.mojang.renderpearl.backend.vulkan.VulkanCommandEncoder;
import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.mixin.GpuDeviceAccessor;
import org.lwjgl.system.MemoryUtil;

final class NvidiumPlusSodiumRunTable {
   static final int RUN_BYTES = 32;
   private static final int SLOTS = 8;
   private static final int RUNS_PER_SLOT = 16384;
   private static volatile int runsPerSlot = 16384;
   private static final int RUNS_OBSERVED_AT_96 = 28207;
   private static final int ANCHOR_DISTANCE = 96;
   private static final int SAFETY_NUMERATOR = 3;
   private static final int SAFETY_DENOMINATOR = 2;
   private static final int RUNS_PER_SLOT_CEILING = 131072;
   private static final String RUNS_PROPERTY = "nvidiumplus.sodium.runsPerSlot";
   static final int INDIRECT_BYTES = 12;
   private static final int GROUPS_PER_SLOT = 131072;
   private static volatile int groupsPerSlot = 131072;
   private static final int GROUPS_OBSERVED_AT_96 = 72000;
   private static final int GROUPS_PER_SLOT_CEILING = 262144;
   static final int GROUP_LOCAL_BITS = 12;
   private final VulkanCommandEncoder encoder;
   private final long vma;
   private final NvidiumPlusVkBuffers.MappedBuffer buffer;
   private final NvidiumPlusVkBuffers.MappedBuffer indirect;
   private final NvidiumPlusVkBuffers.MappedBuffer groupMap;
   private final long slotBytes;
   private final long indirectSlotBytes;
   private final long groupSlotBytes;
   private long record;
   private static int advancesSinceSubmit;

   private NvidiumPlusSodiumRunTable(
      VulkanCommandEncoder encoder,
      long vma,
      NvidiumPlusVkBuffers.MappedBuffer buffer,
      NvidiumPlusVkBuffers.MappedBuffer indirect,
      NvidiumPlusVkBuffers.MappedBuffer groupMap,
      long slotBytes,
      long indirectSlotBytes,
      long groupSlotBytes
   ) {
      this.encoder = encoder;
      this.vma = vma;
      this.buffer = buffer;
      this.indirect = indirect;
      this.groupMap = groupMap;
      this.slotBytes = slotBytes;
      this.indirectSlotBytes = indirectSlotBytes;
      this.groupSlotBytes = groupSlotBytes;
   }

   static NvidiumPlusSodiumRunTable create() {
      GpuDevice facade = RenderSystem.tryGetDevice();
      if (facade == null) {
         return null;
      }

      VulkanDevice device = (VulkanDevice)((GpuDeviceAccessor)facade).nvidiumplus$backend();
      VulkanCommandEncoder encoder = device.createCommandEncoder();
      int cap = NvidiumPlusConfig.maxRenderDistanceConfigured();
      int wantRuns = sizeForCap(28207, cap, 16384, 131072);
      int wantGroups = sizeForCap(72000, cap, 131072, 262144);
      String override = System.getProperty("nvidiumplus.sodium.runsPerSlot");
      if (override != null) {
         try {
            wantRuns = Math.max(1024, Integer.parseInt(override.trim()));
         } catch (NumberFormatException e) {
            NvidiumPlusLog.LOGGER
               .warn("Unparseable {}='{}' - using the derived {} runs/slot", new Object[]{"nvidiumplus.sodium.runsPerSlot", override, wantRuns});
         }
      }

      runsPerSlot = wantRuns;
      groupsPerSlot = wantGroups;
      long slotBytes = runsPerSlot * 32L;
      long totalBytes = slotBytes * 8L;
      NvidiumPlusVkBuffers.MappedBuffer buf = NvidiumPlusVkBuffers.createDeviceMapped(
         device.vma(), totalBytes, 32, "vmaCreateBuffer(NvidiumPlus sodium run table)"
      );
      MemoryUtil.memSet(buf.mappedAddress(), 0, totalBytes);
      long indirectSlotBytes = runsPerSlot * 12L;
      long indirectTotal = indirectSlotBytes * 8L;
      NvidiumPlusVkBuffers.MappedBuffer ind = NvidiumPlusVkBuffers.createDeviceMapped(
         device.vma(), indirectTotal, 256, "vmaCreateBuffer(NvidiumPlus sodium indirect commands)"
      );
      MemoryUtil.memSet(ind.mappedAddress(), 0, indirectTotal);
      long groupSlotBytes = groupsPerSlot * 4L;
      long groupTotal = groupSlotBytes * 8L;
      NvidiumPlusVkBuffers.MappedBuffer gm = NvidiumPlusVkBuffers.createDeviceMapped(
         device.vma(), groupTotal, 32, "vmaCreateBuffer(NvidiumPlus sodium group map)"
      );
      MemoryUtil.memSet(gm.mappedAddress(), 0, groupTotal);
      NvidiumPlusLog.LOGGER
         .info(
            "NvidiumPlus Sodium run table up: {} runs/slot x {} slots = {} KiB run records + {} KiB indirect commands + {} KiB group map ({} workgroups/slot), device-local where the card allows it, sized for a Distance Cap of {}. This is what lets one command cover a whole region group instead of one draw per section.",
            new Object[]{runsPerSlot, 8, totalBytes >> 10, indirectTotal >> 10, groupTotal >> 10, groupsPerSlot, cap}
         );
      return new NvidiumPlusSodiumRunTable(encoder, device.vma(), buf, ind, gm, slotBytes, indirectSlotBytes, groupSlotBytes);
   }

   private static int sizeForCap(int observed, int cap, int floor, int ceiling) {
      long scaled = (long)observed * cap * cap / 9216L;
      long safe = scaled * 3L / 2L;
      long rounded = (safe + 1023L) / 1024L * 1024L;
      return (int)Math.max(floor, Math.min(ceiling, rounded));
   }

   static int capacity() {
      return runsPerSlot;
   }

   static boolean ringGuardTripped() {
      return advancesSinceSubmit >= safeAdvancesPerSubmit();
   }

   static int safeAdvancesPerSubmit() {
      return 4;
   }

   static void onSubmit() {
      advancesSinceSubmit = 0;
   }

   ByteBuffer advance() {
      this.record++;
      advancesSinceSubmit++;
      long base = this.buffer.mappedAddress() + this.slotIndex() * this.slotBytes;
      return MemoryUtil.memByteBuffer(base, (int)this.slotBytes).order(ByteOrder.LITTLE_ENDIAN);
   }

   ByteBuffer indirectView() {
      long base = this.indirect.mappedAddress() + this.slotIndex() * this.indirectSlotBytes;
      return MemoryUtil.memByteBuffer(base, (int)this.indirectSlotBytes).order(ByteOrder.LITTLE_ENDIAN);
   }

   long indirectBuffer() {
      return this.indirect.vkBuffer();
   }

   long indirectOffset() {
      return this.slotIndex() * this.indirectSlotBytes;
   }

   static int groupCapacity() {
      return groupsPerSlot;
   }

   ByteBuffer groupMapView() {
      long base = this.groupMap.mappedAddress() + this.slotIndex() * this.groupSlotBytes;
      return MemoryUtil.memByteBuffer(base, (int)this.groupSlotBytes).order(ByteOrder.LITTLE_ENDIAN);
   }

   long groupMapBuffer() {
      return this.groupMap.vkBuffer();
   }

   long groupMapOffset() {
      return this.slotIndex() * this.groupSlotBytes;
   }

   long groupMapRange() {
      return this.groupSlotBytes;
   }

   long vkBuffer() {
      return this.buffer.vkBuffer();
   }

   long offset() {
      return this.slotIndex() * this.slotBytes;
   }

   long range() {
      return this.slotBytes;
   }

   private long slotIndex() {
      return Math.floorMod(this.record, 8L);
   }

   void destroyNow() {
      NvidiumPlusVkBuffers.destroy(this.vma, this.buffer.vkBuffer(), this.buffer.allocation());
      NvidiumPlusVkBuffers.destroy(this.vma, this.indirect.vkBuffer(), this.indirect.allocation());
      NvidiumPlusVkBuffers.destroy(this.vma, this.groupMap.vkBuffer(), this.groupMap.allocation());
   }

   void destroy() {
      long vmaHandle = this.vma;
      NvidiumPlusVkBuffers.MappedBuffer b = this.buffer;
      NvidiumPlusVkBuffers.MappedBuffer i = this.indirect;
      NvidiumPlusVkBuffers.MappedBuffer g = this.groupMap;
      this.encoder.queueForDestroy(() -> {
         NvidiumPlusVkBuffers.destroy(vmaHandle, b.vkBuffer(), b.allocation());
         NvidiumPlusVkBuffers.destroy(vmaHandle, i.vkBuffer(), i.allocation());
         NvidiumPlusVkBuffers.destroy(vmaHandle, g.vkBuffer(), g.allocation());
      });
   }
}
