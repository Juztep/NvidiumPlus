package nvidiumplus.engine;

import java.util.Arrays;
import net.minecraft.client.Minecraft;

public final class NvidiumPlusBenchRecorder {
   public static final String PROPERTY = "nvidiumplus.bench";
   public static final String FARBENCH_PROPERTY = "nvidiumplus.test.farbench";
   public static final boolean ARMED = System.getProperty("nvidiumplus.bench") != null || Boolean.getBoolean("nvidiumplus.test.farbench");
   private static long[] frameNanos = new long[0];
   private static long[] frameCpuNanos = new long[0];
   private static int[] frameRuns = new int[0];
   private static int[] frameRunsRejected = new int[0];
   private static int pendingRuns;
   private static int pendingRunsRejected;
   public static final boolean JITTER = Boolean.getBoolean("nvidiumplus.bench.jitter");
   static final float JITTER_DEGREES = 0.001F;
   private static float jitterBaseYaw = Float.NaN;
   private static long jitterFrames;
   private static volatile int filled;
   private static volatile boolean capturing;
   private static long lastFrameNanoTime;

   private NvidiumPlusBenchRecorder() {
   }

   public static String sceneName() {
      return System.getProperty("nvidiumplus.bench");
   }

   public static void onRenderFrame() {
      if (JITTER) {
         jitter();
      }

      int runs = pendingRuns;
      int rejected = pendingRunsRejected;
      pendingRuns = 0;
      pendingRunsRejected = 0;
      if (!capturing) {
         lastFrameNanoTime = 0L;
      } else {
         long now = System.nanoTime();
         if (lastFrameNanoTime != 0L) {
            int i = filled;
            if (i < frameNanos.length) {
               frameNanos[i] = now - lastFrameNanoTime;
               frameCpuNanos[i] = cpuFrameNanos();
               frameRuns[i] = runs;
               frameRunsRejected[i] = rejected;
               filled = i + 1;
               if (i + 1 == frameNanos.length) {
                  capturing = false;
               }
            }
         }

         lastFrameNanoTime = now;
      }
   }

   private static long cpuFrameNanos() {
      Minecraft minecraft = Minecraft.getInstance();
      return minecraft == null ? 0L : minecraft.getFrameTimeNs();
   }

   private static void jitter() {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft != null && minecraft.player != null) {
         float yaw = minecraft.player.getYRot();
         if (Float.isNaN(jitterBaseYaw) || Math.abs(yaw - jitterBaseYaw) > 0.002F) {
            jitterBaseYaw = yaw;
         }

         jitterFrames++;
         float nudged = jitterBaseYaw + ((jitterFrames & 1L) == 0L ? 0.0F : 0.001F);
         minecraft.player.setYRot(nudged);
         minecraft.player.yRotO = nudged;
      }
   }

   public static void arm(int frames) {
      frameNanos = new long[frames];
      frameCpuNanos = new long[frames];
      frameRuns = new int[frames];
      frameRunsRejected = new int[frames];
      filled = 0;
      lastFrameNanoTime = 0L;
      capturing = true;
   }

   public static void disarm() {
      capturing = false;
   }

   public static int filled() {
      return filled;
   }

   public static long[] snapshot() {
      return Arrays.copyOf(frameNanos, filled);
   }

   public static long[] snapshotCpu() {
      return Arrays.copyOf(frameCpuNanos, filled);
   }

   public static void addRuns(int runs, int rejected) {
      pendingRuns += runs;
      pendingRunsRejected += rejected;
   }

   public static long[] snapshotRuns() {
      return widen(frameRuns, filled);
   }

   public static long[] snapshotRunsRejected() {
      return widen(frameRunsRejected, filled);
   }

   private static long[] widen(int[] values, int n) {
      long[] out = new long[n];

      for (int i = 0; i < n; i++) {
         out[i] = values[i];
      }

      return out;
   }
}
