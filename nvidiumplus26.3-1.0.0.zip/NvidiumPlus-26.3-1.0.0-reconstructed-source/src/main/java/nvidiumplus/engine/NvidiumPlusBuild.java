package nvidiumplus.engine;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Properties;
import java.util.Set;

public final class NvidiumPlusBuild {
   public static final String RESOURCE = "/nvidiumplus-build.properties";
   public static final String MINECRAFT_TARGET;
   public static final String SODIUM_BUILT_AGAINST;
   public static final Set<String> SODIUM_ALSO_MATCHING;
   public static final int LAUNCH_SHADOW_PAGES;

   private NvidiumPlusBuild() {
   }

   private static String required(Properties props, String key) {
      String v = props.getProperty(key, "").trim();
      if (!v.isEmpty() && !v.startsWith("${")) {
         return v;
      } else {
         throw new IllegalStateException(
            "/nvidiumplus-build.properties has no expanded value for "
               + key
               + " (got '"
               + v
               + "'); the build's processResources did not run over it. Known keys: "
               + Arrays.toString(props.stringPropertyNames().toArray())
         );
      }
   }

   static {
      Properties props = new Properties();

      try (InputStream in = NvidiumPlusBuild.class.getResourceAsStream("/nvidiumplus-build.properties")) {
         if (in == null) {
            throw new IllegalStateException(
               "NvidiumPlus jar has no /nvidiumplus-build.properties; the build did not expand it, so this jar cannot say which Minecraft it is for"
            );
         }

         props.load(in);
      } catch (IOException e) {
         throw new IllegalStateException("NvidiumPlus could not read /nvidiumplus-build.properties", e);
      }

      MINECRAFT_TARGET = required(props, "minecraft_target");
      SODIUM_BUILT_AGAINST = required(props, "sodium_built_against");
      Set<String> also = new LinkedHashSet<>();

      for (String s : props.getProperty("sodium_also_matching", "").split(",")) {
         String t = s.trim();
         if (!t.isEmpty()) {
            also.add(t);
         }
      }

      SODIUM_ALSO_MATCHING = Set.copyOf(also);
      String shadow = props.getProperty("launch_shadow_pages", "0").trim();
      if (shadow.startsWith("${")) {
         throw new IllegalStateException("NvidiumPlus jar's /nvidiumplus-build.properties was not expanded (launch_shadow_pages=" + shadow + ")");
      }

      LAUNCH_SHADOW_PAGES = shadow.isEmpty() ? 0 : Integer.parseInt(shadow);
   }
}
