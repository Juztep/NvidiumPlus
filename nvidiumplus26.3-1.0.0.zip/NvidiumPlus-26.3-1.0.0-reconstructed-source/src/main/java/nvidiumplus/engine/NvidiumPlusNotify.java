package nvidiumplus.engine;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.toasts.SystemToast;
import net.minecraft.client.gui.components.toasts.SystemToast.SystemToastId;
import net.minecraft.network.chat.Component;

public final class NvidiumPlusNotify {
   private NvidiumPlusNotify() {
   }

   public static void error(SystemToastId id, Component title, Component body) {
      Minecraft minecraft = client();
      if (minecraft != null) {
         if (minecraft.gui != null) {
            SystemToast.add(minecraft.gui.toastManager(), id, title, body);
         }

         chat(Component.translatable("nvidiumplus.chat.line", new Object[]{title, body}));
      }
   }

   public static void chat(Component line) {
      Minecraft minecraft = client();
      if (minecraft != null) {
         minecraft.execute(() -> {
            try {
               if (minecraft.gui == null || minecraft.gui.hud == null) {
                  return;
               }

               minecraft.gui.hud.getChat().addClientSystemMessage(line);
            } catch (Throwable t) {
               NvidiumPlusLog.LOGGER.debug("NvidiumPlus could not write a chat notice", t);
            }
         });
      }
   }

   private static Minecraft client() {
      try {
         return Minecraft.getInstance();
      } catch (Throwable t) {
         return null;
      }
   }

   public static void chat(String translationKey) {
      chat(Component.translatable("nvidiumplus.chat.prefix", new Object[]{Component.translatable(translationKey)}));
   }
}
