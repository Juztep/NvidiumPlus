package nvidiumplus.engine;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

public final class NvidiumPlusConfig {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static volatile NvidiumPlusConfig instance;
   public boolean showVulkanPrompt = true;
   public boolean noMeshShaderNoticeShown = false;
   public boolean vulkanFailedNoticeShown = false;
   public boolean enableTerrainRendering = true;
   public boolean suppressVanillaUploads = true;
   public int configVersion = 0;
   private static final int CURRENT_CONFIG_VERSION = 3;
   @Deprecated
   public boolean enableOcclusionCulling = false;
   public NvidiumPlusConfig.FogMode fogMode = NvidiumPlusConfig.FogMode.OFF;
   public int fogEndPercent = 100;
   public static final int MIN_FOG_END_PERCENT = 50;
   public static final int MAX_FOG_END_PERCENT = 200;
   public static final int DEFAULT_FOG_END_PERCENT = 100;
   public boolean greedyMeshing = false;
   public boolean arenaTrim = true;
   public static final int MIN_DETAIL_CULL_CHUNKS = 0;
   public static final int MAX_DETAIL_CULL_CHUNKS = 96;
   public int plantCullChunks = 0;
   public int subPixelCullChunks = 0;
   public boolean sodiumGpuVisibility = true;
   public boolean sodiumOcclusion = true;
   public boolean sodiumRemirrorOnRefusal = true;
   public int smartLeavesChunks = 16;
   public int solidLeavesChunks = 0;
   public NvidiumPlusConfig.OcclusionMode occlusionMode = NvidiumPlusConfig.OcclusionMode.AUTO;
   public static final int MIN_OCCLUSION_AUTO_RD = 2;
   public static final int MAX_OCCLUSION_AUTO_RD = 120;
   public static final int DEFAULT_OCCLUSION_AUTO_RD = 48;
   public int occlusionAutoMinRenderDistance = 48;
   public boolean debugStats = false;
   public boolean retainTerrain = false;
   public int retainTerrainMinutes = 0;
   public static final int MIN_MAX_RENDER_DISTANCE = 32;
   public static final int MAX_MAX_RENDER_DISTANCE = 32;
   public static final int SLIDER_MAX_RENDER_DISTANCE = 32;
   public static final int DEFAULT_MAX_RENDER_DISTANCE = 32;
   public static final int MAX_RETAIN_MINUTES = 10080;
   public int maxRenderDistance = 32;
   public static final String PROPERTY_SKIP_VANILLA_PREP = "nvidiumplus.tune.skipVanillaPrep";
   public static final String PROPERTY_CACHED_CULL = "nvidiumplus.tune.cachedCull";

   private boolean migrate() {
      if (this.configVersion >= 3) {
         return false;
      }

      if (this.configVersion < 1) {
         this.suppressVanillaUploads = true;
      }

      if (this.configVersion < 2) {
         this.fogMode = NvidiumPlusConfig.FogMode.OFF;
      }

      if (this.configVersion < 3) {
         this.showVulkanPrompt = true;
         this.noMeshShaderNoticeShown = false;
         this.vulkanFailedNoticeShown = false;
      }

      this.configVersion = 3;
      return true;
   }

   public static NvidiumPlusConfig get() {
      NvidiumPlusConfig loaded = instance;
      if (loaded == null) {
         synchronized (NvidiumPlusConfig.class) {
            loaded = instance;
            if (loaded == null) {
               loaded = load();
               instance = loaded;
            }
         }
      }

      return loaded;
   }

   public static boolean terrainRenderingEnabled() {
      return propertyOr("nvidiumplus.terrainDraw", get().enableTerrainRendering);
   }

   public static boolean terrainRenderingConfigured() {
      return get().enableTerrainRendering;
   }

   public static boolean suppressVanillaUploads() {
      return propertyOr("nvidiumplus.suppressVanillaUploads", get().suppressVanillaUploads);
   }

   public static boolean occlusionCullingEnabled(int effectiveRenderDistance) {
      String property = System.getProperty("nvidiumplus.terrainDraw.bfsOnly");
      if (property != null) {
         return !Boolean.parseBoolean(property);
      }

      NvidiumPlusConfig config = get();

      return switch (config.occlusionMode) {
         case AUTO -> effectiveRenderDistance >= config.occlusionAutoMinRenderDistance;
         case ON -> true;
         case OFF -> false;
      };
   }

   public static boolean sodiumGpuVisibilityEnabled() {
      return propertyOr("nvidiumplus.sodium.gpuDraw", get().sodiumGpuVisibility);
   }

   public static boolean sodiumOcclusionConfigured() {
      return get().sodiumOcclusion;
   }

   public static boolean sodiumRemirrorOnRefusalEnabled() {
      return propertyOr("nvidiumplus.sodium.remirrorOnRefusal", get().sodiumRemirrorOnRefusal);
   }

   public static boolean greedyMeshingEnabled() {
      return propertyOr("nvidiumplus.greedyMeshing", get().greedyMeshing);
   }

   public static boolean arenaTrimEnabled() {
      return propertyOr("nvidiumplus.tune.arenaTrim", get().arenaTrim);
   }

   public static int plantCullChunks() {
      return Math.max(0, Math.min(96, get().plantCullChunks));
   }

   public static int subPixelCullChunks() {
      return Math.max(0, Math.min(96, get().subPixelCullChunks));
   }

   public static int smartLeavesChunks() {
      Integer override = Integer.getInteger("nvidiumplus.smartLeavesChunks");
      int chunks = override != null ? override : get().smartLeavesChunks;
      return Math.max(0, Math.min(96, chunks));
   }

   public static int solidLeavesChunks() {
      Integer override = Integer.getInteger("nvidiumplus.solidLeavesChunks");
      int chunks = override != null ? override : get().solidLeavesChunks;
      return Math.max(0, Math.min(96, chunks));
   }

   public static NvidiumPlusConfig.FogMode fogMode() {
      String property = System.getProperty("nvidiumplus.fogMode");
      if (property != null) {
         try {
            return NvidiumPlusConfig.FogMode.valueOf(property.toUpperCase(Locale.ROOT));
         } catch (IllegalArgumentException var2) {
         }
      }

      return get().fogMode;
   }

   public static int fogEndPercent() {
      return Math.max(50, Math.min(200, get().fogEndPercent));
   }

   public static NvidiumPlusConfig.OcclusionMode occlusionMode() {
      String property = System.getProperty("nvidiumplus.terrainDraw.bfsOnly");
      if (property != null) {
         return Boolean.parseBoolean(property) ? NvidiumPlusConfig.OcclusionMode.OFF : NvidiumPlusConfig.OcclusionMode.ON;
      } else {
         return get().occlusionMode;
      }
   }

   public static boolean debugStatsEnabled() {
      return propertyOr("nvidiumplus.debugStats", get().debugStats);
   }

   public static boolean retainTerrainEnabled() {
      return propertyOr("nvidiumplus.retainTerrain", get().retainTerrain);
   }

   public static long retainLimitMillis() {
      String property = System.getProperty("nvidiumplus.retainSeconds");
      if (property != null) {
         try {
            return Math.max(0L, Long.parseLong(property.trim())) * 1000L;
         } catch (NumberFormatException e) {
            NvidiumPlusLog.LOGGER.warn("Unparseable nvidiumplus.retainSeconds='{}' — using the config minutes", property);
         }
      }

      return Math.max(0L, get().retainTerrainMinutes) * 60000L;
   }

   public static int maxRenderDistanceConfigured() {
      return Integer.MAX_VALUE;
   }

   public static boolean skipVanillaPrepEnabled() {
      String p = System.getProperty("nvidiumplus.tune.skipVanillaPrep");
      return p != null ? Boolean.parseBoolean(p) : true;
   }

   public static boolean cachedCullEnabled() {
      return Boolean.getBoolean("nvidiumplus.tune.cachedCull");
   }

   private static boolean propertyOr(String key, boolean configValue) {
      String property = System.getProperty(key);
      return property != null ? Boolean.parseBoolean(property) : configValue;
   }

   public void resetToDefaults() {
      NvidiumPlusConfig d = new NvidiumPlusConfig();
      this.enableTerrainRendering = d.enableTerrainRendering;
      this.occlusionMode = d.occlusionMode;
      this.occlusionAutoMinRenderDistance = d.occlusionAutoMinRenderDistance;
      this.enableOcclusionCulling = d.enableOcclusionCulling;
      this.debugStats = d.debugStats;
      this.maxRenderDistance = d.maxRenderDistance;
      this.showVulkanPrompt = d.showVulkanPrompt;
      this.noMeshShaderNoticeShown = d.noMeshShaderNoticeShown;
      this.vulkanFailedNoticeShown = d.vulkanFailedNoticeShown;
      this.fogMode = d.fogMode;
      this.fogEndPercent = d.fogEndPercent;
      this.suppressVanillaUploads = d.suppressVanillaUploads;
      this.greedyMeshing = d.greedyMeshing;
      this.arenaTrim = d.arenaTrim;
      this.plantCullChunks = d.plantCullChunks;
      this.subPixelCullChunks = d.subPixelCullChunks;
      this.sodiumGpuVisibility = d.sodiumGpuVisibility;
      this.sodiumOcclusion = d.sodiumOcclusion;
      this.sodiumRemirrorOnRefusal = d.sodiumRemirrorOnRefusal;
      this.smartLeavesChunks = d.smartLeavesChunks;
      this.solidLeavesChunks = d.solidLeavesChunks;
      this.retainTerrain = d.retainTerrain;
      this.retainTerrainMinutes = d.retainTerrainMinutes;
      this.save();
   }

   private static Path path() {
      return NvidiumPlusPlatform.configDir().resolve("nvidiumplus.json");
   }

   private static NvidiumPlusConfig load() {
      Path path = path();

      try {
         if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
               NvidiumPlusConfig loaded = (NvidiumPlusConfig)GSON.fromJson(reader, NvidiumPlusConfig.class);
               if (loaded != null) {
                  if (loaded.migrate()) {
                     NvidiumPlusLog.LOGGER.info("NvidiumPlus migrated {} to settings schema v{}", path, 3);
                     loaded.save();
                  }

                  return loaded;
               }
            }
         }
      } catch (IOException | JsonParseException e) {
         NvidiumPlusLog.LOGGER.warn("Could not read {}; starting from defaults", path, e);
      }

      NvidiumPlusConfig fresh = new NvidiumPlusConfig();
      fresh.migrate();
      return fresh;
   }

   public void save() {
      Path path = path();

      try {
         Files.createDirectories(path.getParent());

         try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            GSON.toJson(this, writer);
         }
      } catch (IOException e) {
         NvidiumPlusLog.LOGGER.warn("Could not write {}; settings will not persist", path, e);
      }
   }

   public enum FogMode {
      VANILLA,
      SCALED,
      OFF;
   }

   public enum OcclusionMode {
      AUTO,
      ON,
      OFF;
   }
}
