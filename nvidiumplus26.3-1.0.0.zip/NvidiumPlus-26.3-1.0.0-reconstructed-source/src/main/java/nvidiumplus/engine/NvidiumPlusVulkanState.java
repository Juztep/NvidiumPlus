package nvidiumplus.engine;

public final class NvidiumPlusVulkanState {
   private static volatile NvidiumPlusVulkanState.ArenaLimits arenaLimits = new NvidiumPlusVulkanState.ArenaLimits(0L, 0L, 0L, 0L, 0L);
   private static volatile boolean drawIndirectSupported;
   private static volatile boolean memoryBudgetSupported;
   private static volatile boolean conditionalRenderingSupported;
   private static volatile boolean conservativeRasterizationSupported;
   private static volatile boolean conservativeRasterizationEnabled;
   private static volatile NvidiumPlusVulkanState.ConservativeRasterCaps conservativeRasterCaps;
   private static volatile boolean integratedGpu;
   private static volatile boolean vulkanDeviceCreationSeen;
   private static volatile boolean meshShadersRequested;
   private static volatile String deviceName = "<no vulkan device>";
   private static volatile String driverInfo = "";
   private static volatile NvidiumPlusVulkanState.MeshShaderCaps caps;
   private static volatile long deviceLocalHeapBytes;
   private static volatile long maxStorageBufferRangeBytes;

   public static NvidiumPlusVulkanState.ArenaLimits arenaLimits() {
      return arenaLimits;
   }

   public static boolean drawIndirectSupported() {
      return drawIndirectSupported;
   }

   public static void setDrawIndirectSupported(boolean supported) {
      drawIndirectSupported = supported;
   }

   public static boolean memoryBudgetSupported() {
      return memoryBudgetSupported;
   }

   public static void setMemoryBudgetSupported(boolean supported) {
      memoryBudgetSupported = supported;
   }

   public static boolean conditionalRenderingSupported() {
      return conditionalRenderingSupported;
   }

   public static void setConditionalRenderingSupported(boolean supported) {
      conditionalRenderingSupported = supported;
   }

   public static boolean conservativeRasterizationSupported() {
      return conservativeRasterizationSupported;
   }

   public static void setConservativeRasterizationSupported(boolean supported) {
      conservativeRasterizationSupported = supported;
   }

   public static boolean conservativeRasterizationEnabled() {
      return conservativeRasterizationEnabled;
   }

   public static void setConservativeRasterizationEnabled(boolean enabled) {
      conservativeRasterizationEnabled = enabled;
   }

   public static NvidiumPlusVulkanState.ConservativeRasterCaps conservativeRasterCaps() {
      return conservativeRasterCaps;
   }

   public static void setConservativeRasterCaps(NvidiumPlusVulkanState.ConservativeRasterCaps caps) {
      conservativeRasterCaps = caps;
   }

   public static boolean integratedGpu() {
      return integratedGpu;
   }

   public static void setIntegratedGpu(boolean integrated) {
      integratedGpu = integrated;
   }

   private NvidiumPlusVulkanState() {
   }

   public static boolean vulkanDeviceCreationSeen() {
      return vulkanDeviceCreationSeen;
   }

   public static boolean meshShadersRequested() {
      return meshShadersRequested;
   }

   public static String deviceName() {
      return deviceName;
   }

   public static String driverInfo() {
      return driverInfo;
   }

   public static NvidiumPlusVulkanState.MeshShaderCaps caps() {
      return caps;
   }

   public static long deviceLocalHeapBytes() {
      return deviceLocalHeapBytes;
   }

   public static long maxStorageBufferRangeBytes() {
      return maxStorageBufferRangeBytes;
   }

   public static void recordDeviceCreation(
      String name,
      String driver,
      boolean requested,
      NvidiumPlusVulkanState.MeshShaderCaps queriedCaps,
      long localHeapBytes,
      long storageBufferRangeBytes,
      NvidiumPlusVulkanState.ArenaLimits limits
   ) {
      deviceName = name;
      driverInfo = driver;
      meshShadersRequested = requested;
      caps = queriedCaps;
      deviceLocalHeapBytes = localHeapBytes;
      maxStorageBufferRangeBytes = storageBufferRangeBytes;
      arenaLimits = limits == null ? new NvidiumPlusVulkanState.ArenaLimits(storageBufferRangeBytes, 0L, 0L, 0L, 0L) : limits;
      vulkanDeviceCreationSeen = true;
   }

   public record ArenaLimits(
      long maxStorageBufferRange,
      long maxPerStageDescriptorStorageBuffers,
      long maxDescriptorSetStorageBuffers,
      long maxMemoryAllocationSize,
      long maxPushDescriptors
   ) {
   }

   public record ConservativeRasterCaps(
      float primitiveOverestimationSize,
      float maxExtraPrimitiveOverestimationSize,
      float extraPrimitiveOverestimationSizeGranularity,
      boolean degenerateTrianglesRasterized,
      boolean fullyCoveredFragmentShaderInputVariable,
      boolean conservativeRasterizationPostDepthCoverage
   ) {
   }

   public record MeshShaderCaps(
      int maxTaskWorkGroupInvocations,
      int maxTaskPayloadSize,
      int maxMeshWorkGroupInvocations,
      int maxMeshOutputVertices,
      int maxMeshOutputPrimitives,
      int maxMeshOutputComponents,
      int maxMeshOutputMemorySize,
      int maxPreferredTaskWorkGroupInvocations,
      int maxPreferredMeshWorkGroupInvocations,
      boolean prefersLocalInvocationVertexOutput,
      boolean prefersLocalInvocationPrimitiveOutput,
      boolean prefersCompactVertexOutput,
      boolean prefersCompactPrimitiveOutput
   ) {
   }
}
