package nvidiumplus.engine;

import com.mojang.serialization.Codec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.client.OptionInstance.IntRange;
import net.minecraft.client.OptionInstance.ValueSet;
import net.minecraft.client.gui.components.toasts.SystemToast;
import net.minecraft.client.gui.components.toasts.SystemToast.SystemToastId;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsSubScreen;
import net.minecraft.network.chat.Component;
import nvidiumplus.engine.mixin.ChunkTaskPriorityQueueAccessor;
import nvidiumplus.engine.mixin.OptionInstanceAccessor;
import nvidiumplus.engine.terrain.host.TerrainResidency;
import nvidiumplus.engine.terrain.host.VanillaUploadSeam;
import nvidiumplus.engine.vk.TerrainDrawer;

public final class NvidiumPlusExtendedRd {
   private static final SystemToastId TOAST_ID = new SystemToastId();
   private static final SystemToastId REJOIN_TOAST_ID = new SystemToastId();
   private static final int VANILLA_RD_HARD_MAX = 32;
   private static ValueSet<?> vanillaValues;
   private static Codec<?> vanillaCodec;
   private static int vanillaMax = 32;
   private static int vanillaMin = 2;
   private static boolean captured;
   private static boolean captureFailedLogged;
   private static int appliedMax = 32;
   public static final String PROPERTY_BENCH_NO_CLAMP = "nvidiumplus.bench.noClampBack";
   private static boolean clampNoticeArmed = true;
   private static final long ARENA_BACKOFF_PCT = 92L;
   private static final long ARENA_CRITICAL_PCT = 97L;
   private static final int BACKOFF_STEP = 8;
   private static final int BACKOFF_COOLDOWN_TICKS = 60;
   private static final int BACKOFF_CRITICAL_COOLDOWN_TICKS = 10;
   private static int backoffElapsedTicks;
   private static volatile long pressureSteps;
   private static volatile long sessionClamps;
   private static volatile boolean rangeWidenedNow;
   private static volatile long rejoinHints;
   private static Object hintedSnapshot;
   private static boolean ladderWidened;
   private static boolean masterSwitchWas = true;
   private static Boolean greedyMeshingWas;
   private static boolean pendingReencode;
   private static boolean pressureChatted;
   private static boolean arenaShapeReported;
   private static int switchClampedFrom;
   private static int switchClampedTo;

   private NvidiumPlusExtendedRd() {
   }

   public static void init() {
   }

   public static boolean rangeWidened() {
      return rangeWidenedNow;
   }

   public static long sessionClamps() {
      return sessionClamps;
   }

   public static int vanillaMaxRenderDistance() {
      return captured ? vanillaMax : 32;
   }

   public static long rejoinHints() {
      return rejoinHints;
   }

   public static void widenAtConstruction(Options var0) {
   }

   private static void widenChunkTaskLadder(int extraChunks) {
      if (!ladderWidened) {
         ladderWidened = true;
         int base = ChunkTaskPriorityQueueAccessor.nvidiumplus$priorityLevelCount();
         ChunkTaskPriorityQueueAccessor.nvidiumplus$setPriorityLevelCount(base + extraChunks);
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus widened the chunk-task priority ladder: {} -> {} rungs (+{} chunks of unconditional headroom for the {}-chunk ceiling; wave 13)",
               new Object[]{base, base + extraChunks, extraChunks, 120}
            );
      }
   }

   public static int chunkTaskLadderRungs() {
      return ChunkTaskPriorityQueueAccessor.nvidiumplus$priorityLevelCount();
   }

   public static void evaluateNow(Minecraft var0) {
   }

   public static void onConfigChanged(Minecraft var0) {
   }

   public static void onWorldPinned() {
      hintedSnapshot = null;
      pressureChatted = false;
      arenaShapeReported = false;
      masterSwitchWas = NvidiumPlusConfig.terrainRenderingConfigured();
      greedyMeshingWas = NvidiumPlusConfig.greedyMeshingEnabled();
      pendingReencode = false;
   }

   private static void onEndTick(Minecraft var0) {
      driveVanillaUploadSeamRecovery(var0);
   }

   private static void maybeGrowOrHint(Minecraft minecraft, int rd) {
      if (minecraft.level != null) {
         NvidiumPlusScaling.Snapshot pinned = NvidiumPlusScaling.pinned();
         if (pinned != null && rd > pinned.maxRd()) {
            if (!TerrainResidency.pinnedGrowFailedThisWorld()) {
               TerrainResidency.requestPinnedGrow(rd);
            } else if (pinned != hintedSnapshot) {
               hintedSnapshot = pinned;
               rejoinHints++;
               NvidiumPlusLog.LOGGER
                  .warn(
                     "NvidiumPlus: render distance {} exceeds this world's pinned GPU budget ({} chunks) and the live grow FAILED (GPU allocation refused) — drawing continues at pinned capacity; rejoin the world to apply the full distance (wave-15: the hint is the grow path's fallback)",
                     rd,
                     pinned.maxRd()
                  );
               NvidiumPlusNotify.error(
                  REJOIN_TOAST_ID,
                  Component.translatable("nvidiumplus.rd.rejoin.title"),
                  Component.translatable("nvidiumplus.rd.rejoin.body", new Object[]{rd, pinned.maxRd()})
               );
            }
         }
      }
   }

   private static boolean drawerHealthy(Minecraft minecraft) {
      return TerrainDrawer.lastError() != null ? false : minecraft.level == null || !TerrainDrawer.coveragePassive();
   }

   private static void maybeBackOffForArenaPressure(Minecraft minecraft, Options options, int rd) {
      TerrainResidency.Counters counters = TerrainResidency.counters();
      long ceiling = NvidiumPlusScaling.effectiveCeilingBytes(counters.arenaCapacityBytes());
      if (ceiling > 0L) {
         long used = counters.arenaUsedBytes();
         long pct = used * 100L / ceiling;
         backoffElapsedTicks++;
         int required = pct >= 97L ? 10 : 60;
         if (backoffElapsedTicks >= required) {
            if (pct >= 92L && rd > vanillaMax) {
               int target = Math.max(vanillaMax, rd - 8);
               backoffElapsedTicks = 0;
               pressureSteps++;
               options.renderDistance().set(target);
               options.save();
               showRenderDistanceChange(minecraft, target);
               NvidiumPlusLog.LOGGER
                  .info(
                     "NvidiumPlus lowered the render distance {} -> {}: terrain memory is at {}% of the {} MiB ceiling. The far chunks are released through vanilla's own path. This does not go back up on its own - raise it in Video Settings when you want it back",
                     new Object[]{rd, target, pct, ceiling >> 20}
                  );
               reportArenaShapeOnce(counters, ceiling);
            }
         }
      }
   }

   private static void reportArenaShapeOnce(TerrainResidency.Counters counters, long ceiling) {
      if (!arenaShapeReported) {
         arenaShapeReported = true;
         long holes = Math.max(0L, counters.arenaExtentBytes() - counters.arenaUsedBytes());
         long tail = Math.max(0L, counters.arenaCapacityBytes() - counters.arenaExtentBytes());
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus arena shape at pressure: live {} MiB, holes {} MiB, unused tail {} MiB, committed {} MiB of a {} MiB effective ceiling, across {} block(s) of which {} at the top are completely empty. Holes are what compaction could recover and it would cost copies; the empty top blocks could go back to the driver for free. Neither is acted on yet: this line exists to decide which is worth building",
               new Object[]{
                  counters.arenaUsedBytes() >> 20,
                  holes >> 20,
                  tail >> 20,
                  counters.arenaCapacityBytes() >> 20,
                  ceiling >> 20,
                  counters.arenaBlocks(),
                  counters.emptyTopBlocks()
               }
            );
      }
   }

   private static void driveVanillaUploadSeamRecovery(Minecraft minecraft) {
      if (minecraft.level != null && minecraft.levelRenderer != null) {
         boolean nowEnabled = NvidiumPlusConfig.terrainRenderingConfigured();
         if (nowEnabled != masterSwitchWas) {
            masterSwitchWas = nowEnabled;
            if (nowEnabled) {
               VanillaUploadSeam.onTerrainRenderingEnabled();
               VanillaUploadSeam.requestVanillaRebuild("NvidiumPlus terrain rendering switched on");
            } else {
               VanillaUploadSeam.demote("terrain rendering turned off");
               VanillaUploadSeam.requestVanillaRebuild("NvidiumPlus terrain rendering switched off");
            }
         }

         boolean greedyNow = NvidiumPlusConfig.greedyMeshingEnabled();
         if (greedyMeshingWas == null) {
            greedyMeshingWas = greedyNow;
         } else if (greedyNow != greedyMeshingWas) {
            greedyMeshingWas = greedyNow;
            if (nowEnabled && NvidiumPlusGate.state() == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
               pendingReencode = true;
               NvidiumPlusLog.LOGGER.info("NvidiumPlus greedy meshing switched {}; re-encoding the loaded terrain", greedyNow ? "on" : "off");
            }
         }

         boolean seamRebuild = VanillaUploadSeam.consumeRebuildRequest();
         if (seamRebuild || pendingReencode) {
            try {
               minecraft.levelExtractor.allChanged();
               pendingReencode = false;
               if (seamRebuild) {
                  if (VanillaUploadSeam.armed()) {
                     NvidiumPlusLog.LOGGER
                        .info(
                           "NvidiumPlus dropped vanilla's terrain sections to empty its heaps; vanilla terrain memory was {} MiB and should fall to near zero over the next few seconds",
                           VanillaTerrainCensus.committedBytes() >> 20
                        );
                  } else {
                     NvidiumPlusLog.LOGGER
                        .info(
                           "NvidiumPlus asked vanilla to rebuild its terrain after the upload seam stood down; NvidiumPlus keeps drawing until it looks complete"
                        );
                  }
               }
            } catch (Throwable t) {
               if (seamRebuild) {
                  VanillaUploadSeam.reinstateRebuildRequest();
               }

               NvidiumPlusLog.LOGGER.error("NvidiumPlus could not ask vanilla to rebuild; retrying next tick", t);
               return;
            }
         }

         VanillaUploadSeam.noteRebuildProgress(minecraft.levelRenderer.hasRenderedAllSections());
      }
   }

   private static void showRenderDistanceChange(Minecraft minecraft, int target) {
      if (minecraft.gui != null) {
         if (pressureChatted) {
            SystemToast.add(
               minecraft.gui.toastManager(),
               TOAST_ID,
               Component.translatable("nvidiumplus.rd.pressure.title", new Object[]{target}),
               Component.translatable("nvidiumplus.rd.pressure.body")
            );
         } else {
            pressureChatted = true;
            NvidiumPlusNotify.error(
               TOAST_ID, Component.translatable("nvidiumplus.rd.pressure.title", new Object[]{target}), Component.translatable("nvidiumplus.rd.pressure.body")
            );
         }

         Screen screen = minecraft.gui.screen();
         if (screen instanceof OptionsSubScreen && minecraft.getWindow() != null) {
            screen.resize(minecraft.getWindow().getGuiScaledWidth(), minecraft.getWindow().getGuiScaledHeight());
         }
      }
   }

   public static long pressureSteps() {
      return pressureSteps;
   }

   private static void clampBack(Minecraft minecraft, Options options, NvidiumPlusGate.State state, boolean extendedWanted) {
      int target = vanillaMax;
      int before = (Integer)options.renderDistance().get();
      boolean guardPassive = false;
      if (state == NvidiumPlusGate.State.VULKAN_MESH_SHADERS) {
         guardPassive = extendedWanted && minecraft.level != null && TerrainDrawer.coveragePassive();
      }

      boolean switchIsTheReason = state == NvidiumPlusGate.State.VULKAN_MESH_SHADERS && !guardPassive && !NvidiumPlusConfig.terrainRenderingConfigured();
      if (switchIsTheReason && before > target) {
         switchClampedFrom = before;
         switchClampedTo = target;
      }

      options.renderDistance().set(target);
      options.save();
      sessionClamps++;
      if (clampNoticeArmed) {
         clampNoticeArmed = false;
         String bodyKey = guardPassive ? "nvidiumplus.rd.clamped.passive" : "nvidiumplus.rd.clamped.off";
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus clamped the render distance back to {} (gate={}, terrainEnabled={}, configuredMax={}, guardPassive={}) — the extended range only takes effect while NvidiumPlus draws (wave-10 clamp-back invariant)",
               new Object[]{target, state, NvidiumPlusConfig.terrainRenderingEnabled(), NvidiumPlusConfig.maxRenderDistanceConfigured(), guardPassive}
            );
         NvidiumPlusNotify.error(TOAST_ID, Component.translatable("nvidiumplus.rd.clamped.title", new Object[]{target}), Component.translatable(bodyKey));
      }
   }

   private static void applyRange(Options options, int newMax) {
      if (captured && newMax != appliedMax) {
         OptionInstance<Integer> rd = options.renderDistance();
         OptionInstanceAccessor accessor = (OptionInstanceAccessor)rd;
         if (newMax <= vanillaMax) {
            accessor.nvidiumplus$setValues(vanillaValues);
            accessor.nvidiumplus$setCodec(vanillaCodec);
            appliedMax = vanillaMax;
            rangeWidenedNow = false;
         } else {
            accessor.nvidiumplus$setValues(new IntRange(vanillaMin, newMax, false));
            accessor.nvidiumplus$setCodec(Codec.intRange(vanillaMin, newMax + 1));
            appliedMax = newMax;
            rangeWidenedNow = true;
         }
      }
   }

   public static int serverViewDistanceCap() {
      return 32;
   }
}
