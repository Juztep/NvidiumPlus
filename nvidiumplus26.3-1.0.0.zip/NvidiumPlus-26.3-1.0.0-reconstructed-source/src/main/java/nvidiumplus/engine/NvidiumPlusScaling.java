package nvidiumplus.engine;

import nvidiumplus.engine.farfield.FarFieldConfig;

public final class NvidiumPlusScaling {
   public static final int STANDARD_MAX_REGIONS = 2048;
   public static final int STANDARD_DISPATCH_CAPACITY = 512;
   public static final long STANDARD_ARENA_BYTES = 268435456L;
   public static final long ARENA_BLOCK_PREFERRED_BYTES = 536870912L;
   public static final int ARENA_MAX_BLOCKS = 16;
   private static final int TASK_NON_ARENA_BINDINGS = 11;
   private static final int MESH_STAGE_OTHER_STORAGE = 2;
   private static final int TASK_SET_OTHER_STORAGE = 5;
   public static final int ARENA_CEILING_HEAP_PCT = 50;
   public static final long ARENA_CEILING_FLOOR_BYTES = 268435456L;
   public static final long ARENA_CEILING_FALLBACK_BYTES = 1073741824L;
   private static final NvidiumPlusScaling.Snapshot STANDARD = new NvidiumPlusScaling.Snapshot(32, false, 2048, 512, 268435456L);
   private static volatile NvidiumPlusScaling.Snapshot current;
   private static final int FAR_REGION_Y_ROWS_DEFAULT = 3;
   private static final int FAR_REGION_ROW_COST_KIB = 10;
   private static final int FAR_GUARD_PCT = 85;
   private static final int FAR_REGION_CAP = 4096;

   public static long arenaBlockBytes() {
      long forcedMiB = Long.getLong("nvidiumplus.tune.arenaBlockMiB", 0L);
      if (forcedMiB > 0L) {
         long forced = forcedMiB << 20;
         return Math.max(64L, Long.highestOneBit(forced));
      }

      NvidiumPlusVulkanState.ArenaLimits limits = NvidiumPlusVulkanState.arenaLimits();
      long cap = 536870912L;
      if (limits.maxStorageBufferRange() > 0L) {
         cap = Math.min(cap, limits.maxStorageBufferRange());
      }

      if (limits.maxMemoryAllocationSize() > 0L) {
         cap = Math.min(cap, limits.maxMemoryAllocationSize());
      }

      long block = Long.highestOneBit(cap);
      return Math.max(64L, block);
   }

   public static int arenaBlockCount() {
      long forced = Long.getLong("nvidiumplus.tune.arenaBlocks", 0L);
      if (forced > 0L) {
         return (int)Math.min(16L, forced);
      }

      long block = arenaBlockBytes();
      if (block <= 0L) {
         return 1;
      }

      long ceiling = defaultPolicyCeilingBytes();
      int n = (int)Math.min(16L, (ceiling + block - 1L) / block);
      NvidiumPlusVulkanState.ArenaLimits limits = NvidiumPlusVulkanState.arenaLimits();
      long capped = n;
      if (limits.maxPushDescriptors() > 0L) {
         capped = Math.min(capped, limits.maxPushDescriptors() - 11L);
      }

      if (limits.maxPerStageDescriptorStorageBuffers() > 0L) {
         capped = Math.min(capped, limits.maxPerStageDescriptorStorageBuffers() - 2L);
      }

      if (limits.maxDescriptorSetStorageBuffers() > 0L) {
         capped = Math.min(capped, limits.maxDescriptorSetStorageBuffers() - 5L);
      }

      return (int)Math.max(1L, capped);
   }

   private static long defaultPolicyCeilingBytes() {
      long heap = NvidiumPlusVulkanState.deviceLocalHeapBytes();
      if (heap <= 0L) {
         return 1073741824L;
      }

      long fraction = heap / 100L * 50L >> 20 << 20;
      return Math.max(268435456L, fraction);
   }

   public static long arenaCeilingBytes() {
      long testMiB = Long.getLong("nvidiumplus.test.arenaMiB", 0L);
      if (testMiB > 0L) {
         return clampToAddressable(testMiB << 20);
      }

      long overrideMiB = Long.getLong("nvidiumplus.tune.arenaCeilingMiB", 0L);
      if (overrideMiB > 0L) {
         return clampToAddressable(overrideMiB << 20);
      }

      long heap = NvidiumPlusVulkanState.deviceLocalHeapBytes();
      if (heap <= 0L) {
         return capToBlocks(1073741824L);
      }

      long fraction = heap / 100L * 50L >> 20 << 20;
      return capToBlocks(Math.max(268435456L, fraction));
   }

   public static long effectiveCeilingBytes(long currentCapacityBytes) {
      long staticCeiling = arenaCeilingBytes();
      long headroom = NvidiumPlusVramState.sustainedHeadroomBytes();
      if (headroom == Long.MAX_VALUE) {
         return staticCeiling;
      }

      long block = arenaBlockBytes();
      long reachable = currentCapacityBytes;
      if (currentCapacityBytes < block) {
         reachable += headroom;
      } else if (block > 0L) {
         reachable += headroom / block * block;
      }

      return Math.max(currentCapacityBytes, Math.min(staticCeiling, reachable));
   }

   private static long capToBlocks(long bytes) {
      long block = arenaBlockBytes();
      int blocks = arenaBlockCount();
      if (block > 0L && blocks > 0) {
         long total = block * blocks;
         return Math.max(Math.min(268435456L, total), Math.min(bytes, total));
      } else {
         return addressable(bytes);
      }
   }

   private static long addressable(long bytes) {
      return addressableFor(bytes, NvidiumPlusVulkanState.maxStorageBufferRangeBytes());
   }

   private static long clampToAddressable(long bytes) {
      return clampToAddressableFor(bytes, NvidiumPlusVulkanState.maxStorageBufferRangeBytes());
   }

   public static long clampToAddressableFor(long bytes, long limit) {
      if (limit <= 0L) {
         return bytes;
      }

      long limitAligned = limit >> 20 << 20;
      return limitAligned <= 0L ? Math.min(bytes, limit) : Math.min(bytes, limitAligned);
   }

   public static long addressableFor(long bytes, long limit) {
      if (limit <= 0L) {
         return bytes;
      }

      long limitAligned = limit >> 20 << 20;
      return limitAligned <= 0L ? limit : Math.max(Math.min(268435456L, limitAligned), Math.min(bytes, limitAligned));
   }

   public static long arenaInitialBytes() {
      long ceiling = arenaCeilingBytes();
      long testMiB = Long.getLong("nvidiumplus.test.arenaMiB", 0L);
      if (testMiB > 0L) {
         return testMiB << 20;
      }

      long initialMiB = Long.getLong("nvidiumplus.tune.arenaInitialMiB", 0L);
      long initial = initialMiB > 0L ? initialMiB << 20 : current().arenaBytes();
      return Math.min(initial, ceiling);
   }

   private NvidiumPlusScaling() {
   }

   public static NvidiumPlusScaling.Snapshot current() {
      NvidiumPlusScaling.Snapshot pinned = current;
      return pinned != null ? pinned : STANDARD;
   }

   public static NvidiumPlusScaling.Snapshot pinned() {
      return current;
   }

   public static NvidiumPlusScaling.Snapshot pinForWorld(int optionRd) {
      NvidiumPlusScaling.Snapshot snapshot = compute(pinnedRd(optionRd));
      current = snapshot;
      if (snapshot.extended()) {
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus extended render distance pinned for this world: option {} chunks -> pinned {} (next-8 headroom, ceiling {}) -> maxRegions={} ({} MiB section records), dispatchCapacity={} (SSBO frame lists), arena starts at {} MiB and grows on demand to the {} MiB device ceiling (wave 14; raising the slider past the pinned budget mid-world grows the records live, wave 15)",
               new Object[]{
                  optionRd,
                  snapshot.maxRd(),
                  NvidiumPlusConfig.maxRenderDistanceConfigured(),
                  snapshot.maxRegions(),
                  snapshot.maxRegions() * 8192L >> 20,
                  snapshot.dispatchCapacity(),
                  snapshot.arenaBytes() >> 20,
                  arenaCeilingBytes() >> 20
               }
            );
      } else if (snapshot.maxRegions() > 2048) {
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus scaling pinned for this world: option {} chunks -> the standard wave-<=9 near sizes with a FAR-FIELD region budget of {} ids ({} MiB section records, {} MiB more than the standard 2048) because the LOD ring spans more region columns than the render distance does (pre13); {} dispatch slots, arena starts at 256 MiB and grows on demand to the {} MiB device ceiling",
               new Object[]{
                  optionRd,
                  snapshot.maxRegions(),
                  snapshot.maxRegions() * 8192L >> 20,
                  (snapshot.maxRegions() - 2048) * 10L * 1024L >> 20,
                  snapshot.dispatchCapacity(),
                  arenaCeilingBytes() >> 20
               }
            );
      } else {
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus scaling pinned for this world: option {} chunks -> the standard wave-<=9 sizes (2048 regions, 512 dispatch slots, arena starts at 256 MiB and grows on demand to the {} MiB device ceiling — wave 14; extended record sizing pins only when the option exceeds 32 at world standup)",
               optionRd,
               arenaCeilingBytes() >> 20
            );
      }

      return snapshot;
   }

   public static NvidiumPlusScaling.Snapshot computeForOption(int optionRd) {
      return compute(pinnedRd(optionRd));
   }

   public static void growPinned(NvidiumPlusScaling.Snapshot grown) {
      current = grown;
      NvidiumPlusLog.LOGGER
         .info(
            "NvidiumPlus scaling grown mid-world: pinned {} chunks -> maxRegions={} ({} MiB section records), dispatchCapacity={} (live render-distance raise, wave 15; no rejoin needed)",
            new Object[]{grown.maxRd(), grown.maxRegions(), grown.maxRegions() * 8192L >> 20, grown.dispatchCapacity()}
         );
   }

   static int pinnedRd(int var0) {
      return var0 <= 32 ? 32 : (var0 / 8 + 1) * 8;
   }

   private static NvidiumPlusScaling.Snapshot compute(int pinnedRd) {
      int far = farRegionDemand();
      if (pinnedRd <= 32) {
         return far <= 2048 ? STANDARD : new NvidiumPlusScaling.Snapshot(32, false, far, 512, 268435456L);
      }

      int maxRegions = Math.max(2048, roundUp(2 * regionsTouched(pinnedRd), 256));
      maxRegions = Math.max(maxRegions, far);
      return new NvidiumPlusScaling.Snapshot(pinnedRd, true, maxRegions, maxRegions, 268435456L);
   }

   static int regionsTouched(int rd) {
      int chunks = 2 * rd + 1;
      int horizontal = (chunks + 7) / 8 + 1;
      return horizontal * horizontal * 7;
   }

   public static int farRegionDemand() {
      int l1;
      try {
         if (!FarFieldConfig.enabled()) {
            return 0;
         }

         l1 = FarFieldConfig.l1RadiusChunks();
      } catch (Throwable t) {
         return 0;
      }

      if (l1 <= 32) {
         return 0;
      }

      int rows = Integer.getInteger("nvidiumplus.tune.farRegionYRows", 3);
      rows = Math.max(1, Math.min(7, rows));
      int chunks = 2 * l1 + 1;
      int square = (chunks + 7) / 8 + 1;
      long columns = ((long)square * square * 79L + 99L) / 100L;
      long far = columns * rows;
      long near = regionsTouched(32);
      long budget = Math.max((far + near) * 100L / 85L, far + 2L * near);
      int cap = Integer.getInteger("nvidiumplus.tune.farRegionCap", 4096);
      return Math.min(Math.max(256, cap), roundUp((int)Math.min(budget, 1048576L), 256));
   }

   private static int roundUp(int value, int multiple) {
      return (value + multiple - 1) / multiple * multiple;
   }

   public record Snapshot(int maxRd, boolean extended, int maxRegions, int dispatchCapacity, long arenaBytes) {
   }
}
