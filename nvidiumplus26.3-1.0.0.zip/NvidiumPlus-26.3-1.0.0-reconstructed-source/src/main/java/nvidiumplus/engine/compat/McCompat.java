package nvidiumplus.engine.compat;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.vulkan.init.VulkanPNextStruct;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.geometry.BakedQuad.MaterialInfo;
import net.minecraft.core.Direction;

public final class McCompat {
   private McCompat() {
   }

   public static VulkanPNextStruct pnextStruct(Class<?> structClass, int sType, int structSize) {
      return new VulkanPNextStruct(structClass, sType, structSize);
   }

   public static RenderTarget opaqueTarget() {
      return Minecraft.getInstance().gameRenderer.mainRenderTarget();
   }

   public static RenderTarget translucentTarget() {
      return Minecraft.getInstance().gameRenderer.mainRenderTarget();
   }

   public static GpuTextureView blockAtlasView() {
      return Minecraft.getInstance().getTextureManager().getTexture(TextureAtlas.LOCATION_BLOCKS).getTextureView();
   }

   public static ChunkSectionsToRender emptySectionsToRender(GpuTextureView atlasView) {
      return null;
   }

   public static boolean quadShaded(MaterialInfo info, Direction quadFace) {
      Direction override = info.shadeDirectionOverride();
      return override == null || override == quadFace;
   }
}
