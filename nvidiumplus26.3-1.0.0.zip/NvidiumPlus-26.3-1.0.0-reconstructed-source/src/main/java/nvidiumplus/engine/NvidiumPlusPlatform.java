package nvidiumplus.engine;

import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;

public final class NvidiumPlusPlatform {
   private static volatile NvidiumPlusPlatform.Services services;

   private NvidiumPlusPlatform() {
   }

   public static void install(NvidiumPlusPlatform.Services impl) {
      if (impl == null) {
         throw new IllegalArgumentException("NvidiumPlus platform services must not be null");
      }

      if (services != null) {
         throw new IllegalStateException(
            "NvidiumPlus platform services were already installed by "
               + services.getClass().getName()
               + "; a second install from "
               + impl.getClass().getName()
               + " means two entrypoints ran"
         );
      }

      services = impl;
   }

   public static Path gameDir() {
      return require().gameDir();
   }

   public static Path configDir() {
      return require().configDir();
   }

   public static void onEndClientTick(Consumer<Minecraft> callback) {
      require().onEndClientTick(callback);
   }

   public static boolean isDevelopment() {
      return require().isDevelopment();
   }

   public static boolean isModLoaded(String modId) {
      try {
         return require().isModLoaded(modId);
      } catch (Throwable t) {
         NvidiumPlusLog.LOGGER
            .warn(
               "NvidiumPlus could not ask the loader whether '{}' is installed; assuming it is not. If terrain is missing and another rendering mod is present, this is the first thing to suspect.",
               modId,
               t
            );
         return false;
      }
   }

   public static boolean sodiumAdapterAvailable() {
      try {
         return require().sodiumAdapterAvailable();
      } catch (Throwable t) {
         return false;
      }
   }

   public static Optional<String> modVersion(String modId) {
      try {
         return require().modVersion(modId);
      } catch (Throwable t) {
         return Optional.empty();
      }
   }

   private static NvidiumPlusPlatform.Services require() {
      NvidiumPlusPlatform.Services s = services;
      if (s == null) {
         throw new IllegalStateException(
            "NvidiumPlus asked its loader for a service before the loader installed one. NvidiumPlusPlatform.install(...) must be the first thing the entrypoint does, and something is running earlier than the entrypoint - most likely a mixin that touches config while vanilla is still constructing Options."
         );
      } else {
         return s;
      }
   }

   public interface Services {
      Path gameDir();

      Path configDir();

      void onEndClientTick(Consumer<Minecraft> var1);

      boolean isDevelopment();

      boolean isModLoaded(String var1);

      boolean sodiumAdapterAvailable();

      Optional<String> modVersion(String var1);
   }
}
