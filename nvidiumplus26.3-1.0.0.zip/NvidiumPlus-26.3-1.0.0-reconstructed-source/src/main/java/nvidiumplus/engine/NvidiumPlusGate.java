package nvidiumplus.engine;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.device.DeviceInfo;
import com.mojang.renderpearl.api.device.GpuDevice;
import net.minecraft.client.Minecraft;
import net.minecraft.client.PreferredGraphicsApi;
import net.minecraft.client.gui.components.toasts.SystemToast;
import net.minecraft.client.gui.components.toasts.SystemToast.SystemToastId;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;
import nvidiumplus.engine.gui.NvidiumPlusPopupScreen;

public final class NvidiumPlusGate {
   public static final String SODIUM_MOD_ID = "sodium";
   public static final String SODIUM_ADAPTER_PROPERTY = "nvidiumplus.sodium.adapter";
   private static volatile NvidiumPlusGate.State state = NvidiumPlusGate.State.UNKNOWN;
   private static volatile NvidiumPlusGate.State backendDecided = NvidiumPlusGate.State.UNKNOWN;
   private static boolean popupOwed;
   private static int inWorldSettleTicks;
   private static boolean inWorldNoticeShown;
   private static final SystemToastId POPUP_TOAST_ID = new SystemToastId();
   public static final int IN_WORLD_SETTLE_TICKS = 20;

   public static boolean sodiumAdapterConfigured() {
      return NvidiumPlusPlatform.sodiumAdapterAvailable() && !"false".equalsIgnoreCase(System.getProperty("nvidiumplus.sodium.adapter"));
   }

   public static boolean sodiumAdapterArmed() {
      return state == NvidiumPlusGate.State.SODIUM_PRESENT && backendDecided == NvidiumPlusGate.State.VULKAN_MESH_SHADERS && sodiumAdapterConfigured();
   }

   public static NvidiumPlusGate.State backend() {
      return backendDecided;
   }

   private NvidiumPlusGate() {
   }

   public static NvidiumPlusGate.State state() {
      return state;
   }

   public static void init() {
      NvidiumPlusPlatform.onEndClientTick(NvidiumPlusGate::onEndTick);
   }

   private static void onEndTick(Minecraft minecraft) {
      if (state != NvidiumPlusGate.State.UNKNOWN) {
         tryShowOwedPopup(minecraft);
      } else if (minecraft.gui.overlay() == null) {
         GpuDevice device = RenderSystem.tryGetDevice();
         if (device != null) {
            DeviceInfo info = device.getDeviceInfo();
            boolean vulkan = "Vulkan".equals(info.backendName());
            NvidiumPlusGate.State decided;
            if (vulkan) {
               decided = NvidiumPlusVulkanState.meshShadersRequested()
                  ? NvidiumPlusGate.State.VULKAN_MESH_SHADERS
                  : NvidiumPlusGate.State.VULKAN_NO_MESH_SHADERS;
            } else {
               decided = NvidiumPlusGate.State.OPENGL;
            }

            backendDecided = decided;
            if (NvidiumPlusPlatform.isModLoaded("sodium")) {
               state = NvidiumPlusGate.State.SODIUM_PRESENT;
               String installedSodium = NvidiumPlusPlatform.modVersion("sodium").orElse(null);
               String sodiumForLog = installedSodium != null ? installedSodium : "not reported";
               if (sodiumAdapterArmed()) {
                  NvidiumPlusLog.LOGGER
                     .info(
                        "Backend gate: SODIUM_PRESENT — Sodium is installed, so NvidiumPlus's own chunk tap and terrain draw stand down and Sodium builds the chunks. NvidiumPlus then draws Sodium's opaque terrain with mesh shaders, reading it out of Sodium's own buffers. -D{}=false turns that off and leaves Sodium to draw it all. (backend={}, device='{}', driver={}, sodium={}, built against {})",
                        new Object[]{
                           "nvidiumplus.sodium.adapter",
                           info.backendName(),
                           info.name(),
                           info.driverInfo(),
                           sodiumForLog,
                           NvidiumPlusSodiumVersion.BUILT_AGAINST
                        }
                     );
               } else if (!NvidiumPlusPlatform.sodiumAdapterAvailable()) {
                  NvidiumPlusLog.LOGGER
                     .warn(
                        "Backend gate: SODIUM_PRESENT — Sodium is installed and this loader's build of NvidiumPlus has no adapter for it, so Sodium is drawing the terrain on its own and NvidiumPlus is doing nothing to it on any backend. The render-distance range above 32 still applies. (backend={}, device='{}', driver={}, sodium={}, built against {})",
                        new Object[]{info.backendName(), info.name(), info.driverInfo(), sodiumForLog, NvidiumPlusSodiumVersion.BUILT_AGAINST}
                     );
               } else {
                  NvidiumPlusLog.LOGGER
                     .warn(
                        "Backend gate: SODIUM_PRESENT — the Vulkan Sodium adapter is not running on OpenGL, so this adapter leaves terrain rendering to Sodium. The separate native OpenGL renderer has its own NVIDIA mesh-shader requirements. The adapter can be disabled with -D{}=false. (backend={}, device='{}', driver={}, {}={}, sodium={}, built against {})",
                        new Object[]{
                           "nvidiumplus.sodium.adapter",
                           info.backendName(),
                           info.name(),
                           info.driverInfo(),
                           "nvidiumplus.sodium.adapter",
                           System.getProperty("nvidiumplus.sodium.adapter"),
                           sodiumForLog,
                           NvidiumPlusSodiumVersion.BUILT_AGAINST
                        }
                     );
               }

               if (installedSodium != null && !NvidiumPlusSodiumVersion.matches(installedSodium)) {
                  NvidiumPlusLog.LOGGER
                     .warn(
                        "NvidiumPlus's Sodium adapter was written against Sodium {} and this game is running Sodium {}. NvidiumPlus's draw hooks are optional and every error inside the draw hands the pass straight back to Sodium, but whether a MOVED hook fails to APPLY rather than degrade has not been verified on this Mixin version. If terrain looks wrong, this is the first thing to suspect: put Sodium {} back, or start with -D{}=false to leave Sodium to draw it all.",
                        new Object[]{
                           NvidiumPlusSodiumVersion.BUILT_AGAINST, installedSodium, NvidiumPlusSodiumVersion.BUILT_AGAINST, "nvidiumplus.sodium.adapter"
                        }
                     );
               }
            } else {
               state = decided;
               NvidiumPlusLog.LOGGER
                  .info("Backend gate: {} (backend={}, device='{}', driver={})", new Object[]{decided, info.backendName(), info.name(), info.driverInfo()});
            }

            NvidiumPlusExtendedRd.evaluateNow(minecraft);
            popupOwed = decided == NvidiumPlusGate.State.OPENGL || decided == NvidiumPlusGate.State.VULKAN_NO_MESH_SHADERS;
            inWorldSettleTicks = 0;
            tryShowOwedPopup(minecraft);
         }
      }
   }

   private static void tryShowOwedPopup(Minecraft minecraft) {
      if (popupOwed) {
         if (minecraft.gui.screen() instanceof TitleScreen) {
            popupOwed = false;
            inWorldSettleTicks = 0;
            showPopupIfNeeded(minecraft, backendDecided, NvidiumPlusGate.Presentation.TITLE);
         } else if (minecraft.gui.canInterruptScreen()
            && minecraft.gui.overlay() == null
            && minecraft.gui.screen() == null
            && minecraft.level != null
            && minecraft.player != null
            && !minecraft.player.isDeadOrDying()
            && minecraft.player.hurtTime == 0) {
            if (++inWorldSettleTicks >= 20) {
               inWorldSettleTicks = 0;
               if (popupWouldPauseThisWorld(minecraft)) {
                  popupOwed = false;
                  showPopupIfNeeded(minecraft, backendDecided, NvidiumPlusGate.Presentation.IN_WORLD);
               } else {
                  if (!inWorldNoticeShown) {
                     inWorldNoticeShown = true;
                     popupOwed = showPopupIfNeeded(minecraft, backendDecided, NvidiumPlusGate.Presentation.NO_SCREEN);
                  }
               }
            }
         } else {
            inWorldSettleTicks = 0;
         }
      }
   }

   private static boolean popupWouldPauseThisWorld(Minecraft minecraft) {
      IntegratedServer server = minecraft.getSingleplayerServer();
      return minecraft.hasSingleplayerServer() && server != null && !server.isPublished();
   }

   public static boolean popupOwed() {
      return popupOwed;
   }

   public static boolean inWorldNoticeShown() {
      return inWorldNoticeShown;
   }

   public static boolean testPopupWouldPauseThisWorld(Minecraft minecraft) {
      return popupWouldPauseThisWorld(minecraft);
   }

   public static void testRearmPopup() {
      popupOwed = true;
      inWorldSettleTicks = 0;
      inWorldNoticeShown = false;
   }

   private static boolean present(Minecraft minecraft, NvidiumPlusPopupScreen.Variant variant, Screen parent, NvidiumPlusGate.Presentation how) {
      if (how == NvidiumPlusGate.Presentation.NO_SCREEN) {
         try {
            SystemToast.add(
               minecraft.gui.toastManager(),
               POPUP_TOAST_ID,
               Component.translatable("nvidiumplus.toast.popup.title"),
               Component.translatable(toastBodyKeyFor(variant))
            );
         } catch (Throwable t) {
            NvidiumPlusLog.LOGGER.debug("NvidiumPlus could not raise the backend toast", t);
         }

         NvidiumPlusNotify.chat(chatKeyFor(variant));
         return variant == NvidiumPlusPopupScreen.Variant.ENABLE_VULKAN;
      } else {
         minecraft.gui.setScreen(new NvidiumPlusPopupScreen(variant, parent));
         if (how == NvidiumPlusGate.Presentation.IN_WORLD) {
            NvidiumPlusNotify.chat(chatKeyFor(variant));
         }

         return false;
      }
   }

   private static String chatKeyFor(NvidiumPlusPopupScreen.Variant variant) {
      boolean sodium = NvidiumPlusPlatform.isModLoaded("sodium");
      boolean adapter = sodium && sodiumAdapterConfigured();

      return switch (variant) {
         case ENABLE_VULKAN -> adapter
            ? "nvidiumplus.chat.popup.opengl.sodium"
            : (sodium ? "nvidiumplus.chat.popup.opengl.sodium_no_adapter" : "nvidiumplus.chat.popup.opengl");
         case VULKAN_FAILED -> sodium ? "nvidiumplus.chat.popup.vulkan_failed.sodium" : "nvidiumplus.chat.popup.vulkan_failed";
         case NO_MESH_SHADERS -> sodium ? "nvidiumplus.chat.popup.no_mesh.sodium" : "nvidiumplus.chat.popup.no_mesh";
         case RESTART_REQUIRED -> throw new AssertionError("RESTART_REQUIRED is never presented by the gate");
      };
   }

   private static String toastBodyKeyFor(NvidiumPlusPopupScreen.Variant variant) {
      return switch (variant) {
         case ENABLE_VULKAN -> "nvidiumplus.toast.popup.opengl";
         case VULKAN_FAILED -> "nvidiumplus.toast.popup.vulkan_failed";
         case NO_MESH_SHADERS -> "nvidiumplus.toast.popup.no_mesh";
         case RESTART_REQUIRED -> throw new AssertionError("RESTART_REQUIRED is never presented by the gate");
      };
   }

   private static boolean showPopupIfNeeded(Minecraft minecraft, NvidiumPlusGate.State decided, NvidiumPlusGate.Presentation how) {
      NvidiumPlusConfig config = NvidiumPlusConfig.get();
      Screen parent = minecraft.gui.screen();
      switch (decided) {
         case OPENGL:
            boolean vulkanWasRequested = minecraft.options.preferredGraphicsBackend().get() == PreferredGraphicsApi.VULKAN;
            if (vulkanWasRequested) {
               if (!config.vulkanFailedNoticeShown) {
                  config.vulkanFailedNoticeShown = true;
                  config.save();
                  return present(minecraft, NvidiumPlusPopupScreen.Variant.VULKAN_FAILED, parent, how);
               }
            } else if (config.showVulkanPrompt) {
               return present(minecraft, NvidiumPlusPopupScreen.Variant.ENABLE_VULKAN, parent, how);
            }
            break;
         case VULKAN_NO_MESH_SHADERS:
            if (!NvidiumPlusVulkanState.vulkanDeviceCreationSeen()) {
               NvidiumPlusLog.LOGGER
                  .error(
                     "NvidiumPlus is off, and this one is NvidiumPlus's fault rather than your hardware's: the Vulkan backend is running but our mesh-shader probe never finished, so we never learned what this device supports. Look for a 'mesh-shader probe failed' error earlier in this log and report it. No popup is shown for this, because the honest message would be an apology rather than advice."
                  );
               return false;
            }

            if (!config.noMeshShaderNoticeShown) {
               config.noMeshShaderNoticeShown = true;
               config.save();
               return present(minecraft, NvidiumPlusPopupScreen.Variant.NO_MESH_SHADERS, parent, how);
            }
      }

      return false;
   }

   private enum Presentation {
      TITLE,
      IN_WORLD,
      NO_SCREEN;
   }

   public enum State {
      UNKNOWN,
      OPENGL,
      VULKAN_NO_MESH_SHADERS,
      VULKAN_MESH_SHADERS,
      SODIUM_PRESENT;
   }
}
