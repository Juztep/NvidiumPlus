package nvidiumplus.engine.sodium;

import java.util.function.Supplier;
import net.caffeinemc.mods.sodium.api.config.option.SteppedValidator;

record NvidiumPlusSodiumRange(int min, int max, int step) implements SteppedValidator {
   NvidiumPlusSodiumRange(int min, int max, int step) {
      if (step > 0 && max >= min) {
         this.min = min;
         this.max = max;
         this.step = step;
      } else {
         throw new IllegalArgumentException("bad range " + min + ".." + max + " step " + step);
      }
   }

   public Integer getValidatedValue(Integer value, Supplier<Integer> fallback) {
      if (value == null) {
         return fallback.get();
      }

      if (this.isValueValid(value)) {
         return value;
      }

      int clamped = Math.clamp(value.intValue(), this.min, this.max);
      int snapped = this.min + Math.round((float)(clamped - this.min) / this.step) * this.step;
      return Math.min(snapped, this.max);
   }
}
