package nvidiumplus.engine.sodium;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import java.util.IdentityHashMap;

final class NvidiumPlusSodiumBufferKeys {
   private final IdentityHashMap<GpuBuffer, int[]> keys = new IdentityHashMap<>();
   private int next;

   int keyOf(GpuBuffer buffer) {
      int[] e = this.keys.get(buffer);
      if (e == null) {
         e = new int[]{++this.next, 0};
         this.keys.put(buffer, e);
      }

      return e[0];
   }

   int peekKey(GpuBuffer buffer) {
      int[] e = this.keys.get(buffer);
      return e == null ? 0 : e[0];
   }

   void retain(GpuBuffer buffer) {
      int[] e = this.keys.get(buffer);
      if (e != null) {
         e[1]++;
      }
   }

   void release(GpuBuffer buffer) {
      int[] e = this.keys.get(buffer);
      if (e != null && --e[1] <= 0) {
         this.keys.remove(buffer);
      }
   }

   int count() {
      return this.keys.size();
   }

   int issued() {
      return this.next;
   }

   void clear() {
      this.keys.clear();
   }
}
