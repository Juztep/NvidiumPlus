package nvidiumplus.engine.sodium;

public interface NvidiumPlusRegionCacheHolder {
   int nvidiumplus$epoch();

   void nvidiumplus$bumpEpoch();

   NvidiumPlusRegionRunCache nvidiumplus$runCache();

   void nvidiumplus$setRunCache(NvidiumPlusRegionRunCache var1);

   int nvidiumplus$mid();

   void nvidiumplus$setMid(int var1);

   boolean nvidiumplus$dirtyQueued();

   void nvidiumplus$setDirtyQueued(boolean var1);
}
