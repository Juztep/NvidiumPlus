package nvidiumplus.engine.sodium.mixin;

import net.caffeinemc.mods.sodium.client.render.chunk.RenderSection;
import net.caffeinemc.mods.sodium.client.render.chunk.region.RenderRegion;
import nvidiumplus.engine.sodium.NvidiumPlusRegionCacheHolder;
import nvidiumplus.engine.sodium.NvidiumPlusRegionMirror;
import nvidiumplus.engine.sodium.NvidiumPlusRegionRunCache;
import nvidiumplus.engine.vk.SodiumTerrainDrawer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(RenderRegion.class)
public abstract class RenderRegionMixin implements NvidiumPlusRegionCacheHolder {
   @Unique
   private int nvidiumplus$epoch;
   @Unique
   private NvidiumPlusRegionRunCache nvidiumplus$runCache;
   @Unique
   private int nvidiumplus$mid = -1;
   @Unique
   private boolean nvidiumplus$dirtyQueued;

   @Override
   public int nvidiumplus$mid() {
      return this.nvidiumplus$mid;
   }

   @Override
   public void nvidiumplus$setMid(int mid) {
      this.nvidiumplus$mid = mid;
   }

   @Override
   public boolean nvidiumplus$dirtyQueued() {
      return this.nvidiumplus$dirtyQueued;
   }

   @Override
   public void nvidiumplus$setDirtyQueued(boolean value) {
      this.nvidiumplus$dirtyQueued = value;
   }

   @Override
   public int nvidiumplus$epoch() {
      return this.nvidiumplus$epoch;
   }

   @Override
   public void nvidiumplus$bumpEpoch() {
      this.nvidiumplus$epoch++;
   }

   @Override
   public NvidiumPlusRegionRunCache nvidiumplus$runCache() {
      return this.nvidiumplus$runCache;
   }

   @Override
   public void nvidiumplus$setRunCache(NvidiumPlusRegionRunCache cache) {
      this.nvidiumplus$runCache = cache;
   }

   @Inject(method = "removeSection(Lnet/caffeinemc/mods/sodium/client/render/chunk/RenderSection;)V", at = @At("HEAD"), require = 0, expect = 0)
   private void nvidiumplus$onRemoveSection(RenderSection section, CallbackInfo ci) {
      this.nvidiumplus$epoch++;
      NvidiumPlusRegionMirror.onMutation((RenderRegion)this);
      SodiumTerrainDrawer.onHookRemoveSection();
   }

   @Inject(method = "onGeometryBufferChange()V", at = @At("HEAD"), require = 0, expect = 0)
   private void nvidiumplus$onGeometryBufferChange(CallbackInfo ci) {
      this.nvidiumplus$epoch++;
      NvidiumPlusRegionMirror.onMutation((RenderRegion)this);
      SodiumTerrainDrawer.onHookBufferChange();
   }

   @Inject(method = "onGeometrySegmentChange(I)V", at = @At("HEAD"), require = 0, expect = 0)
   private void nvidiumplus$onGeometrySegmentChange(int packedOwner, CallbackInfo ci) {
      this.nvidiumplus$epoch++;
      NvidiumPlusRegionMirror.onMutation((RenderRegion)this);
      SodiumTerrainDrawer.onHookSegmentChange();
   }

   @Inject(method = "delete()V", at = @At("HEAD"), require = 0, expect = 0)
   private void nvidiumplus$onDelete(CallbackInfo ci) {
      NvidiumPlusRegionMirror.onDelete((RenderRegion)this);
      this.nvidiumplus$epoch++;
      this.nvidiumplus$runCache = null;
      SodiumTerrainDrawer.onHookDelete();
   }
}
