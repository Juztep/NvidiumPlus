package nvidiumplus.engine.sodium;

import net.caffeinemc.mods.sodium.api.config.ConfigEntryPoint;
import net.caffeinemc.mods.sodium.api.config.ConfigState;
import net.caffeinemc.mods.sodium.api.config.structure.ConfigBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.ModOptionsBuilder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.OptionInstance.IntRange;
import net.minecraft.resources.Identifier;
import nvidiumplus.engine.NvidiumPlusPlatform;

public final class NvidiumPlusSodiumConfigEntry implements ConfigEntryPoint {
   static final Identifier RENDER_DISTANCE = Identifier.parse("sodium:general.render_distance");
   static final int OVERLAY_PRIORITY = 100;

   public void registerConfigLate(ConfigBuilder var1) {
      ModOptionsBuilder var2 = var1.registerOwnModOptions();
      var2.setName("NvidiumPlus");
      var2.setVersion(version());
      NvidiumPlusSodiumPage.addTo(var1, var2);
   }

   static NvidiumPlusSodiumRange range(ConfigState state) {
      return new NvidiumPlusSodiumRange(2, sliderMax(NvidiumPlusSodiumPage.effectiveCap(state)), 1);
   }

   static int sliderMax(int var0) {
      return var0;
   }

   private static String version() {
      return NvidiumPlusPlatform.modVersion("nvidiumplus").orElse("unknown");
   }

   private static Integer loadRenderDistance() {
      return (Integer)Minecraft.getInstance().options.renderDistance().get();
   }

   private static void saveRenderDistance(Integer value) {
      OptionInstance<Integer> option = Minecraft.getInstance().options.renderDistance();
      int held = value;
      if (option.values() instanceof IntRange range) {
         held = Math.clamp(held, range.minInclusive(), range.maxInclusive());
      }

      option.set(held);
   }

   static String withoutBuildTag(String version) {
      int plus = version.indexOf(43);
      return plus > 0 ? version.substring(0, plus) : version;
   }
}
