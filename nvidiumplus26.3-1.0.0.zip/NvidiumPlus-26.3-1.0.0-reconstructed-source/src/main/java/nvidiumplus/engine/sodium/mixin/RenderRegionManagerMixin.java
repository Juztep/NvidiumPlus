package nvidiumplus.engine.sodium.mixin;

import java.util.Collection;
import net.caffeinemc.mods.sodium.client.render.chunk.UniformBufferManager;
import net.caffeinemc.mods.sodium.client.render.chunk.region.RenderRegion;
import net.caffeinemc.mods.sodium.client.render.chunk.region.RenderRegionManager;
import nvidiumplus.engine.sodium.NvidiumPlusRegionCacheHolder;
import nvidiumplus.engine.sodium.NvidiumPlusRegionMirror;
import nvidiumplus.engine.vk.SodiumTerrainDrawer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(RenderRegionManager.class)
public abstract class RenderRegionManagerMixin {
   @Inject(
      method = "uploadResults(Lnet/caffeinemc/mods/sodium/client/render/chunk/region/RenderRegion;Ljava/util/Collection;Lnet/caffeinemc/mods/sodium/client/render/chunk/UniformBufferManager;)V",
      at = @At("HEAD"),
      require = 0,
      expect = 0
   )
   private void nvidiumplus$onUploadResults(RenderRegion region, Collection<?> results, UniformBufferManager uniforms, CallbackInfo ci) {
      if (region instanceof NvidiumPlusRegionCacheHolder holder) {
         holder.nvidiumplus$bumpEpoch();
      }

      NvidiumPlusRegionMirror.onMutation(region);
      SodiumTerrainDrawer.onHookUpload();
   }
}
