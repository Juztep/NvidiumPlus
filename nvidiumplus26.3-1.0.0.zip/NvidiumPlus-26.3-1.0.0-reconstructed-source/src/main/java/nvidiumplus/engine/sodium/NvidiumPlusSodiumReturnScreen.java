package nvidiumplus.engine.sodium;

import net.caffeinemc.mods.sodium.client.config.ConfigManager;
import net.caffeinemc.mods.sodium.client.config.structure.Config;
import net.caffeinemc.mods.sodium.client.config.structure.ModOptions;
import net.caffeinemc.mods.sodium.client.config.structure.Page;
import net.caffeinemc.mods.sodium.client.gui.VideoSettingsScreen;
import net.minecraft.client.gui.screens.Screen;

final class NvidiumPlusSodiumReturnScreen extends Screen {
   private final Screen sodiumScreen;

   NvidiumPlusSodiumReturnScreen(Screen sodiumScreen) {
      super(sodiumScreen.getTitle());
      this.sodiumScreen = sodiumScreen;
   }

   protected void init() {
      Config config = ConfigManager.CONFIG;
      if (config != null && !config.anyOptionChanged()) {
         config.resetAllOptionsFromBindings();
      }

      this.minecraft.gui.setScreen(this.sodiumScreen);
      if (config != null && this.sodiumScreen instanceof VideoSettingsScreen video) {
         for (ModOptions mod : config.getModOptions()) {
            if ("nvidiumplus".equals(mod.configId()) && !mod.pages().isEmpty()) {
               video.jumpToPage((Page)mod.pages().get(0));
               break;
            }
         }
      }
   }
}
