package nvidiumplus.engine.sodium;

public final class NvidiumPlusSodiumHooks {
   public static final String RENDER_REGION = "net/caffeinemc/mods/sodium/client/render/chunk/region/RenderRegion";
   public static final String RENDER_REGION_MANAGER = "net/caffeinemc/mods/sodium/client/render/chunk/region/RenderRegionManager";
   public static final String UPLOAD_NAME = "uploadResults";
   public static final String UPLOAD_DESC = "(Lnet/caffeinemc/mods/sodium/client/render/chunk/region/RenderRegion;Ljava/util/Collection;Lnet/caffeinemc/mods/sodium/client/render/chunk/UniformBufferManager;)V";
   public static final String UPLOAD_TARGET = "uploadResults(Lnet/caffeinemc/mods/sodium/client/render/chunk/region/RenderRegion;Ljava/util/Collection;Lnet/caffeinemc/mods/sodium/client/render/chunk/UniformBufferManager;)V";
   public static final String REMOVE_SECTION_NAME = "removeSection";
   public static final String REMOVE_SECTION_DESC = "(Lnet/caffeinemc/mods/sodium/client/render/chunk/RenderSection;)V";
   public static final String REMOVE_SECTION_TARGET = "removeSection(Lnet/caffeinemc/mods/sodium/client/render/chunk/RenderSection;)V";
   public static final String BUFFER_CHANGE_NAME = "onGeometryBufferChange";
   public static final String BUFFER_CHANGE_DESC = "()V";
   public static final String BUFFER_CHANGE_TARGET = "onGeometryBufferChange()V";
   public static final String SEGMENT_CHANGE_NAME = "onGeometrySegmentChange";
   public static final String SEGMENT_CHANGE_DESC = "(I)V";
   public static final String SEGMENT_CHANGE_TARGET = "onGeometrySegmentChange(I)V";
   public static final String DELETE_NAME = "delete";
   public static final String DELETE_DESC = "()V";
   public static final String DELETE_TARGET = "delete()V";
   public static final int HOOK_UPLOAD = 1;
   public static final int HOOK_REMOVE_SECTION = 2;
   public static final int HOOK_BUFFER_CHANGE = 4;
   public static final int HOOK_SEGMENT_CHANGE = 8;
   public static final int HOOK_DELETE = 16;
   public static final int HOOKS_ALL = 31;
   public static final String RENDER_SECTION_MANAGER = "net/caffeinemc/mods/sodium/client/render/chunk/RenderSectionManager";
   public static final String SEARCH_DISTANCE_NAME = "getSearchDistance";
   public static final String SEARCH_DISTANCE_DESC = "(Lnet/caffeinemc/mods/sodium/client/util/FogParameters;)F";
   public static final String SEARCH_DISTANCE_TARGET = "getSearchDistance(Lnet/caffeinemc/mods/sodium/client/util/FogParameters;)F";
   public static final int HOOK_SEARCH_DISTANCE = 32;
   public static final String CHUNK_RENDER_LIST = "net/caffeinemc/mods/sodium/client/render/chunk/lists/ChunkRenderList";
   public static final String GEOMETRY_MAP_NAME = "sectionsWithGeometryMap";
   public static final String GEOMETRY_MAP_DESC = "[J";
   public static final String GEOMETRY_MAP_TARGET = "sectionsWithGeometryMap [J";
   public static final int HOOK_GEOMETRY_MAP = 64;
   public static final String VK_INDIRECT_CONTEXT = "net/caffeinemc/mods/sodium/client/gpu/device/context/VKIndirectContext";
   public static final int INDIRECT_RING_STOCK_BYTES = 512000;
   public static final int INDIRECT_RING_DEFAULT_BYTES = 4194304;
   public static final String INDIRECT_RING_PROPERTY = "nvidiumplus.sodium.indirectRingBytes";
   public static final int HOOK_INDIRECT_RING = 128;
   private static volatile int hooksFound;
   private static volatile String disarmReason;

   public static int indirectRingBytes(int stock) {
      int want = 4194304;

      try {
         String raw = System.getProperty("nvidiumplus.sodium.indirectRingBytes");
         if (raw != null) {
            want = Integer.parseInt(raw.trim());
         }
      } catch (Throwable ignored) {
         want = 4194304;
      }

      return want <= stock ? stock : want;
   }

   public static boolean indirectRingFound() {
      return (hooksFound & 128) != 0;
   }

   public static boolean geometryMapFound() {
      return (hooksFound & 64) != 0;
   }

   public static boolean searchDistanceFound() {
      return (hooksFound & 32) != 0;
   }

   private NvidiumPlusSodiumHooks() {
   }

   public static void markFound(int bit) {
      hooksFound |= bit;
   }

   public static int hooksFound() {
      return hooksFound;
   }

   public static boolean hooksComplete() {
      return (hooksFound & 31) == 31;
   }

   public static void disarm(String reason) {
      if (disarmReason == null) {
         System.out.println("[NvidiumPlus] Sodium run cache disarmed for this session: " + reason);
      }

      if (disarmReason == null) {
         disarmReason = reason;
      }
   }

   public static boolean disarmed() {
      return disarmReason != null;
   }

   public static String disarmReason() {
      return disarmReason;
   }

   public static String describeMissing() {
      int found = hooksFound;
      StringBuilder sb = new StringBuilder();
      if ((found & 1) == 0) {
         sb.append("RenderRegionManager.")
            .append(
               "uploadResults(Lnet/caffeinemc/mods/sodium/client/render/chunk/region/RenderRegion;Ljava/util/Collection;Lnet/caffeinemc/mods/sodium/client/render/chunk/UniformBufferManager;)V"
            )
            .append(' ');
      }

      if ((found & 2) == 0) {
         sb.append("RenderRegion.").append("removeSection(Lnet/caffeinemc/mods/sodium/client/render/chunk/RenderSection;)V").append(' ');
      }

      if ((found & 4) == 0) {
         sb.append("RenderRegion.").append("onGeometryBufferChange()V").append(' ');
      }

      if ((found & 8) == 0) {
         sb.append("RenderRegion.").append("onGeometrySegmentChange(I)V").append(' ');
      }

      if ((found & 16) == 0) {
         sb.append("RenderRegion.").append("delete()V").append(' ');
      }

      return sb.toString().trim();
   }
}
