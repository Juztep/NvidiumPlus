package nvidiumplus.engine.sodium.mixin;

import net.caffeinemc.mods.sodium.client.render.chunk.ChunkRenderer;
import net.caffeinemc.mods.sodium.client.render.chunk.RenderSectionManager;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.sodium.NvidiumPlusChunkRenderer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(RenderSectionManager.class)
public abstract class RenderSectionManagerMixin {
   @Shadow
   @Final
   @Mutable
   private ChunkRenderer chunkRenderer;

   @Inject(method = "<init>", at = @At("TAIL"))
   private void nvidiumplus$installChunkRenderer(CallbackInfo ci) {
      if (NvidiumPlusGate.sodiumAdapterArmed()) {
         ChunkRenderer sodiums = this.chunkRenderer;
         if (sodiums == null) {
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus found no chunk renderer to wrap after Sodium's RenderSectionManager finished constructing. Leaving Sodium's pipeline untouched."
               );
         } else if (!(sodiums instanceof NvidiumPlusChunkRenderer)) {
            this.chunkRenderer = new NvidiumPlusChunkRenderer(sodiums, (RenderSectionManager)this);
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus has taken Sodium's chunk-renderer slot, wrapping {}. Opaque terrain will be drawn with mesh shaders out of Sodium's own buffers; translucent geometry stays with Sodium.",
                  sodiums.getClass().getName()
               );
         }
      }
   }
}
