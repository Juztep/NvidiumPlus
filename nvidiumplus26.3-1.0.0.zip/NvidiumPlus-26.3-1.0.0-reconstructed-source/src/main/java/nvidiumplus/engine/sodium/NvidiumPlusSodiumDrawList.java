package nvidiumplus.engine.sodium;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import java.util.Arrays;
import net.caffeinemc.mods.sodium.client.SodiumClientMod;
import net.caffeinemc.mods.sodium.client.model.quad.properties.ModelQuadFacing;
import net.caffeinemc.mods.sodium.client.render.chunk.DefaultChunkRenderer;
import net.caffeinemc.mods.sodium.client.render.chunk.LocalSectionIndex;
import net.caffeinemc.mods.sodium.client.render.chunk.data.SectionRenderDataStorage;
import net.caffeinemc.mods.sodium.client.render.chunk.data.SectionRenderDataUnsafe;
import net.caffeinemc.mods.sodium.client.render.chunk.lists.ChunkRenderList;
import net.caffeinemc.mods.sodium.client.render.chunk.lists.ChunkRenderListIterable;
import net.caffeinemc.mods.sodium.client.render.chunk.region.RenderRegion;
import net.caffeinemc.mods.sodium.client.render.chunk.region.RenderRegion.DeviceResources;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import net.caffeinemc.mods.sodium.client.render.viewport.CameraTransform;
import net.caffeinemc.mods.sodium.client.util.iterator.ByteIterator;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.vk.SodiumTerrainDrawer;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

final class NvidiumPlusSodiumDrawList {
   private static final ThreadLocal<NvidiumPlusSodiumDrawList.AllSlots> ALL_SLOTS = ThreadLocal.withInitial(NvidiumPlusSodiumDrawList.AllSlots::new);
   private static final int FACINGS = ModelQuadFacing.COUNT;
   private static final boolean DIAG_ALL_SLOTS = Boolean.getBoolean("nvidiumplus.sodium.diag.allSlots");
   static final String PROPERTY_FACE_CULL = "nvidiumplus.sodium.facecull";
   static final boolean FACE_CULL = !"false".equalsIgnoreCase(System.getProperty("nvidiumplus.sodium.facecull"));
   private static boolean uploadGuardReported;
   private long quadsKept;
   private long quadsCulled;
   private int sectionsEmitted;
   private GpuBuffer[] buffers = new GpuBuffer[64];
   private int bufferCount;
   private int[] meta = new int[768];
   private float[] origins = new float[768];
   private int drawCount;
   private int regionCount;
   private final byte[] sequence = new byte[256];
   private final NvidiumPlusSodiumDrawList.Sequence replay = new NvidiumPlusSodiumDrawList.Sequence();
   private TerrainRenderPass[] passes = new TerrainRenderPass[4];
   private int passCount;
   private NvidiumPlusRegionRunCache.Entry recording;
   private boolean cacheArmed;
   private int regionsHit;
   private int regionsRebuilt;
   private final boolean frustumTest = SodiumTerrainDrawer.frustumCpuTestWanted();
   private final boolean frustumDrop = SodiumTerrainDrawer.FRUSTUM_MODE == 2;
   private final float[] planes = new float[24];
   private final Matrix4f mvpScratch = new Matrix4f();
   private int runsPushed;
   private int runsFrustumRejected;
   private long quadsFrustumRejected;

   GpuBuffer[] buffers() {
      return this.buffers;
   }

   int bufferCount() {
      return this.bufferCount;
   }

   int[] meta() {
      return this.meta;
   }

   float[] origins() {
      return this.origins;
   }

   int drawCount() {
      return this.drawCount;
   }

   int regionCount() {
      return this.regionCount;
   }

   long quadsKept() {
      return this.quadsKept;
   }

   long quadsCulled() {
      return this.quadsCulled;
   }

   int sectionsEmitted() {
      return this.sectionsEmitted;
   }

   boolean cacheArmed() {
      return this.cacheArmed;
   }

   int regionsHit() {
      return this.regionsHit;
   }

   int regionsRebuilt() {
      return this.regionsRebuilt;
   }

   int runsPushed() {
      return this.runsPushed;
   }

   int runsFrustumRejected() {
      return this.runsFrustumRejected;
   }

   long quadsFrustumRejected() {
      return this.quadsFrustumRejected;
   }

   void build(ChunkRenderListIterable renderLists, TerrainRenderPass pass, CameraTransform camera, Matrix4fc modelView, Matrix4fc projection) {
      this.bufferCount = 0;
      this.drawCount = 0;
      this.regionCount = 0;
      this.quadsKept = 0L;
      this.quadsCulled = 0L;
      this.sectionsEmitted = 0;
      this.regionsHit = 0;
      this.regionsRebuilt = 0;
      this.recording = null;
      this.runsPushed = 0;
      this.runsFrustumRejected = 0;
      this.quadsFrustumRejected = 0L;
      if (this.frustumTest) {
         this.setPlanes(modelView, projection);
      }

      boolean faceCull = FACE_CULL;

      try {
         faceCull = faceCull && SodiumClientMod.options().performance.useBlockFaceCulling;
      } catch (Throwable ignored) {
         faceCull = false;
      }

      boolean translucent = pass.isTranslucent();
      this.cacheArmed = runCacheArmed();
      if (this.cacheArmed) {
         this.buildCached(renderLists, pass, camera, faceCull, translucent);
         if (this.drawCount > 0 && SodiumTerrainDrawer.hookUpload() == 0L) {
            NvidiumPlusSodiumHooks.disarm("a pass drew " + this.drawCount + " runs while the upload hook had never fired");
            if (!uploadGuardReported) {
               uploadGuardReported = true;
               NvidiumPlusLog.LOGGER
                  .warn(
                     "NvidiumPlus's per-region run cache is standing down for this session: {}. The enumeration walk draws instead (reported once).",
                     NvidiumPlusSodiumHooks.disarmReason()
                  );
            }
         }
      } else {
         this.buildWalk(renderLists, pass, camera, faceCull, translucent);
      }
   }

   private static boolean runCacheArmed() {
      return !DIAG_ALL_SLOTS && SodiumTerrainDrawer.runCacheEnabled() && NvidiumPlusSodiumHooks.hooksComplete() && !NvidiumPlusSodiumHooks.disarmed();
   }

   private void buildWalk(ChunkRenderListIterable renderLists, TerrainRenderPass pass, CameraTransform camera, boolean faceCull, boolean translucent) {
      for (ChunkRenderList list : renderLists) {
         RenderRegion region = list.getRegion();
         if (region != null) {
            SectionRenderDataStorage storage = region.getStorage(pass);
            if (storage != null) {
               DeviceResources resources = region.getResources();
               if (resources != null) {
                  GpuBuffer geometry = resources.getGeometryBuffer();
                  if (geometry != null) {
                     ByteIterator sections = list.sectionsWithGeometryIterator(translucent);
                     if (DIAG_ALL_SLOTS) {
                        sections = ALL_SLOTS.get();
                        ((NvidiumPlusSodiumDrawList.AllSlots)sections).reset();
                     }

                     if (sections != null && this.walkRegion(region, storage, geometry, sections, camera, faceCull)) {
                        this.regionCount++;
                     }
                  }
               }
            }
         }
      }
   }

   private void buildCached(ChunkRenderListIterable renderLists, TerrainRenderPass pass, CameraTransform camera, boolean faceCull, boolean translucent) {
      int passIndex = this.passIndex(pass);
      int camKeyX = faceCull ? NvidiumPlusRegionRunCache.cameraKey(camera.intX) : 0;
      int camKeyY = faceCull ? NvidiumPlusRegionRunCache.cameraKey(camera.intY) : 0;
      int camKeyZ = faceCull ? NvidiumPlusRegionRunCache.cameraKey(camera.intZ) : 0;
      byte[] seq = this.sequence;

      for (ChunkRenderList list : renderLists) {
         RenderRegion region = list.getRegion();
         if (region != null) {
            SectionRenderDataStorage storage = region.getStorage(pass);
            if (storage != null) {
               DeviceResources resources = region.getResources();
               if (resources != null) {
                  GpuBuffer geometry = resources.getGeometryBuffer();
                  if (geometry != null) {
                     ByteIterator sections = list.sectionsWithGeometryIterator(translucent);
                     if (sections != null) {
                        int n;
                        for (n = 0; sections.hasNext(); seq[n++] = (byte)sections.nextByteAsInt()) {
                           if (n == seq.length) {
                              throw new IllegalStateException("Sodium listed more than 256 sections for one region");
                           }
                        }

                        if (region instanceof NvidiumPlusRegionCacheHolder holder) {
                           NvidiumPlusRegionRunCache cache = holder.nvidiumplus$runCache();
                           if (cache == null) {
                              cache = new NvidiumPlusRegionRunCache();
                              holder.nvidiumplus$setRunCache(cache);
                           }

                           NvidiumPlusRegionRunCache.Entry entry = cache.entry(passIndex);
                           int epoch = holder.nvidiumplus$epoch();
                           if (entry.matches(epoch, faceCull, camKeyX, camKeyY, camKeyZ, seq, n)) {
                              if (this.replayEntry(entry, geometry, camera)) {
                                 this.regionCount++;
                              }

                              this.regionsHit++;
                           } else {
                              entry.begin(epoch, faceCull, camKeyX, camKeyY, camKeyZ, seq, n);
                              long keptBefore = this.quadsKept;
                              long culledBefore = this.quadsCulled;
                              int sectionsBefore = this.sectionsEmitted;
                              this.recording = entry;
                              this.replay.reset(seq, n);
                              boolean drew = this.walkRegion(region, storage, geometry, this.replay, camera, faceCull);
                              this.recording = null;
                              entry.finish(this.quadsKept - keptBefore, this.quadsCulled - culledBefore, this.sectionsEmitted - sectionsBefore);
                              if (drew) {
                                 this.regionCount++;
                              }

                              this.regionsRebuilt++;
                           }
                        } else {
                           NvidiumPlusSodiumHooks.disarm("RenderRegion does not carry NvidiumPlus's cache field");
                           this.replay.reset(seq, n);
                           if (this.walkRegion(region, storage, geometry, this.replay, camera, faceCull)) {
                              this.regionCount++;
                           }

                           this.regionsRebuilt++;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean replayEntry(NvidiumPlusRegionRunCache.Entry entry, GpuBuffer geometry, CameraTransform camera) {
      this.quadsKept = this.quadsKept + entry.quadsKept();
      this.quadsCulled = this.quadsCulled + entry.quadsCulled();
      this.sectionsEmitted = this.sectionsEmitted + entry.sectionsEmitted();
      int runs = entry.runCount();
      if (runs == 0) {
         return false;
      }

      int bufferIndex = this.intern(geometry);
      int[] r = entry.runs();

      for (int i = 0; i < runs; i++) {
         int base = i * 5;
         int sectionX = r[base + 2];
         int sectionY = r[base + 3];
         int sectionZ = r[base + 4];
         float ox = (float)((sectionX & -8) * 16.0 - camera.x) + 16.0F * (sectionX & 7);
         float oy = (float)((sectionY & -4) * 16.0 - camera.y) + 16.0F * (sectionY & 3);
         float oz = (float)((sectionZ & -8) * 16.0 - camera.z) + 16.0F * (sectionZ & 7);
         this.push(bufferIndex, r[base + 0], r[base + 1], sectionX, sectionY, sectionZ, ox, oy, oz);
      }

      return true;
   }

   private boolean walkRegion(
      RenderRegion region, SectionRenderDataStorage storage, GpuBuffer geometry, ByteIterator sections, CameraTransform camera, boolean faceCull
   ) {
      int bufferIndex = -1;
      boolean drewFromRegion = false;
      float rx = (float)(region.getOriginX() - camera.x);
      float ry = (float)(region.getOriginY() - camera.y);
      float rz = (float)(region.getOriginZ() - camera.z);

      while (sections.hasNext()) {
         int index = sections.nextByteAsInt();
         long record = storage.getDataPointer(index);
         if (record != 0L) {
            int sectionX = region.getChunkX() + LocalSectionIndex.unpackX(index);
            int sectionY = region.getChunkY() + LocalSectionIndex.unpackY(index);
            int sectionZ = region.getChunkZ() + LocalSectionIndex.unpackZ(index);
            int visible = faceCull
               ? DefaultChunkRenderer.getVisibleFaces(camera.intX, camera.intY, camera.intZ, sectionX, sectionY, sectionZ)
               : ModelQuadFacing.ALL;
            int mask = visible & SectionRenderDataUnsafe.getSliceMask(record);
            if (mask != 0) {
               if (bufferIndex < 0) {
                  bufferIndex = this.intern(geometry);
               }

               float ox = rx + 16.0F * LocalSectionIndex.unpackX(index);
               float oy = ry + 16.0F * LocalSectionIndex.unpackY(index);
               float oz = rz + 16.0F * LocalSectionIndex.unpackZ(index);
               if (this.emitRuns(record, bufferIndex, sectionX, sectionY, sectionZ, ox, oy, oz, mask)) {
                  drewFromRegion = true;
                  this.sectionsEmitted++;
               }
            }
         }
      }

      return drewFromRegion;
   }

   private boolean emitRuns(long record, int bufferIndex, int sectionX, int sectionY, int sectionZ, float ox, float oy, float oz, int mask) {
      long facingList = SectionRenderDataUnsafe.getFacingList(record);
      long cursor = SectionRenderDataUnsafe.getBaseVertex(record);
      long runStart = 0L;
      long pending = 0L;
      boolean any = false;

      for (int i = 0; i <= FACINGS; i++) {
         if (i < FACINGS) {
            long count = SectionRenderDataUnsafe.getVertexCount(record, i);
            if (count != 0L) {
               int facing = (int)(facingList >>> i * 8 & 255L);
               if ((mask >>> facing & 1) != 0) {
                  if (pending == 0L) {
                     runStart = cursor;
                  }

                  pending += count;
                  this.quadsKept += count >> 2;
               } else {
                  if (pending > 0L) {
                     this.push(bufferIndex, (int)runStart, (int)(pending >> 2), sectionX, sectionY, sectionZ, ox, oy, oz);
                     pending = 0L;
                     any = true;
                  }

                  this.quadsCulled += count >> 2;
               }

               cursor += count;
            }
         } else if (pending > 0L) {
            this.push(bufferIndex, (int)runStart, (int)(pending >> 2), sectionX, sectionY, sectionZ, ox, oy, oz);
            any = true;
         }
      }

      return any;
   }

   private int intern(GpuBuffer buffer) {
      for (int i = 0; i < this.bufferCount; i++) {
         if (this.buffers[i] == buffer) {
            return i;
         }
      }

      if (this.bufferCount == this.buffers.length) {
         this.buffers = Arrays.copyOf(this.buffers, this.buffers.length * 2);
      }

      this.buffers[this.bufferCount] = buffer;
      return this.bufferCount++;
   }

   private int passIndex(TerrainRenderPass pass) {
      for (int i = 0; i < this.passCount; i++) {
         if (this.passes[i] == pass) {
            return i;
         }
      }

      if (this.passCount == this.passes.length) {
         this.passes = Arrays.copyOf(this.passes, this.passes.length * 2);
      }

      this.passes[this.passCount] = pass;
      return this.passCount++;
   }

   private void push(int bufferIndex, int baseVertex, int quads, int sectionX, int sectionY, int sectionZ, float ox, float oy, float oz) {
      if (this.recording != null) {
         this.recording.addRun(baseVertex, quads, sectionX, sectionY, sectionZ);
      }

      this.runsPushed++;
      if (this.frustumTest && !this.inFrustum(ox, oy, oz)) {
         this.runsFrustumRejected++;
         this.quadsFrustumRejected += quads;
         if (this.frustumDrop) {
            return;
         }
      }

      if ((this.drawCount + 1) * 3 > this.meta.length) {
         this.meta = Arrays.copyOf(this.meta, this.meta.length * 2);
         this.origins = Arrays.copyOf(this.origins, this.origins.length * 2);
      }

      int m = this.drawCount * 3;
      this.meta[m] = bufferIndex;
      this.meta[m + 1] = baseVertex;
      this.meta[m + 2] = quads;
      int o = this.drawCount * 3;
      this.origins[o] = ox;
      this.origins[o + 1] = oy;
      this.origins[o + 2] = oz;
      this.drawCount++;
   }

   private boolean inFrustum(float ox, float oy, float oz) {
      float s = 1.125F;
      float lx = ox - s;
      float ly = oy - s;
      float lz = oz - s;
      float hx = ox + 16.0F + s;
      float hy = oy + 16.0F + s;
      float hz = oz + 16.0F + s;
      float[] p = this.planes;

      for (int i = 0; i < 24; i += 4) {
         float a = p[i];
         float b = p[i + 1];
         float c = p[i + 2];
         float px = a >= 0.0F ? hx : lx;
         float py = b >= 0.0F ? hy : ly;
         float pz = c >= 0.0F ? hz : lz;
         if (a * px + b * py + c * pz < -p[i + 3]) {
            return false;
         }
      }

      return true;
   }

   private void setPlanes(Matrix4fc modelView, Matrix4fc projection) {
      Matrix4f m = this.mvpScratch.set(projection).mul(modelView);
      float[] p = this.planes;
      plane(p, 0, m.m03() + m.m00(), m.m13() + m.m10(), m.m23() + m.m20(), m.m33() + m.m30());
      plane(p, 4, m.m03() - m.m00(), m.m13() - m.m10(), m.m23() - m.m20(), m.m33() - m.m30());
      plane(p, 8, m.m03() + m.m01(), m.m13() + m.m11(), m.m23() + m.m21(), m.m33() + m.m31());
      plane(p, 12, m.m03() - m.m01(), m.m13() - m.m11(), m.m23() - m.m21(), m.m33() - m.m31());
      plane(p, 16, m.m03() + m.m02(), m.m13() + m.m12(), m.m23() + m.m22(), m.m33() + m.m32());
      plane(p, 20, m.m03() - m.m02(), m.m13() - m.m12(), m.m23() - m.m22(), m.m33() - m.m32());
   }

   private static void plane(float[] p, int i, float a, float b, float c, float d) {
      p[i] = a;
      p[i + 1] = b;
      p[i + 2] = c;
      p[i + 3] = d;
   }

   void clearBufferRefs() {
      for (int i = 0; i < this.bufferCount; i++) {
         this.buffers[i] = null;
      }

      this.bufferCount = 0;
   }

   private static final class AllSlots implements ByteIterator {
      private int next;

      void reset() {
         this.next = 0;
      }

      public boolean hasNext() {
         return this.next < 256;
      }

      public int nextByteAsInt() {
         return this.next++;
      }
   }

   private static final class Sequence implements ByteIterator {
      private byte[] data;
      private int next;
      private int end;

      void reset(byte[] data, int count) {
         this.data = data;
         this.next = 0;
         this.end = count;
      }

      public boolean hasNext() {
         return this.next < this.end;
      }

      public int nextByteAsInt() {
         return this.data[this.next++] & 0xFF;
      }
   }
}
