package nvidiumplus.engine.sodium;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.renderpearl.api.device.GpuDeviceLossException;
import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import net.caffeinemc.mods.sodium.client.render.chunk.ChunkRenderMatrices;
import net.caffeinemc.mods.sodium.client.render.chunk.ChunkRenderer;
import net.caffeinemc.mods.sodium.client.render.chunk.RenderSectionManager;
import net.caffeinemc.mods.sodium.client.render.chunk.data.SectionRenderDataUnsafe;
import net.caffeinemc.mods.sodium.client.render.chunk.lists.ChunkRenderListIterable;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.DefaultTerrainRenderPasses;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import net.caffeinemc.mods.sodium.client.render.viewport.CameraTransform;
import net.caffeinemc.mods.sodium.client.util.FogParameters;
import net.minecraft.client.Minecraft;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.NvidiumPlusVulkanState;
import nvidiumplus.engine.sodium.mixin.RenderSectionManagerInvoker;
import nvidiumplus.engine.vk.SodiumFrameRing;
import nvidiumplus.engine.vk.SodiumMirrorGpu;
import nvidiumplus.engine.vk.SodiumTerrainDrawer;

public abstract class NvidiumPlusChunkRendererBase {
   protected final ChunkRenderer delegate;
   private final RenderSectionManager manager;
   private final NvidiumPlusSodiumDrawList drawList = new NvidiumPlusSodiumDrawList();
   private final NvidiumPlusRegionMirror mirror;
   private SodiumTerrainDrawer.InstanceState gpu;
   private final NvidiumPlusRegionMirror.FrameOutput frame = new NvidiumPlusRegionMirror.FrameOutput();
   private int lastFrameSeen = Integer.MIN_VALUE;
   private long attempts;
   private boolean frameOwned;
   private int invariantRun;
   private final float[] sceneTail = new float[4];
   private final int[] cameraBlock = new int[3];
   private Boolean armed;
   private static boolean strideChecked;
   private String searchDistanceSource = "none";

   protected NvidiumPlusChunkRendererBase(ChunkRenderer delegate) {
      this(delegate, null);
   }

   protected NvidiumPlusChunkRendererBase(ChunkRenderer delegate, RenderSectionManager manager) {
      if (delegate == null) {
         throw new IllegalArgumentException(
            "NvidiumPlus's chunk renderer needs Sodium's to delegate to; without it there is no way to hand a frame back and a failure would draw nothing"
         );
      }

      this.delegate = delegate;
      this.manager = manager;
      this.mirror = manager == null ? null : new NvidiumPlusRegionMirror(manager);
   }

   public ChunkRenderer delegate() {
      return this.delegate;
   }

   protected final boolean draw(
      ChunkRenderMatrices matrices,
      ChunkRenderListIterable renderLists,
      TerrainRenderPass pass,
      CameraTransform camera,
      FogParameters fog,
      GpuSampler atlasSampler
   ) {
      if (pass.isTranslucent() || !this.armed()) {
         return false;
      }

      if (SodiumTerrainDrawer.enabled() && !SodiumTerrainDrawer.broken()) {
         if (matrices != null && camera != null && renderLists != null) {
            RenderTarget target = pass.getTarget();
            GpuTextureView atlasView = pass.getAtlas();
            if (target != null && atlasView != null) {
               Minecraft minecraft = Minecraft.getInstance();
               GpuTextureView lightmapView = minecraft.gameRenderer.lightmap();
               boolean solid = pass == DefaultTerrainRenderPasses.SOLID;
               boolean cutout = pass == DefaultTerrainRenderPasses.CUTOUT;
               if (solid) {
                  this.frameOwned = false;
                  if (this.rung0Wanted()) {
                     this.frameOwned = this.attemptRung0(matrices, renderLists, camera, fog, atlasSampler, target, atlasView, lightmapView);
                     if (this.frameOwned) {
                        return true;
                     }
                  } else if (this.mirror != null) {
                     this.mirror.sleep();
                  }
               } else if (cutout && this.frameOwned) {
                  boolean ok;
                  try {
                     ok = SodiumTerrainDrawer.drawCutoutOwned(
                        this.gpu, target.getColorTextureView(), target.getDepthTextureView(), atlasView, atlasSampler, lightmapView, solidNoDiscard()
                     );
                  } catch (GpuDeviceLossException t) {
                     throw t;
                  } catch (Throwable t) {
                     SodiumTerrainDrawer.latchGpuDraw(t);
                     ok = false;
                  } finally {
                     this.frame.clear();
                     this.frameOwned = false;
                  }

                  if (ok) {
                     return true;
                  }
               }

               return this.rung1(matrices, renderLists, pass, camera, atlasSampler, target, atlasView, lightmapView, solid ? 0 : (cutout ? 1 : -1));
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         if (this.mirror != null) {
            this.mirror.sleep();
         }

         return false;
      }
   }

   private static void checkRecordStride() {
      if (!strideChecked) {
         strideChecked = true;

         try {
            long stride = SectionRenderDataUnsafe.heapPointer(0L, 1);
            if (stride != 48L) {
               SodiumTerrainDrawer.latchGpuDraw("Sodium's per-section record stride is " + stride + " bytes, not the 48 this mirror is built on");
            }
         } catch (Throwable t) {
            SodiumTerrainDrawer.latchGpuDraw(t);
         }
      }
   }

   private boolean rung0Wanted() {
      checkRecordStride();
      return SodiumTerrainDrawer.gpuDrawEnabled()
         && !SodiumTerrainDrawer.gpuDrawBroken()
         && this.manager != null
         && this.mirror != null
         && NvidiumPlusVulkanState.caps() != null
         && NvidiumPlusSodiumHooks.hooksComplete()
         && !NvidiumPlusSodiumHooks.disarmed();
   }

   private boolean attemptRung0(
      ChunkRenderMatrices matrices,
      ChunkRenderListIterable renderLists,
      CameraTransform camera,
      FogParameters fog,
      GpuSampler atlasSampler,
      RenderTarget target,
      GpuTextureView atlasView,
      GpuTextureView lightmapView
   ) {
      int sodiumFrame = this.manager.getFrame();
      if (sodiumFrame == this.lastFrameSeen) {
         return false;
      }

      this.lastFrameSeen = sodiumFrame;
      if (this.gpu == null) {
         this.gpu = SodiumTerrainDrawer.newInstanceState();
      }

      SodiumTerrainDrawer.reportAttempt();
      long serial = ++this.attempts;

      try {
         this.mirror.ensureTracking();
         if (SodiumTerrainDrawer.takeRemirrorRequest()) {
            this.mirror.remirrorAll();
         }

         String forced = SodiumTerrainDrawer.takeForcedDecline();
         if (forced != null) {
            return this.decline("forced");
         }

         if (!SodiumTerrainDrawer.ensureResources(this.gpu)) {
            return this.decline("deviceNotUp");
         }

         SodiumMirrorGpu mirrorGpu = this.gpu.mirror();
         this.mirror.syncCapacity(mirrorGpu.capacity());
         if (SodiumFrameRing.guardTripped()) {
            return this.decline("ringGuard");
         }

         boolean occlusion = SodiumTerrainDrawer.occlusionEnabled() && !SodiumTerrainDrawer.occlusionBroken() && SodiumTerrainDrawer.prepareOcclusion(this.gpu);
         this.mirror.beginFrame(serial);
         int growTo = this.mirror.growthNeeded();
         if (growTo > 0) {
            if (SodiumTerrainDrawer.growInstance(this.gpu, growTo)) {
               this.mirror.syncCapacity(growTo);
            }

            return this.decline("growth");
         } else {
            long commitStart = System.nanoTime();
            boolean[] declined = new boolean[1];
            int committed = this.mirror.commit(mirrorGpu, declined);
            mirrorGpu.endCommit();
            SodiumTerrainDrawer.reportCommit(
               committed,
               mirrorGpu.lastCommitBytes(),
               System.nanoTime() - commitStart,
               this.mirror.deadRows(),
               this.mirror.midsLive(),
               this.mirror.midsCapacity(),
               this.mirror.midsReleased(),
               this.mirror.bufferKeys()
            );
            if (declined[0]) {
               return this.decline(this.mirror.growthNeeded() > 0 ? "growth" : "staging");
            }

            if (SodiumTerrainDrawer.mirrorAuditEnabled()) {
               this.mirror.audit(mirrorGpu, this.gpu.statsFrames());
            }

            SodiumFrameRing ring = this.gpu.ring();
            ring.advance();
            boolean frustumRegions = occlusion && !SodiumTerrainDrawer.graphRegions();
            int listed = this.mirror.buildFrame(renderLists, camera, matrices.modelView(), matrices.projection(), frustumRegions, ring, this.frame);
            SodiumTerrainDrawer.reportInvariant(this.mirror.midMissing(), this.mirror.keyMismatch());
            if (listed < 0) {
               this.frame.clear();
               if (++this.invariantRun >= 3) {
                  SodiumTerrainDrawer.latchGpuDraw(
                     "a mid/key invariant breach repeated "
                        + this.invariantRun
                        + " frames running (midMissing="
                        + this.mirror.midMissing()
                        + ", keyMismatch="
                        + this.mirror.keyMismatch()
                        + ")"
                  );
               }

               return this.decline("invariant");
            } else {
               this.invariantRun = 0;
               String gateMode = SodiumTerrainDrawer.distanceGateMode();
               float searchDistance = this.searchDistance(fog, gateMode);
               boolean distanceGate = !"off".equals(gateMode);
               this.sceneTail[0] = camera.fracX;
               this.sceneTail[1] = camera.fracY;
               this.sceneTail[2] = camera.fracZ;
               this.sceneTail[3] = searchDistance;
               this.cameraBlock[0] = camera.intX;
               this.cameraBlock[1] = camera.intY;
               this.cameraBlock[2] = camera.intZ;
               SodiumTerrainDrawer.reportFrameLoop(
                  listed, this.frame.listedSections, this.frame.groupCount, this.frame.loopNanos, this.frame.faceAll, searchDistance, this.searchDistanceSource
               );
               SodiumTerrainDrawer.reportDroppedRegions(this.frame.droppedMirrored, this.frame.oneFrameGaps, listed);
               SodiumTerrainDrawer.reportUnreachable(this.frame.unreachableSections, this.frame.unreachableRegions, this.frame.listedSections);
               boolean owned = SodiumTerrainDrawer.drawSolidOwned(
                  this.gpu,
                  target.getColorTextureView(),
                  target.getDepthTextureView(),
                  atlasView,
                  atlasSampler,
                  lightmapView,
                  matrices.modelView(),
                  matrices.projection(),
                  camera.x,
                  camera.y,
                  camera.z,
                  this.sceneTail,
                  this.cameraBlock,
                  this.frame.groupBuffers,
                  this.frame.groupKeys,
                  this.frame.groupStart,
                  this.frame.groupCount,
                  listed,
                  this.frame.signature,
                  this.frame.faceAll,
                  distanceGate,
                  occlusion,
                  solidNoDiscard()
               );
               if (!owned) {
                  this.frame.clear();
                  return this.decline("deviceNotUp");
               } else {
                  return true;
               }
            }
         }
      } catch (GpuDeviceLossException t) {
         throw t;
      } catch (Throwable t) {
         this.frame.clear();
         SodiumTerrainDrawer.latchGpuDraw(t);
         return false;
      }
   }

   private boolean decline(String reason) {
      SodiumTerrainDrawer.reportDecline(reason);
      return false;
   }

   private float searchDistance(FogParameters fog, String gateMode) {
      if ("fog".equals(gateMode) && fog != null && NvidiumPlusSodiumHooks.searchDistanceFound() && this.manager instanceof RenderSectionManagerInvoker invoker) {
         try {
            float d = invoker.nvidiumplus$getSearchDistance(fog);
            this.searchDistanceSource = "invoker";
            return d;
         } catch (Throwable var5) {
         }
      }

      this.searchDistanceSource = "fallback";
      Minecraft client = Minecraft.getInstance();
      int rd = client != null && client.options != null ? client.options.getEffectiveRenderDistance() : 32;
      return rd * 16.0F;
   }

   private static boolean solidNoDiscard() {
      return Boolean.getBoolean("nvidiumplus.sodium.solidNoDiscard");
   }

   private boolean rung1(
      ChunkRenderMatrices matrices,
      ChunkRenderListIterable renderLists,
      TerrainRenderPass pass,
      CameraTransform camera,
      GpuSampler atlasSampler,
      RenderTarget target,
      GpuTextureView atlasView,
      GpuTextureView lightmapView,
      int passIndex
   ) {
      try {
         long buildStart = System.nanoTime();

         try {
            this.drawList.build(renderLists, pass, camera, matrices.modelView(), matrices.projection());
         } catch (Throwable t) {
            SodiumTerrainDrawer.failEnumeration(t);
            return false;
         }

         SodiumTerrainDrawer.reportQuads(this.drawList.quadsKept(), this.drawList.quadsCulled(), System.nanoTime() - buildStart);
         SodiumTerrainDrawer.reportSectionsEmitted(passIndex, this.drawList.sectionsEmitted(), this.drawList.quadsKept());
         SodiumTerrainDrawer.reportRunCache(this.drawList.cacheArmed(), this.drawList.regionsHit(), this.drawList.regionsRebuilt());
         SodiumTerrainDrawer.reportFrustum(this.drawList.runsPushed(), this.drawList.runsFrustumRejected(), this.drawList.quadsFrustumRejected());
         boolean noDiscard = !pass.supportsFragmentDiscard() && solidNoDiscard();
         boolean drawn = SodiumTerrainDrawer.drawOpaque(
            target.getColorTextureView(),
            target.getDepthTextureView(),
            atlasView,
            atlasSampler,
            lightmapView,
            matrices.modelView(),
            matrices.projection(),
            this.drawList.buffers(),
            this.drawList.bufferCount(),
            this.drawList.drawCount(),
            this.drawList.meta(),
            this.drawList.origins(),
            this.drawList.regionCount(),
            noDiscard
         );
         if (drawn) {
            SodiumTerrainDrawer.reportRung("1");
         }

         return drawn;
      } finally {
         this.drawList.clearBufferRefs();
      }
   }

   protected final boolean wantsDraw(TerrainRenderPass pass) {
      return pass != null && !pass.isTranslucent() && this.armed() && SodiumTerrainDrawer.enabled() && !SodiumTerrainDrawer.broken();
   }

   protected final boolean armed() {
      Boolean a = this.armed;
      if (a == null) {
         if (NvidiumPlusGate.state() == NvidiumPlusGate.State.UNKNOWN) {
            return false;
         }

         a = NvidiumPlusGate.sodiumAdapterArmed() && NvidiumPlusVulkanState.caps() != null;
         this.armed = a;
         if (a) {
            NvidiumPlusLog.LOGGER
               .info(
                  "NvidiumPlus is drawing Sodium's opaque terrain with mesh shaders. Sodium keeps the chunk building and the translucent pass; the geometry is read out of Sodium's own region buffers with no copy and no re-encode."
               );
         } else {
            NvidiumPlusLog.LOGGER
               .warn(
                  "NvidiumPlus is in Sodium's chunk-renderer slot but has no mesh-shader device to draw with, so every pass is forwarded to Sodium unchanged. This is the OpenGL backend, or a GPU without VK_EXT_mesh_shader."
               );
         }
      }

      return a;
   }

   public void rotate() {
      this.delegate.rotate();
   }

   public void delete() {
      this.frame.clear();
      this.frameOwned = false;
      if (this.mirror != null) {
         this.mirror.retire();
      }

      if (this.gpu != null) {
         SodiumTerrainDrawer.retire(this.gpu);
         this.gpu = null;
      }

      this.delegate.delete();
   }
}
