package nvidiumplus.engine.sodium;

import java.util.Arrays;
import net.caffeinemc.mods.sodium.client.render.chunk.DefaultChunkRenderer;

public final class NvidiumPlusRegionRunCache {
   static final int RUN_STRIDE = 5;
   static final int RUN_FIRST_VERTEX = 0;
   static final int RUN_QUADS = 1;
   static final int RUN_X = 2;
   static final int RUN_Y = 3;
   static final int RUN_Z = 4;
   private NvidiumPlusRegionRunCache.Entry[] entries = new NvidiumPlusRegionRunCache.Entry[2];

   NvidiumPlusRegionRunCache.Entry entry(int passIndex) {
      if (passIndex >= this.entries.length) {
         this.entries = Arrays.copyOf(this.entries, Math.max(passIndex + 1, this.entries.length * 2));
      }

      NvidiumPlusRegionRunCache.Entry e = this.entries[passIndex];
      if (e == null) {
         e = new NvidiumPlusRegionRunCache.Entry();
         this.entries[passIndex] = e;
      }

      return e;
   }

   public static int cameraKey(int cam) {
      int a = cam + 2 >> 4;
      int b = cam - 3 >> 4;
      return (a << 1) + (a - b);
   }

   public static String cameraKeyLatticeFailure() {
      boolean naiveFailed = false;

      for (int cam = -40; cam <= 40; cam++) {
         for (int other = -40; other <= 40; other++) {
            boolean sameKey = cameraKey(cam) == cameraKey(other);
            boolean sameSection = cam >> 4 == other >> 4;

            for (int s = -4; s <= 4; s++) {
               boolean sameMask = DefaultChunkRenderer.getVisibleFaces(cam, 0, 0, s, 0, 0) == DefaultChunkRenderer.getVisibleFaces(other, 0, 0, s, 0, 0);
               if (sameKey && !sameMask) {
                  return "cameraKey("
                     + cam
                     + ") == cameraKey("
                     + other
                     + ") but getVisibleFaces differs for section "
                     + s
                     + "; the run cache would replay under a stale facing mask";
               }

               if (sameSection && !sameMask) {
                  naiveFailed = true;
               }
            }
         }
      }

      return !naiveFailed
         ? "the camera-section key passed the facing lattice, so the lattice cannot tell an exact key from a wrong one; the check is vacuous"
         : null;
   }

   static final class Entry {
      private boolean valid;
      private int epoch;
      private boolean faceCull;
      private int camKeyX;
      private int camKeyY;
      private int camKeyZ;
      private int count;
      private final byte[] sequence = new byte[256];
      private int runCount;
      private int[] runs = new int[160];
      private long quadsKept;
      private long quadsCulled;
      private int sectionsEmitted;

      boolean matches(int epoch, boolean faceCull, int camKeyX, int camKeyY, int camKeyZ, byte[] candidate, int candidateCount) {
         return this.valid
            && this.epoch == epoch
            && this.faceCull == faceCull
            && this.camKeyX == camKeyX
            && this.camKeyY == camKeyY
            && this.camKeyZ == camKeyZ
            && this.count == candidateCount
            && Arrays.equals(this.sequence, 0, candidateCount, candidate, 0, candidateCount);
      }

      void begin(int epoch, boolean faceCull, int camKeyX, int camKeyY, int camKeyZ, byte[] candidate, int candidateCount) {
         this.valid = false;
         this.epoch = epoch;
         this.faceCull = faceCull;
         this.camKeyX = camKeyX;
         this.camKeyY = camKeyY;
         this.camKeyZ = camKeyZ;
         this.count = candidateCount;
         System.arraycopy(candidate, 0, this.sequence, 0, candidateCount);
         this.runCount = 0;
         this.quadsKept = 0L;
         this.quadsCulled = 0L;
         this.sectionsEmitted = 0;
      }

      void addRun(int firstVertex, int quads, int sectionX, int sectionY, int sectionZ) {
         if ((this.runCount + 1) * 5 > this.runs.length) {
            this.runs = Arrays.copyOf(this.runs, this.runs.length * 2);
         }

         int r = this.runCount * 5;
         this.runs[r + 0] = firstVertex;
         this.runs[r + 1] = quads;
         this.runs[r + 2] = sectionX;
         this.runs[r + 3] = sectionY;
         this.runs[r + 4] = sectionZ;
         this.runCount++;
      }

      void finish(long quadsKept, long quadsCulled, int sectionsEmitted) {
         this.quadsKept = quadsKept;
         this.quadsCulled = quadsCulled;
         this.sectionsEmitted = sectionsEmitted;
         this.valid = true;
      }

      int sectionsEmitted() {
         return this.sectionsEmitted;
      }

      int runCount() {
         return this.runCount;
      }

      int[] runs() {
         return this.runs;
      }

      long quadsKept() {
         return this.quadsKept;
      }

      long quadsCulled() {
         return this.quadsCulled;
      }
   }
}
