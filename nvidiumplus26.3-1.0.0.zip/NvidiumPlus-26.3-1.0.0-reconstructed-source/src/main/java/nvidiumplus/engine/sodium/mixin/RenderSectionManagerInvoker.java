package nvidiumplus.engine.sodium.mixin;

import net.caffeinemc.mods.sodium.client.render.chunk.RenderSectionManager;
import net.caffeinemc.mods.sodium.client.util.FogParameters;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(RenderSectionManager.class)
public interface RenderSectionManagerInvoker {
   @Invoker("getSearchDistance")
   float nvidiumplus$getSearchDistance(FogParameters var1);
}
