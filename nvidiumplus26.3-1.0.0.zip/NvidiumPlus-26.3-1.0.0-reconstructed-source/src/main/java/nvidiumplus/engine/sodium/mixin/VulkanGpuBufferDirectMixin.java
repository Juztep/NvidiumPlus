package nvidiumplus.engine.sodium.mixin;

import com.mojang.renderpearl.backend.vulkan.VulkanConst;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(targets = "com.mojang.renderpearl.backend.vulkan.VulkanGpuBuffer$Direct")
abstract class VulkanGpuBufferDirectMixin {
   @Redirect(method = "<init>", at = @At(value = "INVOKE", target = "Lcom/mojang/renderpearl/backend/vulkan/VulkanConst;bufferUsageToVk(I)I"))
   private static int nvidiumplus$storageCapableVertexBuffers(int usage) {
      int vk = VulkanConst.bufferUsageToVk(usage);
      if ((usage & 32) != 0) {
         vk |= 32;
      }

      return vk;
   }
}
