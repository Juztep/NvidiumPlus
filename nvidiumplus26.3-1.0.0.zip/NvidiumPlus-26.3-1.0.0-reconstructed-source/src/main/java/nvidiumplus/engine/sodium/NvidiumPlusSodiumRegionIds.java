package nvidiumplus.engine.sodium;

import java.util.Arrays;
import java.util.BitSet;

final class NvidiumPlusSodiumRegionIds {
   private final BitSet used = new BitSet();
   private int capacity;
   private int live;
   private long releasedTotal;
   private int[] releaseMid = new int[64];
   private long[] releaseSerial = new long[64];
   private int releaseHead;
   private int releaseCount;

   NvidiumPlusSodiumRegionIds(int capacity) {
      this.capacity = capacity;
   }

   int acquire() {
      int mid = this.used.nextClearBit(0);
      if (mid >= this.capacity) {
         return -1;
      }

      this.used.set(mid);
      this.live++;
      return mid;
   }

   void release(int mid, long serial) {
      if (this.releaseCount == this.releaseMid.length) {
         int n = this.releaseMid.length * 2;
         int[] mids = new int[n];
         long[] serials = new long[n];

         for (int i = 0; i < this.releaseCount; i++) {
            int j = (this.releaseHead + i) % this.releaseMid.length;
            mids[i] = this.releaseMid[j];
            serials[i] = this.releaseSerial[j];
         }

         this.releaseMid = mids;
         this.releaseSerial = serials;
         this.releaseHead = 0;
      }

      int tail = (this.releaseHead + this.releaseCount) % this.releaseMid.length;
      this.releaseMid[tail] = mid;
      this.releaseSerial[tail] = serial;
      this.releaseCount++;
      this.live--;
      this.releasedTotal++;
   }

   void beginFrame(long serial) {
      while (this.releaseCount > 0 && serial - this.releaseSerial[this.releaseHead] >= 3L) {
         this.used.clear(this.releaseMid[this.releaseHead]);
         this.releaseHead = (this.releaseHead + 1) % this.releaseMid.length;
         this.releaseCount--;
      }
   }

   int capacity() {
      return this.capacity;
   }

   int live() {
      return this.live;
   }

   int occupied() {
      return this.used.cardinality();
   }

   long releasedTotal() {
      return this.releasedTotal;
   }

   void growTo(int newCapacity) {
      if (newCapacity > this.capacity) {
         this.capacity = newCapacity;
      }
   }

   void setCapacity(int newCapacity) {
      if (newCapacity < this.capacity && this.used.length() > newCapacity) {
         throw new IllegalStateException("mirror capacity " + newCapacity + " below an id already in use (" + (this.used.length() - 1) + ")");
      }

      this.capacity = newCapacity;
   }

   int[] pendingReleases() {
      int[] out = new int[this.releaseCount];

      for (int i = 0; i < this.releaseCount; i++) {
         out[i] = this.releaseMid[(this.releaseHead + i) % this.releaseMid.length];
      }

      return out;
   }

   @Override
   public String toString() {
      return "ids{capacity="
         + this.capacity
         + ", live="
         + this.live
         + ", occupied="
         + this.occupied()
         + ", pending="
         + Arrays.toString(this.pendingReleases())
         + "}";
   }
}
