package nvidiumplus.engine.sodium;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Random;
import java.util.Set;
import net.caffeinemc.mods.sodium.client.SodiumClientMod;
import net.caffeinemc.mods.sodium.client.render.chunk.RenderSectionManager;
import net.caffeinemc.mods.sodium.client.render.chunk.data.SectionRenderDataStorage;
import net.caffeinemc.mods.sodium.client.render.chunk.lists.ChunkRenderList;
import net.caffeinemc.mods.sodium.client.render.chunk.lists.ChunkRenderListIterable;
import net.caffeinemc.mods.sodium.client.render.chunk.region.RenderRegion;
import net.caffeinemc.mods.sodium.client.render.chunk.region.RenderRegion.DeviceResources;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.DefaultTerrainRenderPasses;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import net.caffeinemc.mods.sodium.client.render.viewport.CameraTransform;
import net.caffeinemc.mods.sodium.client.util.iterator.ByteIterator;
import nvidiumplus.engine.NvidiumPlusLog;
import nvidiumplus.engine.sodium.mixin.ChunkRenderListAccessor;
import nvidiumplus.engine.vk.SodiumFrameRing;
import nvidiumplus.engine.vk.SodiumMirrorGpu;
import nvidiumplus.engine.vk.SodiumTerrainDrawer;
import nvidiumplus.engine.vk.TerrainDrawer;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.system.MemoryUtil;

public final class NvidiumPlusRegionMirror {
   private static final int PASS_BLOCK_BYTES = 12288;
   private static final int RECORD_BYTES = 48;
   private static final int ROW_BYTES = 64;
   private static final int LIST_ENTRY_BYTES = 128;
   private static final int INDIRECT_BYTES = 12;
   private static final int RECORD_COUNTS = 20;
   private static final int RECORD_RUNS = 7;
   private static volatile NvidiumPlusRegionMirror current;
   private static volatile long mutationsTotal;
   private static volatile long deletesTotal;
   private final RenderSectionManager manager;
   private final NvidiumPlusSodiumRegionIds ids;
   private final NvidiumPlusSodiumBufferKeys keys = new NvidiumPlusSodiumBufferKeys();
   private final ArrayList<RenderRegion> dirty = new ArrayList<>();
   private int[] dead = new int[256];
   private int deadCount;
   private RenderRegion[] regionOf;
   private GpuBuffer[] bufferOf;
   private int[] shadowKey;
   private int[] shadowPop;
   private int[] shadowMin;
   private int[] shadowMax;
   private int[] shadowProbe;
   private boolean[] shadowLive;
   private int[] committedEpoch;
   private long[] listedAt;
   private long[] sodiumListedAt;
   private int[] shadowMask;
   private boolean tracking;
   private long serial;
   private long deadRowsTotal;
   private long midMissingTotal;
   private long keyMismatchTotal;
   private RenderRegion[] listRegion = new RenderRegion[1024];
   private int[] listMid = new int[1024];
   private int[] listGroup = new int[1024];
   private int[] listMask = new int[8192];
   private static final int MAP_WORDS = 4;
   private final int[] scratchMask = new int[8];
   private long buildFrames;
   private long listSerial = 2L;
   private int prevListCount = -1;
   private boolean frameUsesMap;
   private boolean frameVerifies;
   private int listCount;
   private int[] groupCursor = new int[16];
   private int[] groupWgCursor = new int[16];
   private final int[] occScratch = new int[8];
   private long scratch = MemoryUtil.nmemAllocChecked(12288L);
   private final Matrix4f mvp = new Matrix4f();
   private final float[] planes = new float[24];
   private final boolean audit = SodiumTerrainDrawer.mirrorAuditEnabled();
   private long auditBase;
   private int auditCapacity;
   private long auditFrames;
   private long auditMismatches;
   private long gpuMismatches;
   private int auditPendingMid = -1;
   private int auditPendingPass;
   private int auditPendingEpoch;
   private final Random auditRandom = new Random(1L);
   public static final int CENSUS_LOADED = 0;
   public static final int CENSUS_LISTABLE = 1;
   public static final int CENSUS_UNMIRRORED = 2;
   public static final int CENSUS_ORPHANED = 3;
   public static final int CENSUS_MIRRORED = 4;

   NvidiumPlusRegionMirror(RenderSectionManager manager) {
      this.manager = manager;
      int capacity = SodiumTerrainDrawer.initialCapacity();
      this.ids = new NvidiumPlusSodiumRegionIds(capacity);
      this.allocateShadow(capacity);
      SodiumTerrainDrawer.resetRowLedger();
      current = this;
   }

   private void allocateShadow(int capacity) {
      this.regionOf = new RenderRegion[capacity];
      this.bufferOf = new GpuBuffer[capacity];
      this.shadowKey = new int[capacity];
      this.shadowPop = new int[capacity];
      this.shadowMin = new int[capacity];
      this.shadowMax = new int[capacity];
      this.shadowProbe = new int[capacity * 2];
      this.shadowLive = new boolean[capacity];
      this.committedEpoch = new int[capacity];
      this.listedAt = new long[capacity];
      this.sodiumListedAt = new long[capacity];
      this.shadowMask = new int[capacity * 8];
      if (this.audit) {
         this.auditBase = MemoryUtil.nmemCallocChecked(capacity, 24576L);
         this.auditCapacity = capacity;
      }
   }

   public static void onMutation(RenderRegion region) {
      mutationsTotal++;
      NvidiumPlusRegionMirror m = current;
      if (m != null && m.tracking) {
         m.markDirty(region);
      }
   }

   public static void onDelete(RenderRegion region) {
      deletesTotal++;
      if (region instanceof NvidiumPlusRegionCacheHolder holder) {
         int mid = holder.nvidiumplus$mid();
         NvidiumPlusRegionMirror m = current;
         if (mid >= 0 && m != null) {
            m.releaseMid(mid, region);
         }

         holder.nvidiumplus$setMid(-1);
         holder.nvidiumplus$setDirtyQueued(false);
      }
   }

   public static long mutationsTotal() {
      return mutationsTotal;
   }

   public static long deletesTotal() {
      return deletesTotal;
   }

   private void fillGeometryMask(ChunkRenderList list, int base) {
      if (this.frameUsesMap && this.fillFromMap(list, base)) {
         if (this.frameVerifies) {
            drainInto(this.scratchMask, 0, list);
            int diff = 0;

            for (int w = 0; w < 8; w++) {
               if (this.listMask[base + w] != this.scratchMask[w]) {
                  diff++;
               }
            }

            SodiumTerrainDrawer.reportListMapCompare(diff);
            if (diff != 0) {
               System.arraycopy(this.scratchMask, 0, this.listMask, base, 8);
               this.disarmMap("the map and the drain disagreed in " + diff + " of 8 words");
            }
         }
      } else {
         drainInto(this.listMask, base, list);
      }
   }

   private boolean fillFromMap(ChunkRenderList list, int base) {
      long[] map;
      try {
         map = ((ChunkRenderListAccessor)list).nvidiumplus$sectionsWithGeometryMap();
      } catch (Throwable t) {
         this.disarmMap("reading the geometry map threw " + t);
         return false;
      }

      if (map != null && map.length == 4) {
         int bits = 0;

         for (int k = 0; k < 4; k++) {
            long word = map[k];
            bits += Long.bitCount(word);
            this.listMask[base + (k << 1)] = (int)word;
            this.listMask[base + (k << 1) + 1] = (int)(word >>> 32);
         }

         int counted = list.getSectionsWithGeometryCount();
         if (bits != counted) {
            this.disarmMap("the map holds " + bits + " bits and the list reports " + counted + " sections with geometry");
            return false;
         } else {
            return true;
         }
      } else {
         this.disarmMap("the geometry map is " + (map == null ? "null" : map.length + " longs") + ", not 4");
         return false;
      }
   }

   private static void drainInto(int[] target, int base, ChunkRenderList list) {
      Arrays.fill(target, base, base + 8, 0);
      ByteIterator sections = list.sectionsWithGeometryIterator(false);
      if (sections != null) {
         while (sections.hasNext()) {
            int b = sections.nextByteAsInt() & 0xFF;
            target[base + (b >>> 5)] = target[base + (b >>> 5)] | 1 << (b & 31);
         }
      }
   }

   private void disarmMap(String reason) {
      this.frameUsesMap = false;
      SodiumTerrainDrawer.disarmListMap(reason);
   }

   private void markDirty(RenderRegion region) {
      if (region instanceof NvidiumPlusRegionCacheHolder holder && !holder.nvidiumplus$dirtyQueued()) {
         holder.nvidiumplus$setDirtyQueued(true);
         this.dirty.add(region);
      }
   }

   int bufferKeysIssued() {
      return this.keys.issued();
   }

   private void releaseMid(int mid, RenderRegion region) {
      if (mid < this.regionOf.length && this.regionOf[mid] == region) {
         this.regionOf[mid] = null;
         if (this.bufferOf[mid] != null) {
            this.keys.release(this.bufferOf[mid]);
            this.bufferOf[mid] = null;
         }

         this.shadowLive[mid] = false;
         this.shadowKey[mid] = 0;
         this.listedAt[mid] = 0L;
         this.sodiumListedAt[mid] = 0L;
         SodiumTerrainDrawer.recordRowRelease(mid);
         Arrays.fill(this.shadowMask, mid * 8, mid * 8 + 8, 0);
         if (this.deadCount == this.dead.length) {
            this.dead = Arrays.copyOf(this.dead, this.dead.length * 2);
         }

         this.dead[this.deadCount++] = mid;
      }
   }

   void remirrorAll() {
      this.tracking = false;
      this.ensureTracking();
   }

   void ensureTracking() {
      if (!this.tracking) {
         this.tracking = true;

         for (RenderRegion region : this.manager.regions.getLoadedRegions()) {
            if (region instanceof NvidiumPlusRegionCacheHolder holder) {
               holder.nvidiumplus$setDirtyQueued(false);
            }

            this.markDirty(region);
         }
      }
   }

   void sleep() {
      this.tracking = false;
   }

   boolean tracking() {
      return this.tracking;
   }

   void beginFrame(long frameSerial) {
      this.serial = frameSerial;
      this.ids.beginFrame(frameSerial);
   }

   void syncCapacity(int capacity) {
      if (capacity <= this.regionOf.length) {
         this.ids.setCapacity(capacity);
      } else {
         this.regionOf = Arrays.copyOf(this.regionOf, capacity);
         this.bufferOf = Arrays.copyOf(this.bufferOf, capacity);
         this.shadowKey = Arrays.copyOf(this.shadowKey, capacity);
         this.shadowPop = Arrays.copyOf(this.shadowPop, capacity);
         this.shadowMin = Arrays.copyOf(this.shadowMin, capacity);
         this.shadowMax = Arrays.copyOf(this.shadowMax, capacity);
         this.shadowProbe = Arrays.copyOf(this.shadowProbe, capacity * 2);
         this.shadowLive = Arrays.copyOf(this.shadowLive, capacity);
         this.committedEpoch = Arrays.copyOf(this.committedEpoch, capacity);
         this.listedAt = Arrays.copyOf(this.listedAt, capacity);
         this.sodiumListedAt = Arrays.copyOf(this.sodiumListedAt, capacity);
         this.shadowMask = Arrays.copyOf(this.shadowMask, capacity * 8);
         if (this.audit) {
            long grown = MemoryUtil.nmemCallocChecked(capacity, 24576L);
            MemoryUtil.memCopy(this.auditBase, grown, this.auditCapacity * 2L * 12288L);
            MemoryUtil.nmemFree(this.auditBase);
            this.auditBase = grown;
            this.auditCapacity = capacity;
         }

         this.ids.setCapacity(capacity);
      }
   }

   int growthNeeded() {
      int fresh = 0;
      int i = 0;

      for (int n = this.dirty.size(); i < n; i++) {
         if (this.dirty.get(i) instanceof NvidiumPlusRegionCacheHolder holder && holder.nvidiumplus$dirtyQueued() && holder.nvidiumplus$mid() < 0) {
            fresh++;
         }
      }

      i = this.ids.occupied() + fresh;
      int capacity = this.ids.capacity();
      if (i <= capacity) {
         return 0;
      }

      int target = Math.max(capacity + capacity / 2, i);
      int round = 64;
      return (target + round - 1) / round * round;
   }

   int commit(SodiumMirrorGpu gpu, boolean[] declined) {
      if (!gpu.beginCommit(this.serial)) {
         declined[0] = true;
         return 0;
      }

      for (int i = 0; i < this.deadCount; i++) {
         gpu.zeroRow(this.dead[i]);
         this.ids.release(this.dead[i], this.serial);
      }

      this.deadRowsTotal = this.deadRowsTotal + this.deadCount;
      this.deadCount = 0;
      int committed = 0;
      int n = this.dirty.size();

      int i;
      for (i = 0; i < n; i++) {
         RenderRegion region = this.dirty.get(i);
         if (region instanceof NvidiumPlusRegionCacheHolder holder && holder.nvidiumplus$dirtyQueued()) {
            int mid = holder.nvidiumplus$mid();
            if (mid >= 0 && (mid >= this.regionOf.length || this.regionOf[mid] != region)) {
               mid = -1;
            }

            if (mid < 0) {
               mid = this.ids.acquire();
               if (mid < 0) {
                  declined[0] = true;
                  break;
               }

               holder.nvidiumplus$setMid(mid);
               this.regionOf[mid] = region;
            }

            if (!this.commitRegion(gpu, region, holder, mid)) {
               declined[0] = true;
               break;
            }

            holder.nvidiumplus$setDirtyQueued(false);
            committed++;
         }
      }

      if (i >= n) {
         this.dirty.clear();
      } else {
         this.dirty.subList(0, i).clear();
      }

      return committed;
   }

   private boolean commitRegion(SodiumMirrorGpu gpu, RenderRegion region, NvidiumPlusRegionCacheHolder holder, int mid) {
      DeviceResources resources = region.getResources();
      GpuBuffer geometry = resources == null ? null : resources.getGeometryBuffer();
      boolean live = geometry != null;
      int[] occ = this.occScratch;
      Arrays.fill(occ, 0);

      for (int pass = 0; pass < 2; pass++) {
         SectionRenderDataStorage storage = region.getStorage(passOf(pass));
         long heap = storage == null ? 0L : storage.getDataPointer(0);
         long copy = this.audit ? this.auditBlock(mid, pass) : this.scratch;
         if (heap == 0L) {
            gpu.zeroPassBlock(mid, pass);
            if (this.audit) {
               MemoryUtil.memSet(copy, 0, 12288L);
            }
         } else {
            MemoryUtil.memCopy(heap, copy, 12288L);
            occupancy(copy, occ);
            long staged = gpu.stageBlock(12288);
            if (staged == 0L) {
               return false;
            }

            MemoryUtil.memCopy(copy, staged, 12288L);
            gpu.copyPassBlock(mid, pass, staged);
         }
      }

      int pop = 0;
      int minX = 8;
      int minY = 4;
      int minZ = 8;
      int maxX = -1;
      int maxY = -1;
      int maxZ = -1;

      for (int w = 0; w < 8; w++) {
         for (int word = occ[w]; word != 0; pop++) {
            int bit = Integer.numberOfTrailingZeros(word);
            word &= word - 1;
            int slot = w << 5 | bit;
            int x = slot >>> 5 & 7;
            int y = slot & 3;
            int z = slot >>> 2 & 7;
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            minZ = Math.min(minZ, z);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
            maxZ = Math.max(maxZ, z);
         }
      }

      System.arraycopy(occ, 0, this.shadowMask, mid * 8, 8);
      int slot0 = -1;

      for (int w = 0; w < 8 && slot0 < 0; w++) {
         if (occ[w] != 0) {
            slot0 = w << 5 | Integer.numberOfTrailingZeros(occ[w]);
         }
      }

      for (int pass = 0; pass < 2; pass++) {
         int probe = 0;
         if (slot0 >= 0) {
            SectionRenderDataStorage probeStorage = region.getStorage(passOf(pass));
            long probeHeap = probeStorage == null ? 0L : probeStorage.getDataPointer(0);
            if (probeHeap != 0L) {
               probe = MemoryUtil.memGetInt(probeHeap + slot0 * 48L + 4L);
            }
         }

         this.shadowProbe[mid * 2 + pass] = probe;
      }

      int occMin = pop == 0 ? 0 : minX | minY << 8 | minZ << 16;
      int occMax = pop == 0 ? 0 : maxX | maxY << 8 | maxZ << 16;
      int key = live ? this.keys.keyOf(geometry) : 0;
      long row = gpu.stageBlock(64);
      if (row == 0L) {
         return false;
      }

      MemoryUtil.memPutInt(row + 0L, region.getChunkX());
      MemoryUtil.memPutInt(row + 4L, region.getChunkY());
      MemoryUtil.memPutInt(row + 8L, region.getChunkZ());
      MemoryUtil.memPutInt(row + 12L, live ? 1 : 0);

      for (int w = 0; w < 8; w++) {
         MemoryUtil.memPutInt(row + 16L + 4L * w, occ[w]);
      }

      MemoryUtil.memPutInt(row + 48L, key);
      MemoryUtil.memPutInt(row + 52L, pop);
      MemoryUtil.memPutInt(row + 56L, occMin);
      MemoryUtil.memPutInt(row + 60L, occMax);
      gpu.copyRow(mid, row);
      SodiumTerrainDrawer.recordRowWrite(mid, region.getChunkX(), region.getChunkY(), region.getChunkZ(), key, this.keys.issued());
      if (this.bufferOf[mid] != geometry) {
         if (this.bufferOf[mid] != null) {
            this.keys.release(this.bufferOf[mid]);
         }

         if (geometry != null) {
            this.keys.retain(geometry);
         }

         this.bufferOf[mid] = geometry;
      }

      this.shadowKey[mid] = key;
      this.shadowPop[mid] = pop;
      this.shadowMin[mid] = occMin;
      this.shadowMax[mid] = occMax;
      this.shadowLive[mid] = live;
      this.committedEpoch[mid] = holder.nvidiumplus$epoch();
      return true;
   }

   private static void occupancy(long block, int[] occ) {
      for (int slot = 0; slot < 256; slot++) {
         long counts = block + slot * 48L + 20L;
         int any = 0;

         for (int i = 0; i < 7; i++) {
            any |= MemoryUtil.memGetInt(counts + 4L * i);
         }

         if (any != 0) {
            occ[slot >>> 5] = occ[slot >>> 5] | 1 << (slot & 31);
         }
      }
   }

   private static TerrainRenderPass passOf(int pass) {
      return pass == 0 ? DefaultTerrainRenderPasses.SOLID : DefaultTerrainRenderPasses.CUTOUT;
   }

   private long auditBlock(int mid, int pass) {
      return this.auditBase + (mid * 2L + pass) * 12288L;
   }

   int buildFrame(
      ChunkRenderListIterable lists,
      CameraTransform camera,
      Matrix4fc modelView,
      Matrix4fc projection,
      boolean frustumRegions,
      SodiumFrameRing ring,
      NvidiumPlusRegionMirror.FrameOutput out
   ) {
      long t0;
      boolean var10001;
      label274: {
         label273: {
            t0 = System.nanoTime();
            long parity = this.buildFrames++;
            String listMapMode = SodiumTerrainDrawer.listMapMode();
            boolean mapUsable = NvidiumPlusSodiumHooks.geometryMapFound() && !SodiumTerrainDrawer.listMapDisarmed();
            this.frameVerifies = mapUsable && "verify".equals(listMapMode);
            if (mapUsable) {
               switch (listMapMode) {
                  case "on":
                  case "verify":
                     break label273;
                  case "ab":
                     if ((parity & 1L) == 1L) {
                        break label273;
                     }
               }
            }

            var10001 = false;
            break label274;
         }

         var10001 = true;
      }

      this.frameUsesMap = var10001;
      boolean faceCull = NvidiumPlusSodiumDrawList.FACE_CULL;

      try {
         faceCull = faceCull && SodiumClientMod.options().performance.useBlockFaceCulling;
      } catch (Throwable ignored) {
         faceCull = false;
      }

      out.faceAll = !faceCull;
      this.listCount = 0;
      int dropped = 0;
      int capacity = ring.capacity();
      long nowSerial = this.listSerial + 1L;
      int gaps = 0;
      int previousListCount = this.prevListCount;
      int unreachable = 0;
      int unreachableRegions = 0;
      if (!frustumRegions) {
         for (ChunkRenderList list : lists) {
            RenderRegion region = list.getRegion();
            if (region != null) {
               DeviceResources resources = region.getResources();
               if (resources == null) {
                  dropped += this.mirroredDrop(region);
               } else {
                  GpuBuffer geometry = resources.getGeometryBuffer();
                  if (geometry == null) {
                     dropped += this.mirroredDrop(region);
                  } else {
                     int mid = this.resolve(region, geometry);
                     if (mid < 0) {
                        return -1;
                     }

                     if (this.listCount >= capacity) {
                        this.midMissingTotal++;
                        return -1;
                     }

                     int e = this.append(region, mid);
                     this.fillGeometryMask(list, e * 8);
                     int missing = this.unreachableSections(region, mid, e * 8);
                     if (missing > 0) {
                        unreachable += missing;
                        unreachableRegions++;
                        this.markDirty(region);
                     }
                  }
               }
            }
         }
      } else {
         this.computePlanes(modelView, projection);

         for (RenderRegion region : this.manager.regions.getLoadedRegions()) {
            DeviceResources resources = region.getResources();
            if (resources == null) {
               dropped += this.mirroredDrop(region);
            } else {
               GpuBuffer geometry = resources.getGeometryBuffer();
               if (geometry == null) {
                  dropped += this.mirroredDrop(region);
               } else {
                  float lx = (float)(region.getOriginX() - camera.x);
                  float ly = (float)(region.getOriginY() - camera.y);
                  float lz = (float)(region.getOriginZ() - camera.z);
                  if (this.boxInFrustum(lx, ly, lz, lx + 128.0F, ly + 64.0F, lz + 128.0F)) {
                     int mid = this.resolve(region, geometry);
                     if (mid < 0) {
                        return -1;
                     }

                     if (this.listCount >= capacity) {
                        this.midMissingTotal++;
                        return -1;
                     }

                     int e = this.append(region, mid);
                     Arrays.fill(this.listMask, e * 8, e * 8 + 8, -1);
                  }
               }
            }
         }
      }

      boolean comparable = previousListCount >= 0 && previousListCount * 100L >= this.listCount * 95L;

      for (int e = 0; e < this.listCount; e++) {
         int mid = this.listMid[e];
         if (comparable && this.listedAt[mid] == nowSerial - 2L) {
            gaps++;
         }

         this.listedAt[mid] = nowSerial;
         this.sodiumListedAt[mid] = nowSerial;
      }

      this.listSerial = nowSerial;
      int held = 0;
      if (this.listCount < capacity && SodiumTerrainDrawer.regionHoldEnabled()) {
         this.computePlanes(modelView, projection);

         for (int mid = 0; mid < this.regionOf.length && this.listCount < capacity; mid++) {
            if (this.sodiumListedAt[mid] == nowSerial - 1L && this.listedAt[mid] != nowSerial) {
               RenderRegion region = this.regionOf[mid];
               if (region != null) {
                  DeviceResources resources = region.getResources();
                  GpuBuffer geometry = resources == null ? null : resources.getGeometryBuffer();
                  if (geometry != null) {
                     float lx = (float)(region.getOriginX() - camera.x);
                     float ly = (float)(region.getOriginY() - camera.y);
                     float lz = (float)(region.getOriginZ() - camera.z);
                     if (this.boxInFrustum(lx, ly, lz, lx + 128.0F, ly + 64.0F, lz + 128.0F)
                        && region instanceof NvidiumPlusRegionCacheHolder holder
                        && holder.nvidiumplus$mid() == mid
                        && this.shadowLive[mid]
                        && this.keys.peekKey(geometry) == this.shadowKey[mid]
                        && holder.nvidiumplus$epoch() == this.committedEpoch[mid]) {
                        int e = this.append(region, mid);
                        Arrays.fill(this.listMask, e * 8, e * 8 + 8, -1);
                        this.listedAt[mid] = nowSerial;
                        held++;
                     }
                  }
               }
            }
         }
      }

      SodiumTerrainDrawer.reportRegionsHeld(held);
      this.prevListCount = this.listCount;
      out.groupCount = 0;

      for (int e = 0; e < this.listCount; e++) {
         int mid = this.listMid[e];
         int key = this.shadowKey[mid];
         int g = -1;

         for (int k = 0; k < out.groupCount; k++) {
            if (out.groupKeys[k] == key) {
               g = k;
               break;
            }
         }

         if (g < 0) {
            out.ensureGroups(out.groupCount + 1);
            g = out.groupCount++;
            out.groupKeys[g] = key;
            out.groupBuffers[g] = this.bufferOf[mid];
            out.groupCounts[g] = 0;
         }

         out.groupCounts[g]++;
         this.listGroup[e] = g;
      }

      if (out.groupCount > 64) {
         this.midMissingTotal++;
         return -1;
      }

      if (this.groupCursor.length < out.groupCount) {
         this.groupCursor = new int[Math.max(out.groupCount, this.groupCursor.length * 2)];
         this.groupWgCursor = new int[this.groupCursor.length];
      }

      out.groupStart[0] = 0;

      for (int g = 0; g < out.groupCount; g++) {
         out.groupStart[g + 1] = out.groupStart[g] + out.groupCounts[g];
         this.groupCursor[g] = out.groupStart[g];
         this.groupWgCursor[g] = 0;
      }

      int taskWg = Math.max(1, TerrainDrawer.taskWorkgroupSections());
      long listAddress = ring.listAddress();
      long indirectAddress = ring.indirectAddress();
      long sig = -7046029254386353131L;
      int listedSections = 0;

      for (int e = 0; e < this.listCount; e++) {
         int mid = this.listMid[e];
         RenderRegion region = this.listRegion[e];
         int i = this.groupCursor[this.listGroup[e]]++;
         long a = listAddress + i * 128L;
         MemoryUtil.memPutFloat(a + 0L, (float)(region.getOriginX() - camera.x));
         MemoryUtil.memPutFloat(a + 0L + 4L, (float)(region.getOriginY() - camera.y));
         MemoryUtil.memPutFloat(a + 0L + 8L, (float)(region.getOriginZ() - camera.z));
         int pop = this.shadowPop[mid];
         int wg = (pop + taskWg - 1) / taskWg;
         int g = this.listGroup[e];
         this.groupWgCursor[g] = this.groupWgCursor[g] + wg;
         MemoryUtil.memPutInt(a + 12L, this.groupWgCursor[g]);
         MemoryUtil.memPutInt(a + 16L, mid);
         MemoryUtil.memPutInt(a + 20L, pop);
         MemoryUtil.memPutInt(a + 24L, this.shadowMin[mid]);
         MemoryUtil.memPutInt(a + 28L, this.shadowMax[mid]);
         int base = e * 8;

         for (int w = 0; w < 8; w++) {
            MemoryUtil.memPutInt(a + 32L + 4L * w, this.listMask[base + w]);
         }

         long r = a + 64L;
         MemoryUtil.memPutInt(r + 0L, region.getChunkX());
         MemoryUtil.memPutInt(r + 4L, region.getChunkY());
         MemoryUtil.memPutInt(r + 8L, region.getChunkZ());
         MemoryUtil.memPutInt(r + 12L, this.shadowLive[mid] ? 1 : 0);
         int maskBase = mid * 8;

         for (int w = 0; w < 8; w++) {
            MemoryUtil.memPutInt(r + 16L + 4L * w, this.shadowMask[maskBase + w]);
         }

         MemoryUtil.memPutInt(r + 48L, this.shadowKey[mid]);
         MemoryUtil.memPutInt(r + 52L, pop);
         MemoryUtil.memPutInt(a + 120L, this.shadowProbe[mid * 2 + 0]);
         MemoryUtil.memPutInt(a + 124L, this.shadowProbe[mid * 2 + 1]);
         long ia = indirectAddress + i * 12L;
         MemoryUtil.memPutInt(ia, wg);
         MemoryUtil.memPutInt(ia + 4L, 1);
         MemoryUtil.memPutInt(ia + 8L, 1);
         sig = (sig ^ mid) * 1099511628211L;
         listedSections += pop;
         sig = (sig ^ pop) * 1099511628211L;
      }

      long groupAddress = ring.indirectGroupAddress();

      for (int g = 0; g < out.groupCount; g++) {
         long ga = groupAddress + g * 12L;
         MemoryUtil.memPutInt(ga, this.groupWgCursor[g]);
         MemoryUtil.memPutInt(ga + 4L, 1);
         MemoryUtil.memPutInt(ga + 8L, 1);
      }

      Arrays.fill(this.listRegion, 0, this.listCount, null);
      out.listedRegions = this.listCount;
      out.oneFrameGaps = gaps;
      out.listedSections = listedSections;
      out.droppedMirrored = dropped;
      out.unreachableSections = unreachable;
      out.unreachableRegions = unreachableRegions;
      out.signature = sig;
      out.loopNanos = System.nanoTime() - t0;
      SodiumTerrainDrawer.reportListMapFrame(this.frameUsesMap, out.loopNanos, this.listCount);
      return this.listCount;
   }

   private int resolve(RenderRegion region, GpuBuffer geometry) {
      if (region instanceof NvidiumPlusRegionCacheHolder holder) {
         int mid = holder.nvidiumplus$mid();
         if (mid < 0 || mid >= this.regionOf.length || this.regionOf[mid] != region) {
            this.midMissingTotal++;
            this.markDirty(region);
            return -1;
         }

         if (this.shadowLive[mid] && this.keys.peekKey(geometry) == this.shadowKey[mid] && holder.nvidiumplus$epoch() == this.committedEpoch[mid]) {
            return mid;
         }

         this.keyMismatchTotal++;
         this.markDirty(region);
         return -1;
      } else {
         this.midMissingTotal++;
         return -1;
      }
   }

   private int mirroredDrop(RenderRegion region) {
      if (!(region instanceof NvidiumPlusRegionCacheHolder holder)) {
         return 0;
      } else {
         int mid = holder.nvidiumplus$mid();
         return mid >= 0 && mid < this.shadowLive.length && this.regionOf[mid] == region && this.shadowLive[mid] ? 1 : 0;
      }
   }

   private int unreachableSections(RenderRegion region, int mid, int base) {
      int m = mid * 8;
      boolean any = false;

      for (int w = 0; w < 8; w++) {
         if ((this.listMask[base + w] & ~this.shadowMask[m + w]) != 0) {
            any = true;
            break;
         }
      }

      if (!any) {
         return 0;
      }

      long solid = passDataPointer(region, 0);
      long cutout = passDataPointer(region, 1);
      if (solid == 0L && cutout == 0L) {
         return 0;
      }

      int missing = 0;

      for (int w = 0; w < 8; w++) {
         int bits = this.listMask[base + w] & ~this.shadowMask[m + w];

         while (bits != 0) {
            int slot = w << 5 | Integer.numberOfTrailingZeros(bits);
            bits &= bits - 1;
            if (recordHasGeometry(solid, slot) || recordHasGeometry(cutout, slot)) {
               missing++;
            }
         }
      }

      return missing;
   }

   private static long passDataPointer(RenderRegion region, int pass) {
      SectionRenderDataStorage storage = region.getStorage(passOf(pass));
      return storage == null ? 0L : storage.getDataPointer(0);
   }

   private static boolean recordHasGeometry(long block, int slot) {
      if (block == 0L) {
         return false;
      }

      long counts = block + slot * 48L + 20L;
      int any = 0;

      for (int i = 0; i < 7; i++) {
         any |= MemoryUtil.memGetInt(counts + 4L * i);
      }

      return any != 0;
   }

   private int append(RenderRegion region, int mid) {
      int e = this.listCount;
      if (e == this.listMid.length) {
         int n = this.listMid.length * 2;
         this.listRegion = Arrays.copyOf(this.listRegion, n);
         this.listMid = Arrays.copyOf(this.listMid, n);
         this.listGroup = Arrays.copyOf(this.listGroup, n);
         this.listMask = Arrays.copyOf(this.listMask, n * 8);
      }

      this.listRegion[e] = region;
      this.listMid[e] = mid;
      this.listCount = e + 1;
      return e;
   }

   private void computePlanes(Matrix4fc modelView, Matrix4fc projection) {
      Matrix4f m = this.mvp.set(projection).mul(modelView);
      float[] p = this.planes;
      plane(p, 0, m.m03() + m.m00(), m.m13() + m.m10(), m.m23() + m.m20(), m.m33() + m.m30());
      plane(p, 4, m.m03() - m.m00(), m.m13() - m.m10(), m.m23() - m.m20(), m.m33() - m.m30());
      plane(p, 8, m.m03() + m.m01(), m.m13() + m.m11(), m.m23() + m.m21(), m.m33() + m.m31());
      plane(p, 12, m.m03() - m.m01(), m.m13() - m.m11(), m.m23() - m.m21(), m.m33() - m.m31());
      plane(p, 16, m.m03() + m.m02(), m.m13() + m.m12(), m.m23() + m.m22(), m.m33() + m.m32());
      plane(p, 20, m.m03() - m.m02(), m.m13() - m.m12(), m.m23() - m.m22(), m.m33() - m.m32());
   }

   private static void plane(float[] p, int o, float a, float b, float c, float d) {
      p[o] = a;
      p[o + 1] = b;
      p[o + 2] = c;
      p[o + 3] = d;
   }

   private boolean boxInFrustum(float lx, float ly, float lz, float hx, float hy, float hz) {
      float[] p = this.planes;

      for (int o = 0; o < 24; o += 4) {
         float a = p[o];
         float b = p[o + 1];
         float c = p[o + 2];
         float d = p[o + 3];
         float px = a > 0.0F ? hx : lx;
         float py = b > 0.0F ? hy : ly;
         float pz = c > 0.0F ? hz : lz;
         if (a * px + b * py + c * pz + d < 0.0F) {
            return false;
         }
      }

      return true;
   }

   long audit(SodiumMirrorGpu gpu, long statsFrames) {
      if (!this.audit) {
         return 0L;
      }

      this.auditFrames++;
      long mismatches = 0L;
      int live = 0;

      for (int mid = 0; mid < this.regionOf.length; mid++) {
         RenderRegion region = this.regionOf[mid];
         if (region != null && region instanceof NvidiumPlusRegionCacheHolder holder && !holder.nvidiumplus$dirtyQueued()) {
            live++;

            for (int pass = 0; pass < 2; pass++) {
               SectionRenderDataStorage storage = region.getStorage(passOf(pass));
               long heap = storage == null ? 0L : storage.getDataPointer(0);
               long differing = differingBytes(heap, this.auditBlock(mid, pass));
               mismatches += differing;
               if (differing > 0L) {
                  SodiumTerrainDrawer.reportAuditMismatch(mid, pass, differing, region.getChunkX(), region.getChunkY(), region.getChunkZ());
               }
            }
         }
      }

      this.auditMismatches += mismatches;
      long back = gpu.takeBlockReadback(statsFrames);
      if (back != 0L && this.auditPendingMid >= 0) {
         int mid = this.auditPendingMid;
         if (this.regionOf[mid] != null && this.committedEpoch[mid] == this.auditPendingEpoch) {
            this.gpuMismatches = this.gpuMismatches + differingBytes(back, this.auditBlock(mid, this.auditPendingPass));
         }

         this.auditPendingMid = -1;
      }

      if (this.auditPendingMid < 0 && live > 0 && gpu.blockReadbackMid() < 0) {
         int tries = 0;

         int mid;
         do {
            mid = this.auditRandom.nextInt(this.regionOf.length);
         } while (this.regionOf[mid] == null && ++tries < 64);

         if (this.regionOf[mid] != null) {
            this.auditPendingMid = mid;
            this.auditPendingPass = this.auditRandom.nextInt(2);
            this.auditPendingEpoch = this.committedEpoch[mid];
            gpu.requestBlockReadback(mid, this.auditPendingPass);
         }
      }

      SodiumTerrainDrawer.reportAudit(this.auditFrames, this.auditMismatches, this.gpuMismatches);
      return mismatches;
   }

   private static long differingBytes(long a, long b) {
      long diff = 0L;

      for (long o = 0L; o < 12288L; o += 8L) {
         long x = a == 0L ? 0L : MemoryUtil.memGetLong(a + o);
         long y = MemoryUtil.memGetLong(b + o);
         if (x != y) {
            long v = x ^ y;

            for (int k = 0; k < 8; k++) {
               if ((v >>> 8 * k & 255L) != 0L) {
                  diff++;
               }
            }
         }
      }

      return diff;
   }

   int midsLive() {
      return this.ids.live();
   }

   int midsCapacity() {
      return this.ids.capacity();
   }

   long midsReleased() {
      return this.ids.releasedTotal();
   }

   int bufferKeys() {
      return this.keys.count();
   }

   long deadRows() {
      return this.deadRowsTotal;
   }

   long midMissing() {
      return this.midMissingTotal;
   }

   long keyMismatch() {
      return this.keyMismatchTotal;
   }

   int dirtyCount() {
      return this.dirty.size();
   }

   public static int[] censusForTest() {
      NvidiumPlusRegionMirror m = current;
      if (m == null) {
         return null;
      }

      Set<RenderRegion> loaded = Collections.newSetFromMap(new IdentityHashMap<>());
      int listable = 0;
      int unmirrored = 0;

      for (RenderRegion region : m.manager.regions.getLoadedRegions()) {
         loaded.add(region);
         DeviceResources resources = region.getResources();
         if (resources != null && resources.getGeometryBuffer() != null) {
            listable++;
            int mid = region instanceof NvidiumPlusRegionCacheHolder holder ? holder.nvidiumplus$mid() : -1;
            if (mid < 0 || mid >= m.regionOf.length || m.regionOf[mid] != region) {
               unmirrored++;
            }
         }
      }

      int orphaned = 0;
      int mirrored = 0;

      for (RenderRegion region : m.regionOf) {
         if (region != null) {
            mirrored++;
            if (!loaded.contains(region)) {
               orphaned++;
            }
         }
      }

      return new int[]{loaded.size(), listable, unmirrored, orphaned, mirrored};
   }

   RenderSectionManager manager() {
      return this.manager;
   }

   void retire() {
      if (current == this) {
         current = null;
      }

      this.tracking = false;
      this.dirty.clear();
      this.deadCount = 0;
      this.keys.clear();
      Arrays.fill(this.regionOf, null);
      Arrays.fill(this.bufferOf, null);
      long freed = this.scratch != 0L ? 12288L : 0L;
      MemoryUtil.nmemFree(this.scratch);
      this.scratch = 0L;
      if (this.auditBase != 0L) {
         freed += this.auditCapacity * 2L * 12288L;
         MemoryUtil.nmemFree(this.auditBase);
         this.auditBase = 0L;
      }

      if (freed > 0L) {
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus region mirror retired with the chunk renderer: {} B of native scratch freed (audit={}, {} mutations / {} deletes seen this session)",
               new Object[]{freed, this.audit, mutationsTotal, deletesTotal}
            );
         NvidiumPlusLog.LOGGER
            .info(
               "NvidiumPlus terrain continuity so far this session (stamp hold {}, regions from {}; the counters are session totals, not this world's): {} section(s) in {} chunk group(s) the graphics card could not reach, {} one-frame region gap(s), {} region(s) dropped from a frame's list for want of a geometry buffer, {} whole-frame visibility dip(s), {} group(s) found with stale records by the audit (the audit runs only under -Dnvidiumplus.sodium.mirrorAudit=true), {} draw group(s) covering {} chunk group(s) left out of a frame for want of a buffer, {} chunk group(s) held one extra frame, {} whole chunk group(s) the graphics card itself refused to draw, after which the mirror was written again {} time(s). Of the frames that refused, {} read a row describing the SAME chunk the processor last wrote for that id (so the card holds an older copy of the right row and a row copy is not reaching it), {} read a row describing a DIFFERENT place (so the card is not holding that region's row at all, and the fault is the id or the addressing), and {} named an id the processor has no record of writing. {} task workgroup(s) found the card's copy of a chunk group record out of date and used the frame's fresh copy instead.",
               new Object[]{
                  SodiumTerrainDrawer.stampHoldEnabled() ? "ON" : "OFF",
                  SodiumTerrainDrawer.graphRegions() ? "Sodium's list" : "the loaded set",
                  SodiumTerrainDrawer.unreachableSectionsTotal(),
                  SodiumTerrainDrawer.unreachableRegionsTotal(),
                  SodiumTerrainDrawer.oneFrameGapsTotal(),
                  SodiumTerrainDrawer.droppedRegionsTotal(),
                  SodiumTerrainDrawer.visibilityDips(),
                  SodiumTerrainDrawer.auditMismatchRegions(),
                  SodiumTerrainDrawer.skippedGroupsTotal(),
                  SodiumTerrainDrawer.skippedGroupRegions(),
                  SodiumTerrainDrawer.regionsHeldTotal(),
                  SodiumTerrainDrawer.regionRejectionsTotal(),
                  SodiumTerrainDrawer.remirrorsTotal(),
                  SodiumTerrainDrawer.rowVerdictCounts()[0],
                  SodiumTerrainDrawer.rowVerdictCounts()[1],
                  SodiumTerrainDrawer.rowVerdictCounts()[2],
                  SodiumTerrainDrawer.mirrorStaleTotal()
               }
            );
      }
   }

   static final class FrameOutput {
      GpuBuffer[] groupBuffers = new GpuBuffer[16];
      int[] groupKeys = new int[16];
      int[] groupStart = new int[17];
      int[] groupCounts = new int[16];
      int groupCount;
      int listedRegions;
      int listedSections;
      int droppedMirrored;
      int unreachableSections;
      int unreachableRegions;
      int oneFrameGaps;
      long signature;
      boolean faceAll;
      long loopNanos;

      void ensureGroups(int n) {
         if (n > this.groupBuffers.length) {
            int m = Math.max(n, this.groupBuffers.length * 2);
            this.groupBuffers = Arrays.copyOf(this.groupBuffers, m);
            this.groupKeys = Arrays.copyOf(this.groupKeys, m);
            this.groupStart = Arrays.copyOf(this.groupStart, m + 1);
            this.groupCounts = Arrays.copyOf(this.groupCounts, m);
         }
      }

      void clear() {
         Arrays.fill(this.groupBuffers, 0, Math.min(this.groupCount, this.groupBuffers.length), null);
         this.groupCount = 0;
         this.listedRegions = 0;
         this.listedSections = 0;
         this.droppedMirrored = 0;
         this.oneFrameGaps = 0;
         this.unreachableSections = 0;
         this.unreachableRegions = 0;
      }
   }
}
