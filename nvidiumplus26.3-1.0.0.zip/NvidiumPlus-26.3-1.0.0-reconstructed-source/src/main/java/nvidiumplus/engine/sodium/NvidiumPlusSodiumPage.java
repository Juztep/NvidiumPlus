package nvidiumplus.engine.sodium;

import net.caffeinemc.mods.sodium.api.config.ConfigState;
import net.caffeinemc.mods.sodium.api.config.StorageEventHandler;
import net.caffeinemc.mods.sodium.api.config.structure.BooleanOptionBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.ConfigBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.EnumOptionBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.ExternalButtonOptionBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.IntegerOptionBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.ModOptionsBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.OptionGroupBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.OptionPageBuilder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusExtendedRd;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.gui.NvidiumPlusOptionsScreen;
import nvidiumplus.engine.vk.SodiumTerrainDrawer;

public final class NvidiumPlusSodiumPage {
   static final String NAMESPACE = "nvidiumplus";
   public static final Identifier DISTANCE_CAP = id("general.distance_cap");
   public static final Identifier GPU_VISIBILITY = id("general.gpu_visibility");
   public static final Identifier FOG_MODE = id("general.fog_mode");
   public static final Identifier FOG_END = id("general.fog_end");
   public static final Identifier SUB_PIXEL_CULL = id("advanced.sub_pixel_cull");
   public static final Identifier SODIUM_OCCLUSION = id("advanced.sodium_occlusion");
   public static final Identifier RECORD_REPAIR = id("advanced.record_repair");
   public static final Identifier DEBUG_STATS = id("advanced.debug_stats");
   public static final Identifier BACKEND_POPUP = id("advanced.backend_popup");
   public static final Identifier FULL_SCREEN = id("advanced.full_screen");
   static final Identifier ICON = Identifier.fromNamespaceAndPath("nvidiumplus", "textures/gui/config-icon.png");
   static final int THEME_BASE = 16777215;
   static final StorageEventHandler STORAGE = () -> NvidiumPlusConfig.get().save();
   private static final NvidiumPlusConfig DEFAULTS = new NvidiumPlusConfig();

   private NvidiumPlusSodiumPage() {
   }

   static void addTo(ConfigBuilder builder, ModOptionsBuilder mod) {
      mod.setNonTintedIcon(ICON);
      mod.setColorTheme(builder.createColorTheme().setBaseThemeRGB(16777215));
      OptionGroupBuilder everyday = builder.createOptionGroup();
      everyday.addOption(gpuVisibility(builder));
      everyday.addOption(fogMode(builder));
      everyday.addOption(fogEnd(builder));
      OptionGroupBuilder advanced = builder.createOptionGroup().setName(Component.translatable("nvidiumplus.options.sodium_group.advanced"));
      advanced.addOption(subPixelCull(builder));
      advanced.addOption(sodiumOcclusion(builder));
      advanced.addOption(recordRepair(builder));
      advanced.addOption(debugStats(builder));
      advanced.addOption(backendPopup(builder));
      OptionGroupBuilder more = builder.createOptionGroup();
      more.addOption(fullScreen(builder));
      OptionPageBuilder page = builder.createOptionPage().setName(Component.translatable("nvidiumplus.options.sodium_page"));
      page.addOptionGroup(everyday);
      page.addOptionGroup(advanced);
      page.addOptionGroup(more);
      mod.addPage(page);
   }

   private static IntegerOptionBuilder distanceCap(ConfigBuilder builder) {
      IntegerOptionBuilder cap = builder.createIntegerOption(DISTANCE_CAP);
      cap.setName(Component.translatable("nvidiumplus.options.max_rd"));
      cap.setTooltip(Component.translatable("nvidiumplus.options.tooltip.max_rd.sodium"));
      cap.setStorageHandler(STORAGE);
      cap.setValidator(new NvidiumPlusSodiumRange(32, 32, 1));
      cap.setValueFormatter(NvidiumPlusSodiumPage::formatCap);
      cap.setDefaultValue(DEFAULTS.maxRenderDistance);
      cap.setBinding(NvidiumPlusSodiumPage::saveCap, () -> Math.clamp(NvidiumPlusConfig.get().maxRenderDistance, 32, 120));
      cap.setEnabled(!capOverridden());
      return cap;
   }

   private static BooleanOptionBuilder gpuVisibility(ConfigBuilder builder) {
      BooleanOptionBuilder gpu = builder.createBooleanOption(GPU_VISIBILITY);
      gpu.setName(Component.translatable("nvidiumplus.options.sodium_gpu"));
      gpu.setTooltip(value -> heldAware("nvidiumplus.options.tooltip.sodium_gpu"));
      gpu.setStorageHandler(STORAGE);
      gpu.setDefaultValue(DEFAULTS.sodiumGpuVisibility);
      gpu.setBinding(value -> NvidiumPlusConfig.get().sodiumGpuVisibility = value, () -> NvidiumPlusConfig.get().sodiumGpuVisibility);
      gpu.setEnabledProvider(
         state -> NvidiumPlusGate.sodiumAdapterArmed() && System.getProperty("nvidiumplus.sodium.gpuDraw") == null,
         new Identifier[]{ConfigState.UPDATE_ON_REBUILD}
      );
      gpu.setApplyHook(state -> applyGpuVisibility());
      return gpu;
   }

   private static EnumOptionBuilder<NvidiumPlusConfig.FogMode> fogMode(ConfigBuilder builder) {
      EnumOptionBuilder<NvidiumPlusConfig.FogMode> fog = builder.createEnumOption(FOG_MODE, NvidiumPlusConfig.FogMode.class);
      fog.setName(Component.translatable("nvidiumplus.options.fog"));
      fog.setTooltip(Component.translatable("nvidiumplus.options.tooltip.fog"));
      fog.setStorageHandler(STORAGE);
      fog.setElementNameProvider(NvidiumPlusSodiumPage::fogModeName);
      fog.setDefaultValue(DEFAULTS.fogMode);
      fog.setBinding(value -> NvidiumPlusConfig.get().fogMode = value, () -> NvidiumPlusConfig.get().fogMode);
      fog.setEnabled(!fogOverridden());
      return fog;
   }

   private static IntegerOptionBuilder fogEnd(ConfigBuilder builder) {
      IntegerOptionBuilder end = builder.createIntegerOption(FOG_END);
      end.setName(Component.translatable("nvidiumplus.options.fog_end"));
      end.setTooltip(Component.translatable("nvidiumplus.options.tooltip.fog_end"));
      end.setStorageHandler(STORAGE);
      end.setValidator(new NvidiumPlusSodiumRange(50, 200, 1));
      end.setValueFormatter(value -> Component.translatable("nvidiumplus.options.fog_end.percent", new Object[]{value}));
      end.setDefaultValue(DEFAULTS.fogEndPercent);
      end.setBinding(value -> NvidiumPlusConfig.get().fogEndPercent = value, () -> Math.clamp(NvidiumPlusConfig.get().fogEndPercent, 50, 200));
      end.setEnabledProvider(
         state -> !fogOverridden() && state.readEnumOption(FOG_MODE, NvidiumPlusConfig.FogMode.class) == NvidiumPlusConfig.FogMode.SCALED,
         new Identifier[]{FOG_MODE}
      );
      return end;
   }

   private static IntegerOptionBuilder subPixelCull(ConfigBuilder builder) {
      IntegerOptionBuilder cull = builder.createIntegerOption(SUB_PIXEL_CULL);
      cull.setName(Component.translatable("nvidiumplus.options.detail_cull"));
      cull.setTooltip(value -> heldAware("nvidiumplus.options.tooltip.detail_cull"));
      cull.setStorageHandler(STORAGE);
      cull.setValidator(new NvidiumPlusSodiumRange(0, 96, 1));
      cull.setValueFormatter(NvidiumPlusSodiumPage::formatCullChunks);
      cull.setDefaultValue(DEFAULTS.subPixelCullChunks);
      cull.setBinding(value -> NvidiumPlusConfig.get().subPixelCullChunks = value, () -> Math.clamp(NvidiumPlusConfig.get().subPixelCullChunks, 0, 96));
      cull.setEnabledProvider(state -> NvidiumPlusGate.sodiumAdapterArmed(), new Identifier[]{ConfigState.UPDATE_ON_REBUILD});
      return cull;
   }

   private static BooleanOptionBuilder sodiumOcclusion(ConfigBuilder builder) {
      BooleanOptionBuilder occ = builder.createBooleanOption(SODIUM_OCCLUSION);
      occ.setName(Component.translatable("nvidiumplus.options.sodium_occlusion"));
      occ.setTooltip(value -> heldAware("nvidiumplus.options.tooltip.sodium_occlusion"));
      occ.setStorageHandler(STORAGE);
      occ.setDefaultValue(DEFAULTS.sodiumOcclusion);
      occ.setBinding(value -> NvidiumPlusConfig.get().sodiumOcclusion = value, () -> NvidiumPlusConfig.get().sodiumOcclusion);
      occ.setEnabledProvider(
         state -> NvidiumPlusGate.sodiumAdapterArmed() && System.getProperty("nvidiumplus.sodium.occlusion") == null,
         new Identifier[]{ConfigState.UPDATE_ON_REBUILD}
      );
      occ.setApplyHook(state -> applyGpuVisibility());
      return occ;
   }

   private static BooleanOptionBuilder recordRepair(ConfigBuilder builder) {
      BooleanOptionBuilder repair = builder.createBooleanOption(RECORD_REPAIR);
      repair.setName(Component.translatable("nvidiumplus.options.sodium_record_repair"));
      repair.setTooltip(value -> heldAware("nvidiumplus.options.tooltip.sodium_record_repair"));
      repair.setStorageHandler(STORAGE);
      repair.setDefaultValue(DEFAULTS.sodiumRemirrorOnRefusal);
      repair.setBinding(value -> NvidiumPlusConfig.get().sodiumRemirrorOnRefusal = value, () -> NvidiumPlusConfig.get().sodiumRemirrorOnRefusal);
      repair.setEnabledProvider(
         state -> NvidiumPlusGate.sodiumAdapterArmed() && System.getProperty("nvidiumplus.sodium.remirrorOnRefusal") == null,
         new Identifier[]{ConfigState.UPDATE_ON_REBUILD}
      );
      return repair;
   }

   private static BooleanOptionBuilder debugStats(ConfigBuilder builder) {
      BooleanOptionBuilder stats = builder.createBooleanOption(DEBUG_STATS);
      stats.setName(Component.translatable("nvidiumplus.options.debug_stats"));
      stats.setTooltip(value -> heldAware("nvidiumplus.options.tooltip.debug_stats"));
      stats.setStorageHandler(STORAGE);
      stats.setDefaultValue(DEFAULTS.debugStats);
      stats.setBinding(value -> NvidiumPlusConfig.get().debugStats = value, () -> NvidiumPlusConfig.get().debugStats);
      stats.setEnabledProvider(
         state -> NvidiumPlusGate.sodiumAdapterArmed() && System.getProperty("nvidiumplus.debugStats") == null, new Identifier[]{ConfigState.UPDATE_ON_REBUILD}
      );
      return stats;
   }

   private static BooleanOptionBuilder backendPopup(ConfigBuilder builder) {
      BooleanOptionBuilder popup = builder.createBooleanOption(BACKEND_POPUP);
      popup.setName(Component.translatable("nvidiumplus.options.popup"));
      popup.setTooltip(
         Component.translatable("nvidiumplus.options.tooltip.popup").append(" ").append(Component.translatable("nvidiumplus.options.applies.restart"))
      );
      popup.setStorageHandler(STORAGE);
      popup.setDefaultValue(DEFAULTS.showVulkanPrompt);
      popup.setBinding(value -> {
         NvidiumPlusConfig config = NvidiumPlusConfig.get();
         config.showVulkanPrompt = value;
         config.noMeshShaderNoticeShown = !value;
         config.vulkanFailedNoticeShown = !value;
      }, () -> NvidiumPlusConfig.get().showVulkanPrompt);
      return popup;
   }

   private static ExternalButtonOptionBuilder fullScreen(ConfigBuilder builder) {
      ExternalButtonOptionBuilder open = builder.createExternalButtonOption(FULL_SCREEN);
      open.setName(Component.translatable("nvidiumplus.options.open"));
      open.setTooltip(Component.translatable("nvidiumplus.options.tooltip.sodium_full"));
      open.setScreenConsumer(NvidiumPlusSodiumPage::openFullScreen);
      return open;
   }

   private static void saveCap(Integer value) {
      NvidiumPlusConfig.get().maxRenderDistance = value;
      NvidiumPlusExtendedRd.onConfigChanged(Minecraft.getInstance());
   }

   static int effectiveCap(ConfigState state) {
      return capOverridden() ? NvidiumPlusConfig.maxRenderDistanceConfigured() : state.readIntOption(DISTANCE_CAP);
   }

   static boolean capOverridden() {
      return System.getProperty("nvidiumplus.maxRenderDistance") != null;
   }

   private static boolean fogOverridden() {
      return System.getProperty("nvidiumplus.fogMode") != null;
   }

   private static Component formatCap(int value) {
      return value == 32
         ? Component.translatable("nvidiumplus.options.max_rd.vanilla")
         : Component.translatable("nvidiumplus.options.cull.chunks", new Object[]{value});
   }

   private static Component formatCullChunks(int value) {
      return value == 0
         ? Component.translatable("nvidiumplus.options.cull.off")
         : Component.translatable("nvidiumplus.options.cull.chunks", new Object[]{value});
   }

   private static Component fogModeName(NvidiumPlusConfig.FogMode mode) {
      return switch (mode) {
         case VANILLA -> Component.translatable("nvidiumplus.options.fog.vanilla");
         case SCALED -> Component.translatable("nvidiumplus.options.fog.scaled");
         case OFF -> Component.translatable("nvidiumplus.options.fog.off");
      };
   }

   private static Component heldAware(String key) {
      MutableComponent text = Component.translatable(key);
      if (!NvidiumPlusGate.sodiumAdapterArmed()) {
         text.append(" ").append(Component.translatable("nvidiumplus.options.applies.sodium_gpu_held"));
      }

      return text;
   }

   private static void applyGpuVisibility() {
      if (NvidiumPlusGate.sodiumAdapterArmed()) {
         SodiumTerrainDrawer.applyConfiguredGpuVisibility();
      }
   }

   private static void openFullScreen(Screen sodiumScreen) {
      Minecraft.getInstance().gui.setScreen(new NvidiumPlusOptionsScreen(new NvidiumPlusSodiumReturnScreen(sodiumScreen)));
   }

   private static Identifier id(String path) {
      return Identifier.fromNamespaceAndPath("nvidiumplus", path);
   }
}
