package nvidiumplus.engine.sodium.mixin;

import java.util.List;
import java.util.Set;
import nvidiumplus.engine.sodium.NvidiumPlusSodiumHooks;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.service.MixinService;

public final class NvidiumPlusSodiumMixinPlugin implements IMixinConfigPlugin {
   private static final String SODIUM_MOD_ID = "sodium";
   public static final String ADAPTER_PROPERTY = "nvidiumplus.sodium.adapter";
   private static final String SODIUM_PRESENCE_CLASS = "net/caffeinemc/mods/sodium/client/render/chunk/RenderSectionManager.class";
   private static final String CONFIG_LOADER_FABRIC_CLASS = "net/caffeinemc/mods/sodium/fabric/config/ConfigLoaderFabric.class";
   private static final String CONFIG_LOADER_FORGE_CLASS = "net/caffeinemc/mods/sodium/neoforge/config/ConfigLoaderForge.class";
   private boolean apply;
   private boolean sodiumPresent;
   private static boolean searchDistanceMissingReported;

   public void onLoad(String mixinPackage) {
      boolean sodium = resourcePresent("net/caffeinemc/mods/sodium/client/render/chunk/RenderSectionManager.class");
      boolean declined = "false".equalsIgnoreCase(System.getProperty("nvidiumplus.sodium.adapter"));
      this.sodiumPresent = sodium;
      this.apply = sodium && !declined;
      if (sodium && declined) {
         System.out
            .println(
               "[NvidiumPlus] Sodium (mod id 'sodium') is installed and -Dnvidiumplus.sodium.adapter=false is set, so NvidiumPlus is not touching Sodium's renderer. Sodium draws the terrain on its own."
            );
      }
   }

   private static boolean resourcePresent(String resource) {
      try {
         ClassLoader loader = NvidiumPlusSodiumMixinPlugin.class.getClassLoader();
         return loader != null && loader.getResource(resource) != null;
      } catch (Throwable t) {
         return false;
      }
   }

   public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
      if (mixinClassName != null && mixinClassName.endsWith(".ConfigLoaderFabricMixin")) {
         return this.sodiumPresent && resourcePresent("net/caffeinemc/mods/sodium/fabric/config/ConfigLoaderFabric.class");
      } else if (mixinClassName != null && mixinClassName.endsWith(".ConfigLoaderForgeMixin")) {
         return this.sodiumPresent && resourcePresent("net/caffeinemc/mods/sodium/neoforge/config/ConfigLoaderForge.class");
      } else if (!this.apply) {
         return false;
      } else {
         return mixinClassName != null && mixinClassName.endsWith(".RenderSectionManagerInvoker") ? searchDistancePresent(targetClassName) : true;
      }
   }

   private static boolean searchDistancePresent(String targetClassName) {
      if (NvidiumPlusSodiumHooks.searchDistanceFound()) {
         return true;
      }

      try {
         ClassNode node = MixinService.getService().getBytecodeProvider().getClassNode(targetClassName);
         if (node != null) {
            for (MethodNode method : node.methods) {
               if ("getSearchDistance".equals(method.name) && "(Lnet/caffeinemc/mods/sodium/client/util/FogParameters;)F".equals(method.desc)) {
                  NvidiumPlusSodiumHooks.markFound(32);
                  return true;
               }
            }
         }
      } catch (Throwable var4) {
      }

      if (!searchDistanceMissingReported) {
         searchDistanceMissingReported = true;
         System.out
            .println(
               "[NvidiumPlus] Sodium's RenderSectionManager has no method getSearchDistance(Lnet/caffeinemc/mods/sodium/client/util/FogParameters;)F, so the GPU-visibility distance gate widens to the render distance instead of Sodium's fog search distance. A Sodium update moved it; the rendering draws more, never fewer."
            );
      }

      return false;
   }

   public String getRefMapperConfig() {
      return null;
   }

   public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
   }

   public List<String> getMixins() {
      return null;
   }

   public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
      String name = targetClass.name;
      if ("net/caffeinemc/mods/sodium/client/render/chunk/region/RenderRegion".equals(name)) {
         check(targetClass, "removeSection", "(Lnet/caffeinemc/mods/sodium/client/render/chunk/RenderSection;)V", 2);
         check(targetClass, "onGeometryBufferChange", "()V", 4);
         check(targetClass, "onGeometrySegmentChange", "(I)V", 8);
         check(targetClass, "delete", "()V", 16);
      } else if ("net/caffeinemc/mods/sodium/client/render/chunk/region/RenderRegionManager".equals(name)) {
         check(
            targetClass,
            "uploadResults",
            "(Lnet/caffeinemc/mods/sodium/client/render/chunk/region/RenderRegion;Ljava/util/Collection;Lnet/caffeinemc/mods/sodium/client/render/chunk/UniformBufferManager;)V",
            1
         );
      } else if ("net/caffeinemc/mods/sodium/client/gpu/device/context/VKIndirectContext".equals(name)) {
         checkConstant(targetClass, "<init>", "()V", 512000, 128);
      } else if ("net/caffeinemc/mods/sodium/client/render/chunk/lists/ChunkRenderList".equals(name)) {
         checkField(targetClass, "sectionsWithGeometryMap", "[J", 64);
      } else if ("net/caffeinemc/mods/sodium/client/render/chunk/RenderSectionManager".equals(name)) {
         for (MethodNode method : targetClass.methods) {
            if ("getSearchDistance".equals(method.name) && "(Lnet/caffeinemc/mods/sodium/client/util/FogParameters;)F".equals(method.desc)) {
               NvidiumPlusSodiumHooks.markFound(32);
               break;
            }
         }
      }
   }

   private static void check(ClassNode targetClass, String name, String desc, int bit) {
      for (MethodNode method : targetClass.methods) {
         if (name.equals(method.name) && desc.equals(method.desc)) {
            NvidiumPlusSodiumHooks.markFound(bit);
            return;
         }
      }

      System.out
         .println(
            "[NvidiumPlus] Sodium's "
               + targetClass.name
               + " has no method "
               + name
               + desc
               + ", so NvidiumPlus's per-region run cache stays off and the per-section enumeration draws every pass. A Sodium update moved it; the rendering is unaffected, only slower at distance."
         );
   }

   private static void checkField(ClassNode targetClass, String name, String desc, int bit) {
      for (FieldNode field : targetClass.fields) {
         if (name.equals(field.name) && desc.equals(field.desc)) {
            NvidiumPlusSodiumHooks.markFound(bit);
            return;
         }
      }

      System.out
         .println(
            "[NvidiumPlus] Sodium's "
               + targetClass.name
               + " has no field "
               + name
               + " "
               + desc
               + ", so NvidiumPlus rebuilds the per-region geometry bitmap from the section iterator instead of reading Sodium's own. A Sodium update moved it; the rendering is unaffected, only slightly slower at distance."
         );
   }

   private static void checkConstant(ClassNode targetClass, String name, String desc, int literal, int bit) {
      for (MethodNode method : targetClass.methods) {
         if (name.equals(method.name) && desc.equals(method.desc) && method.instructions != null) {
            for (AbstractInsnNode insn : method.instructions.toArray()) {
               if (insn instanceof LdcInsnNode ldc && ldc.cst instanceof Integer value && value == literal) {
                  NvidiumPlusSodiumHooks.markFound(bit);
                  return;
               }
            }
         }
      }

      System.out
         .println(
            "[NvidiumPlus] Sodium's "
               + targetClass.name
               + " no longer loads the literal "
               + literal
               + " in "
               + name
               + desc
               + ", so its indirect-command ring keeps Sodium's own size. A Sodium update moved it. If that update did not also fix the ring's grow-and-copy, a long session at a high render distance can still stall for five seconds inside the terrain pass."
         );
   }

   public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
   }
}
