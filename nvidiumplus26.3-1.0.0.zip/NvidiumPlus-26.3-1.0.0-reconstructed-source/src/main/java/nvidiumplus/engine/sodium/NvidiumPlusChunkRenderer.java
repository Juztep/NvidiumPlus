package nvidiumplus.engine.sodium;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.renderpearl.api.textures.GpuSampler;
import net.caffeinemc.mods.sodium.client.render.chunk.ChunkRenderMatrices;
import net.caffeinemc.mods.sodium.client.render.chunk.ChunkRenderer;
import net.caffeinemc.mods.sodium.client.render.chunk.RenderSectionManager;
import net.caffeinemc.mods.sodium.client.render.chunk.lists.ChunkRenderListIterable;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import net.caffeinemc.mods.sodium.client.render.viewport.CameraTransform;
import net.caffeinemc.mods.sodium.client.util.FogParameters;
import net.minecraft.client.renderer.oit.OitStage;
import nvidiumplus.engine.vk.MainPassSuspension;
import nvidiumplus.engine.vk.SodiumTerrainDrawer;

public final class NvidiumPlusChunkRenderer extends NvidiumPlusChunkRendererBase implements ChunkRenderer {
   public NvidiumPlusChunkRenderer(ChunkRenderer delegate) {
      super(delegate);
   }

   public NvidiumPlusChunkRenderer(ChunkRenderer delegate, RenderSectionManager manager) {
      super(delegate, manager);
   }

   public void prepare(ChunkRenderListIterable renderLists, CameraTransform camera, boolean useTranslucencySorting) {
      this.delegate.prepare(renderLists, camera, useTranslucencySorting);
   }

   public void render(
      ChunkRenderMatrices matrices,
      ChunkRenderListIterable renderLists,
      TerrainRenderPass pass,
      CameraTransform camera,
      FogParameters fog,
      boolean useTranslucencySorting,
      RenderPass renderPass,
      GpuSampler atlasSampler,
      GpuBufferSlice globalsUbo,
      GpuBuffer sectionTimeInfo,
      OitStage oitStage
   ) {
      if (oitStage == null && this.wantsDraw(pass)) {
         try (MainPassSuspension suspended = MainPassSuspension.suspend(renderPass)) {
            if (suspended != null && this.draw(matrices, renderLists, pass, camera, fog, atlasSampler)) {
               return;
            }
         }
      }

      if (pass != null && !pass.isTranslucent()) {
         SodiumTerrainDrawer.reportRung("2");
      }

      this.delegate.render(matrices, renderLists, pass, camera, fog, useTranslucencySorting, renderPass, atlasSampler, globalsUbo, sectionTimeInfo, oitStage);
   }
}
