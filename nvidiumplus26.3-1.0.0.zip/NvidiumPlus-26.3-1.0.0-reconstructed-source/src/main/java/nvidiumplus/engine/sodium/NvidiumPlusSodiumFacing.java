package nvidiumplus.engine.sodium;

import net.caffeinemc.mods.sodium.client.model.quad.properties.ModelQuadFacing;
import net.caffeinemc.mods.sodium.client.render.chunk.DefaultChunkRenderer;

public final class NvidiumPlusSodiumFacing {
   public static final int POS_X = 0;
   public static final int POS_Y = 1;
   public static final int POS_Z = 2;
   public static final int NEG_X = 3;
   public static final int NEG_Y = 4;
   public static final int NEG_Z = 5;
   public static final int UNASSIGNED = 6;
   public static final int ALL = 127;

   private NvidiumPlusSodiumFacing() {
   }

   public static int visibleFaces(int camX, int camY, int camZ, int sx, int sy, int sz) {
      int ox = sx << 4;
      int oy = sy << 4;
      int oz = sz << 4;
      int ex = ox + 16;
      int ey = oy + 16;
      int ez = oz + 16;
      int mask = 64;
      mask |= (camX > ox - 3 ? 1 : 0) << 0;
      mask |= (camY > oy - 3 ? 1 : 0) << 1;
      mask |= (camZ > oz - 3 ? 1 : 0) << 2;
      mask |= (camX < ex + 3 ? 1 : 0) << 3;
      mask |= (camY < ey + 3 ? 1 : 0) << 4;
      return mask | (camZ < ez + 3 ? 1 : 0) << 5;
   }

   public static String latticeFailure() {
      String ordinals = ordinalFailure();
      if (ordinals != null) {
         return ordinals;
      }

      int[] coarse = new int[]{-40, -19, -3, -2, 0, 2, 13, 14, 19, 40};

      for (int axis = 0; axis < 3; axis++) {
         for (int c = -40; c <= 40; c++) {
            for (int a : coarse) {
               for (int b : coarse) {
                  int camX = axis == 0 ? c : (axis == 1 ? a : b);
                  int camY = axis == 1 ? c : (axis == 0 ? a : b);
                  int camZ = axis == 2 ? c : a;

                  for (int sx = -4; sx <= 4; sx++) {
                     for (int sy = -4; sy <= 4; sy++) {
                        for (int sz = -4; sz <= 4; sz++) {
                           int ours = visibleFaces(camX, camY, camZ, sx, sy, sz);
                           int theirs = DefaultChunkRenderer.getVisibleFaces(camX, camY, camZ, sx, sy, sz);
                           if (ours != theirs) {
                              return "visibleFaces("
                                 + camX
                                 + ","
                                 + camY
                                 + ","
                                 + camZ
                                 + " ; "
                                 + sx
                                 + ","
                                 + sy
                                 + ","
                                 + sz
                                 + ") = "
                                 + ours
                                 + " but Sodium's getVisibleFaces = "
                                 + theirs
                                 + "; the task shader would cull differently";
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      boolean naiveFailed = false;

      for (int cam = -40; cam <= 40 && !naiveFailed; cam++) {
         for (int other = -40; other <= 40 && !naiveFailed; other++) {
            if (cam >> 4 == other >> 4) {
               for (int s = -4; s <= 4; s++) {
                  if (DefaultChunkRenderer.getVisibleFaces(cam, 0, 0, s, 0, 0) != DefaultChunkRenderer.getVisibleFaces(other, 0, 0, s, 0, 0)) {
                     naiveFailed = true;
                     break;
                  }
               }
            }
         }
      }

      return !naiveFailed
         ? "the camera-section key passed the facing lattice, so the lattice cannot tell an exact formula from a wrong one; the check is vacuous"
         : null;
   }

   private static String ordinalFailure() {
      int[][] expected = new int[][]{
         {ModelQuadFacing.POS_X.ordinal(), 0},
         {ModelQuadFacing.POS_Y.ordinal(), 1},
         {ModelQuadFacing.POS_Z.ordinal(), 2},
         {ModelQuadFacing.NEG_X.ordinal(), 3},
         {ModelQuadFacing.NEG_Y.ordinal(), 4},
         {ModelQuadFacing.NEG_Z.ordinal(), 5},
         {ModelQuadFacing.UNASSIGNED.ordinal(), 6}
      };

      for (int[] pair : expected) {
         if (pair[0] != pair[1]) {
            return "ModelQuadFacing ordinal " + pair[0] + " != assumed " + pair[1] + "; the task shader's facing bits are wrong for this Sodium";
         }
      }

      return ModelQuadFacing.ALL == 127 && ModelQuadFacing.COUNT == 7
         ? null
         : "ModelQuadFacing.ALL/COUNT are "
            + ModelQuadFacing.ALL
            + "/"
            + ModelQuadFacing.COUNT
            + ", not 0x7F/7; the record walk's run count is wrong for this Sodium";
   }
}
