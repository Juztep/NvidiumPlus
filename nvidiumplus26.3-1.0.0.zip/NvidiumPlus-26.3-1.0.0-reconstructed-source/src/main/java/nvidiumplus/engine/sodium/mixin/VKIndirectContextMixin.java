package nvidiumplus.engine.sodium.mixin;

import net.caffeinemc.mods.sodium.client.gpu.device.context.VKIndirectContext;
import nvidiumplus.engine.sodium.NvidiumPlusSodiumHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(VKIndirectContext.class)
public class VKIndirectContextMixin {
   @ModifyConstant(method = "<init>", constant = @Constant(intValue = 512000), require = 0, expect = 0)
   private int nvidiumplus$widenIndirectRing(int stock) {
      return NvidiumPlusSodiumHooks.indirectRingBytes(stock);
   }
}
