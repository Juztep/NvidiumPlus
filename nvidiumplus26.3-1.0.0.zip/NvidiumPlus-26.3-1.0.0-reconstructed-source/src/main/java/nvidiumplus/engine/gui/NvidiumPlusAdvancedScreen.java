package nvidiumplus.engine.gui;

import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.components.ScrollableLayout;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.terrain.host.VanillaUploadSeam;
import nvidiumplus.engine.vk.SodiumTerrainDrawer;

public class NvidiumPlusAdvancedScreen extends Screen {
   private static final int WIDGET_WIDTH = 200;
   private static final int BANNER_WIDTH = 340;
   private final Screen parent;
   private final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);
   private ScrollableLayout scrollArea;
   private final boolean gateLocked;
   private final boolean sodium;

   public NvidiumPlusAdvancedScreen(Screen parent) {
      super(Component.translatable("nvidiumplus.options.advanced.title"));
      this.parent = parent;
      this.gateLocked = NvidiumPlusGate.state() != NvidiumPlusGate.State.VULKAN_MESH_SHADERS;
      this.sodium = NvidiumPlusGate.state() == NvidiumPlusGate.State.SODIUM_PRESENT;
   }

   protected void init() {
      NvidiumPlusConfig config = NvidiumPlusConfig.get();
      this.layout.addTitleHeader(this.getTitle(), this.font);
      LinearLayout rows = LinearLayout.vertical().spacing(2);
      rows.defaultCellSetting().alignHorizontallyCenter();
      boolean statsOverridden = System.getProperty("nvidiumplus.debugStats") != null;
      boolean greedyOverridden = !this.sodium && System.getProperty("nvidiumplus.greedyMeshing") != null;
      boolean sodiumRowsOverridden = this.sodium
         && (System.getProperty("nvidiumplus.sodium.occlusion") != null || System.getProperty("nvidiumplus.sodium.remirrorOnRefusal") != null);
      if (statsOverridden || greedyOverridden || sodiumRowsOverridden) {
         MultiLineTextWidget banner = new MultiLineTextWidget(Component.translatable("nvidiumplus.options.dev_override"), this.font);
         banner.setMaxWidth(340);
         banner.setCentered(true);
         rows.addChild(banner, s -> s.paddingTop(2).paddingBottom(2));
      }

      if (this.gateLocked) {
         String lockedKey = !this.sodium
            ? "nvidiumplus.options.advanced.locked"
            : (NvidiumPlusGate.sodiumAdapterArmed() ? "nvidiumplus.options.advanced.locked.sodium" : "nvidiumplus.options.advanced.locked.sodium_off");
         MultiLineTextWidget locked = new MultiLineTextWidget(Component.translatable(lockedKey).withStyle(ChatFormatting.YELLOW), this.font);
         locked.setMaxWidth(340);
         locked.setCentered(true);
         rows.addChild(locked, s -> s.paddingTop(2).paddingBottom(2));
      }

      if (!this.sodium) {
         CycleButton<Boolean> greedy = CycleButton.onOffBuilder(config.greedyMeshing)
            .create(Component.translatable("nvidiumplus.options.greedy_meshing"), (b, value) -> {
               config.greedyMeshing = value;
               config.save();
            });
         greedy.setWidth(200);
         greedy.active = !this.gateLocked && !greedyOverridden;
         greedy.setTooltip(this.tip("nvidiumplus.options.tooltip.greedy_meshing", "nvidiumplus.options.applies.rebuild"));
         rows.addChild(greedy, s -> s.paddingTop(4));
         NvidiumPlusAdvancedScreen.CullDistanceSlider plantCull = new NvidiumPlusAdvancedScreen.CullDistanceSlider(
            "nvidiumplus.options.plant_cull.label", () -> NvidiumPlusConfig.get().plantCullChunks, chunks -> {
               config.plantCullChunks = chunks;
               config.save();
            }, !this.gateLocked
         );
         plantCull.setTooltip(this.tip("nvidiumplus.options.tooltip.plant_cull", "nvidiumplus.options.applies.now"));
         rows.addChild(plantCull);
      }

      boolean subPixelLive = !this.gateLocked || NvidiumPlusGate.sodiumAdapterArmed();
      NvidiumPlusAdvancedScreen.CullDistanceSlider subPixelCull = new NvidiumPlusAdvancedScreen.CullDistanceSlider(
         "nvidiumplus.options.detail_cull.label", () -> NvidiumPlusConfig.get().subPixelCullChunks, chunks -> {
            config.subPixelCullChunks = chunks;
            config.save();
         }, subPixelLive
      );
      subPixelCull.setTooltip(
         this.tip(!subPixelLive, "nvidiumplus.options.tooltip.detail_cull", "nvidiumplus.options.applies.now", "nvidiumplus.options.applies.sodium_gpu_held")
      );
      rows.addChild(subPixelCull);
      if (!this.sodium) {
         NvidiumPlusAdvancedScreen.CullDistanceSlider smartLeaves = new NvidiumPlusAdvancedScreen.CullDistanceSlider(
            "nvidiumplus.options.smart_leaves.label", () -> NvidiumPlusConfig.get().smartLeavesChunks, chunks -> {
               config.smartLeavesChunks = chunks;
               config.save();
            }, !this.gateLocked
         );
         smartLeaves.setTooltip(this.tip("nvidiumplus.options.tooltip.smart_leaves", "nvidiumplus.options.applies.new_builds"));
         rows.addChild(smartLeaves);
         NvidiumPlusAdvancedScreen.CullDistanceSlider solidLeaves = new NvidiumPlusAdvancedScreen.CullDistanceSlider(
            "nvidiumplus.options.solid_leaves.label", () -> NvidiumPlusConfig.get().solidLeavesChunks, chunks -> {
               config.solidLeavesChunks = chunks;
               config.save();
            }, !this.gateLocked
         );
         solidLeaves.setTooltip(this.tip("nvidiumplus.options.tooltip.solid_leaves", "nvidiumplus.options.applies.new_builds"));
         rows.addChild(solidLeaves);
      }

      if (!this.sodium) {
         CycleButton<Boolean> trim = CycleButton.onOffBuilder(config.arenaTrim)
            .create(Component.translatable("nvidiumplus.options.arena_trim"), (b, value) -> {
               config.arenaTrim = value;
               config.save();
            });
         trim.setWidth(200);
         trim.active = !this.gateLocked;
         trim.setTooltip(this.tip("nvidiumplus.options.tooltip.arena_trim", "nvidiumplus.options.applies.now"));
         rows.addChild(trim);
         CycleButton<Boolean> suppress = CycleButton.booleanBuilder(
               Component.translatable("nvidiumplus.options.suppress_vanilla.freed"),
               Component.translatable("nvidiumplus.options.suppress_vanilla.kept"),
               config.suppressVanillaUploads
            )
            .create(Component.translatable("nvidiumplus.options.suppress_vanilla"), (b, value) -> {
               config.suppressVanillaUploads = value;
               config.save();
               if (this.minecraft != null && this.minecraft.level != null) {
                  VanillaUploadSeam.onSettingChanged();
               }
            });
         suppress.setWidth(200);
         suppress.active = !this.gateLocked;
         suppress.setTooltip(this.tip("nvidiumplus.options.tooltip.suppress_vanilla", "nvidiumplus.options.applies.now"));
         rows.addChild(suppress);
      }

      if (this.sodium) {
         boolean adapterArmed = NvidiumPlusGate.sodiumAdapterArmed();
         rows.addChild(
            this.sodiumToggle(
               "nvidiumplus.options.sodium_occlusion",
               "nvidiumplus.options.tooltip.sodium_occlusion",
               "nvidiumplus.sodium.occlusion",
               adapterArmed,
               config.sodiumOcclusion,
               value -> {
                  config.sodiumOcclusion = value;
                  config.save();
                  SodiumTerrainDrawer.applyConfiguredGpuVisibility();
               }
            )
         );
         rows.addChild(
            this.sodiumToggle(
               "nvidiumplus.options.sodium_record_repair",
               "nvidiumplus.options.tooltip.sodium_record_repair",
               "nvidiumplus.sodium.remirrorOnRefusal",
               adapterArmed,
               config.sodiumRemirrorOnRefusal,
               value -> {
                  config.sodiumRemirrorOnRefusal = value;
                  config.save();
               }
            )
         );
      }

      CycleButton<Boolean> stats = CycleButton.onOffBuilder(config.debugStats)
         .create(Component.translatable("nvidiumplus.options.debug_stats"), (b, value) -> {
            config.debugStats = value;
            config.save();
         });
      stats.setWidth(200);
      boolean statsLive = !this.gateLocked || NvidiumPlusGate.sodiumAdapterArmed();
      stats.active = statsLive && !statsOverridden;
      stats.setTooltip(
         this.tip(!statsLive, "nvidiumplus.options.tooltip.debug_stats", "nvidiumplus.options.applies.now", "nvidiumplus.options.applies.sodium_gpu_held")
      );
      rows.addChild(stats);
      CycleButton<Boolean> popup = CycleButton.onOffBuilder(config.showVulkanPrompt)
         .create(Component.translatable("nvidiumplus.options.popup"), (b, value) -> {
            config.showVulkanPrompt = value;
            config.noMeshShaderNoticeShown = !value;
            config.vulkanFailedNoticeShown = !value;
            config.save();
         });
      popup.setWidth(200);
      popup.setTooltip(Tooltip.create(withSemantics(Component.translatable("nvidiumplus.options.tooltip.popup"), "nvidiumplus.options.applies.restart")));
      rows.addChild(popup);
      this.scrollArea = new ScrollableLayout(this.minecraft, rows, this.layout.getContentHeight());
      this.layout.addToContents(this.scrollArea);
      this.layout.addToFooter(Button.builder(CommonComponents.GUI_DONE, b -> this.onClose()).width(200).build());
      this.layout.visitWidgets(x$0 -> this.addRenderableWidget(x$0));
      this.repositionElements();
   }

   private CycleButton<Boolean> sodiumToggle(String nameKey, String tipKey, String property, boolean adapterArmed, boolean initial, Consumer<Boolean> onChange) {
      CycleButton<Boolean> row = CycleButton.onOffBuilder(initial).create(Component.translatable(nameKey), (b, value) -> onChange.accept(value));
      row.setWidth(200);
      row.active = adapterArmed && System.getProperty(property) == null;
      row.setTooltip(this.tip(!adapterArmed, tipKey, "nvidiumplus.options.applies.now", "nvidiumplus.options.applies.sodium_gpu_held"));
      return row;
   }

   private Tooltip tip(String descriptionKey, String appliesKey) {
      return this.tip(this.gateLocked, descriptionKey, appliesKey);
   }

   private Tooltip tip(boolean locked, String descriptionKey, String appliesKey) {
      return this.tip(locked, descriptionKey, appliesKey, "nvidiumplus.options.applies.sodium");
   }

   private Tooltip tip(boolean locked, String descriptionKey, String appliesKey, String sodiumHeldKey) {
      String semantics = !locked
         ? appliesKey
         : (NvidiumPlusGate.state() == NvidiumPlusGate.State.SODIUM_PRESENT ? sodiumHeldKey : "nvidiumplus.options.applies.vulkan");
      return Tooltip.create(withSemantics(Component.translatable(descriptionKey), semantics));
   }

   private static Component withSemantics(MutableComponent description, String semanticsKey) {
      return description.append(Component.literal("\n\n")).append(Component.translatable(semanticsKey).withStyle(ChatFormatting.GRAY));
   }

   private static double cullFraction(int chunks) {
      int span = 96;
      double f = (double)(chunks - 0) / span;
      return Math.max(0.0, Math.min(1.0, f));
   }

   protected void repositionElements() {
      this.scrollArea.arrangeElements();
      this.scrollArea.setMaxHeight(this.layout.getContentHeight());
      this.layout.arrangeElements();
   }

   public void onClose() {
      if (this.minecraft != null) {
         this.minecraft.gui.setScreen(this.parent);
      }
   }

   private final class CullDistanceSlider extends AbstractSliderButton {
      private final String labelKey;
      private final IntConsumer apply;
      private int displayed;

      CullDistanceSlider(String labelKey, IntSupplier current, IntConsumer apply, boolean active) {
         super(0, 0, 200, 20, Component.empty(), NvidiumPlusAdvancedScreen.cullFraction(current.getAsInt()));
         this.labelKey = labelKey;
         this.apply = apply;
         this.active = active;
         this.displayed = current.getAsInt();
         this.updateMessage();
      }

      protected void updateMessage() {
         Component shown = this.displayed <= 0
            ? Component.translatable("nvidiumplus.options.cull.off")
            : Component.translatable("nvidiumplus.options.cull.chunks", new Object[]{Component.literal(Integer.toString(this.displayed))});
         this.setMessage(Component.translatable(this.labelKey, new Object[]{shown}));
      }

      protected void applyValue() {
         int span = 96;
         int chunks = 0 + (int)Math.round(this.value * span);
         if (chunks != this.displayed) {
            this.displayed = chunks;
            this.apply.accept(chunks);
         }

         this.updateMessage();
      }
   }
}
