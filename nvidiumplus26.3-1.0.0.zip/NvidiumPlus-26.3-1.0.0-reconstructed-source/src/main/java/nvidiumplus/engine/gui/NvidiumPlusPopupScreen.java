package nvidiumplus.engine.gui;

import net.minecraft.client.PreferredGraphicsApi;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusPlatform;

public final class NvidiumPlusPopupScreen extends Screen {
   private static final int BODY_MAX_WIDTH = 320;
   private static final int BUTTON_WIDTH = 150;
   private final NvidiumPlusPopupScreen.Variant variant;
   private final Screen parent;
   private final LinearLayout layout = LinearLayout.vertical().spacing(8);
   private MultiLineTextWidget body;

   public NvidiumPlusPopupScreen(NvidiumPlusPopupScreen.Variant variant, Screen parent) {
      super(Component.translatable(variant.titleKey));
      this.variant = variant;
      this.parent = parent;
   }

   public NvidiumPlusPopupScreen.Variant variant() {
      return this.variant;
   }

   public String bodyText() {
      return this.body != null ? this.body.getMessage().getString() : "";
   }

   protected void init() {
      super.init();
      this.layout.defaultCellSetting().alignHorizontallyCenter();
      this.layout.addChild(new StringWidget(this.getTitle(), this.font));
      boolean sodium = NvidiumPlusPlatform.isModLoaded("sodium");
      boolean adapter = sodium && NvidiumPlusGate.sodiumAdapterConfigured();

      String bodyKey = switch (this.variant) {
         case ENABLE_VULKAN -> adapter
            ? "nvidiumplus.popup.opengl.body.sodium"
            : (sodium ? "nvidiumplus.popup.opengl.body.sodium_no_adapter" : this.variant.bodyKey);
         case VULKAN_FAILED -> sodium ? "nvidiumplus.popup.vulkan_failed.body.sodium" : this.variant.bodyKey;
         case NO_MESH_SHADERS -> sodium ? "nvidiumplus.popup.no_mesh.body.sodium" : this.variant.bodyKey;
         case RESTART_REQUIRED -> this.variant.bodyKey;
      };
      this.body = (MultiLineTextWidget)this.layout
         .addChild(new MultiLineTextWidget(Component.translatable(bodyKey), this.font).setMaxWidth(320).setCentered(true));
      this.addButtons();
      this.layout.visitWidgets(x$0 -> this.addRenderableWidget(x$0));
      this.repositionElements();
   }

   private void addButtons() {
      switch (this.variant) {
         case ENABLE_VULKAN: {
            LinearLayout row = (LinearLayout)this.layout.addChild(LinearLayout.horizontal().spacing(8), s -> s.paddingTop(8));
            row.addChild(button("nvidiumplus.popup.enable_vulkan", this::enableVulkan));
            row.addChild(button("nvidiumplus.popup.not_now", this::dismiss));
            this.layout.addChild(Button.builder(Component.translatable("nvidiumplus.popup.dont_show_again"), b -> this.dontShowAgain()).width(200).build());
            break;
         }
         case VULKAN_FAILED:
         case NO_MESH_SHADERS:
            this.layout.addChild(button("nvidiumplus.popup.ok", this::dismiss), s -> s.paddingTop(8));
            break;
         case RESTART_REQUIRED: {
            LinearLayout row = (LinearLayout)this.layout.addChild(LinearLayout.horizontal().spacing(8), s -> s.paddingTop(8));
            row.addChild(button("nvidiumplus.popup.quit", () -> this.minecraft.stop()));
            row.addChild(button("nvidiumplus.popup.later", this::dismiss));
         }
      }
   }

   private static Button button(String key, Runnable action) {
      return Button.builder(Component.translatable(key), b -> action.run()).width(150).build();
   }

   protected void repositionElements() {
      this.layout.arrangeElements();
      FrameLayout.centerInRectangle(this.layout, this.getRectangle());
   }

   public void onClose() {
      this.dismiss();
   }

   public boolean isPauseScreen() {
      return true;
   }

   private void enableVulkan() {
      this.minecraft.options.preferredGraphicsBackend().set(PreferredGraphicsApi.VULKAN);
      this.minecraft.options.save();
      this.minecraft.gui.setScreen(new NvidiumPlusPopupScreen(NvidiumPlusPopupScreen.Variant.RESTART_REQUIRED, this.parent));
   }

   private void dontShowAgain() {
      NvidiumPlusConfig config = NvidiumPlusConfig.get();
      config.showVulkanPrompt = false;
      config.save();
      this.dismiss();
   }

   private void dismiss() {
      if (this.parent != null || this.minecraft.gui.canInterruptScreen()) {
         this.minecraft.gui.setScreen(this.parent);
      }
   }

   public enum Variant {
      ENABLE_VULKAN("nvidiumplus.popup.opengl.title", "nvidiumplus.popup.opengl.body"),
      VULKAN_FAILED("nvidiumplus.popup.vulkan_failed.title", "nvidiumplus.popup.vulkan_failed.body"),
      NO_MESH_SHADERS("nvidiumplus.popup.no_mesh.title", "nvidiumplus.popup.no_mesh.body"),
      RESTART_REQUIRED("nvidiumplus.popup.restart.title", "nvidiumplus.popup.restart.body");

      final String titleKey;
      final String bodyKey;

      Variant(String titleKey, String bodyKey) {
         this.titleKey = titleKey;
         this.bodyKey = bodyKey;
      }
   }
}
