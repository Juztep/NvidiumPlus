package nvidiumplus.engine.gui;

import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Options;
import net.minecraft.client.OptionInstance.IntRangeBase;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.components.ScrollableLayout;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.farfield.FarField;
import nvidiumplus.engine.farfield.FarFieldConfig;
import nvidiumplus.engine.farfield.FarFieldResidency;
import nvidiumplus.engine.farfield.extract.ExtractDispatch;

public class NvidiumPlusFarFieldScreen extends Screen {
   private static final int WIDGET_WIDTH = 200;
   private static final int BANNER_WIDTH = 340;
   private static final int SIZE_REFRESH_TICKS = 40;
   private static final int CLEAR_RESULT_TICKS = 100;
   private static final int APPLY_DEBOUNCE_TICKS = 8;
   private static final long SIZE_PENDING = -2L;
   private static final long SIZE_FAILED = -1L;
   private static final int CLEAR_IDLE = 0;
   private static final int CLEAR_WORKING = 1;
   private static final int CLEAR_DONE = 2;
   private static final int CLEAR_FAILED = 3;
   private static final int FALLBACK_MIN_RENDER_DISTANCE = 2;
   private static final int FALLBACK_MAX_RENDER_DISTANCE = 32;
   private final Screen parent;
   private final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);
   private ScrollableLayout scrollArea;
   private final boolean gateLocked;
   private CycleButton<Boolean> masterButton;
   private NvidiumPlusFarFieldScreen.PresetSlider presetSlider;
   private NvidiumPlusFarFieldScreen.RenderDistanceSlider renderDistanceSlider;
   private NvidiumPlusFarFieldScreen.FarRadiusSlider radiusSlider;
   private CycleButton<Boolean> bandButton;
   private StringWidget sizeLine;
   private StringWidget statusLine;
   private Button clearButton;
   private volatile long cacheBytes = -2L;
   private volatile boolean sizeInFlight;
   private volatile boolean sizeDirty = true;
   private volatile int clearState = 0;
   private int sizeCooldownTicks;
   private boolean clearArmed;
   private int clearResultTicks;
   private FarFieldConfig.Preset pendingPreset;
   private int pendingRenderDistance = -1;
   private int applyDebounceTicks;

   public NvidiumPlusFarFieldScreen(Screen parent) {
      super(Component.translatable("nvidiumplus.options.farfield.title"));
      this.parent = parent;
      this.gateLocked = NvidiumPlusGate.state() != NvidiumPlusGate.State.VULKAN_MESH_SHADERS;
   }

   protected void init() {
      FarFieldConfig config = FarFieldConfig.get();
      this.reconcilePresetWithRenderDistance(config);
      this.layout.addTitleHeader(this.getTitle(), this.font);
      LinearLayout rows = LinearLayout.vertical().spacing(2);
      rows.defaultCellSetting().alignHorizontallyCenter();
      boolean enabledOverridden = System.getProperty("nvidiumplus.farfield.enabled") != null;
      boolean radiusOverridden = FarFieldConfig.isPropertyOverridden(FarFieldConfig.Layer.L1, FarFieldConfig.Control.DISTANCE)
         || FarFieldConfig.isPropertyOverridden(FarFieldConfig.Layer.L1, FarFieldConfig.Control.LAYER_ENABLED);
      boolean bandOverridden = System.getProperty("nvidiumplus.farfield.surfaceBand") != null;
      boolean presetOverridden = System.getProperty("nvidiumplus.farfield.preset") != null;
      if (enabledOverridden || radiusOverridden || bandOverridden || presetOverridden) {
         rows.addChild(this.banner(Component.translatable("nvidiumplus.options.dev_override")), s -> s.paddingTop(2).paddingBottom(2));
      }

      if (this.gateLocked) {
         String lockedKey = NvidiumPlusGate.sodiumAdapterArmed() ? "nvidiumplus.options.advanced.locked.sodium" : "nvidiumplus.options.advanced.locked";
         rows.addChild(this.banner(Component.translatable(lockedKey).withStyle(ChatFormatting.YELLOW)), s -> s.paddingTop(2).paddingBottom(2));
      }

      rows.addChild(this.sectionHeader("nvidiumplus.options.farfield.section.quick"), s -> s.paddingTop(6).paddingBottom(2));
      this.masterButton = CycleButton.onOffBuilder(config.enabled).create(Component.translatable("nvidiumplus.options.farfield.enabled"), (b, value) -> {
         config.enabled = value;
         this.markCustomAndSave(config);
      });
      this.masterButton.setWidth(200);
      this.masterButton.active = !this.gateLocked && !enabledOverridden;
      this.masterButton.setTooltip(this.tip("nvidiumplus.options.tooltip.farfield.enabled", "nvidiumplus.options.applies.now"));
      rows.addChild(this.masterButton, s -> s.paddingTop(4));
      this.presetSlider = new NvidiumPlusFarFieldScreen.PresetSlider(
         !this.gateLocked && !enabledOverridden && !radiusOverridden && !bandOverridden && !presetOverridden
      );
      this.presetSlider.setTooltip(this.tip("nvidiumplus.options.tooltip.farfield.preset", "nvidiumplus.options.applies.now"));
      rows.addChild(this.presetSlider);
      this.renderDistanceSlider = new NvidiumPlusFarFieldScreen.RenderDistanceSlider();
      this.renderDistanceSlider
         .setTooltip(
            Tooltip.create(withSemantics(Component.translatable("nvidiumplus.options.tooltip.farfield.render_distance"), "nvidiumplus.options.applies.now"))
         );
      rows.addChild(this.renderDistanceSlider);
      this.radiusSlider = new NvidiumPlusFarFieldScreen.FarRadiusSlider(!this.gateLocked && !radiusOverridden);
      this.radiusSlider.setTooltip(this.tip("nvidiumplus.options.tooltip.farfield.radius", "nvidiumplus.options.applies.now"));
      rows.addChild(this.radiusSlider);
      rows.addChild(this.sectionHeader("nvidiumplus.options.farfield.section.layers"), s -> s.paddingTop(8).paddingBottom(2));
      rows.addChild(this.banner(Component.translatable("nvidiumplus.options.farfield.layers.note").withStyle(ChatFormatting.GRAY)), s -> s.paddingBottom(2));

      for (FarFieldConfig.Layer layer : FarFieldConfig.Layer.values()) {
         rows.addChild(this.layerButton(layer));
      }

      rows.addChild(this.sectionHeader("nvidiumplus.options.farfield.section.storage"), s -> s.paddingTop(8).paddingBottom(2));
      this.bandButton = CycleButton.booleanBuilder(
            Component.translatable("nvidiumplus.options.farfield.band.surface"),
            Component.translatable("nvidiumplus.options.farfield.band.full"),
            config.surfaceBand
         )
         .create(Component.translatable("nvidiumplus.options.farfield.band"), (b, value) -> {
            config.surfaceBand = value;
            this.markCustomAndSave(config);
         });
      this.bandButton.setWidth(200);
      this.bandButton.active = !this.gateLocked && !bandOverridden;
      this.bandButton.setTooltip(this.tip("nvidiumplus.options.tooltip.farfield.band", "nvidiumplus.options.applies.new_cache"));
      rows.addChild(this.bandButton);
      rows.addChild(
         this.banner(Component.translatable("nvidiumplus.options.farfield.band.note").withStyle(ChatFormatting.GRAY)), s -> s.paddingTop(2).paddingBottom(4)
      );
      MultiLineTextWidget folder = this.banner(
         Component.translatable("nvidiumplus.options.farfield.folder", new Object[]{Component.literal(FarField.cacheFolder().toString())})
      );
      folder.setTooltip(Tooltip.create(Component.translatable("nvidiumplus.options.tooltip.farfield.folder")));
      rows.addChild(folder, s -> s.paddingTop(2));
      this.sizeLine = new StringWidget(this.sizeText(), this.font);
      this.sizeLine.setMaxWidth(340);
      this.sizeLine.setTooltip(Tooltip.create(Component.translatable("nvidiumplus.options.tooltip.farfield.size")));
      rows.addChild(this.sizeLine, s -> s.paddingTop(2).paddingBottom(2));
      this.statusLine = new StringWidget(this.statusText(), this.font);
      this.statusLine.setMaxWidth(340);
      this.statusLine.setTooltip(Tooltip.create(Component.translatable("nvidiumplus.options.tooltip.farfield.status")));
      rows.addChild(this.statusLine, s -> s.paddingTop(2).paddingBottom(2));
      this.clearButton = Button.builder(this.clearText(), b -> {
         if (this.clearState != 1) {
            if (!this.clearArmed) {
               this.clearArmed = true;
               this.clearState = 0;
               b.setMessage(this.clearText());
            } else {
               this.clearArmed = false;
               this.clearState = 1;
               b.setMessage(this.clearText());
               FarField.requestCacheClear(ok -> {
                  this.clearState = ok ? 2 : 3;
                  this.cacheBytes = -2L;
                  this.sizeDirty = true;
               });
            }
         }
      }).width(200).build();
      this.clearButton.setTooltip(Tooltip.create(Component.translatable("nvidiumplus.options.tooltip.farfield.clear")));
      rows.addChild(this.clearButton, s -> s.paddingTop(2));
      this.scrollArea = new ScrollableLayout(this.minecraft, rows, this.layout.getContentHeight());
      this.layout.addToContents(this.scrollArea);
      this.layout.addToFooter(Button.builder(CommonComponents.GUI_DONE, b -> this.onClose()).width(200).build());
      NvidiumPlusFarFieldScreen var13 = this;
      this.layout.visitWidgets(x$0 -> var13.addRenderableWidget(x$0));
      this.repositionElements();
   }

   private MultiLineTextWidget banner(Component text) {
      MultiLineTextWidget widget = new MultiLineTextWidget(text, this.font);
      widget.setMaxWidth(340);
      widget.setCentered(true);
      return widget;
   }

   private StringWidget sectionHeader(String key) {
      StringWidget widget = new StringWidget(Component.translatable(key).withStyle(ChatFormatting.GRAY), this.font);
      widget.setMaxWidth(340);
      return widget;
   }

   private Button layerButton(FarFieldConfig.Layer layer) {
      MutableComponent label = Component.translatable("nvidiumplus.options.farfield." + layer.key);
      boolean wired = FarFieldConfig.isLayerWired(layer);
      Component shown = wired ? label : Component.translatable("nvidiumplus.options.farfield.planned.row", new Object[]{label});
      Button button = Button.builder(shown, b -> {
         if (this.minecraft != null) {
            this.minecraft.gui.setScreen(new NvidiumPlusFarLayerScreen(this, layer));
         }
      }).width(200).build();
      button.setTooltip(Tooltip.create(Component.translatable("nvidiumplus.options.tooltip.farfield." + layer.key)));
      return button;
   }

   private void markCustomAndSave(FarFieldConfig config) {
      config.markCustom();
      config.save();
      ExtractDispatch.refreshArmed();
   }

   private void applyPreset(FarFieldConfig.Preset preset) {
      FarFieldConfig config = FarFieldConfig.get();
      config.applyPreset(preset);
      config.save();
      ExtractDispatch.refreshArmed();
      if (preset.managesValues()) {
         this.commitRenderDistance(preset.renderDistanceChunks());
      }

      this.syncRows();
   }

   private void commitRenderDistance(int chunks) {
      if (this.minecraft != null && this.minecraft.options != null) {
         Options options = this.minecraft.options;
         int target = Math.max(this.renderDistanceMin(), Math.min(this.renderDistanceMax(), chunks));
         if ((Integer)options.renderDistance().get() != target) {
            options.renderDistance().set(target);
         }

         options.save();
      }
   }

   private int renderDistanceMin() {
      return this.renderDistanceBound(true);
   }

   private int renderDistanceMax() {
      return this.renderDistanceBound(false);
   }

   private int renderDistanceBound(boolean wantMin) {
      if (this.minecraft != null && this.minecraft.options != null && this.minecraft.options.renderDistance().values() instanceof IntRangeBase range) {
         return wantMin ? range.minInclusive() : range.maxInclusive();
      } else {
         return wantMin ? 2 : 32;
      }
   }

   private int currentRenderDistance() {
      return this.minecraft != null && this.minecraft.options != null ? (Integer)this.minecraft.options.renderDistance().get() : 32;
   }

   private void reconcilePresetWithRenderDistance(FarFieldConfig config) {
      FarFieldConfig.Preset selected = FarFieldConfig.selectedPreset();
      if (selected.managesValues()) {
         int want = Math.max(this.renderDistanceMin(), Math.min(this.renderDistanceMax(), selected.renderDistanceChunks()));
         if (want != this.currentRenderDistance() && config.markCustom()) {
            config.save();
         }
      }
   }

   private void syncRows() {
      FarFieldConfig config = FarFieldConfig.get();
      if (this.masterButton != null && !Boolean.valueOf(config.enabled).equals(this.masterButton.getValue())) {
         this.masterButton.setValue(config.enabled);
      }

      if (this.bandButton != null && !Boolean.valueOf(config.surfaceBand).equals(this.bandButton.getValue())) {
         this.bandButton.setValue(config.surfaceBand);
      }

      if (this.presetSlider != null && this.pendingPreset == null) {
         this.presetSlider.showPreset(FarFieldConfig.selectedPreset());
      }

      if (this.renderDistanceSlider != null && this.pendingRenderDistance < 0) {
         this.renderDistanceSlider.showChunks(this.currentRenderDistance());
      }

      if (this.radiusSlider != null) {
         this.radiusSlider.showChunks(FarFieldConfig.layerRadiusChunks(FarFieldConfig.Layer.L1));
      }
   }

   private void flushPending() {
      this.applyDebounceTicks = 0;
      FarFieldConfig.Preset preset = this.pendingPreset;
      int chunks = this.pendingRenderDistance;
      this.pendingPreset = null;
      this.pendingRenderDistance = -1;
      if (preset != null) {
         this.applyPreset(preset);
      }

      if (chunks >= 0) {
         this.commitRenderDistance(chunks);
         this.markCustomAndSave(FarFieldConfig.get());
         this.syncRows();
      }
   }

   public void tick() {
      super.tick();
      if (this.applyDebounceTicks > 0 && --this.applyDebounceTicks == 0) {
         this.flushPending();
      }

      if (!this.sizeDirty && this.sizeCooldownTicks > 0) {
         this.sizeCooldownTicks--;
      } else {
         this.sizeDirty = false;
         this.sizeCooldownTicks = 40;
         this.requestSize();
      }

      if (this.sizeLine != null) {
         this.sizeLine.setMessage(this.sizeText());
      }

      if (this.statusLine != null) {
         this.statusLine.setMessage(this.statusText());
      }

      this.syncRows();
      if (this.clearState != 2 && this.clearState != 3) {
         this.clearResultTicks = 0;
      } else if (this.clearResultTicks++ >= 100) {
         this.clearResultTicks = 0;
         this.clearState = 0;
      }

      if (this.clearButton != null) {
         this.clearButton.setMessage(this.clearText());
      }
   }

   private void requestSize() {
      if (!this.sizeInFlight) {
         this.sizeInFlight = true;
         boolean started = FarField.requestCacheSizeBytes(bytes -> {
            this.cacheBytes = bytes;
            this.sizeInFlight = false;
         });
         if (!started) {
            this.sizeInFlight = false;
         }
      }
   }

   private Component sizeText() {
      long bytes = this.cacheBytes;
      Component value;
      if (bytes == -2L) {
         value = Component.translatable("nvidiumplus.options.farfield.size.checking");
      } else if (bytes == -1L) {
         value = Component.translatable("nvidiumplus.options.farfield.size.unknown");
      } else {
         value = Component.literal(humanBytes(bytes));
      }

      return Component.translatable("nvidiumplus.options.farfield.size", new Object[]{value});
   }

   private Component statusText() {
      if (!FarFieldConfig.enabled()) {
         return Component.translatable("nvidiumplus.options.farfield.status.off");
      }

      long drawn = FarFieldResidency.farSectionsResident.sum();
      long saved = ExtractDispatch.farExtracts.sum();
      return Component.translatable(
         "nvidiumplus.options.farfield.status",
         new Object[]{Component.literal(Long.toString(Math.max(0L, drawn))), Component.literal(Long.toString(Math.max(0L, saved)))}
      );
   }

   private Component clearText() {
      return switch (this.clearState) {
         case 1 -> Component.translatable("nvidiumplus.options.farfield.clear.working");
         case 2 -> Component.translatable("nvidiumplus.options.farfield.clear.done");
         case 3 -> Component.translatable("nvidiumplus.options.farfield.clear.failed").withStyle(ChatFormatting.RED);
         default -> this.clearArmed
            ? Component.translatable("nvidiumplus.options.farfield.clear.confirm").withStyle(ChatFormatting.RED)
            : Component.translatable("nvidiumplus.options.farfield.clear");
      };
   }

   private static String humanBytes(long bytes) {
      if (bytes < 1024L) {
         return bytes + " B";
      } else if (bytes < 1048576L) {
         return String.format(Locale.ROOT, "%.1f KB", bytes / 1024.0);
      } else {
         return bytes < 1073741824L ? String.format(Locale.ROOT, "%.1f MB", bytes / 1048576.0) : String.format(Locale.ROOT, "%.2f GB", bytes / 1.0737418E9F);
      }
   }

   private Tooltip tip(String descriptionKey, String appliesKey) {
      String semantics = !this.gateLocked
         ? appliesKey
         : (NvidiumPlusGate.state() == NvidiumPlusGate.State.SODIUM_PRESENT ? "nvidiumplus.options.applies.sodium" : "nvidiumplus.options.applies.vulkan");
      return Tooltip.create(withSemantics(Component.translatable(descriptionKey), semantics));
   }

   private static Component withSemantics(MutableComponent description, String semanticsKey) {
      return description.append(Component.literal("\n\n")).append(Component.translatable(semanticsKey).withStyle(ChatFormatting.GRAY));
   }

   private static double presetFraction(FarFieldConfig.Preset preset) {
      for (int i = 0; i < FarFieldConfig.Preset.LADDER.length; i++) {
         if (FarFieldConfig.Preset.LADDER[i] == preset) {
            return (double)i / (FarFieldConfig.Preset.LADDER.length - 1);
         }
      }

      return 0.0;
   }

   private double renderDistanceFraction(int chunks) {
      int min = this.renderDistanceMin();
      int max = this.renderDistanceMax();
      return max <= min ? 0.0 : Math.max(0.0, Math.min(1.0, (double)(chunks - min) / (max - min)));
   }

   private static double radiusFraction(int chunks) {
      int span = 192;
      double f = (double)(chunks - 0) / span;
      return Math.max(0.0, Math.min(1.0, f));
   }

   protected void repositionElements() {
      this.scrollArea.arrangeElements();
      this.scrollArea.setMaxHeight(this.layout.getContentHeight());
      this.layout.arrangeElements();
   }

   public void onClose() {
      this.flushPending();
      if (this.minecraft != null) {
         this.minecraft.gui.setScreen(this.parent);
      }
   }

   private final class FarRadiusSlider extends AbstractSliderButton {
      private int displayed;

      FarRadiusSlider(boolean active) {
         super(0, 0, 200, 20, Component.empty(), NvidiumPlusFarFieldScreen.radiusFraction(FarFieldConfig.layerRadiusChunks(FarFieldConfig.Layer.L1)));
         this.active = active;
         this.displayed = FarFieldConfig.layerRadiusChunks(FarFieldConfig.Layer.L1);
         this.updateMessage();
      }

      void showChunks(int chunks) {
         if (chunks != this.displayed) {
            this.displayed = chunks;
            this.value = NvidiumPlusFarFieldScreen.radiusFraction(chunks);
            this.updateMessage();
         }
      }

      protected void updateMessage() {
         Component shown = this.displayed <= 0
            ? Component.translatable("nvidiumplus.options.cull.off")
            : Component.translatable("nvidiumplus.options.cull.chunks", new Object[]{Component.literal(Integer.toString(this.displayed))});
         this.setMessage(Component.translatable("nvidiumplus.options.farfield.radius.label", new Object[]{shown}));
      }

      protected void applyValue() {
         int span = 192;
         int chunks = 0 + (int)Math.round(this.value * span);
         if (chunks != this.displayed) {
            this.displayed = chunks;
            FarFieldConfig config = FarFieldConfig.get();
            config.layer(FarFieldConfig.Layer.L1).radiusChunks = chunks;
            config.layer(FarFieldConfig.Layer.L1).enabled = chunks > 0;
            NvidiumPlusFarFieldScreen.this.markCustomAndSave(config);
         }

         this.updateMessage();
      }
   }

   private final class PresetSlider extends AbstractSliderButton {
      private FarFieldConfig.Preset displayed;

      PresetSlider(boolean active) {
         super(0, 0, 200, 20, Component.empty(), NvidiumPlusFarFieldScreen.presetFraction(FarFieldConfig.selectedPreset()));
         this.active = active;
         this.displayed = FarFieldConfig.selectedPreset();
         this.updateMessage();
      }

      void showPreset(FarFieldConfig.Preset preset) {
         if (preset != this.displayed) {
            this.displayed = preset;
            this.value = NvidiumPlusFarFieldScreen.presetFraction(preset);
            this.updateMessage();
         }
      }

      protected void updateMessage() {
         this.setMessage(
            Component.translatable(
               "nvidiumplus.options.farfield.preset.label", new Object[]{Component.translatable("nvidiumplus.options.farfield.preset." + this.displayed.id)}
            )
         );
      }

      protected void applyValue() {
         int index = (int)Math.round(this.value * (FarFieldConfig.Preset.LADDER.length - 1));
         index = Math.max(0, Math.min(FarFieldConfig.Preset.LADDER.length - 1, index));
         FarFieldConfig.Preset picked = FarFieldConfig.Preset.LADDER[index];
         if (picked != this.displayed) {
            this.displayed = picked;
            NvidiumPlusFarFieldScreen.this.pendingPreset = picked;
            NvidiumPlusFarFieldScreen.this.pendingRenderDistance = -1;
            NvidiumPlusFarFieldScreen.this.applyDebounceTicks = 8;
         }

         this.updateMessage();
      }

      public void onRelease(MouseButtonEvent event) {
         super.onRelease(event);
         if (NvidiumPlusFarFieldScreen.this.pendingPreset != null) {
            NvidiumPlusFarFieldScreen.this.flushPending();
         }
      }
   }

   private final class RenderDistanceSlider extends AbstractSliderButton {
      private int displayed = NvidiumPlusFarFieldScreen.this.currentRenderDistance();

      RenderDistanceSlider() {
         super(0, 0, 200, 20, Component.empty(), 0.0);
         this.value = NvidiumPlusFarFieldScreen.this.renderDistanceFraction(this.displayed);
         this.updateMessage();
      }

      void showChunks(int chunks) {
         if (chunks != this.displayed) {
            this.displayed = chunks;
            this.value = NvidiumPlusFarFieldScreen.this.renderDistanceFraction(chunks);
            this.updateMessage();
         }
      }

      protected void updateMessage() {
         this.setMessage(
            Component.translatable("nvidiumplus.options.farfield.render_distance.label", new Object[]{Component.literal(Integer.toString(this.displayed))})
         );
      }

      protected void applyValue() {
         int min = NvidiumPlusFarFieldScreen.this.renderDistanceMin();
         int max = NvidiumPlusFarFieldScreen.this.renderDistanceMax();
         int chunks = min + (int)Math.round(this.value * (max - min));
         if (chunks != this.displayed) {
            this.displayed = chunks;
            NvidiumPlusFarFieldScreen.this.pendingRenderDistance = chunks;
            NvidiumPlusFarFieldScreen.this.applyDebounceTicks = 8;
         }

         this.updateMessage();
      }

      public void onRelease(MouseButtonEvent event) {
         super.onRelease(event);
         if (NvidiumPlusFarFieldScreen.this.pendingRenderDistance >= 0) {
            NvidiumPlusFarFieldScreen.this.flushPending();
         }
      }
   }
}
