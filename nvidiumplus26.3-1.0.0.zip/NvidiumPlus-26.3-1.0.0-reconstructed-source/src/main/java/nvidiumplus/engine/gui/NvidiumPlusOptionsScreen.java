package nvidiumplus.engine.gui;

import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.PreferredGraphicsApi;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.VideoSettingsScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import nvidiumplus.engine.NvidiumPlusConfig;
import nvidiumplus.engine.NvidiumPlusExtendedRd;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.NvidiumPlusPlatform;
import nvidiumplus.engine.NvidiumPlusSodiumVersion;
import nvidiumplus.engine.NvidiumPlusVramState;
import nvidiumplus.engine.mixin.OptionsSubScreenAccessor;
import nvidiumplus.engine.terrain.host.TerrainResidency;
import nvidiumplus.engine.vk.SodiumTerrainDrawer;
import nvidiumplus.engine.vk.TerrainDrawer;

public final class NvidiumPlusOptionsScreen extends Screen {
   private static final int WIDGET_WIDTH = 200;
   private static final int SLIDER_WIDTH = 150;
   private static final int CUSTOM_WIDTH = 46;
   private static final int BANNER_MAX_WIDTH = 340;
   private static final int[] CAP_STOPS = buildCapStops();
   private final Screen parent;
   private final LinearLayout layout = LinearLayout.vertical().spacing(2);
   private boolean gateLocked;
   private boolean capLocked;
   private NvidiumPlusGate.State gateAtInit;
   private MultiLineTextWidget gateBanner;
   private StringWidget statusLine;
   private StringWidget memoryLine;
   private MultiLineTextWidget sodiumVersionLine;
   private int capAtOpen;
   private int rdAtOpen;
   private NvidiumPlusOptionsScreen.CapSlider capSlider;
   private NvidiumPlusOptionsScreen.ValueBox capBox;
   private NvidiumPlusOptionsScreen.OcclusionRdSlider occlusionSlider;
   private NvidiumPlusOptionsScreen.ValueBox occlusionBox;
   private NvidiumPlusOptionsScreen.FogEndSlider fogSlider;
   private NvidiumPlusOptionsScreen.ValueBox fogBox;
   private boolean resetArmed;
   private Button resetButton;
   private static final int TEXT_OK = -2039584;
   private static final int TEXT_BAD = -43691;

   public static void openFromCommand() {
      Minecraft client = Minecraft.getInstance();
      if (client != null) {
         client.schedule(() -> client.gui.setScreen(new NvidiumPlusOptionsScreen(client.gui.screen())));
      }
   }

   public NvidiumPlusOptionsScreen(Screen parent) {
      super(Component.translatable("nvidiumplus.options.title"));
      this.parent = parent;
   }

   private static int[] buildCapStops() {
      int n = 9;
      int[] stops = new int[n];

      for (int i = 0; i < n; i++) {
         stops[i] = 32 + i * 8;
      }

      return stops;
   }

   public boolean gateLocked() {
      return this.gateLocked;
   }

   public boolean capLocked() {
      return this.capLocked;
   }

   public String gateBannerText() {
      return this.gateBanner != null ? this.gateBanner.getMessage().getString() : "";
   }

   public String sodiumVersionText() {
      return this.sodiumVersionLine != null ? this.sodiumVersionLine.getMessage().getString() : "";
   }

   public void testRefreshStatus() {
      if (this.statusLine != null) {
         this.statusLine.setMessage(this.buildStatusLine());
      }
   }

   public String statusText() {
      return this.statusLine != null ? this.statusLine.getMessage().getString() : "";
   }

   public String capSliderText() {
      return this.capSlider != null ? this.capSlider.getMessage().getString() : "";
   }

   public void testSetCap(int cap) {
      this.applyCap(cap);
   }

   public void testSetCapBoxText(String text) {
      if (this.capBox != null) {
         this.capBox.setValue(text);
      }
   }

   public String testCapBoxText() {
      return this.capBox != null ? this.capBox.getValue() : "";
   }

   public int testCapBoxTextAlpha() {
      return this.capBox != null ? this.capBox.testTextAlpha() : 0;
   }

   public void testCommitCapBox() {
      if (this.capBox != null) {
         this.capBox.testCommit();
      }
   }

   public void tick() {
      super.tick();
      if (this.gateAtInit == NvidiumPlusGate.State.UNKNOWN && NvidiumPlusGate.state() != NvidiumPlusGate.State.UNKNOWN && this.minecraft != null) {
         this.minecraft.gui.setScreen(new NvidiumPlusOptionsScreen(this.parent));
      } else {
         if (this.statusLine != null) {
            this.statusLine.setMessage(this.buildStatusLine());
         }

         if (this.memoryLine != null) {
            this.memoryLine.setMessage(memoryStatus());
         }
      }
   }

   private Component buildStatusLine() {
      return (Component)(switch (NvidiumPlusGate.state()) {
         case OPENGL -> off("nvidiumplus.options.status.reason.opengl");
         case VULKAN_NO_MESH_SHADERS -> off("nvidiumplus.options.status.reason.no_mesh");
         case UNKNOWN -> Component.translatable("nvidiumplus.options.status.checking").withStyle(ChatFormatting.YELLOW);
         case SODIUM_PRESENT -> this.sodiumStatusLine();
         case VULKAN_MESH_SHADERS -> this.vulkanStatusLine();
      });
   }

   private Component sodiumStatusLine() {
      if (!NvidiumPlusGate.sodiumAdapterArmed()) {
         String reason = !NvidiumPlusPlatform.sodiumAdapterAvailable()
            ? "nvidiumplus.options.status.reason.sodium_no_adapter"
            : (!NvidiumPlusGate.sodiumAdapterConfigured() ? "nvidiumplus.options.status.reason.sodium_declined" : "nvidiumplus.options.status.reason.sodium");
         return off(reason);
      } else if (SodiumTerrainDrawer.broken()) {
         return off("nvidiumplus.options.status.reason.error");
      } else if (this.minecraft != null && this.minecraft.level != null) {
         return (Component)(SodiumTerrainDrawer.framesDrawn() == 0L
            ? off("nvidiumplus.options.status.reason.sodium_no_frames")
            : Component.translatable("nvidiumplus.options.status.sodium_active", new Object[]{SodiumTerrainDrawer.lastSectionsDrawnFrame()})
               .withStyle(ChatFormatting.GREEN));
      } else {
         return Component.translatable("nvidiumplus.options.status.sodium_ready").withStyle(ChatFormatting.GREEN);
      }
   }

   private static String sodiumBannerKey(NvidiumPlusGate.State backend, boolean vulkanAlreadyRequested) {
      if (NvidiumPlusGate.sodiumAdapterArmed()) {
         return "nvidiumplus.options.gate.sodium";
      }

      if (!NvidiumPlusPlatform.sodiumAdapterAvailable()) {
         return "nvidiumplus.options.gate.sodium_no_adapter";
      }

      return switch (backend) {
         case OPENGL -> vulkanAlreadyRequested ? "nvidiumplus.options.gate.vulkan_failed.sodium" : "nvidiumplus.options.gate.sodium_opengl";
         case VULKAN_NO_MESH_SHADERS -> "nvidiumplus.options.gate.no_mesh.sodium";
         case UNKNOWN -> "nvidiumplus.options.gate.unknown";
         default -> "nvidiumplus.options.gate.sodium_declined";
      };
   }

   private Component vulkanStatusLine() {
      if (!NvidiumPlusConfig.terrainRenderingEnabled()) {
         return off("nvidiumplus.options.status.reason.terrain_off");
      } else if (TerrainDrawer.lastError() != null) {
         return off("nvidiumplus.options.status.reason.error");
      } else if (this.minecraft == null || this.minecraft.level == null) {
         return Component.translatable("nvidiumplus.options.status.ready").withStyle(ChatFormatting.GREEN);
      } else {
         return (Component)(TerrainDrawer.coveragePassive()
            ? offPassive()
            : Component.translatable("nvidiumplus.options.status.active", new Object[]{TerrainDrawer.lastDrawnSections()}).withStyle(ChatFormatting.GREEN));
      }
   }

   private static Component memoryStatus() {
      long used = TerrainResidency.counters().arenaUsedBytes();
      long budget = NvidiumPlusVramState.budgetBytes();
      if (budget <= 0L) {
         return Component.translatable("nvidiumplus.options.status.memory", new Object[]{used >> 20}).withStyle(ChatFormatting.GRAY);
      }

      long free = Math.max(0L, budget - NvidiumPlusVramState.usageBytes());
      return Component.translatable("nvidiumplus.options.status.memory_free", new Object[]{used >> 20, free >> 20}).withStyle(ChatFormatting.GRAY);
   }

   private static Component off(String reasonKey) {
      return Component.translatable("nvidiumplus.options.status.off", new Object[]{Component.translatable(reasonKey)}).withStyle(ChatFormatting.RED);
   }

   private static Component offPassive() {
      TerrainResidency.GuardTrip trip = TerrainResidency.guardTrip();
      if (trip == null) {
         return off("nvidiumplus.options.status.reason.passive");
      }

      Component reason = switch (trip.kind()) {
         case "arena" -> Component.translatable("nvidiumplus.options.status.reason.passive.arena", new Object[]{trip.value(), trip.limit()});
         case "oversize" -> Component.translatable("nvidiumplus.options.status.reason.passive.oversize", new Object[]{trip.value(), trip.limit()});
         case "region" -> Component.translatable("nvidiumplus.options.status.reason.passive.region", new Object[]{trip.value(), trip.limit()});
         case "vram" -> Component.translatable("nvidiumplus.options.status.reason.passive.vram", new Object[]{trip.value(), trip.limit()});
         case "encoding" -> Component.translatable("nvidiumplus.options.status.reason.passive.encoding");
         default -> Component.translatable("nvidiumplus.options.status.reason.passive");
      };
      return Component.translatable("nvidiumplus.options.status.off", new Object[]{reason}).withStyle(ChatFormatting.RED);
   }

   private void enableVulkan() {
      this.minecraft.options.preferredGraphicsBackend().set(PreferredGraphicsApi.VULKAN);
      this.minecraft.options.save();
      this.minecraft.gui.setScreen(new NvidiumPlusPopupScreen(NvidiumPlusPopupScreen.Variant.RESTART_REQUIRED, this));
   }

   protected void init() {
      super.init();
      NvidiumPlusConfig config = NvidiumPlusConfig.get();
      NvidiumPlusGate.State gate = NvidiumPlusGate.state();
      this.gateAtInit = gate;
      boolean sodium = gate == NvidiumPlusGate.State.SODIUM_PRESENT;
      this.gateLocked = gate != NvidiumPlusGate.State.VULKAN_MESH_SHADERS;
      this.capLocked = this.gateLocked && !sodium;
      this.capAtOpen = config.maxRenderDistance;
      this.rdAtOpen = this.minecraft != null && this.minecraft.options != null ? (Integer)this.minecraft.options.renderDistance().get() : -1;
      boolean terrainOverridden = System.getProperty("nvidiumplus.terrainDraw") != null;
      boolean maxRdOverridden = System.getProperty("nvidiumplus.maxRenderDistance") != null;
      boolean occlusionOverridden = System.getProperty("nvidiumplus.terrainDraw.bfsOnly") != null;
      boolean fogOverridden = System.getProperty("nvidiumplus.fogMode") != null;
      boolean sodiumGpuOverridden = System.getProperty("nvidiumplus.sodium.gpuDraw") != null;
      this.layout.defaultCellSetting().alignHorizontallyCenter();
      this.layout.addChild(new StringWidget(this.getTitle(), this.font));
      this.statusLine = (StringWidget)this.layout.addChild(new StringWidget(this.buildStatusLine(), this.font), s -> s.paddingTop(2));
      this.statusLine.setTooltip(Tooltip.create(Component.translatable("nvidiumplus.options.tooltip.status")));
      if (sodium) {
         String installedSodium = NvidiumPlusPlatform.modVersion("sodium").orElse(null);
         if (installedSodium != null) {
            Component versionLine = NvidiumPlusSodiumVersion.matches(installedSodium)
               ? Component.translatable("nvidiumplus.options.sodium.version", new Object[]{installedSodium}).withStyle(ChatFormatting.GRAY)
               : Component.translatable("nvidiumplus.options.sodium.version_mismatch", new Object[]{installedSodium, NvidiumPlusSodiumVersion.BUILT_AGAINST})
                  .withStyle(ChatFormatting.YELLOW);
            this.sodiumVersionLine = (MultiLineTextWidget)this.layout
               .addChild(new MultiLineTextWidget(versionLine, this.font).setMaxWidth(340).setCentered(true), s -> s.paddingTop(1));
         }
      }

      if (!sodium) {
         this.memoryLine = (StringWidget)this.layout.addChild(new StringWidget(memoryStatus(), this.font), s -> s.paddingTop(1));
      }

      if (this.gateLocked) {
         NvidiumPlusGate.State backend = NvidiumPlusGate.backend();
         boolean vulkanAlreadyRequested = backend == NvidiumPlusGate.State.OPENGL
            && this.minecraft.options.preferredGraphicsBackend().get() == PreferredGraphicsApi.VULKAN;

         String reasonKey = switch (gate) {
            case OPENGL -> vulkanAlreadyRequested ? "nvidiumplus.options.gate.vulkan_failed" : "nvidiumplus.options.gate.opengl";
            case VULKAN_NO_MESH_SHADERS -> "nvidiumplus.options.gate.no_mesh";
            case UNKNOWN -> "nvidiumplus.options.gate.unknown";
            case SODIUM_PRESENT -> sodiumBannerKey(backend, vulkanAlreadyRequested);
            case VULKAN_MESH_SHADERS -> throw new AssertionError("gateLocked is false for " + gate);
         };
         this.gateBanner = (MultiLineTextWidget)this.layout
            .addChild(
               new MultiLineTextWidget(Component.translatable(reasonKey).withStyle(ChatFormatting.YELLOW), this.font).setMaxWidth(340).setCentered(true),
               s -> s.paddingTop(2)
            );
         if (backend == NvidiumPlusGate.State.OPENGL && !vulkanAlreadyRequested && (!sodium || NvidiumPlusGate.sodiumAdapterConfigured())) {
            Button enable = Button.builder(Component.translatable("nvidiumplus.popup.enable_vulkan"), b -> this.enableVulkan()).width(200).build();
            enable.setTooltip(Tooltip.create(Component.translatable("nvidiumplus.options.tooltip.enable_vulkan")));
            this.layout.addChild(enable);
         }
      }

      boolean devOverride = sodium
         ? maxRdOverridden || fogOverridden || sodiumGpuOverridden
         : terrainOverridden || maxRdOverridden || occlusionOverridden || fogOverridden;
      if (devOverride) {
         this.layout
            .addChild(new MultiLineTextWidget(Component.translatable("nvidiumplus.options.dev_override"), this.font).setMaxWidth(340).setCentered(true));
      }

      if (!sodium) {
         CycleButton<Boolean> terrain = CycleButton.booleanBuilder(
               Component.translatable("nvidiumplus.options.enabled"), Component.translatable("nvidiumplus.options.disabled"), config.enableTerrainRendering
            )
            .create(Component.translatable("nvidiumplus.options.terrain"), (b, value) -> {
               config.enableTerrainRendering = value;
               config.save();
               NvidiumPlusExtendedRd.onConfigChanged(this.minecraft);
            });
         terrain.setWidth(200);
         terrain.active = !this.gateLocked && !terrainOverridden;
         terrain.setTooltip(this.tip(this.gateLocked, "nvidiumplus.options.tooltip.terrain", "nvidiumplus.options.applies.now"));
         this.layout.addChild(terrain, s -> s.paddingBottom(4));
      }

      this.capSlider = new NvidiumPlusOptionsScreen.CapSlider(config, !this.capLocked && !maxRdOverridden);
      this.capSlider.setTooltip(this.tip(this.capLocked, "nvidiumplus.options.tooltip.max_rd", "nvidiumplus.options.applies.now"));
      this.capBox = new NvidiumPlusOptionsScreen.ValueBox(
         32,
         sodium ? 96 : 120,
         () -> NvidiumPlusConfig.get().maxRenderDistance,
         this::applyCap,
         Component.translatable("nvidiumplus.options.max_rd.label", new Object[]{Component.literal("")})
      );
      this.capBox.active = !this.capLocked && !maxRdOverridden;
      this.capBox
         .setTooltip(
            this.tip(
               this.capLocked,
               sodium ? "nvidiumplus.options.tooltip.max_rd_custom.sodium" : "nvidiumplus.options.tooltip.max_rd_custom",
               "nvidiumplus.options.applies.now"
            )
         );
      this.layout.addChild(sliderRow(this.capSlider, this.capBox), s -> s.paddingTop(4));
      boolean adapterArmed = NvidiumPlusGate.sodiumAdapterArmed();
      CycleButton<Boolean> sodiumGpu = toggle("nvidiumplus.options.sodium_gpu", config.sodiumGpuVisibility, adapterArmed && !sodiumGpuOverridden, value -> {
         config.sodiumGpuVisibility = value;
         config.save();
         SodiumTerrainDrawer.applyConfiguredGpuVisibility();
      });
      sodiumGpu.setTooltip(
         Tooltip.create(
            withSemantics(
               Component.translatable("nvidiumplus.options.tooltip.sodium_gpu"),
               adapterArmed ? "nvidiumplus.options.applies.now" : "nvidiumplus.options.applies.sodium_gpu_held"
            )
         )
      );
      this.layout.addChild(sodiumGpu, s -> s.paddingTop(4));
      if (!sodium) {
         CycleButton<NvidiumPlusConfig.OcclusionMode> occlusion = CycleButton.builder(m -> {
               return Component.translatable(switch (m) {
                  case AUTO -> "nvidiumplus.options.occlusion.auto";
                  case ON -> "nvidiumplus.options.occlusion.on";
                  case OFF -> "nvidiumplus.options.occlusion.off";
               });
            }, config.occlusionMode)
            .withValues(NvidiumPlusConfig.OcclusionMode.values())
            .create(Component.translatable("nvidiumplus.options.occlusion"), (b, value) -> {
               config.occlusionMode = value;
               config.save();
               this.rebuildOcclusionRows();
            });
         occlusion.setWidth(200);
         occlusion.active = !this.gateLocked && !occlusionOverridden;
         occlusion.setTooltip(this.tip(this.gateLocked, "nvidiumplus.options.tooltip.occlusion", "nvidiumplus.options.applies.now"));
         this.layout.addChild(occlusion);
         boolean autoActive = !this.gateLocked && !occlusionOverridden && config.occlusionMode == NvidiumPlusConfig.OcclusionMode.AUTO;
         this.occlusionSlider = new NvidiumPlusOptionsScreen.OcclusionRdSlider(config, autoActive);
         this.occlusionSlider.setTooltip(this.tip(this.gateLocked, "nvidiumplus.options.tooltip.occlusion_rd", "nvidiumplus.options.applies.now"));
         this.occlusionBox = new NvidiumPlusOptionsScreen.ValueBox(
            2,
            120,
            () -> NvidiumPlusConfig.get().occlusionAutoMinRenderDistance,
            this::applyOcclusionRd,
            Component.translatable("nvidiumplus.options.occlusion_rd.label", new Object[]{Component.literal("")})
         );
         this.occlusionBox.active = autoActive;
         this.occlusionBox.setTooltip(this.tip(this.gateLocked, "nvidiumplus.options.tooltip.occlusion_rd_custom", "nvidiumplus.options.applies.now"));
         this.layout.addChild(sliderRow(this.occlusionSlider, this.occlusionBox));
      }

      CycleButton<NvidiumPlusConfig.FogMode> fog = CycleButton.builder(m -> {
         return Component.translatable(switch (m) {
            case VANILLA -> "nvidiumplus.options.fog.vanilla";
            case SCALED -> "nvidiumplus.options.fog.scaled";
            case OFF -> "nvidiumplus.options.fog.off";
         });
      }, config.fogMode).withValues(NvidiumPlusConfig.FogMode.values()).create(Component.translatable("nvidiumplus.options.fog"), (b, value) -> {
         config.fogMode = value;
         config.save();
         this.rebuildOcclusionRows();
      });
      fog.setWidth(200);
      fog.active = !fogOverridden;
      fog.setTooltip(this.tipAlways("nvidiumplus.options.tooltip.fog", "nvidiumplus.options.applies.now"));
      this.layout.addChild(fog, s -> s.paddingTop(4));
      boolean fogSliderActive = !fogOverridden && config.fogMode == NvidiumPlusConfig.FogMode.SCALED;
      this.fogSlider = new NvidiumPlusOptionsScreen.FogEndSlider(config, fogSliderActive);
      this.fogSlider.setTooltip(this.tipAlways("nvidiumplus.options.tooltip.fog_end", "nvidiumplus.options.applies.now"));
      this.fogBox = new NvidiumPlusOptionsScreen.ValueBox(
         50,
         200,
         () -> NvidiumPlusConfig.get().fogEndPercent,
         this::applyFogEnd,
         Component.translatable("nvidiumplus.options.fog_end.box", new Object[]{Component.literal("")})
      );
      this.fogBox.active = fogSliderActive;
      this.fogBox.setTooltip(this.tipAlways("nvidiumplus.options.tooltip.fog_end_custom", "nvidiumplus.options.applies.now"));
      this.layout.addChild(sliderRow(this.fogSlider, this.fogBox));
      Button advanced = Button.builder(Component.translatable("nvidiumplus.options.advanced"), b -> {
         this.resetArmed = false;
         if (this.resetButton != null) {
            this.resetButton.setMessage(Component.translatable("nvidiumplus.options.reset"));
         }

         if (this.minecraft != null) {
            this.minecraft.gui.setScreen(new NvidiumPlusAdvancedScreen(this));
         }
      }).width(200).build();
      if (sodium) {
         advanced.setTooltip(Tooltip.create(Component.translatable("nvidiumplus.options.tooltip.advanced.sodium")));
      }

      this.layout.addChild(advanced, s -> s.paddingTop(6));
      this.resetButton = Button.builder(
            Component.translatable("nvidiumplus.options.reset"),
            b -> {
               if (!this.resetArmed) {
                  this.resetArmed = true;
                  b.setMessage(
                     Component.translatable(sodium ? "nvidiumplus.options.reset.confirm.sodium" : "nvidiumplus.options.reset.confirm")
                        .withStyle(ChatFormatting.RED)
                  );
               } else {
                  NvidiumPlusConfig config2 = NvidiumPlusConfig.get();
                  config2.resetToDefaults();
                  if (NvidiumPlusGate.sodiumAdapterArmed()) {
                     SodiumTerrainDrawer.applyConfiguredGpuVisibility();
                  }

                  NvidiumPlusExtendedRd.onConfigChanged(this.minecraft);
                  this.rebuildOcclusionRows();
               }
            }
         )
         .width(200)
         .build();
      this.resetButton
         .setTooltip(
            this.tipAlways(sodium ? "nvidiumplus.options.tooltip.reset.sodium" : "nvidiumplus.options.tooltip.reset", "nvidiumplus.options.applies.now")
         );
      this.layout.addChild(this.resetButton, s -> s.paddingTop(6));
      this.layout.addChild(Button.builder(CommonComponents.GUI_DONE, b -> this.onClose()).width(200).build(), s -> s.paddingTop(4));
      this.layout.visitWidgets(x$0 -> this.addRenderableWidget(x$0));
      this.repositionElements();
   }

   private static LinearLayout sliderRow(AbstractSliderButton slider, AbstractWidget box) {
      LinearLayout row = LinearLayout.horizontal().spacing(4);
      row.defaultCellSetting().alignVerticallyMiddle();
      row.addChild(slider);
      row.addChild(box);
      return row;
   }

   private Tooltip tip(String descriptionKey, String appliesKey) {
      return this.tip(this.gateLocked, descriptionKey, appliesKey);
   }

   private Tooltip tip(boolean locked, String descriptionKey, String appliesKey) {
      String semantics = !locked
         ? appliesKey
         : (NvidiumPlusGate.state() == NvidiumPlusGate.State.SODIUM_PRESENT ? "nvidiumplus.options.applies.sodium" : "nvidiumplus.options.applies.vulkan");
      return Tooltip.create(withSemantics(Component.translatable(descriptionKey), semantics));
   }

   private Tooltip tipAlways(String descriptionKey, String appliesKey) {
      return Tooltip.create(withSemantics(Component.translatable(descriptionKey), appliesKey));
   }

   private static Component withSemantics(MutableComponent description, String semanticsKey) {
      return description.append(Component.literal("\n\n")).append(Component.translatable(semanticsKey).withStyle(ChatFormatting.GRAY));
   }

   private static CycleButton<Boolean> toggle(String key, boolean initial, boolean active, Consumer<Boolean> onChange) {
      CycleButton<Boolean> button = CycleButton.onOffBuilder(initial).create(Component.translatable(key), (b, value) -> onChange.accept(value));
      button.setWidth(200);
      button.active = active;
      return button;
   }

   private void applyCap(int cap) {
      NvidiumPlusConfig config = NvidiumPlusConfig.get();
      config.maxRenderDistance = cap;
      config.save();
      NvidiumPlusExtendedRd.onConfigChanged(this.minecraft);
      if (this.capSlider != null) {
         this.capSlider.refreshFromConfig();
      }

      if (this.capBox != null) {
         this.capBox.refreshFromConfig();
      }
   }

   private void rebuildOcclusionRows() {
      this.minecraft.gui.setScreen(new NvidiumPlusOptionsScreen(this.parent));
   }

   private void applyOcclusionRd(int rd) {
      NvidiumPlusConfig config = NvidiumPlusConfig.get();
      config.occlusionAutoMinRenderDistance = rd;
      config.save();
      if (this.occlusionSlider != null) {
         this.occlusionSlider.refreshFromConfig();
      }

      if (this.occlusionBox != null) {
         this.occlusionBox.refreshFromConfig();
      }
   }

   private static double fogFraction(int pct) {
      int span = 150;
      double f = (double)(pct - 50) / span;
      return Math.max(0.0, Math.min(1.0, f));
   }

   private int fogBlocksFor(int pct) {
      int chunks = NvidiumPlusConfig.get().maxRenderDistance;
      if (this.minecraft != null && this.minecraft.options != null && this.minecraft.level != null) {
         chunks = this.minecraft.options.getEffectiveRenderDistance();
      }

      return Math.round(chunks * 16 * (pct / 100.0F));
   }

   private void applyFogEnd(int pct) {
      NvidiumPlusConfig config = NvidiumPlusConfig.get();
      config.fogEndPercent = pct;
      config.save();
      if (this.fogSlider != null) {
         this.fogSlider.refreshFromConfig();
      }

      if (this.fogBox != null) {
         this.fogBox.refreshFromConfig();
      }
   }

   private static double rdFraction(int rd) {
      int span = 118;
      double f = (double)(rd - 2) / span;
      return Math.max(0.0, Math.min(1.0, f));
   }

   private static double fraction(int value, int[] stops) {
      int best = 0;

      for (int i = 1; i < stops.length; i++) {
         if (Math.abs(value - stops[i]) < Math.abs(value - stops[best])) {
            best = i;
         }
      }

      return (double)best / (stops.length - 1);
   }

   private static int nearestStop(double fraction, int[] stops) {
      int index = (int)Math.round(fraction * (stops.length - 1));
      return stops[Math.max(0, Math.min(stops.length - 1, index))];
   }

   protected void repositionElements() {
      this.layout.arrangeElements();
      FrameLayout.centerInRectangle(this.layout, this.getRectangle());
   }

   public void onClose() {
      boolean capChanged = NvidiumPlusConfig.get().maxRenderDistance != this.capAtOpen;
      boolean rdChanged = this.rdAtOpen >= 0 && this.minecraft.options != null && (Integer)this.minecraft.options.renderDistance().get() != this.rdAtOpen;
      Screen target = this.parent;
      if ((capChanged || rdChanged) && this.parent instanceof VideoSettingsScreen) {
         target = new VideoSettingsScreen(((OptionsSubScreenAccessor)this.parent).nvidiumplus$lastScreen(), this.minecraft, this.minecraft.options);
      }

      this.minecraft.gui.setScreen(target);
   }

   private final class CapSlider extends AbstractSliderButton {
      private int displayed;

      CapSlider(NvidiumPlusConfig config, boolean active) {
         super(0, 0, 150, 20, Component.empty(), NvidiumPlusOptionsScreen.fraction(config.maxRenderDistance, NvidiumPlusOptionsScreen.CAP_STOPS));
         this.active = active;
         this.displayed = config.maxRenderDistance;
         this.updateMessage();
      }

      void refreshFromConfig() {
         this.displayed = NvidiumPlusConfig.get().maxRenderDistance;
         this.value = NvidiumPlusOptionsScreen.fraction(this.displayed, NvidiumPlusOptionsScreen.CAP_STOPS);
         this.updateMessage();
      }

      protected void updateMessage() {
         Component shown = this.displayed <= 32
            ? Component.translatable("nvidiumplus.options.max_rd.vanilla")
            : Component.literal(Integer.toString(this.displayed));
         this.setMessage(Component.translatable("nvidiumplus.options.max_rd.label", new Object[]{shown}));
      }

      protected void applyValue() {
         int snapped = NvidiumPlusOptionsScreen.nearestStop(this.value, NvidiumPlusOptionsScreen.CAP_STOPS);
         if (snapped != this.displayed) {
            this.displayed = snapped;
            NvidiumPlusOptionsScreen.this.applyCap(snapped);
         }

         this.updateMessage();
      }
   }

   private final class FogEndSlider extends AbstractSliderButton {
      private int displayed;

      FogEndSlider(NvidiumPlusConfig config, boolean active) {
         super(0, 0, 150, 20, Component.empty(), NvidiumPlusOptionsScreen.fogFraction(config.fogEndPercent));
         this.active = active;
         this.displayed = config.fogEndPercent;
         this.updateMessage();
      }

      void refreshFromConfig() {
         this.displayed = NvidiumPlusConfig.get().fogEndPercent;
         this.value = NvidiumPlusOptionsScreen.fogFraction(this.displayed);
         this.updateMessage();
      }

      protected void updateMessage() {
         this.setMessage(
            Component.translatable(
               "nvidiumplus.options.fog_end.label",
               new Object[]{
                  Component.literal(Integer.toString(this.displayed)),
                  Component.literal(Integer.toString(NvidiumPlusOptionsScreen.this.fogBlocksFor(this.displayed)))
               }
            )
         );
      }

      protected void applyValue() {
         int span = 150;
         int pct = 50 + (int)Math.round(this.value * span);
         pct = Math.round(pct / 5.0F) * 5;
         pct = Math.max(50, Math.min(200, pct));
         if (pct != this.displayed) {
            this.displayed = pct;
            NvidiumPlusOptionsScreen.this.applyFogEnd(pct);
         }

         this.updateMessage();
      }
   }

   private final class OcclusionRdSlider extends AbstractSliderButton {
      private int displayed;

      OcclusionRdSlider(NvidiumPlusConfig config, boolean active) {
         super(0, 0, 150, 20, Component.empty(), NvidiumPlusOptionsScreen.rdFraction(config.occlusionAutoMinRenderDistance));
         this.active = active;
         this.displayed = config.occlusionAutoMinRenderDistance;
         this.updateMessage();
      }

      void refreshFromConfig() {
         this.displayed = NvidiumPlusConfig.get().occlusionAutoMinRenderDistance;
         this.value = NvidiumPlusOptionsScreen.rdFraction(this.displayed);
         this.updateMessage();
      }

      protected void updateMessage() {
         this.setMessage(Component.translatable("nvidiumplus.options.occlusion_rd.label", new Object[]{Component.literal(Integer.toString(this.displayed))}));
      }

      protected void applyValue() {
         int span = 118;
         int rd = 2 + (int)Math.round(this.value * span);
         if (rd != this.displayed) {
            this.displayed = rd;
            NvidiumPlusOptionsScreen.this.applyOcclusionRd(rd);
         }

         this.updateMessage();
      }
   }

   private final class ValueBox extends EditBox {
      private final int min;
      private final int max;
      private final IntSupplier current;
      private final IntConsumer onCommit;
      private int lastTextColor = -2039584;

      ValueBox(int min, int max, IntSupplier current, IntConsumer onCommit, Component narration) {
         super(NvidiumPlusOptionsScreen.this.font, 46, 20, narration);
         this.min = min;
         this.max = max;
         this.current = current;
         this.onCommit = onCommit;
         this.setMaxLength(3);
         this.setValue(Integer.toString(current.getAsInt()));
         this.setResponder(text -> this.paint(this.parsed() != null ? -2039584 : -43691));
      }

      private void paint(int argb) {
         this.lastTextColor = argb;
         this.setTextColor(argb);
      }

      int testTextAlpha() {
         return this.lastTextColor >>> 24 & 0xFF;
      }

      private Integer parsed() {
         try {
            int v = Integer.parseInt(this.getValue().trim());
            return v >= this.min && v <= this.max ? v : null;
         } catch (NumberFormatException e) {
            return null;
         }
      }

      void refreshFromConfig() {
         if (!this.isFocused()) {
            this.setValue(Integer.toString(this.current.getAsInt()));
         }
      }

      void testCommit() {
         this.commit();
      }

      private void commit() {
         Integer v = this.parsed();
         if (v != null) {
            this.onCommit.accept(v);
         } else {
            this.setValue(Integer.toString(this.current.getAsInt()));
         }

         this.paint(-2039584);
      }

      public boolean keyPressed(KeyEvent event) {
         if (!this.isFocused() || event.key() != 40 && event.key() != 88) {
            return super.keyPressed(event);
         }

         this.commit();
         return true;
      }

      public void setFocused(boolean focused) {
         boolean was = this.isFocused();
         super.setFocused(focused);
         if (was && !focused) {
            this.commit();
         }
      }
   }
}
