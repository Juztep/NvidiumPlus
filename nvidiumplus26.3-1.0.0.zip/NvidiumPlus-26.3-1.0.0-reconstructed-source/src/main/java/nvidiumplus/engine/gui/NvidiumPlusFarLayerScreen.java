package nvidiumplus.engine.gui;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.components.ScrollableLayout;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import nvidiumplus.engine.NvidiumPlusGate;
import nvidiumplus.engine.farfield.FarFieldConfig;
import nvidiumplus.engine.farfield.extract.ExtractDispatch;

public class NvidiumPlusFarLayerScreen extends Screen {
   private static final int WIDGET_WIDTH = 200;
   private static final int BANNER_WIDTH = 340;
   private final Screen parent;
   private final FarFieldConfig.Layer layer;
   private final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);
   private ScrollableLayout scrollArea;
   private final boolean gateLocked;
   private CycleButton<Boolean> waterLookRow;
   private StringWidget savingLine;
   private StringWidget leavingLine;

   public NvidiumPlusFarLayerScreen(Screen parent, FarFieldConfig.Layer layer) {
      super(Component.translatable("nvidiumplus.options.farfield." + layer.key + ".title"));
      this.parent = parent;
      this.layer = layer;
      this.gateLocked = NvidiumPlusGate.state() != NvidiumPlusGate.State.VULKAN_MESH_SHADERS;
   }

   public FarFieldConfig.Layer layer() {
      return this.layer;
   }

   protected void init() {
      FarFieldConfig config = FarFieldConfig.get();
      boolean layerWired = FarFieldConfig.isLayerWired(this.layer);
      this.layout.addTitleHeader(this.getTitle(), this.font);
      LinearLayout rows = LinearLayout.vertical().spacing(2);
      rows.defaultCellSetting().alignHorizontallyCenter();
      if (FarFieldConfig.anyLayerPropertyOverride(this.layer)) {
         rows.addChild(this.banner(Component.translatable("nvidiumplus.options.dev_override")), s -> s.paddingTop(2).paddingBottom(2));
      }

      if (this.gateLocked) {
         String lockedKey = NvidiumPlusGate.sodiumAdapterArmed() ? "nvidiumplus.options.advanced.locked.sodium" : "nvidiumplus.options.advanced.locked";
         rows.addChild(this.banner(Component.translatable(lockedKey).withStyle(ChatFormatting.YELLOW)), s -> s.paddingTop(2).paddingBottom(2));
      }

      rows.addChild(
         this.banner(Component.translatable("nvidiumplus.options.farfield." + this.layer.key + ".about").withStyle(ChatFormatting.GRAY)),
         s -> s.paddingTop(2).paddingBottom(2)
      );
      if (!layerWired) {
         rows.addChild(
            this.banner(
               Component.translatable("nvidiumplus.options.farfield.planned.layer", new Object[]{Component.literal(Integer.toString(this.layer.number))})
                  .withStyle(ChatFormatting.GRAY)
            ),
            s -> s.paddingTop(2).paddingBottom(4)
         );
      }

      rows.addChild(
         this.onOff(
            FarFieldConfig.Control.LAYER_ENABLED,
            "nvidiumplus.options.farfield.layer.enabled",
            "nvidiumplus.options.tooltip.farfield.layer.enabled",
            "nvidiumplus.options.applies.now",
            () -> config.layer(this.layer).enabled,
            value -> config.setLayerFlag(this.layer, FarFieldConfig.Control.LAYER_ENABLED, value)
         ),
         s -> s.paddingTop(4)
      );
      rows.addChild(
         this.slider(
            FarFieldConfig.Control.DISTANCE,
            "nvidiumplus.options.farfield.layer.distance",
            "nvidiumplus.options.tooltip.farfield.layer.distance",
            "nvidiumplus.options.applies.now",
            0,
            192,
            () -> config.layer(this.layer).radiusChunks,
            chunks -> config.layer(this.layer).radiusChunks = chunks,
            NvidiumPlusFarLayerScreen::distanceText
         )
      );
      rows.addChild(
         this.cycle(
            FarFieldConfig.Control.CACHE_SPEED,
            "nvidiumplus.options.farfield.layer.cache_speed",
            "nvidiumplus.options.tooltip.farfield.layer.cache_speed",
            "nvidiumplus.options.applies.saving_rate",
            new int[]{0, 1, 2},
            NvidiumPlusFarLayerScreen::cacheSpeedText,
            () -> config.layer(this.layer).cacheSpeed,
            value -> config.layer(this.layer).cacheSpeed = value
         )
      );
      if (this.layer == FarFieldConfig.Layer.L1) {
         this.savingLine = new StringWidget(this.savingText(), this.font);
         this.savingLine.setMaxWidth(340);
         this.savingLine.setTooltip(Tooltip.create(Component.translatable("nvidiumplus.options.tooltip.farfield.layer.saving_progress")));
         rows.addChild(this.savingLine, s -> s.paddingTop(2));
         this.leavingLine = new StringWidget(this.leavingText(), this.font);
         this.leavingLine.setMaxWidth(340);
         this.leavingLine.setTooltip(Tooltip.create(Component.translatable("nvidiumplus.options.tooltip.farfield.layer.saving_leaving")));
         rows.addChild(this.leavingLine, s -> s.paddingBottom(2));
      } else {
         this.savingLine = null;
         this.leavingLine = null;
      }

      rows.addChild(
         this.cycle(
            FarFieldConfig.Control.SCALE,
            "nvidiumplus.options.farfield.layer.scale",
            "nvidiumplus.options.tooltip.farfield.layer.scale",
            "nvidiumplus.options.applies.new_builds",
            new int[]{1, 2, 4},
            NvidiumPlusFarLayerScreen::scaleText,
            () -> config.layer(this.layer).scale,
            scale -> config.layer(this.layer).scale = scale
         )
      );
      rows.addChild(
         this.onOff(
            FarFieldConfig.Control.UNDERWATER_PLANTS,
            "nvidiumplus.options.farfield.layer.underwater_plants",
            "nvidiumplus.options.tooltip.farfield.layer.underwater_plants",
            "nvidiumplus.options.applies.new_cache",
            () -> config.layer(this.layer).underwaterPlants,
            value -> config.setLayerFlag(this.layer, FarFieldConfig.Control.UNDERWATER_PLANTS, value)
         )
      );
      rows.addChild(
         this.onOff(
            FarFieldConfig.Control.SMALL_DETAIL,
            "nvidiumplus.options.farfield.layer.small_detail",
            "nvidiumplus.options.tooltip.farfield.layer.small_detail",
            "nvidiumplus.options.applies.far_now",
            () -> config.layer(this.layer).smallDetail,
            value -> config.setLayerFlag(this.layer, FarFieldConfig.Control.SMALL_DETAIL, value)
         )
      );
      rows.addChild(
         this.cycle(
            FarFieldConfig.Control.COLOUR_BLEND,
            "nvidiumplus.options.farfield.layer.colour_blend",
            "nvidiumplus.options.tooltip.farfield.layer.colour_blend",
            "nvidiumplus.options.applies.new_cache",
            new int[]{0, 2},
            NvidiumPlusFarLayerScreen::blendText,
            () -> config.layer(this.layer).colourBlend,
            blend -> config.layer(this.layer).colourBlend = blend
         )
      );
      rows.addChild(
         this.cycle(
            FarFieldConfig.Control.LIGHTING,
            "nvidiumplus.options.farfield.layer.lighting",
            "nvidiumplus.options.tooltip.farfield.layer.lighting",
            "nvidiumplus.options.applies.far_now_saved",
            new int[]{0, 1, 2},
            NvidiumPlusFarLayerScreen::lightingText,
            () -> config.layer(this.layer).lighting,
            light -> config.layer(this.layer).lighting = light
         )
      );
      this.waterLookRow = this.boolCycle(
         FarFieldConfig.Control.WATER_LOOK,
         "nvidiumplus.options.farfield.layer.water_look",
         "nvidiumplus.options.tooltip.farfield.layer.water_look",
         "nvidiumplus.options.applies.far_now",
         "nvidiumplus.options.farfield.layer.water_look.stock",
         "nvidiumplus.options.farfield.layer.water_look.saved",
         () -> config.layer(this.layer).waterDepth,
         value -> config.setLayerFlag(this.layer, FarFieldConfig.Control.WATER_LOOK, value)
      );
      rows.addChild(this.waterLookRow);
      rows.addChild(
         this.cycle(
            FarFieldConfig.Control.SMOOTH_LIGHT,
            "nvidiumplus.options.farfield.layer.smooth_light",
            "nvidiumplus.options.tooltip.farfield.layer.smooth_light",
            "nvidiumplus.options.applies.far_now",
            new int[]{0, 1, 2},
            NvidiumPlusFarLayerScreen::smoothText,
            () -> config.layer(this.layer).smoothLight,
            value -> config.layer(this.layer).smoothLight = value
         )
      );
      rows.addChild(
         this.slider(
            FarFieldConfig.Control.CONTACT_SHADE,
            "nvidiumplus.options.farfield.layer.contact",
            "nvidiumplus.options.tooltip.farfield.layer.contact",
            "nvidiumplus.options.applies.far_now",
            0,
            100,
            () -> config.layer(this.layer).contactShade,
            value -> config.layer(this.layer).contactShade = value,
            NvidiumPlusFarLayerScreen::contactText
         )
      );
      rows.addChild(
         this.onOff(
            FarFieldConfig.Control.BLOCK_VARIANTS,
            "nvidiumplus.options.farfield.layer.block_variants",
            "nvidiumplus.options.tooltip.farfield.layer.block_variants",
            "nvidiumplus.options.applies.far_now",
            () -> config.layer(this.layer).blockVariants,
            value -> config.setLayerFlag(this.layer, FarFieldConfig.Control.BLOCK_VARIANTS, value)
         )
      );
      rows.addChild(
         this.onOff(
            FarFieldConfig.Control.SOLID_LEAVES,
            "nvidiumplus.options.farfield.layer.solid_leaves",
            "nvidiumplus.options.tooltip.farfield.layer.solid_leaves",
            "nvidiumplus.options.applies.far_now",
            () -> config.layer(this.layer).solidLeaves,
            value -> config.setLayerFlag(this.layer, FarFieldConfig.Control.SOLID_LEAVES, value)
         )
      );
      rows.addChild(
         this.onOff(
            FarFieldConfig.Control.FLAT_WATER,
            "nvidiumplus.options.farfield.layer.flat_water",
            "nvidiumplus.options.tooltip.farfield.layer.flat_water",
            "nvidiumplus.options.applies.now",
            () -> config.layer(this.layer).flatWater,
            value -> config.setLayerFlag(this.layer, FarFieldConfig.Control.FLAT_WATER, value)
         )
      );
      rows.addChild(
         this.slider(
            FarFieldConfig.Control.TEXTURE_SIMPLIFY,
            "nvidiumplus.options.farfield.layer.texture",
            "nvidiumplus.options.tooltip.farfield.layer.texture",
            "nvidiumplus.options.applies.now",
            0,
            4,
            () -> config.layer(this.layer).textureSimplify,
            step -> config.layer(this.layer).textureSimplify = step,
            NvidiumPlusFarLayerScreen::textureText
         )
      );
      rows.addChild(
         this.onOff(
            FarFieldConfig.Control.COARSE_SHADING,
            "nvidiumplus.options.farfield.layer.shading",
            "nvidiumplus.options.tooltip.farfield.layer.shading",
            "nvidiumplus.options.applies.now",
            () -> config.layer(this.layer).coarseShading,
            value -> config.setLayerFlag(this.layer, FarFieldConfig.Control.COARSE_SHADING, value)
         )
      );
      rows.addChild(
         this.onOff(
            FarFieldConfig.Control.HEIGHTFIELD,
            "nvidiumplus.options.farfield.layer.heightfield",
            "nvidiumplus.options.tooltip.farfield.layer.heightfield",
            "nvidiumplus.options.applies.now",
            () -> config.layer(this.layer).heightfield,
            value -> config.setLayerFlag(this.layer, FarFieldConfig.Control.HEIGHTFIELD, value)
         )
      );
      rows.addChild(
         this.banner(Component.translatable("nvidiumplus.options.farfield.layer.band_note").withStyle(ChatFormatting.GRAY)),
         s -> s.paddingTop(6).paddingBottom(2)
      );
      this.scrollArea = new ScrollableLayout(this.minecraft, rows, this.layout.getContentHeight());
      this.layout.addToContents(this.scrollArea);
      this.layout.addToFooter(Button.builder(CommonComponents.GUI_DONE, b -> this.onClose()).width(200).build());
      this.layout.visitWidgets(x$0 -> this.addRenderableWidget(x$0));
      this.repositionElements();
   }

   private Component savingText() {
      if (!FarFieldConfig.enabled()) {
         return Component.translatable("nvidiumplus.options.farfield.layer.saving.off").withStyle(ChatFormatting.GRAY);
      }

      ExtractDispatch.SaveCensus census = ExtractDispatch.saveCensus();
      int saved = census.savedWhole + census.savedDegraded;
      MutableComponent line = Component.translatable(
         "nvidiumplus.options.farfield.layer.saving_progress",
         new Object[]{
            Component.literal(Integer.toString(saved)),
            Component.literal(Integer.toString(census.savedDegraded)),
            Component.literal(Integer.toString(census.waiting)),
            Component.literal(Integer.toString(census.stale))
         }
      );
      boolean finished = saved > 0 && census.waiting == 0 && ExtractDispatch.pinnedCount() == 0 && ExtractDispatch.pendingCaptureCount() == 0;
      return line.withStyle(finished ? ChatFormatting.GREEN : ChatFormatting.GRAY);
   }

   private Component leavingText() {
      if (!FarFieldConfig.enabled()) {
         return Component.empty();
      }

      long behind = Math.max(0L, ExtractDispatch.farSaveBehind());
      long lost = ExtractDispatch.farSaveLost.sum();
      int held = ExtractDispatch.pinnedCount() + ExtractDispatch.pendingCaptureCount();
      MutableComponent line = Component.translatable(
         "nvidiumplus.options.farfield.layer.saving_leaving",
         new Object[]{Component.literal(Integer.toString(held)), Component.literal(Long.toString(behind)), Component.literal(Long.toString(lost))}
      );
      return line.withStyle(lost > 0L ? ChatFormatting.RED : (behind > 0L ? ChatFormatting.YELLOW : ChatFormatting.GRAY));
   }

   public void tick() {
      super.tick();
      if (this.savingLine != null) {
         this.savingLine.setMessage(this.savingText());
      }

      if (this.leavingLine != null) {
         this.leavingLine.setMessage(this.leavingText());
      }
   }

   private MultiLineTextWidget banner(Component text) {
      MultiLineTextWidget widget = new MultiLineTextWidget(text, this.font);
      widget.setMaxWidth(340);
      widget.setCentered(true);
      return widget;
   }

   private boolean isActive(FarFieldConfig.Control control) {
      return FarFieldConfig.isWired(this.layer, control)
         && !this.gateLocked
         && !FarFieldConfig.isSuperseded(this.layer, control)
         && !FarFieldConfig.isPropertyOverridden(this.layer, control);
   }

   private Component rowLabel(FarFieldConfig.Control control, String labelKey) {
      MutableComponent label = Component.translatable(labelKey);
      if (FarFieldConfig.isWired(this.layer, control)) {
         return label;
      } else {
         return FarFieldConfig.isRetired(this.layer, control)
            ? Component.translatable("nvidiumplus.options.farfield.retired.row", new Object[]{label})
            : Component.translatable("nvidiumplus.options.farfield.planned.row", new Object[]{label});
      }
   }

   private Tooltip tip(FarFieldConfig.Control control, String descriptionKey, String appliesKey) {
      String semanticsKey;
      if (FarFieldConfig.isRetired(this.layer, control)) {
         semanticsKey = "nvidiumplus.options.applies.retired";
      } else if (!FarFieldConfig.isWired(this.layer, control)) {
         semanticsKey = "nvidiumplus.options.applies.planned";
      } else if (FarFieldConfig.isSuperseded(this.layer, control)) {
         semanticsKey = "nvidiumplus.options.applies.superseded";
      } else if (this.gateLocked) {
         semanticsKey = NvidiumPlusGate.state() == NvidiumPlusGate.State.SODIUM_PRESENT
            ? "nvidiumplus.options.applies.sodium"
            : "nvidiumplus.options.applies.vulkan";
      } else {
         semanticsKey = appliesKey;
      }

      return Tooltip.create(
         Component.translatable(descriptionKey).append(Component.literal("\n\n")).append(Component.translatable(semanticsKey).withStyle(ChatFormatting.GRAY))
      );
   }

   private void onChanged() {
      FarFieldConfig config = FarFieldConfig.get();
      config.markCustom();
      config.save();
      ExtractDispatch.refreshArmed();
      this.refreshLockedRows();
   }

   private void refreshLockedRows() {
      if (this.waterLookRow != null) {
         this.waterLookRow.active = this.isActive(FarFieldConfig.Control.WATER_LOOK);
         this.waterLookRow
            .setTooltip(
               this.tip(FarFieldConfig.Control.WATER_LOOK, "nvidiumplus.options.tooltip.farfield.layer.water_look", "nvidiumplus.options.applies.far_now")
            );
      }
   }

   private CycleButton<Boolean> onOff(
      FarFieldConfig.Control control, String labelKey, String tooltipKey, String appliesKey, BooleanSupplier current, Consumer<Boolean> apply
   ) {
      CycleButton<Boolean> button = CycleButton.onOffBuilder(current.getAsBoolean()).create(this.rowLabel(control, labelKey), (b, value) -> {
         apply.accept(value);
         this.onChanged();
      });
      button.setWidth(200);
      button.active = this.isActive(control);
      button.setTooltip(this.tip(control, tooltipKey, appliesKey));
      return button;
   }

   private CycleButton<Boolean> boolCycle(
      FarFieldConfig.Control control,
      String labelKey,
      String tooltipKey,
      String appliesKey,
      String trueKey,
      String falseKey,
      BooleanSupplier current,
      Consumer<Boolean> apply
   ) {
      CycleButton<Boolean> button = CycleButton.booleanBuilder(Component.translatable(trueKey), Component.translatable(falseKey), current.getAsBoolean())
         .create(this.rowLabel(control, labelKey), (b, value) -> {
            apply.accept(value);
            this.onChanged();
         });
      button.setWidth(200);
      button.active = this.isActive(control);
      button.setTooltip(this.tip(control, tooltipKey, appliesKey));
      return button;
   }

   private CycleButton<Integer> cycle(
      FarFieldConfig.Control control,
      String labelKey,
      String tooltipKey,
      String appliesKey,
      int[] values,
      IntFunction<Component> naming,
      IntSupplier current,
      IntConsumer apply
   ) {
      Integer[] boxed = new Integer[values.length];

      for (int i = 0; i < values.length; i++) {
         boxed[i] = values[i];
      }

      CycleButton<Integer> button = CycleButton.builder(value -> naming.apply(value), current.getAsInt())
         .withValues(boxed)
         .create(this.rowLabel(control, labelKey), (b, value) -> {
            apply.accept(value);
            this.onChanged();
         });
      button.setWidth(200);
      button.active = this.isActive(control);
      button.setTooltip(this.tip(control, tooltipKey, appliesKey));
      return button;
   }

   private NvidiumPlusFarLayerScreen.LayerIntSlider slider(
      FarFieldConfig.Control control,
      String labelKey,
      String tooltipKey,
      String appliesKey,
      int min,
      int max,
      IntSupplier current,
      IntConsumer apply,
      IntFunction<Component> naming
   ) {
      NvidiumPlusFarLayerScreen.LayerIntSlider widget = new NvidiumPlusFarLayerScreen.LayerIntSlider(
         labelKey, !FarFieldConfig.isWired(this.layer, control), min, max, current.getAsInt(), naming, value -> {
            apply.accept(value);
            this.onChanged();
         }
      );
      widget.active = this.isActive(control);
      widget.setTooltip(this.tip(control, tooltipKey, appliesKey));
      return widget;
   }

   private static Component distanceText(int chunks) {
      return chunks <= 0
         ? Component.translatable("nvidiumplus.options.cull.off")
         : Component.translatable("nvidiumplus.options.cull.chunks", new Object[]{Component.literal(Integer.toString(chunks))});
   }

   private static Component scaleText(int scale) {
      return switch (scale) {
         case 2 -> Component.translatable("nvidiumplus.options.farfield.layer.scale.half");
         case 4 -> Component.translatable("nvidiumplus.options.farfield.layer.scale.quarter");
         default -> Component.translatable("nvidiumplus.options.farfield.layer.scale.full");
      };
   }

   private static Component blendText(int blend) {
      return switch (blend) {
         case 2, 4 -> Component.translatable("nvidiumplus.options.farfield.layer.colour_blend.coarse");
         default -> Component.translatable("nvidiumplus.options.farfield.layer.colour_blend.chunk");
      };
   }

   private static Component cacheSpeedText(int speed) {
      return switch (speed) {
         case 1 -> Component.translatable("nvidiumplus.options.farfield.layer.cache_speed.balanced");
         case 2 -> Component.translatable("nvidiumplus.options.farfield.layer.cache_speed.fast");
         default -> Component.translatable("nvidiumplus.options.farfield.layer.cache_speed.gentle");
      };
   }

   private static Component lightingText(int lighting) {
      return switch (lighting) {
         case 1 -> Component.translatable("nvidiumplus.options.farfield.layer.lighting.glow");
         case 2 -> Component.translatable("nvidiumplus.options.farfield.layer.lighting.real");
         default -> Component.translatable("nvidiumplus.options.farfield.layer.lighting.flat");
      };
   }

   private static Component smoothText(int step) {
      return switch (step) {
         case 1 -> Component.translatable("nvidiumplus.options.farfield.layer.smooth_light.edges");
         case 2 -> Component.translatable("nvidiumplus.options.farfield.layer.smooth_light.full");
         default -> Component.translatable("nvidiumplus.options.cull.off");
      };
   }

   private static Component contactText(int percent) {
      return percent <= 0
         ? Component.translatable("nvidiumplus.options.cull.off")
         : Component.translatable("nvidiumplus.options.farfield.layer.contact.percent", new Object[]{Component.literal(Integer.toString(percent))});
   }

   private static Component textureText(int step) {
      return switch (step) {
         case 1 -> Component.translatable("nvidiumplus.options.farfield.layer.texture.slight");
         case 2 -> Component.translatable("nvidiumplus.options.farfield.layer.texture.medium");
         case 3 -> Component.translatable("nvidiumplus.options.farfield.layer.texture.strong");
         case 4 -> Component.translatable("nvidiumplus.options.farfield.layer.texture.flat");
         default -> Component.translatable("nvidiumplus.options.cull.off");
      };
   }

   protected void repositionElements() {
      this.scrollArea.arrangeElements();
      this.scrollArea.setMaxHeight(this.layout.getContentHeight());
      this.layout.arrangeElements();
   }

   public void onClose() {
      if (this.minecraft != null) {
         this.minecraft.gui.setScreen(this.parent);
      }
   }

   private static final class LayerIntSlider extends AbstractSliderButton {
      private final String labelKey;
      private final boolean planned;
      private final int min;
      private final int max;
      private final IntFunction<Component> naming;
      private final IntConsumer apply;
      private int displayed;

      LayerIntSlider(String labelKey, boolean planned, int min, int max, int initial, IntFunction<Component> naming, IntConsumer apply) {
         super(0, 0, 200, 20, Component.empty(), fraction(initial, min, max));
         this.labelKey = labelKey;
         this.planned = planned;
         this.min = min;
         this.max = max;
         this.naming = naming;
         this.apply = apply;
         this.displayed = initial;
         this.updateMessage();
      }

      protected void updateMessage() {
         MutableComponent base = Component.translatable(this.labelKey, new Object[]{this.naming.apply(this.displayed)});
         this.setMessage(this.planned ? Component.translatable("nvidiumplus.options.farfield.planned.row", new Object[]{base}) : base);
      }

      protected void applyValue() {
         int picked = this.min + (int)Math.round(this.value * (this.max - this.min));
         if (picked != this.displayed) {
            this.displayed = picked;
            this.apply.accept(picked);
         }

         this.updateMessage();
      }

      private static double fraction(int value, int min, int max) {
         return max <= min ? 0.0 : Math.max(0.0, Math.min(1.0, (double)(value - min) / (max - min)));
      }
   }
}
