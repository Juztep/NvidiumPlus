package nvidiumplus.engine;

import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import nvidiumplus.engine.mixin.SectionUberBuffersAccessor;
import nvidiumplus.engine.mixin.UberGpuBufferAccessor;

public final class VanillaTerrainCensus {
   private VanillaTerrainCensus() {
   }

   public static long committedBytes() {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft != null && minecraft.levelRenderer != null) {
         SectionRenderDispatcher dispatcher = minecraft.levelRenderer.sectionRenderDispatcher();
         if (dispatcher == null) {
            return -1L;
         }

         Map<?, ?> layers = ((VanillaTerrainCensus.SectionRenderDispatcherAccessorBridge)dispatcher).nvidiumplus$chunkUberBuffers();
         if (layers == null) {
            return -1L;
         }

         long total = 0L;

         for (Object buffers : layers.values()) {
            if (buffers instanceof SectionUberBuffersAccessor pair) {
               total += bytesOf(pair.nvidiumplus$vertexBuffer());
               total += bytesOf(pair.nvidiumplus$indexBuffer());
            }
         }

         return total;
      } else {
         return -1L;
      }
   }

   private static long bytesOf(Object uberBuffer) {
      if (uberBuffer instanceof UberGpuBufferAccessor accessor) {
         List<?> nodes = accessor.nvidiumplus$nodes();
         return nodes == null ? 0L : (long)nodes.size() * accessor.nvidiumplus$heapSize();
      } else {
         return 0L;
      }
   }

   public interface SectionRenderDispatcherAccessorBridge {
      Map<?, ?> nvidiumplus$chunkUberBuffers();
   }
}
