package nvidiumplus.terrain.mixin.minecraft;

import com.mojang.renderpearl.frontend.FrontendRenderPass;
import java.util.HashMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(FrontendRenderPass.class)
public interface FrontendRenderPassAccessor {
   @Accessor("uniforms")
   HashMap<String, Object> nvidiumplus$getUniforms();
}
