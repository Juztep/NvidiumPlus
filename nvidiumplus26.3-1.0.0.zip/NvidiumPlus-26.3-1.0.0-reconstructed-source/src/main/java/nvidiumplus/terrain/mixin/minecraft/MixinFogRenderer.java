package nvidiumplus.terrain.mixin.minecraft;

import net.minecraft.client.renderer.fog.FogRenderer;
import net.minecraft.util.Mth;
import nvidiumplus.terrain.NvidiumPlus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(FogRenderer.class)
public class MixinFogRenderer {
   @ModifyVariable(
      method = "setupFog(Lnet/minecraft/client/Camera;ILnet/minecraft/client/DeltaTracker;FLnet/minecraft/client/multiplayer/ClientLevel;)Lnet/minecraft/client/renderer/fog/FogData;",
      at = @At("STORE"),
      ordinal = 2
   )
   private float modifyFogRD(float viewDistance) {
      return NvidiumPlus.IS_ENABLED && NvidiumPlus.config.region_keep_distance != 32
         ? Math.max(viewDistance, NvidiumPlus.config.region_keep_distance * 16)
         : viewDistance;
   }

   @ModifyArg(
      method = "updateBuffer(Lnet/minecraft/client/renderer/fog/FogData;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/fog/FogRenderer;updateBuffer(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V"),
      index = 7
   )
   private float clampSkyEnd(float skyEnd) {
      return Mth.clamp(skyEnd, 32.0F, 512.0F);
   }
}
