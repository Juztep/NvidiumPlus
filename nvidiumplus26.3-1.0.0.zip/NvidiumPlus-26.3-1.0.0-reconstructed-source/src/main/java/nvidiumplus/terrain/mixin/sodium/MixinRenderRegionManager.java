package nvidiumplus.terrain.mixin.sodium;

import java.util.Collection;
import net.caffeinemc.mods.sodium.client.render.chunk.UniformBufferManager;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.BuilderTaskOutput;
import net.caffeinemc.mods.sodium.client.render.chunk.region.RenderRegionManager;
import nvidiumplus.terrain.NvidiumPlus;
import nvidiumplus.terrain.NvidiumPlusWorldRenderer;
import nvidiumplus.terrain.sodiumCompat.INvidiumPlusWorldRendererSetter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = RenderRegionManager.class, remap = false)
public abstract class MixinRenderRegionManager implements INvidiumPlusWorldRendererSetter {
   @Unique
   private NvidiumPlusWorldRenderer renderer;

   @Inject(
      method = "uploadResults(Ljava/util/Collection;Lnet/caffeinemc/mods/sodium/client/render/chunk/UniformBufferManager;)V",
      at = @At("HEAD"),
      cancellable = true
   )
   private void redirectUpload(Collection<BuilderTaskOutput> results, UniformBufferManager uniforms, CallbackInfo ci) {
      if (NvidiumPlus.IS_ENABLED) {
         ci.cancel();

         for (BuilderTaskOutput result : results) {
            this.renderer.uploadBuildResult(result);
         }
      }
   }

   @Override
   public void setWorldRenderer(NvidiumPlusWorldRenderer renderer) {
      this.renderer = renderer;
   }
}
