package nvidiumplus.terrain.mixin.sodium;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.backend.opengl.GlStateManager;
import com.mojang.renderpearl.frontend.FrontendRenderPass;
import net.caffeinemc.mods.sodium.client.render.SodiumWorldRenderer;
import net.caffeinemc.mods.sodium.client.render.chunk.ChunkRenderMatrices;
import net.caffeinemc.mods.sodium.client.render.chunk.RenderSectionManager;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.DefaultTerrainRenderPasses;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import net.caffeinemc.mods.sodium.client.render.viewport.Viewport;
import net.caffeinemc.mods.sodium.client.util.FogParameters;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.oit.OitStage;
import nvidiumplus.terrain.NvidiumPlus;
import nvidiumplus.terrain.NvidiumPlusWorldRenderer;
import nvidiumplus.terrain.mixin.minecraft.FrontendCommandEncoderAccessor;
import nvidiumplus.terrain.mixin.minecraft.GlCommandEncoderAccessor;
import nvidiumplus.terrain.sodiumCompat.INvidiumPlusWorldRendererGetter;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = SodiumWorldRenderer.class, remap = false)
public abstract class MixinSodiumWorldRenderer implements INvidiumPlusWorldRendererGetter {
   @Shadow
   private RenderSectionManager renderSectionManager;
   @Unique
   private Viewport viewport;

   @Override
   public NvidiumPlusWorldRenderer getRenderer() {
      return NvidiumPlus.IS_ENABLED ? ((INvidiumPlusWorldRendererGetter)this.renderSectionManager).getRenderer() : null;
   }

   @Inject(method = "setupTerrain", at = @At("HEAD"))
   public void trackViewport(
      Camera camera, Viewport viewport, FogParameters fogParameters, boolean spectator, boolean updateChunksImmediately, Matrix4f cullMatrix, CallbackInfo ci
   ) {
      this.viewport = viewport;
   }

   @Inject(method = "renderLayer", at = @At("HEAD"), cancellable = true)
   public void renderLayer(
      ChunkRenderMatrices matrices,
      TerrainRenderPass pass,
      double x,
      double y,
      double z,
      FogParameters fogParameters,
      GpuSampler terrainSampler,
      RenderPass renderPass,
      OitStage stage,
      CallbackInfo ci
   ) {
      if (pass != DefaultTerrainRenderPasses.TRANSLUCENT || renderPass instanceof FrontendRenderPass) {
         if (NvidiumPlus.IS_ENABLED) {
            ci.cancel();
            if (pass == DefaultTerrainRenderPasses.CUTOUT) {
               return;
            }

            ((GlCommandEncoderAccessor)((FrontendCommandEncoderAccessor)RenderSystem.getDevice().createCommandEncoder()).nvidiumplus$getBackend())
               .nvidiumplus$setLastProgram(null);
            GlStateManager._disableScissorTest();
            GlStateManager._enableCull();
            GlStateManager._enableDepthTest();
            GlStateManager._depthFunc(518);
            GlStateManager._colorMask(0, 15);
            GlStateManager._depthMask(true);
            if (pass == DefaultTerrainRenderPasses.SOLID) {
               GlStateManager._disableBlend(0);
               this.getRenderer().renderFrame(pass, this.viewport, fogParameters, matrices, x, y, z, terrainSampler);
            } else if (pass == DefaultTerrainRenderPasses.TRANSLUCENT) {
               this.getRenderer().renderTranslucent(pass, (FrontendRenderPass)renderPass, terrainSampler, stage);
            }
         }
      }
   }
}
