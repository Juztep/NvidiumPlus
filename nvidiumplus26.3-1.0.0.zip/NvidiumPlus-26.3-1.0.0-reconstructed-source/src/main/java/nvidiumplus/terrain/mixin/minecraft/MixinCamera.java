package nvidiumplus.terrain.mixin.minecraft;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.Camera;
import nvidiumplus.terrain.NvidiumPlus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(Camera.class)
public class MixinCamera {
   @ModifyExpressionValue(method = "update", at = @At(value = "INVOKE", target = "Ljava/lang/Math;max(FF)F"))
   private float nvidiumplus$modifyDepthFar(float original) {
      return NvidiumPlus.IS_ENABLED ? 8192.0F : original;
   }
}
