package nvidiumplus.terrain.mixin.sodium;

import net.caffeinemc.mods.sodium.client.render.chunk.RenderSection;
import nvidiumplus.terrain.sodiumCompat.IRenderSectionExtension;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value = RenderSection.class, remap = false)
public class MixinRenderSection implements IRenderSectionExtension {
   @Unique
   private volatile boolean isEnqueued;
   @Unique
   private volatile boolean isSeen;

   @Override
   public boolean isSubmittedRebuild() {
      return this.isEnqueued;
   }

   @Override
   public void isSubmittedRebuild(boolean state) {
      this.isEnqueued = state;
   }

   @Override
   public boolean isSeen() {
      return this.isSeen;
   }

   @Override
   public void isSeen(boolean state) {
      this.isSeen = state;
   }
}
