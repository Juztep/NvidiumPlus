package nvidiumplus.terrain.mixin.sodium;

import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkBuildOutput;
import nvidiumplus.terrain.sodiumCompat.IRepackagedResult;
import nvidiumplus.terrain.sodiumCompat.RepackagedSectionOutput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = ChunkBuildOutput.class, remap = false)
public class MixinChunkBuildOutput implements IRepackagedResult {
   @Unique
   private RepackagedSectionOutput repackagedSectionOutput;

   @Override
   public RepackagedSectionOutput getOutput() {
      return this.repackagedSectionOutput;
   }

   @Override
   public void set(RepackagedSectionOutput output) {
      this.repackagedSectionOutput = output;
   }

   @Inject(method = "destroy", at = @At("HEAD"))
   private void cleanup(CallbackInfo ci) {
      if (this.repackagedSectionOutput != null) {
         this.repackagedSectionOutput.delete();
      }
   }
}
