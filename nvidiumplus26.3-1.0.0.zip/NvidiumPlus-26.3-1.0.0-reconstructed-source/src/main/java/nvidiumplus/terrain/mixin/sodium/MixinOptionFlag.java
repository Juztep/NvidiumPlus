package nvidiumplus.terrain.mixin.sodium;

import net.caffeinemc.mods.sodium.api.config.option.OptionFlag;
import nvidiumplus.terrain.sodiumCompat.NvidiumPlusOptionFlags;
import org.apache.commons.lang3.ArrayUtils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value = OptionFlag.class, remap = false)
public class MixinOptionFlag {
   @Shadow
   @Final
   @Mutable
   private static OptionFlag[] $VALUES = (OptionFlag[])ArrayUtils.addAll(
      MixinOptionFlag.$VALUES, new OptionFlag[]{NvidiumPlusOptionFlags.REQUIRES_SHADER_RELOAD}
   );

   @Invoker("<init>")
   public static OptionFlag optionFlagCreator(String internalName, int internalId) {
      throw new AssertionError();
   }

   static {
      NvidiumPlusOptionFlags.REQUIRES_SHADER_RELOAD = optionFlagCreator("REQUIRES_SHADER_RELOAD", $VALUES.length);
   }
}
