package nvidiumplus.terrain.mixin.minecraft;

import net.minecraft.client.renderer.texture.TextureAtlas;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(TextureAtlas.class)
public interface TextureAtlasAccessor {
   @Invoker("getWidth")
   int nvidiumplus$getWidth();

   @Invoker("getHeight")
   int nvidiumplus$getHeight();
}
