package nvidiumplus.terrain.mixin.sodium;

import java.util.ArrayList;
import java.util.Collection;
import net.caffeinemc.mods.sodium.client.render.chunk.RenderSection;
import net.caffeinemc.mods.sodium.client.render.chunk.RenderSectionManager;
import net.caffeinemc.mods.sodium.client.render.chunk.region.RenderRegionManager;
import net.caffeinemc.mods.sodium.client.render.chunk.translucent_sorting.SortBehavior;
import net.caffeinemc.mods.sodium.client.render.chunk.vertex.format.ChunkVertexType;
import net.caffeinemc.mods.sodium.client.render.viewport.Viewport;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import nvidiumplus.terrain.NvidiumPlus;
import nvidiumplus.terrain.NvidiumPlusWorldRenderer;
import nvidiumplus.terrain.sodiumCompat.INvidiumPlusWorldRendererGetter;
import nvidiumplus.terrain.sodiumCompat.INvidiumPlusWorldRendererSetter;
import nvidiumplus.terrain.sodiumCompat.IrisCheck;
import nvidiumplus.terrain.sodiumCompat.NvidiumPlusCompactChunkVertex;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = RenderSectionManager.class, remap = false, priority = 1500)
public class MixinRenderSectionManager implements INvidiumPlusWorldRendererGetter {
   @Shadow
   @Final
   private RenderRegionManager regions;
   @Unique
   private NvidiumPlusWorldRenderer renderer;
   @Unique
   private Viewport viewport;

   @Unique
   private static void updateNvidiumPlusIsEnabled() {
      NvidiumPlus.IS_ENABLED = !NvidiumPlus.FORCE_DISABLE && NvidiumPlus.IS_COMPATIBLE && IrisCheck.checkIrisShouldDisable();
   }

   @Inject(method = "<init>", at = @At("TAIL"))
   private void init(ClientLevel level, int renderDistance, SortBehavior sortBehavior, CallbackInfo ci) {
      updateNvidiumPlusIsEnabled();
      if (NvidiumPlus.IS_ENABLED) {
         if (this.renderer != null) {
            throw new IllegalStateException("Cannot have multiple world renderers");
         }

         this.renderer = new NvidiumPlusWorldRenderer();
         ((INvidiumPlusWorldRendererSetter)this.regions).setWorldRenderer(this.renderer);
      }
   }

   @ModifyArg(
      method = "<init>",
      at = @At(
         value = "INVOKE",
         target = "Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/executor/ChunkBuilder;<init>(Lnet/minecraft/client/multiplayer/ClientLevel;Lnet/caffeinemc/mods/sodium/client/render/chunk/vertex/format/ChunkVertexType;)V",
         remap = true
      ),
      index = 1
   )
   private ChunkVertexType modifyVertexType(ChunkVertexType vertexType) {
      updateNvidiumPlusIsEnabled();
      return NvidiumPlus.IS_ENABLED && !NvidiumPlus.config.use_sodium_vertex_format ? NvidiumPlusCompactChunkVertex.INSTANCE : vertexType;
   }

   @Inject(method = "destroy", at = @At("TAIL"))
   private void destroy(CallbackInfo ci) {
      if (NvidiumPlus.IS_ENABLED) {
         if (this.renderer == null) {
            throw new IllegalStateException("Pipeline already destroyed");
         }

         ((INvidiumPlusWorldRendererSetter)this.regions).setWorldRenderer(null);
         this.renderer.delete();
         this.renderer = null;
      }
   }

   @Redirect(method = "onSectionRemoved", at = @At(value = "INVOKE", target = "Lnet/caffeinemc/mods/sodium/client/render/chunk/RenderSection;delete()V"))
   private void deleteSection(RenderSection section) {
      if (NvidiumPlus.IS_ENABLED
         && (
            NvidiumPlus.config.region_keep_distance == 32
               || NvidiumPlus.config.region_keep_distance <= Minecraft.getInstance().options.getEffectiveRenderDistance()
         )) {
         this.renderer.deleteSection(section);
      }

      section.delete();
   }

   @Inject(method = "getDebugStrings", at = @At("HEAD"), cancellable = true)
   private void redirectDebug(CallbackInfoReturnable<Collection<String>> cir) {
      if (NvidiumPlus.IS_ENABLED) {
         ArrayList<String> debugStrings = new ArrayList<>();
         this.renderer.addDebugInfo(debugStrings);
         cir.setReturnValue(debugStrings);
         cir.cancel();
      }
   }

   @Override
   public NvidiumPlusWorldRenderer getRenderer() {
      return this.renderer;
   }
}
