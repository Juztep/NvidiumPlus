package nvidiumplus.terrain.mixin;

import java.util.List;
import java.util.Set;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

public final class VitrailOpenGLCompatibilityPlugin implements IMixinConfigPlugin {
   private static final String VITRAIL_LEVEL_PASS = "dev/vitrail/render/LevelPass.class";
   private boolean vitrailLevelPassPresent;

   public void onLoad(String var1) {
      this.vitrailLevelPassPresent = resourcePresent("dev/vitrail/render/LevelPass.class");
      if (this.vitrailLevelPassPresent) {
         System.out
            .println(
               "[NvidiumPlus] Vitrail LevelPass detected; disabling the legacy Sodium/OpenGL terrain takeover so Sodium can render translucent terrain and water."
            );
      }
   }

   private static boolean resourcePresent(String var0) {
      try {
         ClassLoader var1 = Thread.currentThread().getContextClassLoader();
         if (var1 != null && var1.getResource(var0) != null) {
            return true;
         }

         ClassLoader var2 = VitrailOpenGLCompatibilityPlugin.class.getClassLoader();
         return var2 != null && var2.getResource(var0) != null;
      } catch (Throwable var3) {
         return false;
      }
   }

   public String getRefMapperConfig() {
      return null;
   }

   public boolean shouldApplyMixin(String var1, String var2) {
      return !this.vitrailLevelPassPresent;
   }

   public void acceptTargets(Set<String> var1, Set<String> var2) {
   }

   public List<String> getMixins() {
      return null;
   }

   public void preApply(String var1, ClassNode var2, String var3, IMixinInfo var4) {
   }

   public void postApply(String var1, ClassNode var2, String var3, IMixinInfo var4) {
   }
}
