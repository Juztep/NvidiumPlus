package nvidiumplus.terrain.renderers;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.opengl.GlSampler;
import com.mojang.renderpearl.backend.opengl.GlStateManager;
import com.mojang.renderpearl.backend.opengl.GlTexture;
import com.mojang.renderpearl.frontend.FrontendRenderPass;
import com.mojang.renderpearl.util.TextureViewAndSampler;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.ShaderDefines;
import net.minecraft.client.renderer.oit.OitStage;
import net.minecraft.resources.Identifier;
import nvidiumplus.terrain.gl.shader.Shader;
import nvidiumplus.terrain.gl.shader.ShaderType;
import nvidiumplus.terrain.mixin.minecraft.FrontendRenderPassAccessor;
import nvidiumplus.terrain.sodiumCompat.ShaderLoader;
import org.lwjgl.opengl.GL20C;
import org.lwjgl.opengl.GL33C;
import org.lwjgl.opengl.GL41C;
import org.lwjgl.opengl.GL45C;
import org.lwjgl.opengl.NVMeshShader;
import org.lwjgl.opengl.NVVertexBufferUnifiedMemory;

public class TranslucentTerrainRasterizer extends Phase {
   private final Shader shader = Shader.make()
      .addSource(ShaderType.TASK, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/translucent/task.glsl")))
      .addSource(ShaderType.MESH, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/translucent/mesh.glsl")))
      .addSource(
         ShaderType.FRAGMENT,
         ShaderLoader.parse(
            Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/frag.frag"),
            ShaderDefines.builder().define("TRANSLUCENT_PASS").define("ALPHA_CUTOUT", 0.01F)
         )
      )
      .compile();
   private final Shader[] oitShaders = new Shader[]{
      Shader.make()
         .addSource(ShaderType.TASK, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/translucent/task.glsl")))
         .addSource(ShaderType.MESH, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/translucent/mesh.glsl")))
         .addSource(
            ShaderType.FRAGMENT,
            ShaderLoader.parse(
               Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/frag.frag"),
               ShaderDefines.builder()
                  .define("TRANSLUCENT_PASS")
                  .define("ALPHA_CUTOUT", 0.01F)
                  .define("OIT")
                  .define("OIT_WAVELET_RANK", 2)
                  .define("OIT_COEFF_COUNT", LevelRenderer.OIT_COEFFICIENT_COUNT)
                  .define("OIT_COEFF_ATTACHMENT_COUNT", LevelRenderer.OIT_TRANSMITTANCE_TARGET_COUNT)
                  .define("OIT_ALPHA_ONLY")
                  .define("OIT_DEPTH_BOUNDS")
            )
         )
         .compile(),
      Shader.make()
         .addSource(ShaderType.TASK, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/translucent/task.glsl")))
         .addSource(ShaderType.MESH, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/translucent/mesh.glsl")))
         .addSource(
            ShaderType.FRAGMENT,
            ShaderLoader.parse(
               Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/frag.frag"),
               ShaderDefines.builder()
                  .define("TRANSLUCENT_PASS")
                  .define("ALPHA_CUTOUT", 0.01F)
                  .define("OIT")
                  .define("OIT_WAVELET_RANK", 2)
                  .define("OIT_COEFF_COUNT", LevelRenderer.OIT_COEFFICIENT_COUNT)
                  .define("OIT_COEFF_ATTACHMENT_COUNT", LevelRenderer.OIT_TRANSMITTANCE_TARGET_COUNT)
                  .define("OIT_ALPHA_ONLY")
                  .define("OIT_TRANSMITTANCE")
            )
         )
         .compile(),
      Shader.make()
         .addSource(ShaderType.TASK, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/translucent/task.glsl")))
         .addSource(ShaderType.MESH, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/translucent/mesh.glsl")))
         .addSource(
            ShaderType.FRAGMENT,
            ShaderLoader.parse(
               Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/frag.frag"),
               ShaderDefines.builder()
                  .define("TRANSLUCENT_PASS")
                  .define("ALPHA_CUTOUT", 0.01F)
                  .define("OIT")
                  .define("OIT_WAVELET_RANK", 2)
                  .define("OIT_COEFF_COUNT", LevelRenderer.OIT_COEFFICIENT_COUNT)
                  .define("OIT_COEFF_ATTACHMENT_COUNT", LevelRenderer.OIT_TRANSMITTANCE_TARGET_COUNT)
                  .define("OIT_ACCUMULATE")
            )
         )
         .compile()
   };

   private static void setTexture(GpuTextureView texView, int bindingPoint, GpuSampler sampler) {
      GlTexture tex = (GlTexture)texView.texture();
      GlStateManager._activeTexture(33984 + bindingPoint);
      GlStateManager._bindTexture(tex.glId());
      GlStateManager._texParameter(3553, 33084, texView.baseMipLevel());
      GlStateManager._texParameter(3553, 33085, texView.baseMipLevel() + texView.mipLevels() - 1);
      GL33C.glBindSampler(bindingPoint, ((GlSampler)sampler).getId());
   }

   private static void linkRenderpearlSampler(FrontendRenderPass renderPass, int programId, String name, int bindingPoint) {
      TextureViewAndSampler texViewAndSampler = (TextureViewAndSampler)((FrontendRenderPassAccessor)renderPass).nvidiumplus$getUniforms().get(name);
      setTexture(texViewAndSampler.view(), bindingPoint, texViewAndSampler.sampler());
      int location = GL20C.glGetUniformLocation(programId, name);
      GL41C.glProgramUniform1i(programId, location, bindingPoint);
   }

   public void raster(TerrainRenderPass pass, FrontendRenderPass renderPass, int regionCount, long commandAddr, GpuSampler terrainSampler, OitStage stage) {
      GpuTextureView blockTexture = pass.getAtlas();
      GpuTextureView lightTexture = Minecraft.getInstance().gameRenderer.lightmap();
      setTexture(blockTexture, 0, terrainSampler);
      if (stage == null) {
         this.shader.bind();
         GlStateManager._enableBlend(0);
         GlStateManager._blendFuncSeparate(770, 771, 1, 771);
         setTexture(lightTexture, 1, RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR));
      } else {
         Shader oitShader = this.oitShaders[stage.ordinal()];
         oitShader.bind();
         GlStateManager._depthMask(false);
         switch (stage) {
            case DEPTH_BOUNDS:
               GlStateManager._enableBlend(0);
               GlStateManager._blendFuncSeparate(1, 1, 1, 1);
               GlStateManager._blendEquationSeparate(32776, 32776);
               break;
            case TRANSMITTANCE:
               GlStateManager._enableBlend(0);
               GlStateManager._enableBlend(1);
               GlStateManager._blendFuncSeparate(1, 1, 1, 1);
               GlStateManager._blendEquationSeparate(32774, 32774);
               linkRenderpearlSampler(renderPass, oitShader.getId(), "DepthBoundsSampler", 2);
               break;
            case ACCUMULATE:
               GlStateManager._enableBlend(0);
               GlStateManager._blendFuncSeparate(1, 1, 1, 1);
               GlStateManager._blendEquationSeparate(32774, 32774);
               setTexture(lightTexture, 1, RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR));
               linkRenderpearlSampler(renderPass, oitShader.getId(), "DepthBoundsSampler", 2);
               linkRenderpearlSampler(renderPass, oitShader.getId(), "Coeff0", 3);
               linkRenderpearlSampler(renderPass, oitShader.getId(), "Coeff1", 4);
         }
      }

      NVVertexBufferUnifiedMemory.glBufferAddressRangeNV(36673, 0, commandAddr, regionCount * 8L);
      this.timing.marker();
      NVMeshShader.glMultiDrawMeshTasksIndirectNV(0L, regionCount, 0);
      this.timing.marker();
      this.timing.tick();
      GL45C.glBindSampler(0, 0);
      GL45C.glBindSampler(1, 0);
   }

   @Override
   public void delete() {
      super.delete();
      this.shader.delete();

      for (Shader s : this.oitShaders) {
         s.delete();
      }
   }
}
