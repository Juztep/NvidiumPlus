package nvidiumplus.terrain.renderers;

import net.minecraft.resources.Identifier;
import nvidiumplus.terrain.gl.shader.Shader;
import nvidiumplus.terrain.gl.shader.ShaderType;
import nvidiumplus.terrain.sodiumCompat.ShaderLoader;
import org.lwjgl.opengl.GL43C;

public class SortRegionSectionPhase extends Phase {
   private final Shader shader = Shader.make()
      .addSource(ShaderType.COMPUTE, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "sorting/region_section_sorter.comp")))
      .compile();

   public void dispatch(int sortingRegionCount) {
      this.shader.bind();
      this.timing.marker();
      GL43C.glDispatchCompute(sortingRegionCount, 1, 1);
      this.timing.marker();
      this.timing.tick();
   }

   @Override
   public void delete() {
      super.delete();
      this.shader.delete();
   }
}
