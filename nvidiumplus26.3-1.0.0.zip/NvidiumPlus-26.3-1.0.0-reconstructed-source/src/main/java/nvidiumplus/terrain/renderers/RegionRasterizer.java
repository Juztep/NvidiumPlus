package nvidiumplus.terrain.renderers;

import net.minecraft.resources.Identifier;
import nvidiumplus.terrain.gl.shader.Shader;
import nvidiumplus.terrain.gl.shader.ShaderType;
import nvidiumplus.terrain.sodiumCompat.ShaderLoader;
import org.lwjgl.opengl.NVMeshShader;

public class RegionRasterizer extends Phase {
   private final Shader shader = Shader.make()
      .addSource(ShaderType.MESH, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "occlusion/region_raster/mesh.glsl")))
      .addSource(ShaderType.FRAGMENT, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "occlusion/region_raster/fragment.frag")))
      .compile();

   public void raster(int regionCount) {
      this.shader.bind();
      this.timing.marker();
      NVMeshShader.glDrawMeshTasksNV(0, (regionCount + 3) / 4);
      this.timing.marker();
      this.timing.tick();
   }

   @Override
   public void delete() {
      super.delete();
      this.shader.delete();
   }
}
