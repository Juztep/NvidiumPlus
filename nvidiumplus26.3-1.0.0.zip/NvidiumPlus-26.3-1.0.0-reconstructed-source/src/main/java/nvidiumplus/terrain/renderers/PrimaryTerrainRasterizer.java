package nvidiumplus.terrain.renderers;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.opengl.GlSampler;
import com.mojang.renderpearl.backend.opengl.GlStateManager;
import com.mojang.renderpearl.backend.opengl.GlTexture;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ShaderDefines;
import net.minecraft.resources.Identifier;
import nvidiumplus.terrain.gl.shader.Shader;
import nvidiumplus.terrain.gl.shader.ShaderType;
import nvidiumplus.terrain.sodiumCompat.ShaderLoader;
import org.lwjgl.opengl.GL33C;
import org.lwjgl.opengl.NVMeshShader;
import org.lwjgl.opengl.NVVertexBufferUnifiedMemory;

public class PrimaryTerrainRasterizer extends Phase {
   private final Shader shader = Shader.make()
      .addSource(ShaderType.TASK, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/task.glsl")))
      .addSource(ShaderType.MESH, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/mesh.glsl")))
      .addSource(
         ShaderType.FRAGMENT,
         ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "terrain/frag.frag"), ShaderDefines.builder().define("ALPHA_CUTOUT", 0.5F))
      )
      .compile();

   private static void setTexture(GpuTextureView texView, int bindingPoint, GpuSampler sampler) {
      GlTexture tex = (GlTexture)texView.texture();
      GlStateManager._activeTexture(33984 + bindingPoint);
      GlStateManager._bindTexture(tex.glId());
      GlStateManager._texParameter(3553, 33084, texView.baseMipLevel());
      GlStateManager._texParameter(3553, 33085, texView.baseMipLevel() + texView.mipLevels() - 1);
      GL33C.glBindSampler(bindingPoint, ((GlSampler)sampler).getId());
   }

   public void raster(TerrainRenderPass pass, int regionCount, long commandAddr, GpuSampler terrainSampler) {
      this.shader.bind();
      GpuTextureView blockTexture = pass.getAtlas();
      GpuTextureView lightTexture = Minecraft.getInstance().gameRenderer.lightmap();
      setTexture(blockTexture, 0, terrainSampler);
      setTexture(lightTexture, 1, RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR));
      NVVertexBufferUnifiedMemory.glBufferAddressRangeNV(36673, 0, commandAddr, regionCount * 8L);
      this.timing.marker();
      NVMeshShader.glMultiDrawMeshTasksIndirectNV(0L, regionCount, 0);
      this.timing.marker();
      this.timing.tick();
   }

   @Override
   public void delete() {
      super.delete();
      this.shader.delete();
   }
}
