package nvidiumplus.terrain.renderers;

import nvidiumplus.terrain.util.GPUTiming;

public abstract class Phase {
   GPUTiming timing = new GPUTiming();

   public void delete() {
      this.timing.free();
   }

   public GPUTiming getTiming() {
      return this.timing;
   }
}
