package nvidiumplus.terrain.renderers;

import net.minecraft.resources.Identifier;
import nvidiumplus.terrain.gl.shader.Shader;
import nvidiumplus.terrain.gl.shader.ShaderType;
import nvidiumplus.terrain.sodiumCompat.ShaderLoader;
import org.lwjgl.opengl.NVMeshShader;

public class SectionRasterizer extends Phase {
   private final Shader shader = Shader.make()
      .addSource(ShaderType.TASK, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "occlusion/section_raster/task.glsl")))
      .addSource(ShaderType.MESH, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "occlusion/section_raster/mesh.glsl")))
      .addSource(ShaderType.FRAGMENT, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "occlusion/section_raster/fragment.glsl")))
      .compile();

   public void raster(int regionCount) {
      this.shader.bind();
      this.timing.marker();
      NVMeshShader.glDrawMeshTasksNV(0, regionCount);
      this.timing.marker();
      this.timing.tick();
   }

   @Override
   public void delete() {
      super.delete();
      this.shader.delete();
   }
}
