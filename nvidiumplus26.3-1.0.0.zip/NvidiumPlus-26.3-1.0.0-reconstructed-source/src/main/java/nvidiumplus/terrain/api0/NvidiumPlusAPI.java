package nvidiumplus.terrain.api0;

import net.caffeinemc.mods.sodium.client.render.SodiumWorldRenderer;
import nvidiumplus.terrain.NvidiumPlus;
import nvidiumplus.terrain.NvidiumPlusWorldRenderer;
import nvidiumplus.terrain.sodiumCompat.INvidiumPlusWorldRendererGetter;
import org.joml.Matrix4fc;

public class NvidiumPlusAPI {
   private final String modName;

   public NvidiumPlusAPI(String modName) {
      this.modName = modName;
   }

   public void hideSection(int x, int y, int z) {
      if (NvidiumPlus.IS_ENABLED) {
         NvidiumPlusWorldRenderer renderer = ((INvidiumPlusWorldRendererGetter)SodiumWorldRenderer.instance()).getRenderer();
         if (renderer != null) {
            renderer.getSectionManager().setHideBit(x, y, z, true);
         }
      }
   }

   public void showSection(int x, int y, int z) {
      if (NvidiumPlus.IS_ENABLED) {
         NvidiumPlusWorldRenderer renderer = ((INvidiumPlusWorldRendererGetter)SodiumWorldRenderer.instance()).getRenderer();
         if (renderer != null) {
            renderer.getSectionManager().setHideBit(x, y, z, false);
         }
      }
   }

   public void setRegionTransformId(int id, int x, int y, int z) {
      if (NvidiumPlus.IS_ENABLED) {
         NvidiumPlusWorldRenderer renderer = ((INvidiumPlusWorldRendererGetter)SodiumWorldRenderer.instance()).getRenderer();
         if (renderer != null) {
            renderer.getSectionManager().getRegionManager().setRegionTransformId(x, y, z, id);
         }
      }
   }

   public void setTransformation(int id, Matrix4fc transform) {
      if (NvidiumPlus.IS_ENABLED) {
         NvidiumPlusWorldRenderer renderer = ((INvidiumPlusWorldRendererGetter)SodiumWorldRenderer.instance()).getRenderer();
         if (renderer != null) {
            renderer.setTransformation(id, transform);
         }
      }
   }

   public void setOrigin(int id, int x, int y, int z) {
      if (NvidiumPlus.IS_ENABLED) {
         NvidiumPlusWorldRenderer renderer = ((INvidiumPlusWorldRendererGetter)SodiumWorldRenderer.instance()).getRenderer();
         if (renderer != null) {
            renderer.setOrigin(id, x, y, z);
         }
      }
   }
}
