package nvidiumplus.terrain.util;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class TickableManager {
   private static final Set<UploadingBufferStream> UPLOADERS = new LinkedHashSet<>();
   private static final Set<DownloadTaskStream> DOWNLOADERS = new LinkedHashSet<>();

   public static void register(UploadingBufferStream stream) {
      UPLOADERS.add(stream);
   }

   public static void register(DownloadTaskStream stream) {
      DOWNLOADERS.add(stream);
   }

   public static void remove(UploadingBufferStream stream) {
      UPLOADERS.remove(stream);
   }

   public static void remove(DownloadTaskStream stream) {
      DOWNLOADERS.remove(stream);
   }

   public static void TickAll() {
      Iterator<UploadingBufferStream> iter = UPLOADERS.iterator();

      while (iter.hasNext()) {
         iter.next().tick();
      }

      Iterator<DownloadTaskStream> iter2 = DOWNLOADERS.iterator();

      while (iter2.hasNext()) {
         iter2.next().tick();
      }
   }
}
