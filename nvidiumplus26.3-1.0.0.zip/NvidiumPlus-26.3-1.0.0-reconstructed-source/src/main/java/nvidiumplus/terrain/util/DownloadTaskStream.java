package nvidiumplus.terrain.util;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import nvidiumplus.terrain.gl.RenderDevice;
import nvidiumplus.terrain.gl.buffers.Buffer;
import nvidiumplus.terrain.gl.buffers.PersistentClientMappedBuffer;

public class DownloadTaskStream {
   private final SegmentedManager allocator = new SegmentedManager();
   private final RenderDevice device;
   private PersistentClientMappedBuffer buffer;
   private int cidx;
   private final ObjectList<DownloadTaskStream.Download>[] allocations;

   public DownloadTaskStream(RenderDevice device, int frames, long size) {
      this.device = device;
      this.allocator.setLimit(size);
      this.buffer = device.createClientMappedBuffer(size);
      TickableManager.register(this);
      this.allocations = new ObjectList[frames];

      for (int i = 0; i < frames; i++) {
         this.allocations[i] = new ObjectArrayList();
      }
   }

   public void download(Buffer source, long offset, int size, DownloadTaskStream.IDownloadFinishedCallback callback) {
      long addr = this.allocator.alloc(size);
      this.device.copyBuffer(source, this.buffer, offset, addr, size);
      this.allocations[this.cidx].add(new DownloadTaskStream.Download(addr, callback));
   }

   void tick() {
      this.cidx = (this.cidx + 1) % this.allocations.length;
      ObjectListIterator var1 = this.allocations[this.cidx].iterator();

      while (var1.hasNext()) {
         DownloadTaskStream.Download download = (DownloadTaskStream.Download)var1.next();
         download.callback.accept(download.addr + this.buffer.clientAddress());
         this.allocator.free(download.addr);
      }

      this.allocations[this.cidx].clear();
   }

   public void delete() {
      TickableManager.remove(this);
      this.buffer.delete();
   }

   private record Download(long addr, DownloadTaskStream.IDownloadFinishedCallback callback) {
   }

   public interface IDownloadFinishedCallback {
      void accept(long var1);
   }
}
