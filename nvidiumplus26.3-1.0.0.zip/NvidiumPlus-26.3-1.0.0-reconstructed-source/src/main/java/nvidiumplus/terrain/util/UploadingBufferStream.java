package nvidiumplus.terrain.util;

import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongListIterator;
import java.util.ArrayDeque;
import java.util.Deque;
import nvidiumplus.terrain.gl.GlFence;
import nvidiumplus.terrain.gl.RenderDevice;
import nvidiumplus.terrain.gl.buffers.Buffer;
import nvidiumplus.terrain.gl.buffers.PersistentClientMappedBuffer;
import org.lwjgl.opengl.ARBDirectStateAccess;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL42;

public class UploadingBufferStream {
   private final SegmentedManager allocationArena = new SegmentedManager();
   private final PersistentClientMappedBuffer uploadBuffer;
   private final Deque<UploadingBufferStream.UploadFrame> frames = new ArrayDeque<>();
   private final LongArrayList thisFrameAllocations = new LongArrayList();
   private final Deque<UploadingBufferStream.UploadData> uploadList = new ArrayDeque<>();
   private final LongArrayList flushList = new LongArrayList();
   private long caddr = -1L;
   private long offset = 0L;

   public UploadingBufferStream(RenderDevice device, long size) {
      this.allocationArena.setLimit(size);
      this.uploadBuffer = device.createClientMappedBuffer(size);
      TickableManager.register(this);
   }

   public long upload(Buffer buffer, long destOffset, long size) {
      if (size > 2147483647L || size == 0L || size < 0L) {
         throw new IllegalArgumentException();
      }

      if (destOffset < 0L) {
         throw new IllegalStateException();
      }

      if (destOffset + size > buffer.getSize()) {
         throw new IllegalStateException();
      }

      long addr;
      if (this.caddr != -1L && this.allocationArena.expand(this.caddr, (int)size)) {
         addr = this.caddr + this.offset;
         this.offset += size;
      } else {
         this.caddr = this.allocationArena.alloc((int)size);
         if (this.caddr == -1L) {
            this.commit();

            for (int attempts = 10; --attempts != 0 && this.caddr == -1L; this.caddr = this.allocationArena.alloc((int)size)) {
               GL11.glFinish();
               this.tick();
            }

            if (this.caddr == -1L) {
               throw new IllegalStateException("Could not allocate memory segment big enough for upload even after force flush");
            }
         }

         this.flushList.add(this.caddr);
         this.offset = size;
         addr = this.caddr;
      }

      if (this.caddr + size > this.uploadBuffer.size) {
         throw new IllegalStateException();
      }

      this.uploadList.add(new UploadingBufferStream.UploadData(buffer, addr, destOffset, size));
      return this.uploadBuffer.addr + addr;
   }

   public void commit() {
      LongListIterator var1 = this.flushList.iterator();

      while (var1.hasNext()) {
         long alloc = (Long)var1.next();
         ARBDirectStateAccess.glFlushMappedNamedBufferRange(this.uploadBuffer.getId(), alloc, this.allocationArena.getSize(alloc));
         this.thisFrameAllocations.add(alloc);
      }

      this.flushList.clear();
      GL42.glMemoryBarrier(16384);

      for (UploadingBufferStream.UploadData entry : this.uploadList) {
         ARBDirectStateAccess.glCopyNamedBufferSubData(this.uploadBuffer.getId(), entry.target.getId(), entry.uploadOffset, entry.targetOffset, entry.size);
      }

      this.uploadList.clear();
      GL42.glMemoryBarrier(512);
      this.caddr = -1L;
      this.offset = 0L;
   }

   public void tick() {
      this.commit();
      if (!this.thisFrameAllocations.isEmpty()) {
         this.frames.add(new UploadingBufferStream.UploadFrame(new GlFence(), new LongArrayList(this.thisFrameAllocations)));
         this.thisFrameAllocations.clear();
      }

      while (!this.frames.isEmpty() && this.frames.peek().fence.signaled()) {
         UploadingBufferStream.UploadFrame frame = this.frames.pop();
         frame.allocations.forEach(this.allocationArena::free);
         frame.fence.free();
      }
   }

   public void delete() {
      TickableManager.remove(this);
      this.uploadBuffer.delete();
      this.frames.forEach(frame -> frame.fence.free());
   }

   private record UploadData(Buffer target, long uploadOffset, long targetOffset, long size) {
   }

   private record UploadFrame(GlFence fence, LongArrayList allocations) {
   }
}
