package nvidiumplus.terrain.util;

import nvidiumplus.terrain.NvidiumPlus;
import nvidiumplus.terrain.gl.RenderDevice;
import nvidiumplus.terrain.gl.buffers.IDeviceMappedBuffer;
import nvidiumplus.terrain.gl.buffers.PersistentSparseAddressableBuffer;

public class BufferArena {
   SegmentedManager segments = new SegmentedManager();
   private final RenderDevice device;
   public final IDeviceMappedBuffer buffer;
   private long totalQuads;
   private final int vertexFormatSize;
   private final long memory_size;

   public BufferArena(RenderDevice device, long memory, int vertexFormatSize) {
      this.device = device;
      this.vertexFormatSize = vertexFormatSize;
      this.memory_size = memory;
      if (NvidiumPlus.SUPPORTS_PERSISTENT_SPARSE_ADDRESSABLE_BUFFER) {
         this.buffer = device.createSparseBuffer(80000000000L);
      } else {
         this.buffer = device.createDeviceOnlyMappedBuffer(memory);
         this.segments.setLimit(memory / (4L * this.vertexFormatSize));
      }

      this.allocQuads(1);
   }

   public int allocQuads(int quadCount) {
      this.totalQuads += quadCount;
      int addr = (int)this.segments.alloc(quadCount);
      if (addr == -1L) {
         return addr;
      }

      if (this.buffer instanceof PersistentSparseAddressableBuffer psab) {
         psab.ensureAllocated(Integer.toUnsignedLong(addr) * 4L * this.vertexFormatSize, quadCount * 4L * this.vertexFormatSize);
      }

      return addr;
   }

   public void free(int addr) {
      int count = this.segments.free(addr);
      this.totalQuads -= count;
      if (this.buffer instanceof PersistentSparseAddressableBuffer psab) {
         psab.deallocate(Integer.toUnsignedLong(addr) * 4L * this.vertexFormatSize, count * 4L * this.vertexFormatSize);
      }
   }

   public long upload(UploadingBufferStream stream, int addr) {
      return stream.upload(this.buffer, Integer.toUnsignedLong(addr) * 4L * this.vertexFormatSize, (int)this.segments.getSize(addr) * 4 * this.vertexFormatSize);
   }

   public void delete() {
      this.buffer.delete();
   }

   public int getAllocatedMB() {
      return this.buffer instanceof PersistentSparseAddressableBuffer psab
         ? (int)(psab.getPagesCommitted() * 1048576L / 1048576L)
         : (int)(this.memory_size / 1048576L);
   }

   public int getUsedMB() {
      return (int)(this.totalQuads * this.vertexFormatSize * 4L / 1048576L);
   }

   public long getMemoryUsed() {
      return this.buffer instanceof PersistentSparseAddressableBuffer psab ? psab.getPagesCommitted() * 1048576L : this.memory_size;
   }

   public float getFragmentation() {
      long expected = this.totalQuads * this.vertexFormatSize * 4L;
      return (float)((double)expected / this.getMemoryUsed());
   }

   public boolean canReuse(int addr, int quads) {
      return this.segments.getSize(addr) == quads;
   }
}
