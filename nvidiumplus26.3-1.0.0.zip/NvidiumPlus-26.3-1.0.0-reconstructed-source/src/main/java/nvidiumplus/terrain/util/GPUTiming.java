package nvidiumplus.terrain.util;

import it.unimi.dsi.fastutil.ints.IntArrayFIFOQueue;
import it.unimi.dsi.fastutil.objects.ObjectArrayFIFOQueue;
import java.util.Arrays;
import nvidiumplus.terrain.gl.TrackedObject;
import org.lwjgl.opengl.GL33C;

public class GPUTiming {
   private int index = 0;
   private int count = 0;
   private long total = 0L;
   private final long[] samples = new long[100];
   private final GPUTiming.GlTimestampQuerySet timingSet = new GPUTiming.GlTimestampQuerySet();

   public void marker() {
      this.timingSet.capture(0);
   }

   private void addSample(long timeNs) {
      this.total = this.total - this.samples[this.index];
      this.samples[this.index] = timeNs;
      this.total += timeNs;
      this.index = (this.index + 1) % this.samples.length;
      if (this.count < this.samples.length) {
         this.count++;
      }
   }

   public double getAverageMs() {
      return this.count == 0 ? 0.0 : this.total / this.count / 1000000.0;
   }

   public void tick() {
      this.timingSet.download((meta, data) -> {
         long current = data[0];

         for (int i = 1; i < meta.length; i++) {
            long next = data[i];
            long delta = next - current;
            this.addSample(delta);
            current = next;
         }
      });
      this.timingSet.tick();
   }

   public void free() {
      this.timingSet.free();
   }

   private static final class GlTimestampQuerySet extends TrackedObject {
      private final IntArrayFIFOQueue POOL = new IntArrayFIFOQueue();
      private final ObjectArrayFIFOQueue<GPUTiming.GlTimestampQuerySet.InflightRequest> INFLIGHT = new ObjectArrayFIFOQueue();
      private final int[] queries = new int[64];
      private final int[] metadata = new int[64];
      private int index;

      public void capture(int metadata) {
         if (this.index > this.metadata.length) {
            throw new IllegalStateException();
         }

         int slot = this.index++;
         this.metadata[slot] = metadata;
         int query = this.getQuery();
         GL33C.glQueryCounter(query, 36392);
         this.queries[slot] = query;
      }

      public void download(GPUTiming.TimingDataConsumer consumer) {
         int[] queries = Arrays.copyOf(this.queries, this.index);
         int[] metadata = Arrays.copyOf(this.metadata, this.index);
         this.index = 0;
         this.INFLIGHT.enqueue(new GPUTiming.GlTimestampQuerySet.InflightRequest(queries, metadata, consumer));
      }

      public void tick() {
         while (!this.INFLIGHT.isEmpty() && ((GPUTiming.GlTimestampQuerySet.InflightRequest)this.INFLIGHT.first()).callbackIfReady(this.POOL)) {
            this.INFLIGHT.dequeue();
         }
      }

      private int getQuery() {
         return this.POOL.isEmpty() ? GL33C.glGenQueries() : this.POOL.dequeueInt();
      }

      @Override
      public void free() {
         super.free0();

         while (!this.POOL.isEmpty()) {
            GL33C.glDeleteQueries(this.POOL.dequeueInt());
         }

         while (!this.INFLIGHT.isEmpty()) {
            GL33C.glDeleteQueries(((GPUTiming.GlTimestampQuerySet.InflightRequest)this.INFLIGHT.dequeue()).queries);
         }
      }

      private record InflightRequest(int[] queries, int[] meta, GPUTiming.TimingDataConsumer callback) {
         private boolean callbackIfReady(IntArrayFIFOQueue queryPool) {
            boolean ready = GL33C.glGetQueryObjecti(this.queries[this.queries.length - 1], 34919) == 1;
            if (!ready) {
               return false;
            }

            long[] results = new long[this.queries.length];

            for (int i = 0; i < this.queries.length; i++) {
               results[i] = GL33C.glGetQueryObjecti64(this.queries[i], 34918);
               queryPool.enqueue(this.queries[i]);
            }

            this.callback.accept(this.meta, results);
            return true;
         }
      }
   }

   public interface TimingDataConsumer {
      void accept(int[] var1, long[] var2);
   }
}
