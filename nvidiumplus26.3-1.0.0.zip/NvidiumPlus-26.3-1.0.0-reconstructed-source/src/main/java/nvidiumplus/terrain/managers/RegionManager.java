package nvidiumplus.terrain.managers;

import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.function.Consumer;
import net.caffeinemc.mods.sodium.client.render.viewport.Viewport;
import net.minecraft.core.SectionPos;
import nvidiumplus.terrain.NvidiumPlus;
import nvidiumplus.terrain.gl.RenderDevice;
import nvidiumplus.terrain.gl.buffers.IDeviceMappedBuffer;
import nvidiumplus.terrain.mixin.sodium.ViewportAccessor;
import nvidiumplus.terrain.util.IdProvider;
import nvidiumplus.terrain.util.UploadingBufferStream;
import org.lwjgl.system.MemoryUtil;

public class RegionManager {
   public static final int MAX_TRANSFORMATION_SIZE_BITS = 10;
   public static final int MAX_TRANSFORMATION_COUNT = 1024;
   private static final boolean SAFETY_CHECKS = NvidiumPlus.IS_DEBUG;
   public static final int META_SIZE = 16;
   private static final int TOTAL_SECTION_META_SIZE = 12288;
   private final IDeviceMappedBuffer regionBuffer;
   private final IDeviceMappedBuffer sectionBuffer;
   private final RenderDevice device;
   private final UploadingBufferStream uploadStream;
   private final Long2IntOpenHashMap regionTransformationIdMapping = new Long2IntOpenHashMap();
   private final Long2IntOpenHashMap regionMap = new Long2IntOpenHashMap();
   private final IdProvider idProvider = new IdProvider();
   private final RegionManager.Region[] regions;
   private final ArrayDeque<RegionManager.Region> dirtyRegions = new ArrayDeque<>();
   private final Consumer<Integer> regionUploadCallback;

   public RegionManager(RenderDevice device, int maxRegions, int maxSections, UploadingBufferStream uploadStream, Consumer<Integer> regionUploaded) {
      this.regionMap.defaultReturnValue(-1);
      this.device = device;
      this.regionBuffer = device.createDeviceOnlyMappedBuffer(maxRegions * 16L);
      this.sectionBuffer = device.createDeviceOnlyMappedBuffer(maxSections * 48L);
      this.uploadStream = uploadStream;
      this.regions = new RegionManager.Region[maxRegions];
      this.regionUploadCallback = regionUploaded;
   }

   public void delete() {
      this.regionBuffer.delete();
      this.sectionBuffer.delete();
   }

   public void commitChanges() {
      if (!this.dirtyRegions.isEmpty()) {
         while (!this.dirtyRegions.isEmpty()) {
            RegionManager.Region region = this.dirtyRegions.pop();
            region.isDirty = false;
            if (region.isRemoved) {
               if (this.regions[region.id] == null) {
                  long regionUpload = this.uploadStream.upload(this.regionBuffer, region.id * 16L, 16L);
                  MemoryUtil.memSet(regionUpload, -1, 16L);
                  long sectionUpload = this.uploadStream.upload(this.sectionBuffer, region.id * 12288L, 12288L);
                  MemoryUtil.memSet(sectionUpload, 0, 12288L);
               }
            } else {
               long regionUpload = this.uploadStream.upload(this.regionBuffer, region.id * 16L, 16L);
               this.setRegionMetadata(regionUpload, region);
               long sectionUpload = this.uploadStream.upload(this.sectionBuffer, region.id * 12288L, 12288L);
               MemoryUtil.memCopy(region.sectionData, sectionUpload, 12288L);
               this.regionUploadCallback.accept(region.id);
            }
         }
      }
   }

   private void setRegionMetadata(long upload, RegionManager.Region region) {
      int minX = Integer.MAX_VALUE;
      int maxX = Integer.MIN_VALUE;
      int minY = Integer.MAX_VALUE;
      int maxY = Integer.MIN_VALUE;
      int minZ = Integer.MAX_VALUE;
      int maxZ = Integer.MIN_VALUE;
      int lastIdx = 0;

      for (int i = 0; i < 256; i++) {
         if (region.pos2id[i] != -1) {
            int x = i & 7;
            int y = i >>> 6;
            int z = i >>> 3 & 7;
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            minZ = Math.min(minZ, z);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
            maxZ = Math.max(maxZ, z);
            lastIdx = i;
         }
      }

      long size = (long)(maxY - minY) << 62 | (long)(maxX - minX) << 59 | (long)(maxZ - minZ) << 56;
      long count = (long)lastIdx << 48;
      long x = (((long)region.rx << 3) + minX & 16777215L) << 24;
      long y = (((long)region.ry << 2) + minY & 16777215L) << 0;
      long z = (((long)region.rz << 3) + minZ & 16777215L) << 40;
      long transformationId = (long)region.transformationId << 30;
      MemoryUtil.memPutLong(upload, size | count | x | y);
      MemoryUtil.memPutLong(upload + 8L, z | transformationId);
   }

   public int getSectionRefId(int section) {
      RegionManager.Region region = this.regions[section >>> 8];
      int id = region.pos2id[section & 0xFF];
      if (id >= 0 && id < 256) {
         return id;
      } else {
         throw new IllegalStateException();
      }
   }

   public long setSectionData(int sectionId) {
      RegionManager.Region region = this.regions[sectionId >>> 8];
      sectionId &= 255;
      sectionId = region.pos2id[sectionId];
      if (sectionId >= 0 && sectionId < 256) {
         this.markDirty(region);
         return region.sectionData + sectionId * 48;
      } else {
         throw new IllegalStateException();
      }
   }

   public void removeSection(int sectionId) {
      RegionManager.Region region = this.regions[sectionId >>> 8];
      sectionId &= 255;
      if (region == null) {
         throw new IllegalStateException("Region is null");
      }

      int sectionPos = sectionId;
      sectionId = region.pos2id[sectionId];
      MemoryUtil.memSet(region.sectionData + sectionId * 48L, 0, 48L);
      region.pos2id[sectionPos] = -1;
      region.id2pos[sectionId] = -1;
      region.verifyIntegrity();
      int endId = --region.count;
      if (endId != sectionId) {
         int oldPos = region.id2pos[endId];
         if (oldPos == -1) {
            throw new IllegalStateException();
         }

         MemoryUtil.memCopy(region.sectionData + endId * 48L, region.sectionData + sectionId * 48L, 48L);
         MemoryUtil.memSet(region.sectionData + endId * 48L, 0, 48L);
         if (region.id2pos[endId] == -1 || region.pos2id[oldPos] == -1) {
            throw new IllegalStateException();
         }

         region.id2pos[endId] = -1;
         region.pos2id[oldPos] = -1;
         region.id2pos[sectionId] = oldPos;
         region.pos2id[oldPos] = sectionId;
         long ptr = region.sectionData + sectionId * 48L + 4L;
         int data = MemoryUtil.memGetInt(ptr);
         data &= -66846721;
         data |= sectionId << 18;
         MemoryUtil.memPutInt(ptr, data);
         region.verifyIntegrity();
      }

      if (region.count == 0) {
         region.isRemoved = true;
         region.delete();
         this.regions[region.id] = null;
         this.idProvider.release(region.id);
         this.regionMap.remove(region.key);
      }

      this.markDirty(region);
      region.verifyIntegrity();
   }

   public int allocateSection(int sectionX, int sectionY, int sectionZ) {
      long regionKey = SectionPos.asLong(sectionX >> 3, sectionY >> 2, sectionZ >> 3);
      int regionId = this.regionMap.computeIfAbsent(regionKey, k -> this.idProvider.provide());
      if (this.regions[regionId] == null) {
         this.regions[regionId] = new RegionManager.Region(regionId, sectionX >> 3, sectionY >> 2, sectionZ >> 3);
         this.regions[regionId].transformationId = this.regionTransformationIdMapping.get(regionKey);
      }

      RegionManager.Region region = this.regions[regionId];
      int sectionKey = (sectionY & 3) << 6 | sectionX & 7 | (sectionZ & 7) << 3;
      int sectionId = region.count++;
      if (region.pos2id[sectionKey] == -1 && region.id2pos[sectionId] == -1) {
         region.pos2id[sectionKey] = sectionId;
         region.id2pos[sectionId] = sectionKey;
         this.markDirty(region);
         region.verifyIntegrity();
         return sectionKey | regionId << 8;
      } else {
         throw new IllegalStateException("Section id not free!");
      }
   }

   private void markDirty(RegionManager.Region region) {
      if (!region.isDirty) {
         region.isDirty = true;
         this.dirtyRegions.add(region);
      }
   }

   public int regionCount() {
      return this.regionMap.size();
   }

   public int maxRegions() {
      return this.regions.length;
   }

   public int maxRegionIndex() {
      return this.idProvider.maxIndex();
   }

   public boolean regionExists(int regionId) {
      return this.regions[regionId] != null;
   }

   public boolean isRegionVisible(Viewport viewport, int regionId) {
      RegionManager.Region region = this.regions[regionId];
      if (region == null) {
         return false;
      }

      ViewportAccessor vp = (ViewportAccessor)viewport;
      return vp.nvidiumplus$getFrustum()
         .testAab(
            (region.rx << 7) - vp.nvidiumplus$getTransform().intX - vp.nvidiumplus$getTransform().fracX,
            (region.ry << 6) - vp.nvidiumplus$getTransform().intY - vp.nvidiumplus$getTransform().fracY,
            (region.rz << 7) - vp.nvidiumplus$getTransform().intZ - vp.nvidiumplus$getTransform().fracZ,
            (region.rx + 1 << 7) - vp.nvidiumplus$getTransform().intX - vp.nvidiumplus$getTransform().fracX,
            (region.ry + 1 << 6) - vp.nvidiumplus$getTransform().intY - vp.nvidiumplus$getTransform().fracY,
            (region.rz + 1 << 7) - vp.nvidiumplus$getTransform().intZ - vp.nvidiumplus$getTransform().fracZ
         );
   }

   public int distance(int regionId, int camChunkX, int camChunkY, int camChunkZ) {
      RegionManager.Region region = this.regions[regionId];
      return Math.abs((region.rx << 3) + 4 - camChunkX)
            + Math.abs((region.ry << 2) + 2 - camChunkY)
            + Math.abs((region.rz << 3) + 4 - camChunkZ)
            + Math.abs((region.rx << 3) + 3 - camChunkX)
            + Math.abs((region.ry << 2) + 1 - camChunkY)
            + Math.abs((region.rz << 3) + 3 - camChunkZ)
         >> 1;
   }

   public boolean withinSquare(int dist, int regionId, int camChunkX, int camChunkY, int camChunkZ) {
      RegionManager.Region region = this.regions[regionId];
      return Math.abs((region.rx << 3) + 4 - camChunkX) <= dist
         && Math.abs((region.ry << 2) + 2 - camChunkY) <= dist
         && Math.abs((region.rz << 3) + 4 - camChunkZ) <= dist;
   }

   public boolean isRegionInACameraAxis(int regionId, double camX, double camY, double camZ) {
      RegionManager.Region region = this.regions[regionId];
      return region.rx << 7 <= camX && camX <= region.rx + 1 << 7
         || region.ry << 6 <= camY && camY <= region.ry + 1 << 6
         || region.rz << 7 <= camZ && camZ <= region.rz + 1 << 7;
   }

   public long getRegionBufferAddress() {
      return this.regionBuffer.getDeviceAddress();
   }

   public long getSectionBufferAddress() {
      return this.sectionBuffer.getDeviceAddress();
   }

   public long regionIdToKey(int regionId) {
      if (this.regions[regionId] == null) {
         throw new IllegalStateException();
      } else {
         return this.regions[regionId].key;
      }
   }

   public void setRegionTransformId(int x, int y, int z, int id) {
      if (id >= 0 && id < 1024) {
         long regionKey = SectionPos.asLong(x, y, z);
         int oldId = this.regionTransformationIdMapping.put(regionKey, id);
         if (oldId != id) {
            int regionId = this.regionMap.get(regionKey);
            if (regionId == -1) {
               return;
            }

            RegionManager.Region region = this.regions[regionId];
            region.transformationId = id;
            this.markDirty(region);
         }
      } else {
         throw new IllegalArgumentException("Transformation id out of bounds");
      }
   }

   public void destroy() {
      this.sectionBuffer.delete();
      this.regionBuffer.delete();
   }

   private static class Region {
      private final int rx;
      private final int ry;
      private final int rz;
      private final long key;
      private final int id;
      public int transformationId = 0;
      private int count;
      private final int[] pos2id = new int[256];
      private final int[] id2pos = new int[256];
      private boolean isDirty;
      private boolean isRemoved;
      private final long sectionData = MemoryUtil.nmemAlloc(12288L);

      private Region(int id, int rx, int ry, int rz) {
         Arrays.fill(this.pos2id, -1);
         Arrays.fill(this.id2pos, -1);
         MemoryUtil.memSet(this.sectionData, 0, 12288L);

         for (int i = 0; i < 256; i++) {
            MemoryUtil.memSet(this.sectionData + 48 * i + 32L, -1, 16L);
         }

         this.key = SectionPos.asLong(rx, ry, rz);
         this.id = id;
         this.rx = rx;
         this.ry = ry;
         this.rz = rz;
      }

      public void delete() {
         MemoryUtil.nmemFree(this.sectionData);
      }

      public void verifyIntegrity() {
         if (RegionManager.SAFETY_CHECKS) {
            for (int i = 0; i < 256; i++) {
               if (this.id2pos[i] != -1 && this.pos2id[this.id2pos[i]] != i) {
                  throw new IllegalStateException();
               }

               if (this.pos2id[i] != -1 && this.id2pos[this.pos2id[i]] != i) {
                  throw new IllegalStateException();
               }
            }
         }
      }
   }
}
