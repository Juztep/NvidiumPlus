package nvidiumplus.terrain.managers;

import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import java.nio.IntBuffer;
import net.caffeinemc.mods.sodium.client.model.quad.properties.ModelQuadFacing;
import net.caffeinemc.mods.sodium.client.render.SodiumWorldRenderer;
import net.caffeinemc.mods.sodium.client.render.chunk.RenderSection;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkBuildOutput;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkSortOutput;
import net.caffeinemc.mods.sodium.client.render.chunk.data.BuiltSectionMeshParts;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.DefaultTerrainRenderPasses;
import net.caffeinemc.mods.sodium.client.util.NativeBuffer;
import net.minecraft.core.SectionPos;
import nvidiumplus.terrain.NvidiumPlus;
import nvidiumplus.terrain.NvidiumPlusWorldRenderer;
import nvidiumplus.terrain.config.TranslucencySortingLevel;
import nvidiumplus.terrain.gl.RenderDevice;
import nvidiumplus.terrain.sodiumCompat.INvidiumPlusWorldRendererGetter;
import nvidiumplus.terrain.sodiumCompat.IRepackagedResult;
import nvidiumplus.terrain.sodiumCompat.RepackagedSectionOutput;
import nvidiumplus.terrain.util.BufferArena;
import nvidiumplus.terrain.util.UploadingBufferStream;
import org.joml.Vector3i;
import org.joml.Vector4i;
import org.lwjgl.system.MemoryUtil;

public class SectionManager {
   public static final int SECTION_SIZE = 48;
   private final RegionManager regionManager;
   private final Long2IntOpenHashMap section2id = new Long2IntOpenHashMap();
   private final Long2IntOpenHashMap section2terrain = new Long2IntOpenHashMap();
   private final Long2IntOpenHashMap section2index = new Long2IntOpenHashMap();
   private final Long2IntOpenHashMap section2idxDataCount = new Long2IntOpenHashMap();
   private final int quadVertexSize;
   public final UploadingBufferStream uploadStream;
   public final BufferArena terrainAreana;
   private final Long2ObjectOpenHashMap<int[]> translucencyQuadCounts = new Long2ObjectOpenHashMap();
   private final RenderDevice device;
   private final LongSet hiddenSectionKeys = new LongOpenHashSet();

   public SectionManager(
      RenderDevice device, long fallbackMemorySize, UploadingBufferStream uploadStream, int quadVertexSize, NvidiumPlusWorldRenderer worldRenderer
   ) {
      int maxRegions = 50000;
      this.device = device;
      this.uploadStream = uploadStream;
      this.quadVertexSize = quadVertexSize;
      this.terrainAreana = new BufferArena(device, fallbackMemorySize, quadVertexSize);
      this.regionManager = new RegionManager(device, maxRegions, maxRegions * 200, uploadStream, worldRenderer::enqueueRegionSort);
      this.section2id.defaultReturnValue(-1);
      this.section2terrain.defaultReturnValue(-1);
      this.section2index.defaultReturnValue(-1);
      this.translucencyQuadCounts.defaultReturnValue(null);
   }

   public void uploadIndexBuffer(IntBuffer indexBuffer, int[] quadCountData, long upload) {
      int quadOffset = 0;

      for (ModelQuadFacing facing : ModelQuadFacing.values()) {
         for (int i = 0; i < quadCountData[facing.ordinal()]; i++) {
            int idx = indexBuffer.get((quadOffset + i) * 6) / 4 + quadOffset;
            MemoryUtil.memPutInt(upload + (quadOffset + i) * 4L, idx);
         }

         quadOffset += quadCountData[facing.ordinal()];
      }
   }

   public void uploadChunkSort(ChunkSortOutput sortOutput) {
      if (sortOutput.getSorter() != null) {
         NativeBuffer indexBuffer = sortOutput.getSorter().getIndexBuffer();
         if (indexBuffer != null) {
            RenderSection section = sortOutput.section;
            long sectionKey = SectionPos.asLong(section.getChunkX(), section.getChunkY(), section.getChunkZ());
            int[] quadCountData = (int[])this.translucencyQuadCounts.get(sectionKey);
            if (quadCountData != null) {
               if (quadCountData[7] * 6 * 4 != indexBuffer.getLength()) {
                  NvidiumPlus.LOGGER
                     .error(
                        "ChunkSortOutput integrity check failed at {} {} {}, aborting (totalQuads={};indexBuffer={})",
                        new Object[]{section.getChunkX(), section.getChunkY(), section.getChunkZ(), quadCountData[7], indexBuffer.getLength() / 24}
                     );
               } else {
                  int idxBufferLength = (indexBuffer.getLength() / 6 + (this.quadVertexSize - 1)) / this.quadVertexSize;
                  IntBuffer idxBuffer = indexBuffer.getDirectBuffer().asIntBuffer();
                  int indexDataAddress = this.section2index.get(sectionKey);
                  if (indexDataAddress != -1 && !this.terrainAreana.canReuse(indexDataAddress, idxBufferLength)) {
                     this.section2index.remove(sectionKey);
                     this.section2idxDataCount.remove(sectionKey);
                     this.terrainAreana.free(indexDataAddress);
                     indexDataAddress = -1;
                  }

                  if (indexDataAddress == -1) {
                     indexDataAddress = this.terrainAreana.allocQuads(idxBufferLength);
                  }

                  this.section2index.put(sectionKey, indexDataAddress);
                  this.section2idxDataCount.put(sectionKey, indexBuffer.getLength() / 24);
                  long upload = this.terrainAreana.upload(this.uploadStream, indexDataAddress);
                  this.uploadIndexBuffer(idxBuffer, quadCountData, upload);
                  idxBufferLength = this.section2id.get(sectionKey);
                  if (idxBufferLength == -1) {
                     NvidiumPlus.LOGGER.error("Got translucency data but no section found for {}", sectionKey);
                  } else {
                     long metadata = this.regionManager.setSectionData(idxBufferLength);
                     long var14 = metadata + 36L;
                     MemoryUtil.memPutInt(var14, indexDataAddress * this.quadVertexSize);
                  }
               }
            }
         }
      }
   }

   public void uploadChunkBuildResult(ChunkBuildOutput result) {
      RepackagedSectionOutput output = ((IRepackagedResult)result).getOutput();
      RenderSection section = result.section;
      long sectionKey = SectionPos.asLong(section.getChunkX(), section.getChunkY(), section.getChunkZ());
      if (output != null && output.quads() != 0) {
         int translucentQuadCount = 0;
         BuiltSectionMeshParts translucentData = (BuiltSectionMeshParts)result.meshes.get(DefaultTerrainRenderPasses.TRANSLUCENT);
         if (translucentData != null) {
            int[] quadOffsets = new int[8];

            for (int i = 0; i < ModelQuadFacing.COUNT; i++) {
               int count = translucentData.getVertexSegments()[i * 2];
               int facing = translucentData.getVertexSegments()[i * 2 + 1];
               if (count > 0) {
                  quadOffsets[facing] = count / 4;
                  quadOffsets[7] += count / 4;
               }
            }

            this.translucencyQuadCounts.put(sectionKey, quadOffsets);
            translucentQuadCount = quadOffsets[7];
         }

         int terrainAddress = this.section2terrain.get(sectionKey);
         if (terrainAddress != -1 && !this.terrainAreana.canReuse(terrainAddress, output.quads())) {
            this.section2terrain.remove(sectionKey);
            this.terrainAreana.free(terrainAddress);
            terrainAddress = -1;
         }

         if (terrainAddress == -1) {
            terrainAddress = this.terrainAreana.allocQuads(output.quads());
         }

         if (terrainAddress == -1L) {
            NvidiumPlus.LOGGER
               .error(
                  "Terrain arena critically out of memory, expect issues with chunks!!  quad_used: "
                     + this.terrainAreana.getUsedMB()
                     + " physically used: "
                     + this.terrainAreana.getMemoryUsed()
                     + " limit: "
                     + ((INvidiumPlusWorldRendererGetter)SodiumWorldRenderer.instance()).getRenderer().getMaxGeometryMemory()
               );
            this.deleteSection(sectionKey);
         } else {
            this.section2terrain.put(sectionKey, terrainAddress);
            long geometryUpload = this.terrainAreana.upload(this.uploadStream, terrainAddress);
            MemoryUtil.memCopy(MemoryUtil.memAddress(output.geometry().getDirectBuffer()), geometryUpload, output.geometry().getLength());
            int sectionIdx = this.section2id
               .computeIfAbsent(sectionKey, key -> this.regionManager.allocateSection(SectionPos.x(key), SectionPos.y(key), SectionPos.z(key)));
            long metadata = this.regionManager.setSectionData(sectionIdx);
            boolean hideSectionBitSet = this.hiddenSectionKeys.contains(sectionKey);
            Vector3i min = output.min();
            Vector3i size = output.size();
            int px = section.getChunkX() << 8 | size.x << 4 | min.x;
            int py = (section.getChunkY() & 511) << 8
               | size.y << 4
               | min.y
               | (hideSectionBitSet ? 131072 : 0)
               | this.regionManager.getSectionRefId(sectionIdx) << 18;
            int pz = section.getChunkZ() << 8 | size.z << 4 | min.z;
            int pw = terrainAddress;
            new Vector4i(px, py, pz, pw).getToAddress(metadata);
            metadata += 16L;

            for (int i = 0; i < 4; i++) {
               int geo = output.offsets()[i * 2] & 65535 | (output.offsets()[i * 2 + 1] & 65535) << 16;
               MemoryUtil.memPutInt(metadata, geo);
               metadata += 4L;
            }

            MemoryUtil.memPutInt(metadata, output.offsets()[7]);
            metadata += 4L;
            if (NvidiumPlus.config.translucency_sorting_level == TranslucencySortingLevel.SODIUM) {
               if (result.containsNewIndexData()) {
                  MemoryUtil.memPutInt(metadata, -1);
                  int idxIndex = this.section2index.remove(sectionKey);
                  if (idxIndex != -1) {
                     this.terrainAreana.free(idxIndex);
                  }
               } else {
                  int trIdx = this.section2index.get(sectionKey);
                  if (this.section2idxDataCount.get(sectionKey) != translucentQuadCount) {
                     MemoryUtil.memPutInt(metadata, -1);
                     int idxIndex = this.section2index.remove(sectionKey);
                     if (idxIndex != -1) {
                        this.terrainAreana.free(idxIndex);
                     }
                  } else {
                     MemoryUtil.memPutInt(metadata, trIdx != -1 ? trIdx * this.quadVertexSize : -1);
                  }
               }
            }
         }
      } else {
         this.deleteSection(sectionKey);
      }
   }

   public void setHideBit(int x, int y, int z, boolean hide) {
      long sectionKey = SectionPos.asLong(x, y, z);
      if (hide) {
         if (!this.hiddenSectionKeys.add(sectionKey)) {
            return;
         }
      } else if (!this.hiddenSectionKeys.remove(sectionKey)) {
         return;
      }

      int sectionId = this.section2id.get(sectionKey);
      if (sectionId != -1) {
         long metadata = this.regionManager.setSectionData(sectionId);
         MemoryUtil.memPutInt(metadata + 4L, MemoryUtil.memGetInt(metadata + 4L) & -131073 | (hide ? 1 : 0) << 17);
      }
   }

   public void deleteSection(RenderSection section) {
      this.deleteSection(SectionPos.asLong(section.getChunkX(), section.getChunkY(), section.getChunkZ()));
   }

   private void deleteSection(long sectionKey) {
      int sectionIdx = this.section2id.remove(sectionKey);
      if (sectionIdx != -1) {
         int terrainIndex = this.section2terrain.remove(sectionKey);
         if (terrainIndex != -1) {
            this.terrainAreana.free(terrainIndex);
         }

         this.section2idxDataCount.remove(sectionKey);
         int indexIdx = this.section2index.remove(sectionKey);
         if (indexIdx != -1) {
            this.terrainAreana.free(indexIdx);
         }

         this.translucencyQuadCounts.remove(sectionKey);
         this.regionManager.removeSection(sectionIdx);
      }
   }

   public void destroy() {
      this.regionManager.destroy();
      this.terrainAreana.delete();
   }

   public void commitChanges() {
      this.regionManager.commitChanges();
   }

   public RegionManager getRegionManager() {
      return this.regionManager;
   }

   public void removeRegionById(int regionId) {
      if (this.regionManager.regionExists(regionId)) {
         long rk = this.regionManager.regionIdToKey(regionId);
         int X = SectionPos.x(rk) << 3;
         int Y = SectionPos.y(rk) << 2;
         int Z = SectionPos.z(rk) << 3;

         for (int x = X; x < X + 8; x++) {
            for (int y = Y; y < Y + 4; y++) {
               for (int z = Z; z < Z + 8; z++) {
                  this.deleteSection(SectionPos.asLong(x, y, z));
               }
            }
         }
      }
   }
}
