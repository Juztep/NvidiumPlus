package nvidiumplus.terrain.managers;

import net.minecraft.resources.Identifier;
import nvidiumplus.terrain.gl.buffers.Buffer;
import nvidiumplus.terrain.gl.shader.Shader;
import nvidiumplus.terrain.gl.shader.ShaderType;
import nvidiumplus.terrain.sodiumCompat.ShaderLoader;
import nvidiumplus.terrain.util.DownloadTaskStream;
import org.lwjgl.opengl.GL42;
import org.lwjgl.opengl.NVMeshShader;
import org.lwjgl.system.MemoryUtil;

public class RegionVisibilityTracker {
   private final Shader shader = Shader.make()
      .addSource(ShaderType.MESH, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "occlusion/queries/region/mesh.glsl")))
      .addSource(ShaderType.FRAGMENT, ShaderLoader.parse(Identifier.fromNamespaceAndPath("nvidiumplus", "occlusion/queries/region/fragment.frag")))
      .compile();
   private final DownloadTaskStream downStream;
   private final int[] frustum;
   private final int[] visible;
   private int fram = 0;

   public RegionVisibilityTracker(DownloadTaskStream downStream, int maxRegions) {
      this.downStream = downStream;
      this.visible = new int[maxRegions];
      this.frustum = new int[maxRegions];

      for (int i = 0; i < maxRegions; i++) {
         this.frustum[i] = 0;
         this.visible[i] = 0;
      }
   }

   public void computeVisibility(int regionCount, Buffer regionVisibilityBuffer, short[] regionMapping) {
      this.shader.bind();
      this.fram++;
      NVMeshShader.glDrawMeshTasksNV(0, (regionCount + 3) / 4);
      GL42.glMemoryBarrier(8192);
      this.downStream.download(regionVisibilityBuffer, 0L, regionCount, ptr -> {
         for (int i = 0; i < regionMapping.length; i++) {
            if (MemoryUtil.memGetByte(ptr + i) == 1) {
               this.frustum[regionMapping[i]]++;
               this.visible[regionMapping[i]] = this.fram;
            } else {
               this.frustum[regionMapping[i]]++;
            }
         }
      });
   }

   public void delete() {
      this.shader.delete();
   }

   public void resetRegion(int id) {
      this.frustum[id] = 0;
      this.visible[id] = 0;
   }

   public int findMostLikelyLeastSeenRegion(int maxIndex) {
      int maxRank = Integer.MIN_VALUE;
      int id = -1;

      for (int i = 0; i < maxIndex; i++) {
         if (this.frustum[i] > 200) {
            int rank = -this.visible[i];
            if (maxRank < rank) {
               maxRank = rank;
               id = i;
            }
         }
      }

      return id;
   }
}
