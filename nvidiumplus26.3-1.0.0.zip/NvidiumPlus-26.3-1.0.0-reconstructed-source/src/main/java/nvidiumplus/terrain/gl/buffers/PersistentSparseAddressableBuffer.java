package nvidiumplus.terrain.gl.buffers;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import nvidiumplus.terrain.NvidiumPlus;
import nvidiumplus.terrain.gl.GlObject;
import org.lwjgl.opengl.ARBDirectStateAccess;
import org.lwjgl.opengl.ARBSparseBuffer;
import org.lwjgl.opengl.GL15C;
import org.lwjgl.opengl.GL21;
import org.lwjgl.opengl.NVShaderBufferLoad;

public class PersistentSparseAddressableBuffer extends GlObject implements IDeviceMappedBuffer {
   public final long addr;
   public final long size;
   public static final long PAGE_SIZE = 1048576L;
   private final Int2IntOpenHashMap allocationCount = new Int2IntOpenHashMap();

   public static long alignUp(long number, long alignment) {
      long delta = number % alignment;
      return delta == 0L ? number : number + (alignment - delta);
   }

   public PersistentSparseAddressableBuffer(long size) {
      super(ARBDirectStateAccess.glCreateBuffers());
      if (!NvidiumPlus.SUPPORTS_PERSISTENT_SPARSE_ADDRESSABLE_BUFFER) {
         throw new IllegalStateException();
      }

      this.size = alignUp(size, 1048576L);
      ARBDirectStateAccess.glNamedBufferStorage(this.id, size, 1024);
      long[] holder = new long[1];
      NVShaderBufferLoad.glMakeNamedBufferResidentNV(this.id, 35002);
      NVShaderBufferLoad.glGetNamedBufferParameterui64vNV(this.id, 36637, holder);
      this.addr = holder[0];
      if (this.addr == 0L) {
         throw new IllegalStateException();
      }
   }

   private static void doCommit(int buffer, long offset, long size, boolean commit) {
      GL21.glBindBuffer(34962, buffer);
      ARBSparseBuffer.glBufferPageCommitmentARB(34962, offset, size, commit);
   }

   private void allocatePages(int page, int pageCount) {
      doCommit(this.id, 1048576L * page, 1048576L * pageCount, true);

      for (int i = 0; i < pageCount; i++) {
         this.allocationCount.addTo(i + page, 1);
      }
   }

   private void deallocatePages(int page, int pageCount) {
      for (int i = 0; i < pageCount; i++) {
         int newCount = this.allocationCount.get(i + page) - 1;
         if (newCount != 0) {
            this.allocationCount.put(i + page, newCount);
         } else {
            this.allocationCount.remove(i + page);
            doCommit(this.id, 1048576L * (page + i), 1048576L, false);
         }
      }
   }

   public int getPagesCommitted() {
      return this.allocationCount.size();
   }

   public void ensureAllocated(long addr, long size) {
      int pstart = (int)(addr / 1048576L);
      int pend = (int)((addr + size + 1048576L - 1L) / 1048576L);
      this.allocatePages(pstart, pend - pstart);
   }

   public void deallocate(long addr, long size) {
      int pstart = (int)(addr / 1048576L);
      int pend = (int)((addr + size + 1048576L - 1L) / 1048576L);
      this.deallocatePages(pstart, pend - pstart);
   }

   @Override
   public long getDeviceAddress() {
      return this.addr;
   }

   @Override
   public void delete() {
      super.free0();
      NVShaderBufferLoad.glMakeNamedBufferNonResidentNV(this.id);
      GL15C.glDeleteBuffers(this.id);
   }

   @Override
   public void free() {
      this.delete();
   }

   @Override
   public long getSize() {
      return this.size;
   }
}
