package nvidiumplus.terrain.gl.buffers;

import nvidiumplus.terrain.gl.IResource;

public interface Buffer extends IResource {
   int getId();

   long getSize();
}
