package nvidiumplus.terrain.gl;

import nvidiumplus.terrain.gl.buffers.Buffer;
import nvidiumplus.terrain.gl.buffers.DeviceOnlyMappedBuffer;
import nvidiumplus.terrain.gl.buffers.IClientMappedBuffer;
import nvidiumplus.terrain.gl.buffers.IDeviceMappedBuffer;
import nvidiumplus.terrain.gl.buffers.PersistentClientMappedBuffer;
import nvidiumplus.terrain.gl.buffers.PersistentSparseAddressableBuffer;
import org.lwjgl.opengl.ARBDirectStateAccess;
import org.lwjgl.opengl.GL42C;

public class RenderDevice {
   public PersistentClientMappedBuffer createClientMappedBuffer(long size) {
      return new PersistentClientMappedBuffer(size);
   }

   public void flush(IClientMappedBuffer buffer, long offset, int size) {
      int id = ((GlObject)buffer).getId();
      ARBDirectStateAccess.glFlushMappedNamedBufferRange(id, offset, size);
   }

   public void barrier(int flags) {
      GL42C.glMemoryBarrier(flags);
   }

   public void copyBuffer(Buffer src, Buffer dst, long srcOffset, long dstOffset, long size) {
      ARBDirectStateAccess.glCopyNamedBufferSubData(((GlObject)src).getId(), ((GlObject)dst).getId(), srcOffset, dstOffset, size);
   }

   public PersistentSparseAddressableBuffer createSparseBuffer(long totalSize) {
      return new PersistentSparseAddressableBuffer(totalSize);
   }

   public IDeviceMappedBuffer createDeviceOnlyMappedBuffer(long size) {
      return new DeviceOnlyMappedBuffer(size);
   }
}
