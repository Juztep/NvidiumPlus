package nvidiumplus.terrain.gl;

public interface IResource {
   void delete();
}
