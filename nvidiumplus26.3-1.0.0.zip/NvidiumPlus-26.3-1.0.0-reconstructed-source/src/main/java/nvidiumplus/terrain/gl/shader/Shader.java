package nvidiumplus.terrain.gl.shader;

import java.util.HashMap;
import java.util.Map;
import nvidiumplus.terrain.gl.GlObject;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL20C;

public class Shader extends GlObject {
   private Shader(int program) {
      super(program);
   }

   public static Shader.Builder make(IShaderProcessor processor) {
      return new Shader.Builder(processor);
   }

   public static Shader.Builder make() {
      return new Shader.Builder((aa, source) -> source);
   }

   public void bind() {
      GL20.glUseProgram(this.id);
   }

   @Override
   public void delete() {
      super.free0();
      GL20.glDeleteProgram(this.id);
   }

   @Override
   public void free() {
      this.delete();
   }

   public static class Builder {
      private final Map<ShaderType, String> sources = new HashMap<>();
      private final IShaderProcessor processor;

      private Builder(IShaderProcessor processor) {
         this.processor = processor;
      }

      public Shader.Builder addSource(ShaderType type, String source) {
         this.sources.put(type, this.processor.process(type, source));
         return this;
      }

      public Shader compile() {
         int program = GL20C.glCreateProgram();
         int[] shaders = this.sources.entrySet().stream().mapToInt(a -> createShader(a.getKey(), a.getValue())).toArray();

         for (int i : shaders) {
            GL20C.glAttachShader(program, i);
         }

         GL20C.glLinkProgram(program);

         for (int i : shaders) {
            GL20C.glDetachShader(program, i);
            GL20C.glDeleteShader(i);
         }

         printProgramLinkLog(program);
         verifyProgramLinked(program);
         return new Shader(program);
      }

      private static void printProgramLinkLog(int program) {
         String log = GL20C.glGetProgramInfoLog(program);
         if (!log.isEmpty()) {
            System.err.println(log);
         }
      }

      private static void verifyProgramLinked(int program) {
         int result = GL20C.glGetProgrami(program, 35714);
         if (result != 1) {
            throw new RuntimeException("Shader program linking failed, see log for details");
         }
      }

      private static int createShader(ShaderType type, String src) {
         int shader = GL20C.glCreateShader(type.gl);
         GL20C.glShaderSource(shader, src);
         GL20C.glCompileShader(shader);
         String log = GL20C.glGetShaderInfoLog(shader);
         if (!log.isEmpty()) {
            System.err.println(log);
         }

         int result = GL20C.glGetShaderi(shader, 35713);
         if (result != 1) {
            GL20C.glDeleteShader(shader);
            throw new RuntimeException("Shader compilation failed, see log for details");
         } else {
            return shader;
         }
      }
   }
}
