package nvidiumplus.terrain.gl.buffers;

import nvidiumplus.terrain.gl.GlObject;
import org.lwjgl.opengl.ARBDirectStateAccess;
import org.lwjgl.opengl.GL15C;
import org.lwjgl.opengl.NVShaderBufferLoad;

public class DeviceOnlyMappedBuffer extends GlObject implements IDeviceMappedBuffer {
   public final long size;
   public final long addr;

   public DeviceOnlyMappedBuffer(long size) {
      super(ARBDirectStateAccess.glCreateBuffers());
      this.size = size;
      ARBDirectStateAccess.glNamedBufferStorage(this.id, size, 0);
      long[] holder = new long[1];
      NVShaderBufferLoad.glGetNamedBufferParameterui64vNV(this.id, 36637, holder);
      NVShaderBufferLoad.glMakeNamedBufferResidentNV(this.id, 35002);
      this.addr = holder[0];
      if (this.addr == 0L) {
         throw new IllegalStateException();
      }
   }

   @Override
   public void delete() {
      super.free0();
      NVShaderBufferLoad.glMakeNamedBufferNonResidentNV(this.id);
      GL15C.glDeleteBuffers(this.id);
   }

   @Override
   public long getDeviceAddress() {
      return this.addr;
   }

   @Override
   public void free() {
      this.delete();
   }

   @Override
   public long getSize() {
      return this.size;
   }
}
