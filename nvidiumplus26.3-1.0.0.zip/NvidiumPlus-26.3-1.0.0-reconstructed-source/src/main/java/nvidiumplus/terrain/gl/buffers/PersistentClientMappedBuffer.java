package nvidiumplus.terrain.gl.buffers;

import nvidiumplus.terrain.gl.GlObject;
import org.lwjgl.opengl.ARBDirectStateAccess;
import org.lwjgl.opengl.GL30C;

public class PersistentClientMappedBuffer extends GlObject implements IClientMappedBuffer {
   public final long addr;
   public final long size;

   public PersistentClientMappedBuffer(long size) {
      super(ARBDirectStateAccess.glCreateBuffers());
      this.size = size;
      ARBDirectStateAccess.glNamedBufferStorage(this.id, size, 578);
      this.addr = ARBDirectStateAccess.nglMapNamedBufferRange(this.id, 0L, size, 114);
   }

   @Override
   public long clientAddress() {
      return this.addr;
   }

   @Override
   public void delete() {
      super.free0();
      ARBDirectStateAccess.glUnmapNamedBuffer(this.id);
      GL30C.glDeleteBuffers(this.id);
   }

   @Override
   public void free() {
      this.delete();
   }

   @Override
   public long getSize() {
      return this.size;
   }
}
