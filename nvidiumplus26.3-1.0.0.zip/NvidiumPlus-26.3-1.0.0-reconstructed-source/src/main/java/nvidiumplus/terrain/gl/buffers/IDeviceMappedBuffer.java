package nvidiumplus.terrain.gl.buffers;

public interface IDeviceMappedBuffer extends Buffer {
   long getDeviceAddress();
}
