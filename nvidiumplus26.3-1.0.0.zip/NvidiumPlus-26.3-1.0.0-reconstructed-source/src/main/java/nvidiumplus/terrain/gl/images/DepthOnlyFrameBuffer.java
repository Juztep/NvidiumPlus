package nvidiumplus.terrain.gl.images;

import com.mojang.renderpearl.backend.opengl.GlStateManager;
import org.lwjgl.opengl.ARBDirectStateAccess;
import org.lwjgl.opengl.GL11C;
import org.lwjgl.opengl.GL30C;

public class DepthOnlyFrameBuffer {
   public final int width;
   public final int height;
   private final int fid;
   private final int did;

   public DepthOnlyFrameBuffer(int width, int height) {
      this.width = width;
      this.height = height;
      this.fid = ARBDirectStateAccess.glCreateFramebuffers();
      this.did = ARBDirectStateAccess.glCreateTextures(3553);
      ARBDirectStateAccess.glTextureStorage2D(this.did, 1, 36012, width, height);
      ARBDirectStateAccess.glNamedFramebufferTexture(this.fid, 36096, this.did, 0);
      if (ARBDirectStateAccess.glCheckNamedFramebufferStatus(this.fid, 36160) != 36053) {
         throw new IllegalStateException("ERROR: " + GL30C.glCheckFramebufferStatus(36160));
      }
   }

   public int getDepthBuffer() {
      return this.did;
   }

   public void bind(boolean setViewport) {
      GlStateManager._glBindFramebuffer(36160, this.fid);
      if (setViewport) {
         GlStateManager._viewport(0, 0, this.width, this.height);
      }
   }

   public void delete() {
      GL30C.glDeleteFramebuffers(this.fid);
      GL11C.glDeleteTextures(this.did);
   }
}
