package nvidiumplus.terrain.gl;

import org.lwjgl.opengl.GL32;

public class GlFence extends TrackedObject {
   private final long fence = GL32.glFenceSync(37143, 0);
   private boolean signaled;

   public boolean signaled() {
      this.assertNotFreed();
      if (!this.signaled) {
         int ret = GL32.glClientWaitSync(this.fence, 0, 0L);
         if (ret != 37146 && ret != 37148) {
            if (ret != 37147) {
               throw new IllegalStateException("Poll for fence failed, ret: " + ret + " glError: " + GL32.glGetError());
            }
         } else {
            this.signaled = true;
         }
      }

      return this.signaled;
   }

   @Override
   public void free() {
      super.free0();
      GL32.glDeleteSync(this.fence);
   }
}
