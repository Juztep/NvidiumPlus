package nvidiumplus.terrain.gl.shader;

public interface IShaderProcessor {
   String process(ShaderType var1, String var2);
}
