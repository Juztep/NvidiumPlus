package nvidiumplus.terrain.gl.buffers;

public interface IClientMappedBuffer extends Buffer {
   long clientAddress();
}
