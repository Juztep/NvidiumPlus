package nvidiumplus.terrain;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.util.Util;
import net.minecraft.util.Util.OS;
import nvidiumplus.terrain.config.NvidiumPlusConfig;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GLCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NvidiumPlus {
   public static final String MOD_VERSION;
   public static final Logger LOGGER = LoggerFactory.getLogger("NvidiumPlus");
   public static boolean IS_COMPATIBLE = false;
   public static boolean IS_ENABLED = false;
   public static boolean IS_DEBUG = System.getProperty("nvidiumplus.isDebug", "false").equals("TRUE");
   public static boolean SUPPORTS_PERSISTENT_SPARSE_ADDRESSABLE_BUFFER = true;
   public static boolean FORCE_DISABLE = false;
   public static NvidiumPlusConfig config = NvidiumPlusConfig.loadOrCreate();

   public static void checkSystemIsCapable() {
      GLCapabilities cap = GL.getCapabilities();
      boolean supported = cap.GL_NV_mesh_shader
         && cap.GL_NV_uniform_buffer_unified_memory
         && cap.GL_NV_vertex_buffer_unified_memory
         && cap.GL_NV_representative_fragment_test
         && cap.GL_ARB_sparse_buffer
         && cap.GL_NV_bindless_multi_draw_indirect;
      IS_COMPATIBLE = supported;
      if (IS_COMPATIBLE) {
         LOGGER.info("All capabilities met");
      } else {
         LOGGER.warn("Not all requirements met, disabling nvidiumplus");
      }

      if (IS_COMPATIBLE && Util.getPlatform() == OS.LINUX) {
         LOGGER.warn("Linux currently uses fallback terrain buffer due to driver inconsistencies, expect increase vram usage");
         SUPPORTS_PERSISTENT_SPARSE_ADDRESSABLE_BUFFER = false;
      }

      if (IS_COMPATIBLE) {
         LOGGER.info("Enabling NvidiumPlus");
      }

      IS_ENABLED = IS_COMPATIBLE;
   }

   static {
      ModContainer mod = (ModContainer)FabricLoader.getInstance().getModContainer("nvidiumplus").orElseThrow(NullPointerException::new);
      String version = mod.getMetadata().getVersion().getFriendlyString();
      String commit = mod.getMetadata().getCustomValue("commit").getAsString();
      MOD_VERSION = version + "-" + commit;
   }
}
