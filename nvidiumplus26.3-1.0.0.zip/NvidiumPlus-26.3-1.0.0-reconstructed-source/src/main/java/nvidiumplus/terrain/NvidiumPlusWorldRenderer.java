package nvidiumplus.terrain;

import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.frontend.FrontendRenderPass;
import java.util.ArrayList;
import net.caffeinemc.mods.sodium.client.render.chunk.ChunkRenderMatrices;
import net.caffeinemc.mods.sodium.client.render.chunk.RenderSection;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.BuilderTaskOutput;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkBuildOutput;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkSortOutput;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import net.caffeinemc.mods.sodium.client.render.chunk.vertex.format.ChunkMeshFormats;
import net.caffeinemc.mods.sodium.client.render.viewport.Viewport;
import net.caffeinemc.mods.sodium.client.util.FogParameters;
import net.minecraft.client.renderer.oit.OitStage;
import nvidiumplus.terrain.config.TranslucencySortingLevel;
import nvidiumplus.terrain.gl.RenderDevice;
import nvidiumplus.terrain.managers.SectionManager;
import nvidiumplus.terrain.util.DownloadTaskStream;
import nvidiumplus.terrain.util.UploadingBufferStream;
import org.joml.Matrix4fc;
import org.lwjgl.opengl.GL11;

public class NvidiumPlusWorldRenderer {
   private static final RenderDevice device = new RenderDevice();
   private final UploadingBufferStream uploadStream;
   private final DownloadTaskStream downloadStream;
   private final SectionManager sectionManager;
   private final RenderPipeline renderPipeline;
   private long max_geometry_memory;
   private long last_sample_time;

   public NvidiumPlusWorldRenderer() {
      int frames = 3;
      this.uploadStream = new UploadingBufferStream(device, 32000000L);
      this.downloadStream = new DownloadTaskStream(device, frames, 8000000L);
      this.update_allowed_memory();
      this.sectionManager = new SectionManager(
         device,
         this.max_geometry_memory * 1024L * 1024L,
         this.uploadStream,
         NvidiumPlus.config.use_sodium_vertex_format ? ChunkMeshFormats.COMPACT.getVertexFormat().getVertexSize() : 16,
         this
      );
      this.renderPipeline = new RenderPipeline(device, this.uploadStream, this.downloadStream, this.sectionManager);
   }

   public void enqueueRegionSort(int regionId) {
      this.renderPipeline.enqueueRegionSort(regionId);
   }

   public void delete() {
      this.uploadStream.delete();
      this.downloadStream.delete();
      this.renderPipeline.delete();
      this.sectionManager.destroy();
   }

   public void reloadShaders() {
      this.renderPipeline.reloadShaders();
   }

   public void renderFrame(
      TerrainRenderPass pass,
      Viewport viewport,
      FogParameters fogParameters,
      ChunkRenderMatrices matrices,
      double x,
      double y,
      double z,
      GpuSampler terrainSampler
   ) {
      this.renderPipeline.renderFrame(pass, viewport, fogParameters, matrices, x, y, z, terrainSampler);

      while (this.sectionManager.terrainAreana.getUsedMB() > this.max_geometry_memory - 100L) {
         this.renderPipeline.removeARegion();
      }

      if (NvidiumPlus.SUPPORTS_PERSISTENT_SPARSE_ADDRESSABLE_BUFFER && System.currentTimeMillis() - this.last_sample_time > 60000L) {
         this.last_sample_time = System.currentTimeMillis();
         this.update_allowed_memory();
      }
   }

   public void renderTranslucent(TerrainRenderPass pass, FrontendRenderPass renderPass, GpuSampler terrainSampler, OitStage stage) {
      this.renderPipeline.renderTranslucent(pass, renderPass, terrainSampler, stage);
   }

   public void deleteSection(RenderSection section) {
      this.sectionManager.deleteSection(section);
   }

   public void uploadBuildResult(BuilderTaskOutput buildOutput) {
      if (buildOutput instanceof ChunkBuildOutput chunkBuildOutput) {
         this.sectionManager.uploadChunkBuildResult(chunkBuildOutput);
      }

      if (buildOutput instanceof ChunkSortOutput chunkSortOutput
         && chunkSortOutput.containsNewIndexData()
         && NvidiumPlus.config.translucency_sorting_level == TranslucencySortingLevel.SODIUM) {
         this.sectionManager.uploadChunkSort(chunkSortOutput);
      }
   }

   public void addDebugInfo(ArrayList<String> debugInfo) {
      debugInfo.add("Using NvidiumPlus renderer: " + NvidiumPlus.MOD_VERSION);
      debugInfo.add(
         "Mem"
            + (NvidiumPlus.SUPPORTS_PERSISTENT_SPARSE_ADDRESSABLE_BUFFER ? "" : " (fallback)")
            + ": "
            + (
               NvidiumPlus.SUPPORTS_PERSISTENT_SPARSE_ADDRESSABLE_BUFFER
                  ? this.sectionManager.terrainAreana.getAllocatedMB()
                  : this.sectionManager.terrainAreana.getUsedMB()
            )
            + "/"
            + this.max_geometry_memory
            + String.format(", F: %.2f", this.sectionManager.terrainAreana.getFragmentation() * 100.0F)
      );
      debugInfo.add("Regions: " + this.sectionManager.getRegionManager().regionCount() + "/" + this.sectionManager.getRegionManager().maxRegions());
      this.renderPipeline.addDebugInfo(debugInfo);
   }

   private void update_allowed_memory() {
      if (NvidiumPlus.config.automatic_memory) {
         this.max_geometry_memory = GL11.glGetInteger(36937) / 1024
            + (this.sectionManager == null ? 0L : this.sectionManager.terrainAreana.getMemoryUsed() / 1048576L);
         this.max_geometry_memory -= 1024L;
         this.max_geometry_memory = Math.max(2048L, this.max_geometry_memory);
      } else {
         this.max_geometry_memory = NvidiumPlus.config.max_geometry_memory;
      }
   }

   public SectionManager getSectionManager() {
      return this.sectionManager;
   }

   public void setTransformation(int id, Matrix4fc transform) {
      this.renderPipeline.setTransformation(id, transform);
   }

   public void setOrigin(int id, int x, int y, int z) {
      this.renderPipeline.setOrigin(id, x, y, z);
   }

   public int getMaxGeometryMemory() {
      return (int)this.max_geometry_memory;
   }
}
