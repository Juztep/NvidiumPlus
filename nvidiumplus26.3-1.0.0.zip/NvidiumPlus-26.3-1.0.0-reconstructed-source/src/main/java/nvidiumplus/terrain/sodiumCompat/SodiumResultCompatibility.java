package nvidiumplus.terrain.sodiumCompat;

import it.unimi.dsi.fastutil.longs.LongArrays;
import net.caffeinemc.mods.sodium.client.model.quad.properties.ModelQuadFacing;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkBuildOutput;
import net.caffeinemc.mods.sodium.client.render.chunk.data.BuiltSectionMeshParts;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.DefaultTerrainRenderPasses;
import net.caffeinemc.mods.sodium.client.util.NativeBuffer;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import nvidiumplus.terrain.NvidiumPlus;
import nvidiumplus.terrain.config.TranslucencySortingLevel;
import org.joml.Vector3i;
import org.lwjgl.system.MemoryUtil;

public class SodiumResultCompatibility {
   public static RepackagedSectionOutput repackage(ChunkBuildOutput result, int formatSize) {
      int geometryBytes = result.meshes.values().stream().mapToInt(a -> a.getVertexData().getLength()).sum();
      NativeBuffer output = new NativeBuffer(geometryBytes);
      int[] offsets = new int[8];
      Vector3i min = new Vector3i(2000);
      Vector3i max = new Vector3i(-2000);
      packageSectionGeometry(formatSize, output, offsets, result, min, max);
      min.x = Math.max(min.x, 0);
      min.y = Math.max(min.y, 0);
      min.z = Math.max(min.z, 0);
      min.x = Math.min(min.x, 15);
      min.y = Math.min(min.y, 15);
      min.z = Math.min(min.z, 15);
      max.x = Math.min(max.x, 16);
      max.y = Math.min(max.y, 16);
      max.z = Math.min(max.z, 16);
      max.x = Math.max(max.x, 0);
      max.y = Math.max(max.y, 0);
      max.z = Math.max(max.z, 0);
      Vector3i size = new Vector3i(max.x - min.x - 1, max.y - min.y - 1, max.z - min.z - 1);
      size.x = Math.min(15, Math.max(size.x, 0));
      size.y = Math.min(15, Math.max(size.y, 0));
      size.z = Math.min(15, Math.max(size.z, 0));
      return new RepackagedSectionOutput(geometryBytes / formatSize / 4, output, offsets, min, size);
   }

   private static void copyQuad(long from, long too) {
      long quadSize = NvidiumPlus.config.use_sodium_vertex_format ? 80L : 64L;
      MemoryUtil.memCopy(from, too, quadSize);
   }

   private static int[] computeRanges(int[] segments) {
      int[] ranges = new int[14];
      int offset = 0;

      for (int i = 0; i < ModelQuadFacing.COUNT; i++) {
         int count = segments[i * 2];
         int facing = segments[i * 2 + 1];
         if (count > 0) {
            ranges[facing * 2 + 1] = count;
            ranges[facing * 2] = offset;
         }

         offset += count;
      }

      return ranges;
   }

   private static int copyRange(BuiltSectionMeshParts meshData, int offset, int count, long dst, int formatSize, Vector3i min, Vector3i max) {
      long src = MemoryUtil.memAddress(meshData.getVertexData().getDirectBuffer()) + (long)offset * formatSize;
      MemoryUtil.memCopy(src, dst, (long)count * formatSize);

      for (int j = 0; j < count; j++) {
         long base = dst + (long)j * formatSize;
         updateSectionBounds(min, max, base);
      }

      return count / 4;
   }

   private static void packageSectionGeometry(int formatSize, NativeBuffer output, int[] outOffsets, ChunkBuildOutput result, Vector3i min, Vector3i max) {
      int offset = 0;
      long outPtr = MemoryUtil.memAddress(output.getDirectBuffer());
      BuiltSectionMeshParts translucentData = (BuiltSectionMeshParts)result.meshes.get(DefaultTerrainRenderPasses.TRANSLUCENT);
      if (translucentData != null && NvidiumPlus.config.translucency_sorting_level == TranslucencySortingLevel.SODIUM) {
         int[] translucentRanges = computeRanges(translucentData.getVertexSegments());

         for (int i = 0; i < ModelQuadFacing.COUNT; i++) {
            offset += copyRange(
               translucentData, translucentRanges[i * 2], translucentRanges[i * 2 + 1], outPtr + offset * 4L * formatSize, formatSize, min, max
            );
         }
      } else if (translucentData != null) {
         Vec3 cameraPos = Minecraft.getInstance().gameRenderer.mainCamera().position();
         float cpx = (float)(cameraPos.x - (result.section.getChunkX() << 4));
         float cpy = (float)(cameraPos.y - (result.section.getChunkY() << 4));
         float cpz = (float)(cameraPos.z - (result.section.getChunkZ() << 4));
         float len = (float)Math.sqrt(cpx * cpx + cpy * cpy + cpz * cpz);
         cpx *= 1.0F / len;
         cpy *= 1.0F / len;
         cpz *= 1.0F / len;
         len = Math.min(len, 32.0F);
         cpx *= len;
         cpy *= len;
         cpz *= len;
         int quadCount = translucentData.getVertexData().getLength() / (formatSize * 4);
         int quadId = 0;
         long[] srcs = new long[7];
         long[] sortingData = new long[quadCount];
         int[] ranges = computeRanges(translucentData.getVertexSegments());

         for (int i = 0; i < ModelQuadFacing.COUNT; i++) {
            int off = ranges[i * 2];
            int count = ranges[i * 2 + 1];
            long src = MemoryUtil.memAddress(translucentData.getVertexData().getDirectBuffer()) + (long)off * formatSize;
            srcs[i] = src;
            float cx = 0.0F;
            float cy = 0.0F;
            float cz = 0.0F;

            for (int j = 0; j < count; j++) {
               long base = src + (long)j * formatSize;
               float x;
               float y;
               float z;
               if (NvidiumPlus.config.use_sodium_vertex_format) {
                  int hi = MemoryUtil.memGetInt(base);
                  int lo = MemoryUtil.memGetInt(base + 4L);
                  x = scalePos((hi >> 0 & 1023) << 10 | lo >> 0 & 1023);
                  y = scalePos((hi >> 10 & 1023) << 10 | lo >> 10 & 1023);
                  z = scalePos((hi >> 20 & 1023) << 10 | lo >> 20 & 1023);
               } else {
                  x = decodePosition(MemoryUtil.memGetShort(base));
                  y = decodePosition(MemoryUtil.memGetShort(base + 2L));
                  z = decodePosition(MemoryUtil.memGetShort(base + 4L));
               }

               updateSectionBounds(min, max, base);
               cx += x;
               cy += y;
               cz += z;
               if ((j & 3) == 3) {
                  cx *= 0.25F;
                  cy *= 0.25F;
                  cz *= 0.25F;
                  float dx = cx - cpx;
                  float dy = cy - cpy;
                  float dz = cz - cpz;
                  float dist = dx * dx + dy * dy + dz * dz;
                  int sortDistance = (int)(dist * 4096.0F);
                  long packedSortingData = (long)sortDistance << 32 | (long)j >> 2 << 3 | i;
                  sortingData[quadId++] = packedSortingData;
                  cx = 0.0F;
                  cy = 0.0F;
                  cz = 0.0F;
               }
            }
         }

         if (quadId != sortingData.length) {
            throw new IllegalStateException();
         }

         LongArrays.radixSort(sortingData);

         for (int i = 0; i < sortingData.length; i++) {
            long data = sortingData[i];
            copyQuad(srcs[(int)(data & 7L)] + (data >> 3 & 536870911L) * 4L * formatSize, outPtr + (sortingData.length - 1 - i) * 4L * formatSize);
         }

         offset += quadCount;
      }

      outOffsets[7] = offset;
      BuiltSectionMeshParts solid = (BuiltSectionMeshParts)result.meshes.get(DefaultTerrainRenderPasses.SOLID);
      BuiltSectionMeshParts cutout = (BuiltSectionMeshParts)result.meshes.get(DefaultTerrainRenderPasses.CUTOUT);
      int[] solidRanges = solid != null ? computeRanges(solid.getVertexSegments()) : null;
      int[] cutoutRanges = cutout != null ? computeRanges(cutout.getVertexSegments()) : null;

      for (int i = 0; i < ModelQuadFacing.COUNT; i++) {
         int poff = offset;
         if (solid != null) {
            offset += copyRange(solid, solidRanges[i * 2], solidRanges[i * 2 + 1], outPtr + offset * 4L * formatSize, formatSize, min, max);
         }

         if (cutout != null) {
            offset += copyRange(cutout, cutoutRanges[i * 2], cutoutRanges[i * 2 + 1], outPtr + offset * 4L * formatSize, formatSize, min, max);
         }

         outOffsets[i] = (short)(offset - poff);
      }

      if (offset * 4 * formatSize != output.getLength()) {
         throw new IllegalStateException(
            "NvidiumPlus bad build result got "
               + offset * 4 * formatSize
               + " instead of "
               + output.getLength()
               + " at "
               + result.section.getChunkX()
               + " "
               + result.section.getChunkY()
               + " "
               + result.section.getChunkZ()
         );
      }
   }

   private static float decodePosition(short v) {
      return Short.toUnsignedInt(v) * 4.8828125E-4F - 8.0F;
   }

   private static float scalePos(int pos) {
      float vertexScale = 3.0517607E-5F;
      return pos * vertexScale - 8.0F;
   }

   private static void updateSectionBounds(Vector3i min, Vector3i max, long vertex) {
      float x;
      float y;
      float z;
      if (NvidiumPlus.config.use_sodium_vertex_format) {
         int hi = MemoryUtil.memGetInt(vertex);
         int lo = MemoryUtil.memGetInt(vertex + 4L);
         x = scalePos((hi >> 0 & 1023) << 10 | lo >> 0 & 1023);
         y = scalePos((hi >> 10 & 1023) << 10 | lo >> 10 & 1023);
         z = scalePos((hi >> 20 & 1023) << 10 | lo >> 20 & 1023);
      } else {
         x = decodePosition(MemoryUtil.memGetShort(vertex));
         y = decodePosition(MemoryUtil.memGetShort(vertex + 2L));
         z = decodePosition(MemoryUtil.memGetShort(vertex + 4L));
      }

      updateSectionBounds(min, max, x, y, z);
   }

   private static void updateSectionBounds(Vector3i min, Vector3i max, float x, float y, float z) {
      min.x = (int)Math.min(min.x, Math.floor(x));
      min.y = (int)Math.min(min.y, Math.floor(y));
      min.z = (int)Math.min(min.z, Math.floor(z));
      max.x = (int)Math.max(max.x, Math.ceil(x));
      max.y = (int)Math.max(max.y, Math.ceil(y));
      max.z = (int)Math.max(max.z, Math.ceil(z));
   }
}
