package nvidiumplus.terrain.sodiumCompat;

public interface IRenderSectionExtension {
   boolean isSubmittedRebuild();

   void isSubmittedRebuild(boolean var1);

   boolean isSeen();

   void isSeen(boolean var1);
}
