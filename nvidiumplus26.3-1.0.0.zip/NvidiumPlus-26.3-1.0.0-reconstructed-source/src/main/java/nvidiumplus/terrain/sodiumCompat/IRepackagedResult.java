package nvidiumplus.terrain.sodiumCompat;

public interface IRepackagedResult {
   RepackagedSectionOutput getOutput();

   void set(RepackagedSectionOutput var1);
}
