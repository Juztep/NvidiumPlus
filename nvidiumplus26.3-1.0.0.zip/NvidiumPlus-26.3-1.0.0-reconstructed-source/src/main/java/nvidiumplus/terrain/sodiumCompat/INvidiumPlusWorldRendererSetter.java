package nvidiumplus.terrain.sodiumCompat;

import nvidiumplus.terrain.NvidiumPlusWorldRenderer;

public interface INvidiumPlusWorldRendererSetter {
   void setWorldRenderer(NvidiumPlusWorldRenderer var1);
}
