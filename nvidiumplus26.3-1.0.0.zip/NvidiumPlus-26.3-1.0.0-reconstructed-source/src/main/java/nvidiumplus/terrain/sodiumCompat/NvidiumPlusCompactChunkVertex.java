package nvidiumplus.terrain.sodiumCompat;

import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.api.vertex.VertexFormat;
import net.caffeinemc.mods.sodium.api.util.ColorABGR;
import net.caffeinemc.mods.sodium.api.util.ColorU8;
import net.caffeinemc.mods.sodium.client.render.chunk.vertex.format.ChunkVertexEncoder;
import net.caffeinemc.mods.sodium.client.render.chunk.vertex.format.ChunkVertexType;
import net.caffeinemc.mods.sodium.client.render.chunk.vertex.format.ChunkVertexEncoder.Vertex;
import net.minecraft.util.Mth;
import org.lwjgl.system.MemoryUtil;

public class NvidiumPlusCompactChunkVertex implements ChunkVertexType {
   public static final VertexFormat VERTEX_FORMAT = VertexFormat.builder(0).addAttribute("vtx", GpuFormat.RGBA32_UINT).build();
   public static final int STRIDE = 16;
   public static final NvidiumPlusCompactChunkVertex INSTANCE = new NvidiumPlusCompactChunkVertex();
   private static final int POSITION_MAX_VALUE = 65536;
   public static final int TEXTURE_MAX_VALUE = 32768;
   private static final float MODEL_ORIGIN = 8.0F;
   private static final float MODEL_RANGE = 32.0F;
   private static final float MODEL_SCALE = 4.8828125E-4F;
   private static final float MODEL_SCALE_INV = 2048.0F;
   private static final float TEXTURE_SCALE = 3.0517578E-5F;

   public VertexFormat getVertexFormat() {
      return VERTEX_FORMAT;
   }

   public ChunkVertexEncoder getEncoder() {
      return (ptr, material, vertices, sectionIndex) -> {
         for (Vertex vertex : vertices) {
            int light = compactLight(vertex.light);
            MemoryUtil.memPutInt(ptr + 0L, encodePosition(vertex.x) << 0 | encodePosition(vertex.y) << 16);
            MemoryUtil.memPutInt(ptr + 4L, encodePosition(vertex.z) << 0 | encodeDrawParameters(material) << 16 | (light & 0xFF) << 24);
            MemoryUtil.memPutInt(ptr + 8L, encodeColor(vertex.color, vertex.ao) << 0 | (light >> 8 & 0xFF) << 24);
            MemoryUtil.memPutInt(ptr + 12L, encodeTexture(vertex.u, vertex.v));
            ptr += 16L;
         }

         return ptr;
      };
   }

   private static int compactLight(int light) {
      int sky = Mth.clamp(light >>> 16 & 0xFF, 8, 248);
      int block = Mth.clamp(light >>> 0 & 0xFF, 8, 248);
      return block << 0 | sky << 8;
   }

   private static int encodePosition(float v) {
      return (int)((8.0F + v) / 32.0F * 65536.0F);
   }

   private static int encodeDrawParameters(int material) {
      return (material & 0xFF) << 0;
   }

   private static int encodeColor(int color, float brightness) {
      int r = ColorU8.normalizedFloatToByte(ColorU8.byteToNormalizedFloat(ColorABGR.unpackRed(color)) * brightness);
      int g = ColorU8.normalizedFloatToByte(ColorU8.byteToNormalizedFloat(ColorABGR.unpackGreen(color)) * brightness);
      int b = ColorU8.normalizedFloatToByte(ColorU8.byteToNormalizedFloat(ColorABGR.unpackBlue(color)) * brightness);
      return ColorABGR.pack(r, g, b, 0);
   }

   private static int encodeTexture(float u, float v) {
      return (Math.round(u * 32768.0F) & 65535) << 0 | (Math.round(v * 32768.0F) & 65535) << 16;
   }
}
