package nvidiumplus.terrain.sodiumCompat;

import net.caffeinemc.mods.sodium.client.util.NativeBuffer;
import org.joml.Vector3i;

public record RepackagedSectionOutput(int quads, NativeBuffer geometry, int[] offsets, Vector3i min, Vector3i size) {
   public void delete() {
      this.geometry.free();
   }
}
