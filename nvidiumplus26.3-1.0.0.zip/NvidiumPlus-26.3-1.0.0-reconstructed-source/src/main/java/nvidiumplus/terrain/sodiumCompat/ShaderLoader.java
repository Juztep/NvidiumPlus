package nvidiumplus.terrain.sodiumCompat;

import net.minecraft.client.renderer.ShaderDefines;
import net.minecraft.client.renderer.ShaderDefines.Builder;
import net.minecraft.resources.Identifier;
import nvidiumplus.terrain.NvidiumPlus;
import nvidiumplus.terrain.config.StatisticsLoggingLevel;
import nvidiumplus.terrain.config.TranslucencySortingLevel;
import nvidiumplus.terrain.util.GlslPreprocessor;

public class ShaderLoader {
   public static String parse(Identifier path) {
      return parse(path, ShaderDefines.builder());
   }

   public static String parse(Identifier path, Builder builder) {
      if (NvidiumPlus.IS_DEBUG) {
         builder.define("DEBUG");
      }

      for (int i = 1; i <= NvidiumPlus.config.statistics_level.ordinal(); i++) {
         builder.define("STATISTICS_" + StatisticsLoggingLevel.values()[i].name());
      }

      if (NvidiumPlus.config.translucency_sorting_level.ordinal() >= TranslucencySortingLevel.SECTIONS.ordinal()) {
         builder.define("TRANSLUCENCY_SORTING_SECTIONS");
      }

      if (NvidiumPlus.config.translucency_sorting_level == TranslucencySortingLevel.QUADS) {
         builder.define("TRANSLUCENCY_SORTING_QUADS");
      }

      if (NvidiumPlus.config.translucency_sorting_level == TranslucencySortingLevel.SODIUM) {
         builder.define("TRANSLUCENCY_SORTING_SODIUM");
      }

      if (NvidiumPlus.config.render_fog) {
         builder.define("RENDER_FOG");
      }

      if (NvidiumPlus.config.use_sodium_vertex_format) {
         builder.define("USE_SODIUM_VERTEX_FORMAT");
      }

      if (NvidiumPlus.config.cull_degenerate_triangles) {
         builder.define("CULL_DEGENERATE_TRIANGLES");
      }

      if (NvidiumPlus.config.use_nv_fragment_shader_barycentric) {
         builder.define("USE_NV_FRAGMENT_SHADER_BARYCENTRIC");
      }

      builder.define("TEXTURE_MAX_SCALE", String.valueOf(32768));
      GlslPreprocessor preprocessor = new GlslPreprocessor(builder.build());
      return preprocessor.process(path);
   }
}
