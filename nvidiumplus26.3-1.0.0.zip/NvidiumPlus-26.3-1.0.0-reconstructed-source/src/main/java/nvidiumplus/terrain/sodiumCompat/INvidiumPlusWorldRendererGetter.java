package nvidiumplus.terrain.sodiumCompat;

import nvidiumplus.terrain.NvidiumPlusWorldRenderer;

public interface INvidiumPlusWorldRendererGetter {
   NvidiumPlusWorldRenderer getRenderer();
}
