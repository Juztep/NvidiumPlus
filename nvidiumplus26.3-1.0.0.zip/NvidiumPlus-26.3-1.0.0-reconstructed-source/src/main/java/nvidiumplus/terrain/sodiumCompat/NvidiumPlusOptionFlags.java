package nvidiumplus.terrain.sodiumCompat;

import net.caffeinemc.mods.sodium.api.config.option.OptionFlag;

public class NvidiumPlusOptionFlags {
   public static OptionFlag REQUIRES_SHADER_RELOAD;
}
