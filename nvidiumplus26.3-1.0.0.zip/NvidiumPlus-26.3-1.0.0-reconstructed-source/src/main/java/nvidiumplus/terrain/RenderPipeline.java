package nvidiumplus.terrain;

import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.frontend.FrontendRenderPass;
import it.unimi.dsi.fastutil.ints.IntAVLTreeSet;
import it.unimi.dsi.fastutil.ints.IntBidirectionalIterator;
import it.unimi.dsi.fastutil.ints.IntIterator;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.IntSet;
import it.unimi.dsi.fastutil.ints.IntSortedSet;
import java.util.BitSet;
import java.util.List;
import net.caffeinemc.mods.sodium.client.SodiumClientMod;
import net.caffeinemc.mods.sodium.client.gpu.GPULimits;
import net.caffeinemc.mods.sodium.client.render.chunk.ChunkRenderMatrices;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import net.caffeinemc.mods.sodium.client.render.viewport.Viewport;
import net.caffeinemc.mods.sodium.client.util.FogParameters;
import net.minecraft.client.Minecraft;
import net.minecraft.client.TextureFilteringMethod;
import net.minecraft.client.renderer.oit.OitStage;
import net.minecraft.client.renderer.texture.TextureAtlas;
import nvidiumplus.terrain.config.StatisticsLoggingLevel;
import nvidiumplus.terrain.config.TranslucencySortingLevel;
import nvidiumplus.terrain.gl.RenderDevice;
import nvidiumplus.terrain.gl.buffers.IDeviceMappedBuffer;
import nvidiumplus.terrain.gl.buffers.PersistentSparseAddressableBuffer;
import nvidiumplus.terrain.managers.RegionManager;
import nvidiumplus.terrain.managers.RegionVisibilityTracker;
import nvidiumplus.terrain.managers.SectionManager;
import nvidiumplus.terrain.mixin.minecraft.TextureAtlasAccessor;
import nvidiumplus.terrain.renderers.CmdBufferBuilder;
import nvidiumplus.terrain.renderers.PrimaryTerrainRasterizer;
import nvidiumplus.terrain.renderers.RegionRasterizer;
import nvidiumplus.terrain.renderers.SectionRasterizer;
import nvidiumplus.terrain.renderers.SortRegionSectionPhase;
import nvidiumplus.terrain.renderers.TemporalTerrainRasterizer;
import nvidiumplus.terrain.renderers.TranslucentTerrainRasterizer;
import nvidiumplus.terrain.util.DownloadTaskStream;
import nvidiumplus.terrain.util.TickableManager;
import nvidiumplus.terrain.util.UploadingBufferStream;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.joml.Vector3i;
import org.joml.Vector4f;
import org.joml.Vector4i;
import org.lwjgl.opengl.ARBDirectStateAccess;
import org.lwjgl.opengl.GL42;
import org.lwjgl.opengl.NVVertexBufferUnifiedMemory;
import org.lwjgl.system.MemoryUtil;

public class RenderPipeline {
   public static final int GL_DRAW_INDIRECT_UNIFIED_NV = 36672;
   public static final int GL_DRAW_INDIRECT_ADDRESS_NV = 36673;
   private final RenderDevice device;
   private final UploadingBufferStream uploadStream;
   private final DownloadTaskStream downloadStream;
   private final SectionManager sectionManager;
   public final RegionVisibilityTracker regionVisibilityTracking;
   private PrimaryTerrainRasterizer terrainRasterizer;
   private RegionRasterizer regionRasterizer;
   private SectionRasterizer sectionRasterizer;
   private TemporalTerrainRasterizer temporalRasterizer;
   private TranslucentTerrainRasterizer translucencyTerrainRasterizer;
   private SortRegionSectionPhase regionSectionSorter;
   private CmdBufferBuilder cmdBufferBuilder;
   private final IDeviceMappedBuffer sceneUniform;
   private static final int SCENE_SIZE = (int)PersistentSparseAddressableBuffer.alignUp(343L, 2L);
   private final IDeviceMappedBuffer regionVisibility;
   private final IDeviceMappedBuffer sectionVisibility;
   private final IDeviceMappedBuffer sectionIndices;
   private final IDeviceMappedBuffer terrainCommandBuffer;
   private final IDeviceMappedBuffer translucencyCommandBuffer;
   private final IDeviceMappedBuffer temporalCommandBuffer;
   private final IDeviceMappedBuffer regionSortingList;
   private final IDeviceMappedBuffer statisticsBuffer;
   private final IDeviceMappedBuffer transformationArray;
   private final IDeviceMappedBuffer originOffsetArray;
   private final BitSet regionVisibilityTracker;
   private final IntSet regionsToSort = new IntOpenHashSet();
   private final RenderPipeline.Statistics stats;
   private int prevRegionCount;
   private int frameId;
   private boolean compiledForFog = false;

   public RenderPipeline(RenderDevice device, UploadingBufferStream uploadStream, DownloadTaskStream downloadStream, SectionManager sectionManager) {
      this.device = device;
      this.uploadStream = uploadStream;
      this.downloadStream = downloadStream;
      this.sectionManager = sectionManager;
      this.compiledForFog = NvidiumPlus.config.render_fog;
      this.terrainRasterizer = new PrimaryTerrainRasterizer();
      this.regionRasterizer = new RegionRasterizer();
      this.sectionRasterizer = new SectionRasterizer();
      this.temporalRasterizer = new TemporalTerrainRasterizer();
      this.translucencyTerrainRasterizer = new TranslucentTerrainRasterizer();
      this.regionSectionSorter = new SortRegionSectionPhase();
      this.cmdBufferBuilder = new CmdBufferBuilder();
      int maxRegions = sectionManager.getRegionManager().maxRegions();
      this.sceneUniform = device.createDeviceOnlyMappedBuffer(SCENE_SIZE + maxRegions * 2L);
      this.regionVisibility = device.createDeviceOnlyMappedBuffer(maxRegions);
      this.sectionVisibility = device.createDeviceOnlyMappedBuffer(maxRegions * 256L);
      this.sectionIndices = device.createDeviceOnlyMappedBuffer(maxRegions * 256L * 3L);
      this.terrainCommandBuffer = device.createDeviceOnlyMappedBuffer(maxRegions * 8L);
      this.translucencyCommandBuffer = device.createDeviceOnlyMappedBuffer(maxRegions * 8L);
      this.temporalCommandBuffer = device.createDeviceOnlyMappedBuffer(maxRegions * 8L);
      this.regionSortingList = device.createDeviceOnlyMappedBuffer(maxRegions * 2L);
      this.transformationArray = device.createDeviceOnlyMappedBuffer(65536L);
      this.originOffsetArray = device.createDeviceOnlyMappedBuffer(8192L);
      this.regionVisibilityTracker = new BitSet(maxRegions);
      this.regionVisibilityTracking = new RegionVisibilityTracker(downloadStream, maxRegions);
      this.statisticsBuffer = device.createDeviceOnlyMappedBuffer(16L);
      this.stats = new RenderPipeline.Statistics();
      long ptr = this.uploadStream.upload(this.transformationArray, 0L, 65536L);
      Matrix4f transform = new Matrix4f().identity();

      for (int i = 0; i < 1024; i++) {
         transform.getToAddress(ptr);
         ptr += 64L;
      }

      ARBDirectStateAccess.nglClearNamedBufferData(this.originOffsetArray.getId(), 33330, 36244, 5121, 0L);
   }

   public void setTransformation(int id, Matrix4fc transform) {
      if (id >= 0 && id < 1024) {
         long ptr = this.uploadStream.upload(this.transformationArray, id * 64, 64L);
         transform.getToAddress(ptr);
      } else {
         throw new IllegalArgumentException("Id out of bounds: " + id);
      }
   }

   public void setOrigin(int id, int x, int y, int z) {
      if (id >= 0 && id < 1024) {
         long ptr = this.uploadStream.upload(this.originOffsetArray, id * 8, 8L);
         long pos = 0L;
         pos |= x & 33554431;
         pos |= (long)(z & 33554431) << 25;
         pos |= (long)(y & 16383) << 50;
         MemoryUtil.memPutLong(ptr, pos);
      } else {
         throw new IllegalArgumentException("Id out of bounds: " + id);
      }
   }

   public void renderFrame(
      TerrainRenderPass pass,
      Viewport viewport,
      FogParameters fogParameters,
      ChunkRenderMatrices crm,
      double px,
      double py,
      double pz,
      GpuSampler terrainSampler
   ) {
      if (this.sectionManager.getRegionManager().regionCount() != 0) {
         int DEBUG_RENDER_LEVEL = 0;
         boolean WRITE_DEPTH = false;
         Vector3i blockPos = new Vector3i((int)Math.floor(px), (int)Math.floor(py), (int)Math.floor(pz));
         Vector3i chunkPos = new Vector3i(blockPos.x >> 4, blockPos.y >> 4, blockPos.z >> 4);
         int screenWidth = Minecraft.getInstance().getWindow().getWidth();
         int screenHeight = Minecraft.getInstance().getWindow().getHeight();
         TextureAtlasAccessor textureAtlas = (TextureAtlasAccessor)Minecraft.getInstance().getTextureManager().getTexture(TextureAtlas.LOCATION_BLOCKS);
         double subTexelPrecision = 1 << GPULimits.getSubTexelPrecisionBits();
         double subTexelOffset = 3.0517578E-5F;
         float subTexelWidth = (float)(subTexelOffset - 1.0 / textureAtlas.nvidiumplus$getWidth() / subTexelPrecision);
         float subTexelHeight = (float)(subTexelOffset - 1.0 / textureAtlas.nvidiumplus$getHeight() / subTexelPrecision);
         int visibleRegions = 0;
         long queryAddr = 0L;
         RegionManager rm = this.sectionManager.getRegionManager();
         IntSortedSet regions = new IntAVLTreeSet();

         for (int i = 0; i < rm.maxRegionIndex(); i++) {
            if (rm.regionExists(i)) {
               if (NvidiumPlus.config.region_keep_distance != 257
                  && NvidiumPlus.config.region_keep_distance != 32
                  && NvidiumPlus.config.region_keep_distance > Minecraft.getInstance().options.getEffectiveRenderDistance()
                  && !rm.withinSquare(NvidiumPlus.config.region_keep_distance + 4, i, chunkPos.x, chunkPos.y, chunkPos.z)) {
                  this.removeRegion(i);
               } else if (rm.isRegionVisible(viewport, i)) {
                  regions.add(rm.distance(i, chunkPos.x, chunkPos.y, chunkPos.z) << 16 | i);
                  visibleRegions++;
                  this.regionVisibilityTracker.set(i);
                  if (rm.isRegionInACameraAxis(i, px, py, pz)) {
                     this.regionsToSort.add(i);
                  }
               } else {
                  if (this.regionVisibilityTracker.get(i) && NvidiumPlus.config.enable_temporal_coherence) {
                     ARBDirectStateAccess.nglClearNamedBufferSubData(this.sectionVisibility.getId(), 33330, (long)i << 8, 255L, 36244, 5121, 0L);
                  }

                  this.regionVisibilityTracker.clear(i);
               }
            }
         }

         short[] regionMap = new short[regions.size()];
         if (visibleRegions == 0) {
            this.prevRegionCount = 0;
         } else {
            long addr = this.uploadStream.upload(this.sceneUniform, SCENE_SIZE, visibleRegions * 2);
            int j = 0;

            for (IntBidirectionalIterator region = regions.iterator(); region.hasNext(); j++) {
               int i = (Integer)region.next();
               regionMap[j] = (short)i;
               MemoryUtil.memPutShort(addr + ((long)j << 1), (short)i);
            }

            if (NvidiumPlus.config.statistics_level != StatisticsLoggingLevel.NONE) {
               this.stats.frustumCount = regions.size();
            }

            Vector3f delta = new Vector3f((float)(px - (chunkPos.x << 4)), (float)(py - (chunkPos.y << 4)), (float)(pz - (chunkPos.z << 4)));
            delta.negate();
            addr = this.uploadStream.upload(this.sceneUniform, 0L, SCENE_SIZE);
            new Matrix4f(crm.projection()).mul(crm.modelView()).translate(delta).getToAddress(addr);
            addr += 64L;
            if (this.compiledForFog) {
               new Matrix4f(crm.projection()).mul(crm.modelView()).invert().getToAddress(addr);
               addr += 64L;
            }

            new Vector4i(chunkPos.x, chunkPos.y, chunkPos.z, 0).getToAddress(addr);
            addr += 16L;
            new Vector4f(delta, 0.0F).getToAddress(addr);
            addr += 16L;
            MemoryUtil.memPutLong(addr, this.sceneUniform.getDeviceAddress() + SCENE_SIZE);
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.sectionManager.getRegionManager().getRegionBufferAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.sectionManager.getRegionManager().getSectionBufferAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.regionVisibility.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.sectionVisibility.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.sectionIndices.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.terrainCommandBuffer.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.translucencyCommandBuffer.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.temporalCommandBuffer.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.regionSortingList.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.sectionManager.terrainAreana.buffer.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.sectionManager.terrainAreana.buffer.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.transformationArray.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.originOffsetArray.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutLong(addr, this.statisticsBuffer == null ? 0L : this.statisticsBuffer.getDeviceAddress());
            addr += 8L;
            MemoryUtil.memPutFloat(addr, screenWidth / 2.0F);
            addr += 4L;
            MemoryUtil.memPutFloat(addr, screenHeight / 2.0F);
            addr += 4L;
            new Vector4f(fogParameters.red(), fogParameters.green(), fogParameters.blue(), fogParameters.alpha()).getToAddress(addr);
            addr += 16L;
            new Vector2f(fogParameters.environmentalStart(), fogParameters.environmentalEnd()).getToAddress(addr);
            addr += 8L;
            new Vector2f(fogParameters.renderStart(), fogParameters.renderEnd()).getToAddress(addr);
            addr += 8L;
            MemoryUtil.memPutFloat(addr, subTexelWidth);
            addr += 4L;
            MemoryUtil.memPutFloat(addr, subTexelHeight);
            addr += 4L;
            MemoryUtil.memPutFloat(addr, 1.0F / textureAtlas.nvidiumplus$getWidth());
            addr += 4L;
            MemoryUtil.memPutFloat(addr, 1.0F / textureAtlas.nvidiumplus$getHeight());
            addr += 4L;
            j = 0;
            j |= SodiumClientMod.options().performance.useBlockFaceCulling ? 1 : 0;
            if (Minecraft.getInstance().options.textureFiltering().get() == TextureFilteringMethod.RGSS) {
               j |= 2;
            }

            MemoryUtil.memPutInt(addr, j);
            addr += 4L;
            MemoryUtil.memPutShort(addr, (short)visibleRegions);
            addr += 2L;
            MemoryUtil.memPutByte(addr, (byte)(this.frameId++));
            if (NvidiumPlus.config.translucency_sorting_level == TranslucencySortingLevel.NONE) {
               this.regionsToSort.clear();
            }

            int regionSortSize = this.regionsToSort.size();
            if (regionSortSize != 0) {
               addr = this.uploadStream.upload(this.regionSortingList, 0L, regionSortSize * 2);

               for (IntIterator var72 = this.regionsToSort.iterator(); var72.hasNext(); addr += 2L) {
                  int region = (Integer)var72.next();
                  MemoryUtil.memPutShort(addr, (short)region);
               }

               this.regionsToSort.clear();
            }

            this.sectionManager.commitChanges();
            this.uploadStream.commit();
            TickableManager.TickAll();
            GL42.glEnableClientState(37742);
            GL42.glEnableClientState(36638);
            GL42.glEnableClientState(36639);
            GL42.glEnableClientState(36672);
            NVVertexBufferUnifiedMemory.glBufferAddressRangeNV(37743, 0, this.sceneUniform.getDeviceAddress(), SCENE_SIZE);
            if (this.prevRegionCount != 0) {
               GL42.glEnable(2929);
               this.terrainRasterizer.raster(pass, this.prevRegionCount, this.terrainCommandBuffer.getDeviceAddress(), terrainSampler);
               GL42.glMemoryBarrier(1024);
            }

            if (regionSortSize != 0) {
               GL42.glMemoryBarrier(8192);
               this.regionSectionSorter.dispatch(regionSortSize);
               GL42.glMemoryBarrier(8192);
            }

            GL42.glEnable(2929);
            GL42.glDepthFunc(518);
            GL42.glDepthMask(false);
            GL42.glColorMask(false, false, false, false);
            GL42.glEnable(37759);
            this.regionRasterizer.raster(visibleRegions);
            GL42.glMemoryBarrier(8192);
            this.sectionRasterizer.raster(visibleRegions);
            GL42.glDisable(37759);
            GL42.glDepthMask(true);
            GL42.glColorMask(true, true, true, true);
            GL42.glMemoryBarrier(8192);
            this.cmdBufferBuilder.dispatch(visibleRegions);
            GL42.glMemoryBarrier(8192);
            GL42.glMemoryBarrier(64);
            this.prevRegionCount = visibleRegions;
            if (NvidiumPlus.config.enable_temporal_coherence) {
               GL42.glMemoryBarrier(64);
               this.temporalRasterizer.raster(pass, visibleRegions, this.temporalCommandBuffer.getDeviceAddress(), terrainSampler);
            }

            GL42.glDepthMask(false);
            GL42.glColorMask(false, false, false, false);
            GL42.glEnable(37759);
            this.regionVisibilityTracking.computeVisibility(visibleRegions, this.regionVisibility, regionMap);
            GL42.glDisable(37759);
            GL42.glDepthMask(true);
            GL42.glColorMask(true, true, true, true);
            GL42.glDisableClientState(37742);
            GL42.glDisableClientState(36638);
            GL42.glDisableClientState(36639);
            GL42.glDisableClientState(36672);
            GL42.glDepthFunc(518);
         }
      }
   }

   void enqueueRegionSort(int regionId) {
      this.regionsToSort.add(regionId);
   }

   private void removeRegion(int id) {
      this.sectionManager.removeRegionById(id);
      this.regionVisibilityTracking.resetRegion(id);
   }

   public void removeARegion() {
      this.removeRegion(this.regionVisibilityTracking.findMostLikelyLeastSeenRegion(this.sectionManager.getRegionManager().maxRegionIndex()));
   }

   public void renderTranslucent(TerrainRenderPass pass, FrontendRenderPass renderPass, GpuSampler terrainSampler, OitStage stage) {
      GL42.glEnableClientState(37742);
      GL42.glEnableClientState(36638);
      GL42.glEnableClientState(36639);
      GL42.glEnableClientState(36672);
      NVVertexBufferUnifiedMemory.glBufferAddressRangeNV(37743, 0, this.sceneUniform.getDeviceAddress(), SCENE_SIZE);
      GL42.glEnable(2929);
      this.translucencyTerrainRasterizer
         .raster(pass, renderPass, this.prevRegionCount, this.translucencyCommandBuffer.getDeviceAddress(), terrainSampler, stage);
      GL42.glDisableClientState(37742);
      GL42.glDisableClientState(36638);
      GL42.glDisableClientState(36639);
      GL42.glDisableClientState(36672);
      if (NvidiumPlus.config.statistics_level.ordinal() > StatisticsLoggingLevel.FRUSTUM.ordinal()) {
         this.downloadStream.download(this.statisticsBuffer, 0L, 16, addr -> {
            this.stats.regionCount = MemoryUtil.memGetInt(addr);
            this.stats.sectionCount = MemoryUtil.memGetInt(addr + 4L);
            this.stats.quadCount = MemoryUtil.memGetInt(addr + 8L);
            this.stats.cullCount = MemoryUtil.memGetInt(addr + 12L);
         });
      }

      if (NvidiumPlus.config.statistics_level.ordinal() > StatisticsLoggingLevel.FRUSTUM.ordinal()) {
         long upload = this.uploadStream.upload(this.statisticsBuffer, 0L, 16L);
         MemoryUtil.memSet(upload, 0, 16L);
      }
   }

   public void delete() {
      this.regionVisibilityTracking.delete();
      this.sceneUniform.delete();
      this.regionVisibility.delete();
      this.sectionVisibility.delete();
      this.sectionIndices.delete();
      this.terrainCommandBuffer.delete();
      this.translucencyCommandBuffer.delete();
      this.temporalCommandBuffer.delete();
      this.regionSortingList.delete();
      this.terrainRasterizer.delete();
      this.regionRasterizer.delete();
      this.sectionRasterizer.delete();
      this.temporalRasterizer.delete();
      this.translucencyTerrainRasterizer.delete();
      this.regionSectionSorter.delete();
      this.cmdBufferBuilder.delete();
      this.transformationArray.delete();
      this.originOffsetArray.delete();
      if (this.statisticsBuffer != null) {
         this.statisticsBuffer.delete();
      }
   }

   public void addDebugInfo(List<String> info) {
      if (NvidiumPlus.config.statistics_level != StatisticsLoggingLevel.NONE) {
         StringBuilder builder = new StringBuilder();
         builder.append("Statistics: ");
         if (NvidiumPlus.config.statistics_level.ordinal() >= StatisticsLoggingLevel.FRUSTUM.ordinal()) {
            builder.append("F: ").append(this.stats.frustumCount);
         }

         if (NvidiumPlus.config.statistics_level.ordinal() >= StatisticsLoggingLevel.REGIONS.ordinal()) {
            builder.append(", R: ").append(this.stats.regionCount);
         }

         if (NvidiumPlus.config.statistics_level.ordinal() >= StatisticsLoggingLevel.SECTIONS.ordinal()) {
            builder.append(", S: ").append(this.stats.sectionCount);
         }

         if (NvidiumPlus.config.statistics_level.ordinal() >= StatisticsLoggingLevel.QUADS.ordinal()) {
            builder.append(", Q: ").append(this.stats.quadCount);
         }

         if (NvidiumPlus.config.statistics_level.ordinal() >= StatisticsLoggingLevel.CULL.ordinal()) {
            builder.append(", C: ").append(this.stats.cullCount);
         }

         info.addAll(List.of(builder.toString().split("\n")));
      }

      info.add("Primary Terrain frame time: " + String.format("%.03f", this.terrainRasterizer.getTiming().getAverageMs()) + "ms");
      info.add("Translucent frame time: " + String.format("%.03f", this.translucencyTerrainRasterizer.getTiming().getAverageMs()) + "ms");
      if (NvidiumPlus.config.enable_temporal_coherence) {
         info.add("Temporal frame time: " + String.format("%.03f", this.temporalRasterizer.getTiming().getAverageMs()) + "ms");
      }

      info.add("Region Raster time: " + String.format("%.03f", this.regionRasterizer.getTiming().getAverageMs()) + "ms");
      info.add("Section Raster time: " + String.format("%.03f", this.sectionRasterizer.getTiming().getAverageMs()) + "ms");
      info.add("CmdBufferBuilder time: " + String.format("%.03f", this.cmdBufferBuilder.getTiming().getAverageMs()) + "ms");
      if (NvidiumPlus.config.translucency_sorting_level != TranslucencySortingLevel.NONE) {
         info.add("SectionSorter time: " + String.format("%.03f", this.regionSectionSorter.getTiming().getAverageMs()) + "ms");
      }
   }

   public void reloadShaders() {
      this.compiledForFog = NvidiumPlus.config.render_fog;
      this.terrainRasterizer.delete();
      this.regionRasterizer.delete();
      this.sectionRasterizer.delete();
      this.temporalRasterizer.delete();
      this.translucencyTerrainRasterizer.delete();
      this.regionSectionSorter.delete();
      this.cmdBufferBuilder.delete();
      this.terrainRasterizer = new PrimaryTerrainRasterizer();
      this.regionRasterizer = new RegionRasterizer();
      this.sectionRasterizer = new SectionRasterizer();
      this.temporalRasterizer = new TemporalTerrainRasterizer();
      this.translucencyTerrainRasterizer = new TranslucentTerrainRasterizer();
      this.regionSectionSorter = new SortRegionSectionPhase();
      this.cmdBufferBuilder = new CmdBufferBuilder();
   }

   private static final class Statistics {
      public int frustumCount;
      public int regionCount;
      public int sectionCount;
      public int quadCount;
      public int cullCount;
   }
}
