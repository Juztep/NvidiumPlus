package nvidiumplus.terrain.config;

import net.caffeinemc.mods.sodium.api.config.ConfigEntryPoint;
import net.caffeinemc.mods.sodium.api.config.StorageEventHandler;
import net.caffeinemc.mods.sodium.api.config.option.OptionFlag;
import net.caffeinemc.mods.sodium.api.config.option.OptionImpact;
import net.caffeinemc.mods.sodium.api.config.structure.ConfigBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.OptionPageBuilder;
import net.caffeinemc.mods.sodium.client.gui.options.control.ControlValueFormatterImpls;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import nvidiumplus.terrain.NvidiumPlus;
import nvidiumplus.terrain.sodiumCompat.NvidiumPlusOptionFlags;

public class ConfigGuiBuilder implements ConfigEntryPoint {
   private static final NvidiumPlusConfigStore store = new NvidiumPlusConfigStore();
   private final StorageEventHandler saveConfig = store::save;
   private final StorageEventHandler noSave = () -> {};

   public void registerConfigLate(ConfigBuilder builder) {
      OptionPageBuilder nvidiumplusOptionPage = builder.createOptionPage().setName(Component.literal("NvidiumPlus"));
      nvidiumplusOptionPage.addOption(
         builder.createBooleanOption(Identifier.parse("nvidiumplus:disable_nvidiumplus"))
            .setName(Component.literal("Disable nvidiumplus"))
            .setTooltip(Component.literal("Used to disable NvidiumPlus (DOES NOT SAVE, WILL RE-ENABLE AFTER A RE-LAUNCH)"))
            .setDefaultValue(false)
            .setImpact(OptionImpact.HIGH)
            .setBinding(value -> NvidiumPlus.FORCE_DISABLE = value, () -> NvidiumPlus.FORCE_DISABLE)
            .setFlags(new OptionFlag[]{OptionFlag.REQUIRES_RENDERER_RELOAD})
            .setStorageHandler(this.noSave)
      );
      if (NvidiumPlus.IS_COMPATIBLE && !NvidiumPlus.IS_ENABLED && !NvidiumPlus.FORCE_DISABLE) {
         nvidiumplusOptionPage.addOption(
            builder.createBooleanOption(Identifier.parse("nvidiumplus:force_disabled_nvidiumplus"))
               .setName(Component.literal("NvidiumPlus disabled due to shaders being loaded"))
               .setTooltip(Component.literal("NvidiumPlus disabled due to shaders being loaded"))
               .setImpact(OptionImpact.VARIES)
               .setDefaultValue(true)
               .setBinding(v -> {}, () -> false)
               .setStorageHandler(this.noSave)
         );
      }

      nvidiumplusOptionPage.addOption(
         builder.createIntegerOption(Identifier.parse("nvidiumplus:region_keep_distace"))
            .setName(Component.translatable("nvidiumplus.options.region_keep_distance.name"))
            .setTooltip(Component.translatable("nvidiumplus.options.region_keep_distance.tooltip"))
            .setImpact(OptionImpact.VARIES)
            .setEnabledProvider(c -> NvidiumPlus.IS_ENABLED, new Identifier[0])
            .setBinding(v -> store.getData().region_keep_distance = v, () -> store.getData().region_keep_distance)
            .setRange(32, 257, 1)
            .setDefaultValue(32)
            .setValueFormatter(
               x -> Component.literal(
                  x != 32 && x > Minecraft.getInstance().options.getEffectiveRenderDistance() ? (x == 257 ? "Keep All" : x + " chunks") : "Vanilla"
               )
            )
            .setStorageHandler(this.saveConfig)
      );
      nvidiumplusOptionPage.addOption(
         builder.createBooleanOption(Identifier.parse("nvidiumplus:enable_temporal_coherence"))
            .setName(Component.translatable("nvidiumplus.options.enable_temporal_coherence.name"))
            .setTooltip(Component.translatable("nvidiumplus.options.enable_temporal_coherence.tooltip"))
            .setDefaultValue(true)
            .setImpact(OptionImpact.MEDIUM)
            .setEnabledProvider(c -> NvidiumPlus.IS_ENABLED, new Identifier[0])
            .setBinding(v -> store.getData().enable_temporal_coherence = v, () -> store.getData().enable_temporal_coherence)
            .setStorageHandler(this.saveConfig)
      );
      nvidiumplusOptionPage.addOption(
         builder.createBooleanOption(Identifier.parse("nvidiumplus:automatic_memory_limit"))
            .setName(Component.translatable("nvidiumplus.options.automatic_memory_limit.name"))
            .setTooltip(Component.translatable("nvidiumplus.options.automatic_memory_limit.tooltip"))
            .setDefaultValue(true)
            .setImpact(OptionImpact.VARIES)
            .setEnabledProvider(c -> NvidiumPlus.IS_ENABLED, new Identifier[0])
            .setBinding(v -> store.getData().automatic_memory = v, () -> store.getData().automatic_memory)
            .setStorageHandler(this.saveConfig)
      );
      nvidiumplusOptionPage.addOption(
         builder.createIntegerOption(Identifier.parse("nvidiumplus:max_gpu_memory"))
            .setName(Component.translatable("nvidiumplus.options.max_gpu_memory.name"))
            .setTooltip(Component.translatable("nvidiumplus.options.max_gpu_memory.tooltip"))
            .setDefaultValue(2048)
            .setRange(2048, 32768, 512)
            .setValueFormatter(ControlValueFormatterImpls.translateVariable("nvidiumplus.options.mb"))
            .setImpact(OptionImpact.VARIES)
            .setEnabledProvider(
               c -> NvidiumPlus.IS_ENABLED && !c.readBooleanOption(Identifier.parse("nvidiumplus:automatic_memory_limit")),
               new Identifier[]{Identifier.parse("nvidiumplus:automatic_memory_limit")}
            )
            .setBinding(v -> store.getData().max_geometry_memory = v, () -> store.getData().max_geometry_memory)
            .setFlags(NvidiumPlus.SUPPORTS_PERSISTENT_SPARSE_ADDRESSABLE_BUFFER ? new OptionFlag[0] : new OptionFlag[]{OptionFlag.REQUIRES_RENDERER_RELOAD})
            .setStorageHandler(this.saveConfig)
      );
      nvidiumplusOptionPage.addOption(
         builder.createBooleanOption(Identifier.parse("nvidiumplus:render_fog"))
            .setName(Component.translatable("nvidiumplus.options.render_fog.name"))
            .setTooltip(Component.translatable("nvidiumplus.options.render_fog.tooltip"))
            .setDefaultValue(true)
            .setBinding(v -> store.getData().render_fog = v, () -> store.getData().render_fog)
            .setEnabledProvider(c -> NvidiumPlus.IS_ENABLED, new Identifier[0])
            .setImpact(OptionImpact.MEDIUM)
            .setFlags(new OptionFlag[]{OptionFlag.REQUIRES_RENDERER_RELOAD})
            .setStorageHandler(this.saveConfig)
      );
      nvidiumplusOptionPage.addOption(
         builder.createBooleanOption(Identifier.parse("nvidiumplus:use_sodium_vertex_format"))
            .setName(Component.translatable("nvidiumplus.options.use_sodium_vertex_format.name"))
            .setTooltip(Component.translatable("nvidiumplus.options.use_sodium_vertex_format.tooltip"))
            .setDefaultValue(false)
            .setBinding(v -> store.getData().use_sodium_vertex_format = v, () -> store.getData().use_sodium_vertex_format)
            .setEnabledProvider(c -> NvidiumPlus.IS_ENABLED, new Identifier[0])
            .setImpact(OptionImpact.LOW)
            .setFlags(new OptionFlag[]{OptionFlag.REQUIRES_RENDERER_RELOAD})
            .setStorageHandler(this.saveConfig)
      );
      nvidiumplusOptionPage.addOption(
         builder.createBooleanOption(Identifier.parse("nvidiumplus:cull_degenerate_triangles"))
            .setName(Component.translatable("nvidiumplus.options.cull_degenerate_triangles.name"))
            .setTooltip(Component.translatable("nvidiumplus.options.cull_degenerate_triangles.tooltip"))
            .setDefaultValue(true)
            .setBinding(v -> store.getData().cull_degenerate_triangles = v, () -> store.getData().cull_degenerate_triangles)
            .setEnabledProvider(c -> NvidiumPlus.IS_ENABLED, new Identifier[0])
            .setImpact(OptionImpact.MEDIUM)
            .setFlags(new OptionFlag[]{OptionFlag.REQUIRES_RENDERER_RELOAD})
            .setStorageHandler(this.saveConfig)
      );
      nvidiumplusOptionPage.addOption(
         builder.createBooleanOption(Identifier.parse("nvidiumplus:use_nv_fragment_shader_barycentric"))
            .setName(Component.translatable("nvidiumplus.options.use_nv_fragment_shader_barycentric.name"))
            .setTooltip(Component.translatable("nvidiumplus.options.use_nv_fragment_shader_barycentric.tooltip"))
            .setDefaultValue(true)
            .setBinding(v -> store.getData().use_nv_fragment_shader_barycentric = v, () -> store.getData().use_nv_fragment_shader_barycentric)
            .setEnabledProvider(c -> NvidiumPlus.IS_ENABLED, new Identifier[0])
            .setImpact(OptionImpact.MEDIUM)
            .setFlags(new OptionFlag[]{OptionFlag.REQUIRES_RENDERER_RELOAD})
            .setStorageHandler(this.saveConfig)
      );
      nvidiumplusOptionPage.addOption(
         builder.createEnumOption(Identifier.parse("nvidiumplus:translucency_sorting"), TranslucencySortingLevel.class)
            .setName(Component.translatable("nvidiumplus.options.translucency_sorting.name"))
            .setTooltip(Component.translatable("nvidiumplus.options.translucency_sorting.tooltip"))
            .setDefaultValue(TranslucencySortingLevel.SODIUM)
            .setBinding(v -> store.getData().translucency_sorting_level = v, () -> store.getData().translucency_sorting_level)
            .setEnabledProvider(c -> NvidiumPlus.IS_ENABLED, new Identifier[0])
            .setImpact(OptionImpact.MEDIUM)
            .setElementNameProvider(
               e -> new Component[]{
                  Component.translatable("nvidiumplus.options.translucency_sorting.none"),
                  Component.translatable("nvidiumplus.options.translucency_sorting.sections"),
                  Component.translatable("nvidiumplus.options.translucency_sorting.quads"),
                  Component.translatable("nvidiumplus.options.translucency_sorting.sodium")
               }[e.ordinal()]
            )
            .setFlags(new OptionFlag[]{OptionFlag.REQUIRES_RENDERER_RELOAD})
            .setStorageHandler(this.saveConfig)
      );
      nvidiumplusOptionPage.addOption(
         builder.createEnumOption(Identifier.parse("nvidiumplus:statistics_level"), StatisticsLoggingLevel.class)
            .setName(Component.translatable("nvidiumplus.options.statistics_level.name"))
            .setTooltip(Component.translatable("nvidiumplus.options.statistics_level.tooltip"))
            .setDefaultValue(StatisticsLoggingLevel.NONE)
            .setBinding(v -> store.getData().statistics_level = v, () -> store.getData().statistics_level)
            .setEnabledProvider(c -> NvidiumPlus.IS_ENABLED, new Identifier[0])
            .setImpact(OptionImpact.LOW)
            .setElementNameProvider(
               e -> new Component[]{
                  Component.translatable("nvidiumplus.options.statistics_level.none"),
                  Component.translatable("nvidiumplus.options.statistics_level.frustum"),
                  Component.translatable("nvidiumplus.options.statistics_level.regions"),
                  Component.translatable("nvidiumplus.options.statistics_level.sections"),
                  Component.translatable("nvidiumplus.options.statistics_level.quads"),
                  Component.translatable("nvidiumplus.options.statistics_level.cull")
               }[e.ordinal()]
            )
            .setFlags(new OptionFlag[]{NvidiumPlusOptionFlags.REQUIRES_SHADER_RELOAD})
            .setStorageHandler(this.saveConfig)
      );
      builder.registerOwnModOptions()
         .setIcon(Identifier.parse("nvidiumplus:nvidiumplus.png"))
         .setColorTheme(builder.createColorTheme().setBaseThemeRGB(4714581))
         .addPage(nvidiumplusOptionPage);
   }
}
