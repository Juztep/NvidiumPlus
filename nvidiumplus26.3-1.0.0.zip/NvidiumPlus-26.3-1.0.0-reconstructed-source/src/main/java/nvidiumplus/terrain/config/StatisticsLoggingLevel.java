package nvidiumplus.terrain.config;

public enum StatisticsLoggingLevel {
   NONE,
   FRUSTUM,
   REGIONS,
   SECTIONS,
   QUADS,
   CULL;
}
