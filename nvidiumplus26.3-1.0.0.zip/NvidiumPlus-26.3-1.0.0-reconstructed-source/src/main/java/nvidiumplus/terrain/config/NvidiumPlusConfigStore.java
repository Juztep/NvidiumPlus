package nvidiumplus.terrain.config;

import nvidiumplus.terrain.NvidiumPlus;

public class NvidiumPlusConfigStore {
   private final NvidiumPlusConfig config;

   public NvidiumPlusConfigStore() {
      this.config = NvidiumPlus.config;
   }

   public NvidiumPlusConfig getData() {
      return this.config;
   }

   public void save() {
      this.config.save();
   }
}
