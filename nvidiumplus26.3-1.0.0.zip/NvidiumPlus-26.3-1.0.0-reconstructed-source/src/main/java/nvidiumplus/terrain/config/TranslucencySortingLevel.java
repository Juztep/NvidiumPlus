package nvidiumplus.terrain.config;

public enum TranslucencySortingLevel {
   NONE,
   SECTIONS,
   QUADS,
   SODIUM;
}
