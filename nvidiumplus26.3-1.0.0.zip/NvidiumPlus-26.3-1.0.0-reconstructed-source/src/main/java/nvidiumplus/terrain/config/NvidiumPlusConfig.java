package nvidiumplus.terrain.config;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;
import nvidiumplus.terrain.NvidiumPlus;

public class NvidiumPlusConfig {
   public boolean enable_temporal_coherence = true;
   public int max_geometry_memory = 2048;
   public boolean automatic_memory = true;
   public int region_keep_distance = 32;
   public boolean render_fog = true;
   public boolean use_sodium_vertex_format = false;
   public boolean cull_degenerate_triangles = true;
   public boolean use_nv_fragment_shader_barycentric = true;
   public TranslucencySortingLevel translucency_sorting_level = TranslucencySortingLevel.SODIUM;
   public StatisticsLoggingLevel statistics_level = StatisticsLoggingLevel.NONE;
   private static final Gson GSON = new GsonBuilder()
      .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
      .setPrettyPrinting()
      .excludeFieldsWithModifiers(new int[]{2})
      .create();

   private NvidiumPlusConfig() {
   }

   public static NvidiumPlusConfig loadOrCreate() {
      Path path = getConfigPath();
      if (Files.exists(path)) {
         try (FileReader reader = new FileReader(path.toFile())) {
            return (NvidiumPlusConfig)GSON.fromJson(reader, NvidiumPlusConfig.class);
         } catch (IOException e) {
            NvidiumPlus.LOGGER.error("Could not parse config", e);
         }
      }

      return new NvidiumPlusConfig();
   }

   public void save() {
      try {
         Files.writeString(getConfigPath(), GSON.toJson(this));
      } catch (IOException e) {
         NvidiumPlus.LOGGER.error("Failed to write config file", e);
      }
   }

   private static Path getConfigPath() {
      return FabricLoader.getInstance().getConfigDir().resolve("nvidiumplus-config.json");
   }
}
