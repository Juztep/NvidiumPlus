package nvidiumplus;

import java.lang.reflect.Method;
import java.util.Locale;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class NvidiumPlus implements ClientModInitializer {
   private static final Logger LOG = LoggerFactory.getLogger("NvidiumPlus Plus");
   private static Method drawOn;
   private static Method drawSet;
   private static Method deviceName;
   private static Method driverInfo;
   private static Method packActive;
   private static boolean primed;
   private static boolean held;
   private static boolean failed;
   private static Boolean nvidia;

   public void onInitializeClient() {
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)var0 -> tick());
   }

   private static void tick() {
      if (!failed) {
         try {
            if (!primed) {
               prime();
            }

            boolean var0 = Boolean.FALSE.equals(vendor());
            boolean var1 = packActive != null && (Boolean)packActive.invoke(null);
            boolean var2 = var0 || var1;
            if (var2 && !held && (Boolean)drawOn.invoke(null)) {
               drawSet.invoke(null, false);
               held = true;
               LOG.info("Mesh shader terrain off: {}", var0 ? "GPU is not NVIDIA" : "shader pack active");
            } else if (!var2 && held) {
               drawSet.invoke(null, true);
               held = false;
               LOG.info("Mesh shader terrain back on");
            }
         } catch (Throwable var3) {
            failed = true;
            release();
            LOG.warn("GPU and shader pack checks stopped", var3);
         }
      }
   }

   private static void prime() throws ReflectiveOperationException {
      ClassLoader var0 = NvidiumPlus.class.getClassLoader();
      Class var1 = Class.forName("nvidiumplus.engine.vk.SodiumTerrainDrawer", false, var0);
      drawOn = var1.getMethod("enabled");
      drawSet = var1.getMethod("setEnabled", boolean.class);
      Class var2 = Class.forName("nvidiumplus.engine.NvidiumPlusVulkanState", false, var0);
      deviceName = var2.getMethod("deviceName");
      driverInfo = var2.getMethod("driverInfo");
      Class var3 = find("dev.vitrail.render.PackChain", var0);
      packActive = var3 == null ? null : var3.getMethod("drawingPack");
      primed = true;
      hidePrompt(var0);
   }

   private static void hidePrompt(ClassLoader var0) {
      try {
         Class var1 = Class.forName("nvidiumplus.engine.NvidiumPlusConfig", false, var0);
         var1.getField("showVulkanPrompt").setBoolean(var1.getMethod("get").invoke(null), false);
      } catch (ReflectiveOperationException | RuntimeException var2) {
         LOG.warn("Could not hide the Vulkan prompt", var2);
      }
   }

   private static Class<?> find(String var0, ClassLoader var1) {
      try {
         return Class.forName(var0, false, var1);
      } catch (ClassNotFoundException var3) {
         return null;
      }
   }

   private static Boolean vendor() throws ReflectiveOperationException {
      if (nvidia != null) {
         return nvidia;
      }

      Object var0 = deviceName.invoke(null);
      String var1 = var0 == null ? "" : var0.toString();
      return !var1.isBlank() && !var1.startsWith("<") ? (nvidia = (var1 + " " + driverInfo.invoke(null)).toUpperCase(Locale.ROOT).contains("NVIDIA")) : null;
   }

   private static void release() {
      if (held) {
         held = false;

         try {
            drawSet.invoke(null, true);
         } catch (ReflectiveOperationException var1) {
            LOG.warn("Could not hand terrain drawing back", var1);
         }
      }
   }
}
