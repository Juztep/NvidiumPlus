package nvidiumplus;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import net.caffeinemc.mods.sodium.api.config.ConfigEntryPoint;
import net.caffeinemc.mods.sodium.api.config.structure.ConfigBuilder;

public final class NvidiumPlusConfigEntry implements ConfigEntryPoint {
   public void registerConfigLate(ConfigBuilder var1) {
      Object[] var2 = new Object[1];
      Class<ConfigBuilder> var3 = ConfigBuilder.class;
      ConfigBuilder var4 = (ConfigBuilder)Proxy.newProxyInstance(var3.getClassLoader(), new Class[]{var3}, (var2x, var3x, var4x) -> {
         if (var3x.getName().equals("registerOwnModOptions") && var3x.getParameterCount() == 0) {
            if (var2[0] == null) {
               var2[0] = invoke(var3x, var1, var4x);
            }

            return var2[0];
         } else {
            return invoke(var3x, var1, var4x);
         }
      });
      register("nvidiumplus.terrain.config.ConfigGuiBuilder", var4);
      register("nvidiumplus.engine.sodium.NvidiumPlusSodiumConfigEntry", var4);

      try {
         Class var5 = Class.forName("net.caffeinemc.mods.sodium.api.config.structure.ModOptionsBuilder", true, var3.getClassLoader());
         var5.getMethod("setName", String.class).invoke(var2[0], "NvidiumPlus");
      } catch (InvocationTargetException var6) {
         throw new IllegalStateException("Could not finalize NvidiumPlus Sodium settings", var6.getCause());
      } catch (ReflectiveOperationException var7) {
         throw new IllegalStateException("Could not finalize NvidiumPlus Sodium settings", var7);
      }
   }

   private static Object invoke(Method var0, Object var1, Object[] var2) throws Throwable {
      try {
         return var0.invoke(var1, var2);
      } catch (InvocationTargetException var4) {
         throw var4.getCause();
      }
   }

   private static void register(String var0, ConfigBuilder var1) {
      try {
         Class var2 = Class.forName(var0);
         Object var3 = var2.getConstructor().newInstance();
         var2.getMethod("registerConfigLate", ConfigBuilder.class).invoke(var3, var1);
      } catch (InvocationTargetException var4) {
         throw new IllegalStateException("Failed to register settings from " + var0, var4.getCause());
      } catch (ReflectiveOperationException var5) {
         throw new IllegalStateException("Failed to register settings from " + var0, var5);
      }
   }
}
