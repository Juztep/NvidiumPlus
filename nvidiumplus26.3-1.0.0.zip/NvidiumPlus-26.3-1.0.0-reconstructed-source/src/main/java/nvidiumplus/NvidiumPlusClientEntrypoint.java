package nvidiumplus;

import net.fabricmc.api.ClientModInitializer;
import nvidiumplus.engine.fabric.NvidiumPlusClient;

public final class NvidiumPlusClientEntrypoint implements ClientModInitializer {
   public void onInitializeClient() {
      new NvidiumPlusClient().onInitializeClient();
      new NvidiumPlus().onInitializeClient();
   }
}
